/*     */ package com.habboproject.server.boot;
/*     */ 
/*     */ import com.habboproject.server.boot.utils.ConsoleCommands;
/*     */ import com.habboproject.server.boot.utils.ShutdownHook;
/*     */ import java.io.FileInputStream;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.RuntimeMXBean;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Comet
/*     */ {
/*  18 */   private static Logger log = Logger.getLogger(Comet.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static CometServer server;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long start;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  33 */   public static volatile boolean isDebugging = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  38 */   public static volatile boolean isRunning = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  43 */   public static boolean showGui = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  51 */     start = System.currentTimeMillis();
/*     */     try
/*     */     {
/*  54 */       PropertyConfigurator.configure(new FileInputStream("./config/log4j.properties"));
/*     */     } catch (Exception e) {
/*  56 */       log.error("Error while loading log4j configuration", e);
/*  57 */       return;
/*     */     }
/*     */     
/*  60 */     log.info("Comet Server - " + getBuild());
/*     */     
/*  62 */     log.info(logo);
/*     */     
/*  64 */     for (String arg : ManagementFactory.getRuntimeMXBean().getInputArguments()) {
/*  65 */       if (arg.contains("dt_")) {
/*  66 */         isDebugging = true;
/*  67 */         break;
/*     */       }
/*     */     }
/*     */     
/*  71 */     Level logLevel = Level.INFO;
/*     */     
/*  73 */     if (args.length < 1) {
/*  74 */       log.debug("No config args found, falling back to default configuration!");
/*  75 */       server = new CometServer(null);
/*     */     } else {
/*  77 */       Object cometConfiguration = new HashMap();
/*     */       
/*  79 */       for (int i = 0; i < args.length; i++) {
/*  80 */         if (args[i].equals("--debug-logging")) {
/*  81 */           logLevel = Level.DEBUG;
/*     */         }
/*     */         
/*  84 */         if (args[i].equals("--gui"))
/*     */         {
/*  86 */           showGui = true;
/*     */         }
/*     */         
/*  89 */         if (args[i].contains("="))
/*     */         {
/*     */ 
/*  92 */           String[] splitArgs = args[i].split("=");
/*     */           
/*  94 */           ((Map)cometConfiguration).put(splitArgs[0], splitArgs.length != 1 ? splitArgs[1] : "");
/*     */         }
/*     */       }
/*  97 */       server = new CometServer((Map)cometConfiguration);
/*     */     }
/*     */     
/* 100 */     Logger.getRootLogger().setLevel(logLevel);
/* 101 */     server.init();
/*     */     
/* 103 */     ConsoleCommands.init();
/* 104 */     ShutdownHook.init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void exit(String message)
/*     */   {
/* 113 */     log.error("Comet has shutdown. Reason: \"" + message + "\"");
/* 114 */     System.exit(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long getTime()
/*     */   {
/* 123 */     return System.currentTimeMillis() / 1000L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getBuild()
/*     */   {
/* 132 */     return Comet.class.getPackage().getImplementationVersion() == null ? "2.3.9" : Comet.class.getPackage().getImplementationVersion();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CometServer getServer()
/*     */   {
/* 141 */     return server;
/*     */   }
/*     */   
/* 144 */   public static String logo = "\n\n  /$$$$$$                                                  \n /$$__  $$                                                 \n| $$  \\ $$ /$$   /$$  /$$$$$$   /$$$$$$   /$$$$$$  /$$$$$$ \n| $$$$$$$$| $$  | $$ /$$__  $$ /$$__  $$ /$$__  $$|____  $$\n| $$__  $$| $$  | $$| $$  \\__/| $$  \\ $$| $$  \\__/ /$$$$$$$\n| $$  | $$| $$  | $$| $$      | $$  | $$| $$      /$$__  $$\n| $$  | $$|  $$$$$$/| $$      |  $$$$$$/| $$     |  $$$$$$$\n|__/  |__/ \\______/ |__/       \\______/ |__/      \\_______/\n                                                           \n";
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\boot\Comet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */