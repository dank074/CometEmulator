/*     */ package com.habboproject.server.boot;
/*     */ 
/*     */ import com.habboproject.server.boot.utils.gui.CometGui;
/*     */ import com.habboproject.server.config.CometSettings;
/*     */ import com.habboproject.server.config.Configuration;
/*     */ import com.habboproject.server.config.Locale;
/*     */ import com.habboproject.server.game.GameCycle;
/*     */ import com.habboproject.server.game.achievements.AchievementManager;
/*     */ import com.habboproject.server.game.catalog.CatalogManager;
/*     */ import com.habboproject.server.game.commands.CommandManager;
/*     */ import com.habboproject.server.game.effects.EffectManager;
/*     */ import com.habboproject.server.game.groups.GroupManager;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.landing.LandingManager;
/*     */ import com.habboproject.server.game.marketplace.MarketplaceManager;
/*     */ import com.habboproject.server.game.moderation.BanManager;
/*     */ import com.habboproject.server.game.moderation.ModerationManager;
/*     */ import com.habboproject.server.game.navigator.NavigatorManager;
/*     */ import com.habboproject.server.game.permissions.PermissionsManager;
/*     */ import com.habboproject.server.game.pets.PetManager;
/*     */ import com.habboproject.server.game.players.PlayerManager;
/*     */ import com.habboproject.server.game.polls.PollManager;
/*     */ import com.habboproject.server.game.quests.QuestManager;
/*     */ import com.habboproject.server.game.rooms.RoomManager;
/*     */ import com.habboproject.server.game.rooms.bundles.RoomBundleManager;
/*     */ import com.habboproject.server.game.utilities.validator.PlayerFigureValidator;
/*     */ import com.habboproject.server.logging.LogManager;
/*     */ import com.habboproject.server.modules.ModuleManager;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.websocket.WebSocketManager;
/*     */ import com.habboproject.server.storage.StorageManager;
/*     */ import com.habboproject.server.storage.queue.types.ItemStorageQueue;
/*     */ import com.habboproject.server.storage.queue.types.PlayerDataStorageQueue;
/*     */ import com.habboproject.server.threads.ThreadManager;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ public class CometServer
/*     */ {
/*  41 */   private final Logger log = Logger.getLogger(CometServer.class.getName());
/*     */   
/*     */ 
/*     */   public static final String CLIENT_VERSION = "PRODUCTION-201607262204-86871104";
/*     */   
/*     */   private Configuration config;
/*     */   
/*     */ 
/*     */   public CometServer(Map<String, String> overridenConfig)
/*     */   {
/*  51 */     this.config = new Configuration("./config/comet.properties");
/*     */     
/*  53 */     if (overridenConfig != null) {
/*  54 */       this.config.override(overridenConfig);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void init()
/*     */   {
/*  62 */     ModuleManager.getInstance().initialize();
/*     */     
/*  64 */     WebSocketManager.getInstance().initialize();
/*  65 */     PlayerFigureValidator.loadFigureData();
/*     */     
/*  67 */     ThreadManager.getInstance().initialize();
/*  68 */     StorageManager.getInstance().initialize();
/*  69 */     LogManager.getInstance().initialize();
/*     */     
/*     */ 
/*  72 */     CometSettings.initialize();
/*  73 */     Locale.initialize();
/*     */     
/*     */ 
/*  76 */     PermissionsManager.getInstance().initialize();
/*  77 */     RoomBundleManager.getInstance().initialize();
/*  78 */     ItemManager.getInstance().initialize();
/*  79 */     CatalogManager.getInstance().initialize();
/*  80 */     RoomManager.getInstance().initialize();
/*  81 */     NavigatorManager.getInstance().initialize();
/*  82 */     CommandManager.getInstance().initialize();
/*  83 */     BanManager.getInstance().initialize();
/*  84 */     ModerationManager.getInstance().initialize();
/*  85 */     PetManager.getInstance().initialize();
/*  86 */     LandingManager.getInstance().initialize();
/*  87 */     GroupManager.getInstance().initialize();
/*  88 */     PlayerManager.getInstance().initialize();
/*  89 */     QuestManager.getInstance().initialize();
/*  90 */     AchievementManager.getInstance().initialize();
/*  91 */     PollManager.getInstance().initialize();
/*  92 */     MarketplaceManager.getInstance().initialize();
/*  93 */     EffectManager.getInstance().initialize();
/*     */     
/*  95 */     PlayerDataStorageQueue.getInstance().initialize();
/*  96 */     ItemStorageQueue.getInstance().initialize();
/*     */     
/*  98 */     String ipAddress = getConfig().get("comet.network.host");
/*  99 */     String port = getConfig().get("comet.network.port");
/*     */     
/* 101 */     NetworkManager.getInstance().initialize(ipAddress, port);
/* 102 */     GameCycle.getInstance().initialize();
/*     */     
/* 104 */     if (Comet.showGui) {
/* 105 */       CometGui gui = new CometGui();
/* 106 */       gui.setVisible(true);
/*     */     }
/*     */     
/* 109 */     if (Comet.isDebugging) {
/* 110 */       this.log.debug("Comet Server is debugging");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Configuration getConfig()
/*     */   {
/* 120 */     return this.config;
/*     */   }
/*     */   
/*     */   public Logger getLogger() {
/* 124 */     return this.log;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\boot\CometServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */