/*     */ package com.habboproject.server.boot.utils;
/*     */ 
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.config.CometSettings;
/*     */ import com.habboproject.server.config.Locale;
/*     */ import com.habboproject.server.game.catalog.CatalogManager;
/*     */ import com.habboproject.server.game.moderation.BanManager;
/*     */ import com.habboproject.server.game.navigator.NavigatorManager;
/*     */ import com.habboproject.server.game.permissions.PermissionsManager;
/*     */ import com.habboproject.server.modules.ModuleManager;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.storage.SqlHelper;
/*     */ import com.habboproject.server.utilities.CometStats;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ConsoleCommands
/*     */ {
/*  23 */   private static final Logger log = Logger.getLogger("Console Command Handler");
/*     */   
/*     */   public static void init()
/*     */   {
/*  27 */     Thread cmdThr = new Thread() { public void run() { label380:
/*     */         label391:
/*  29 */         label408: label611: label631: label645: label671: label700: label723: label741: label765: label780: label916: while (Comet.isRunning) {
/*  30 */           if (!Comet.isRunning) {
/*     */             break;
/*     */           }
/*     */           try
/*     */           {
/*  35 */             BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
/*  36 */             String input = br.readLine();
/*     */             
/*  38 */             if ((input != null) && (input.startsWith("/"))) { String str1;
/*  39 */               switch ((str1 = input.split(" ")[0]).hashCode()) {case -1788592143:  if (str1.equals("/reload_locale")) break label765; break; case -688535375:  if (str1.equals("/changemotd")) break label645; break; case -75981915:  if (str1.equals("/clear_queries")) break label916; break; case 47:  if (str1.equals("/")) break label380; break; case 48459:  if (str1.equals("/gc")) break label631; break; case 46604272:  if (str1.equals("/help")) break label380; break; case 346450871:  if (str1.equals("/commands")) break label380; break; case 480717133:  if (str1.equals("/reload_permissions")) break label671; break; case 605512034:  if (str1.equals("/reload_catalog")) break label700; break; case 962794583:  if (str1.equals("/queries")) break label780; break; case 1081944355:  if (str1.equals("/reload_messages")) break label611; break; case 1277241552:  if (str1.equals("/reload_modules")) break label391; break; case 1373371744:  if (str1.equals("/reload_navigator")) break label741; break; case 1438181566:  if (str1.equals("/about")) break label408; break; case 1798943131:  if (str1.equals("/reload_bans"))
/*     */                   break label723; }
/*  41 */               ConsoleCommands.log.error("Invalid command");
/*  42 */               continue;
/*     */               
/*     */ 
/*     */ 
/*  46 */               ConsoleCommands.log.info("Commands available: /about, /reload_messages, /gc, /reload_permissions, /changemotd, /reload_catalog, /reload_bans, /reload_locale, /reload_permissions, /queries, /queries");
/*  47 */               continue;
/*     */               
/*     */ 
/*  50 */               ModuleManager.getInstance().initialize();
/*  51 */               ConsoleCommands.log.info("Modules reloaded successfully.");
/*  52 */               continue;
/*     */               
/*     */ 
/*  55 */               CometStats stats = CometStats.get();
/*     */               
/*  57 */               ConsoleCommands.log.info("This server is powered by Comet (" + Comet.getBuild() + ")");
/*  58 */               ConsoleCommands.log.info("    Players online: " + stats.getPlayers());
/*  59 */               ConsoleCommands.log.info("    Active rooms: " + stats.getRooms());
/*  60 */               ConsoleCommands.log.info("    Uptime: " + stats.getUptime());
/*  61 */               ConsoleCommands.log.info("    Process ID: " + stats.getProcessId());
/*  62 */               ConsoleCommands.log.info("    Memory allocated: " + stats.getAllocatedMemory() + "MB");
/*  63 */               ConsoleCommands.log.info("    Memory usage: " + stats.getUsedMemory() + "MB");
/*  64 */               continue;
/*     */               
/*     */ 
/*  67 */               NetworkManager.getInstance().getMessages().load();
/*  68 */               ConsoleCommands.log.info("Message handlers were reloaded");
/*  69 */               continue;
/*     */               
/*     */ 
/*  72 */               System.gc();
/*  73 */               ConsoleCommands.log.info("GC was execute");
/*  74 */               continue;
/*     */               
/*     */ 
/*  77 */               String motd = input.replace("/changemotd ", "");
/*  78 */               CometSettings.setMotd(motd);
/*  79 */               ConsoleCommands.log.info("Message of the day was set.");
/*  80 */               continue;
/*     */               
/*     */ 
/*  83 */               PermissionsManager.getInstance().loadCommands();
/*  84 */               PermissionsManager.getInstance().loadPerks();
/*  85 */               PermissionsManager.getInstance().loadRankPermissions();
/*  86 */               ConsoleCommands.log.info("Permissions cache was reloaded.");
/*  87 */               continue;
/*     */               
/*     */ 
/*  90 */               CatalogManager.getInstance().loadItemsAndPages();
/*  91 */               CatalogManager.getInstance().loadGiftBoxes();
/*  92 */               ConsoleCommands.log.info("Catalog cache was reloaded.");
/*  93 */               continue;
/*     */               
/*     */ 
/*  96 */               BanManager.getInstance().loadBans();
/*  97 */               ConsoleCommands.log.info("Bans were reloaded.");
/*  98 */               continue;
/*     */               
/*     */ 
/* 101 */               NavigatorManager.getInstance().loadPublicRooms();
/* 102 */               NavigatorManager.getInstance().loadCategories();
/* 103 */               ConsoleCommands.log.info("Navigator was reloaded.");
/* 104 */               continue;
/*     */               
/*     */ 
/* 107 */               Locale.initialize();
/* 108 */               ConsoleCommands.log.info("Locale configuration was reloaded.");
/* 109 */               continue;
/*     */               
/*     */ 
/*     */ 
/* 113 */               ConsoleCommands.log.info("Queries");
/* 114 */               ConsoleCommands.log.info("================================================");
/*     */               
/* 116 */               for (Map.Entry<String, AtomicInteger> query : SqlHelper.getQueryCounters().entrySet()) {
/* 117 */                 ConsoleCommands.log.info("Query:" + (String)query.getKey());
/* 118 */                 ConsoleCommands.log.info("Count: " + ((AtomicInteger)query.getValue()).get());
/* 119 */                 ConsoleCommands.log.info("");
/*     */               }
/*     */               
/* 122 */               continue;
/*     */               
/*     */ 
/* 125 */               SqlHelper.getQueryCounters().clear();
/* 126 */               ConsoleCommands.log.info("Query counters have been cleared.");
/*     */             }
/*     */             else
/*     */             {
/* 130 */               ConsoleCommands.log.error("Invalid command");
/*     */             }
/*     */           } catch (Exception e) {
/* 133 */             ConsoleCommands.log.error("Error while parsing console command");
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 138 */     };
/* 139 */     cmdThr.start();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\boot\utils\ConsoleCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */