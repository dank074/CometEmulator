/*    */ package com.habboproject.server.boot.utils;
/*    */ 
/*    */ import com.habboproject.server.boot.Comet;
/*    */ import com.habboproject.server.logging.LogManager;
/*    */ import com.habboproject.server.logging.database.queries.LogQueries;
/*    */ import com.habboproject.server.storage.StorageManager;
/*    */ import com.habboproject.server.storage.queue.types.ItemStorageQueue;
/*    */ import com.habboproject.server.storage.queue.types.PlayerDataStorageQueue;
/*    */ import com.zaxxer.hikari.HikariDataSource;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ShutdownHook
/*    */ {
/* 14 */   private static final Logger log = Logger.getLogger(ShutdownHook.class.getName());
/*    */   
/*    */   public static void init() {
/* 17 */     Runtime.getRuntime().addShutdownHook(new Thread()
/*    */     {
/*    */       public void run() {
/* 20 */         ShutdownHook.log.info("Comet is now shutting down");
/*    */         
/* 22 */         Comet.isRunning = false;
/*    */         
/* 24 */         PlayerDataStorageQueue.getInstance().shutdown();
/* 25 */         ItemStorageQueue.getInstance().shutdown();
/*    */         
/* 27 */         ShutdownHook.log.info("Resetting statistics");
/* 28 */         com.habboproject.server.storage.queries.system.StatisticsDao.saveStatistics(0, 0, Comet.getBuild());
/*    */         
/* 30 */         if (LogManager.ENABLED) {
/* 31 */           ShutdownHook.log.info("Updating room entry data");
/* 32 */           LogQueries.updateRoomEntries();
/*    */         }
/*    */         
/* 35 */         ShutdownHook.log.info("Closing all database connections");
/* 36 */         StorageManager.getInstance().getConnections().shutdown();
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\boot\utils\ShutdownHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */