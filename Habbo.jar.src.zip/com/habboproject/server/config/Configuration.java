/*    */ package com.habboproject.server.config;
/*    */ 
/*    */ import com.habboproject.server.boot.Comet;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Properties;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ public class Configuration
/*    */   extends Properties
/*    */ {
/* 16 */   private static Logger log = Logger.getLogger(Configuration.class.getName());
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Configuration(String file)
/*    */   {
/*    */     try
/*    */     {
/* 28 */       Reader stream = new InputStreamReader(new FileInputStream(file), "UTF-8");
/*    */       
/* 30 */       load(stream);
/* 31 */       stream.close();
/*    */     } catch (Exception e) {
/* 33 */       Comet.exit("Failed to fetch the server configuration (" + file + ")");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void override(Map<String, String> config)
/*    */   {
/* 43 */     for (Map.Entry<String, String> configOverride : config.entrySet()) {
/* 44 */       if (containsKey(configOverride.getKey())) {
/* 45 */         remove(configOverride.getKey());
/* 46 */         put(configOverride.getKey(), configOverride.getValue());
/*    */       } else {
/* 48 */         put(configOverride.getKey(), configOverride.getValue());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String get(String key)
/*    */   {
/* 61 */     return getProperty(key);
/*    */   }
/*    */   
/*    */   public String get(String key, String fallback) {
/* 65 */     if (containsKey(fallback)) {
/* 66 */       return get(key);
/*    */     }
/*    */     
/* 69 */     return fallback;
/*    */   }
/*    */   
/*    */   public int getInt(String key) {
/* 73 */     return Integer.parseInt(get(key));
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\config\Configuration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */