/*    */ package com.habboproject.server.config;
/*    */ 
/*    */ import com.habboproject.server.storage.queries.config.LocaleDao;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Locale
/*    */ {
/* 13 */   private static Logger log = Logger.getLogger(Locale.class.getName());
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private static Map<String, String> locale;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void initialize() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void reload()
/*    */   {
/* 31 */     if (locale != null) {
/* 32 */       locale.clear();
/*    */     }
/* 34 */     locale = LocaleDao.getAll();
/* 35 */     log.info("Loaded " + locale.size() + " locale strings");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String get(String key)
/*    */   {
/* 45 */     if (locale.containsKey(key)) {
/* 46 */       return (String)locale.get(key);
/*    */     }
/* 48 */     return key;
/*    */   }
/*    */   
/*    */   public static String getOrDefault(String key, String defaultValue) {
/* 52 */     if (!locale.containsKey(key)) {
/* 53 */       return defaultValue;
/*    */     }
/*    */     
/* 56 */     return (String)locale.get(key);
/*    */   }
/*    */   
/*    */   public static Map<String, String> getAll() {
/* 60 */     return locale;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\config\Locale.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */