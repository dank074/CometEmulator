/*     */ package com.habboproject.server.config;
/*     */ 
/*     */ import com.google.common.collect.Maps;
/*     */ import com.habboproject.server.game.rooms.filter.FilterMode;
/*     */ import com.habboproject.server.storage.queries.config.ConfigDao;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ public class CometSettings
/*     */ {
/*  12 */   public static boolean motdEnabled = false;
/*     */   
/*  14 */   public static String motdMessage = "";
/*  15 */   public static String hotelName = "";
/*  16 */   public static String hotelUrl = "";
/*  17 */   public static String aboutImg = "";
/*     */   
/*  19 */   public static boolean onlineRewardEnabled = false;
/*  20 */   public static int onlineRewardCredits = 0;
/*  21 */   public static int onlineRewardDuckets = 0;
/*  22 */   public static int onlineRewardInterval = 15;
/*     */   
/*  24 */   public static int groupCost = 0;
/*     */   
/*  26 */   public static boolean aboutShowPlayersOnline = true;
/*  27 */   public static boolean aboutShowUptime = true;
/*  28 */   public static boolean aboutShowRoomsActive = true;
/*     */   
/*  30 */   public static int floorEditorMaxX = 0;
/*  31 */   public static int floorEditorMaxY = 0;
/*  32 */   public static int floorEditorMaxTotal = 0;
/*     */   
/*  34 */   public static int roomMaxPlayers = 150;
/*  35 */   public static boolean roomEncryptPasswords = false;
/*  36 */   public static int roomPasswordEncryptionRounds = 10;
/*  37 */   public static boolean roomCanPlaceItemOnEntity = false;
/*  38 */   public static int roomMaxBots = 15;
/*  39 */   public static int roomMaxPets = 15;
/*  40 */   public static int roomIdleMinutes = 20;
/*     */   
/*  42 */   public static FilterMode wordFilterMode = FilterMode.DEFAULT;
/*     */   
/*  44 */   public static boolean useDatabaseIp = false;
/*  45 */   public static boolean saveLogins = false;
/*  46 */   public static boolean playerInfiniteBalance = false;
/*  47 */   public static int playerGiftCooldown = 30;
/*  48 */   public static final Map<String, String> strictFilterCharacters = Maps.newHashMap();
/*     */   
/*  50 */   public static boolean playerFigureValidation = false;
/*  51 */   public static int playerChangeFigureCooldown = 5;
/*  52 */   public static int messengerMaxFriends = 1100;
/*  53 */   public static boolean messengerLogMessages = false;
/*     */   
/*  55 */   public static int roomWiredRewardMinimumRank = 4;
/*     */   
/*  57 */   public static boolean asyncCatalogPurchase = true;
/*  58 */   public static boolean storagePlayerQueueEnabled = false;
/*  59 */   public static boolean storageItemQueueEnabled = false;
/*  60 */   public static boolean adaptiveEntityProcessDelay = false;
/*     */   
/*  62 */   public static String defaultEventPointsColumn = "";
/*  63 */   public static int defaultEventPointsQuantity = 0;
/*  64 */   public static boolean enableEventWinnerReward = false;
/*  65 */   public static String eventWinnerRewardType = "credits";
/*  66 */   public static int eventWinnerRewardQuantity = 0;
/*     */   
/*  68 */   public static boolean enableAchievementProgressReward = false;
/*     */   
/*  70 */   public static int cameraPhotoFurnitureId = 0;
/*  71 */   public static String cameraPhotoUrl = "";
/*     */   
/*  73 */   public static boolean enableEventWinnerNotification = false;
/*     */   
/*  75 */   public static String defaultPromoPointsColumn = "";
/*  76 */   public static int defaultPromoPointsQuantity = 0;
/*  77 */   public static boolean enablePromoWinnerReward = false;
/*  78 */   public static String promoWinnerRewardType = "credits";
/*  79 */   public static int promoWinnerRewardQuantity = 0;
/*     */   
/*  81 */   public static String defaultMarketplaceCoin = "credits";
/*  82 */   public static String defaultMarketplaceType = "all";
/*     */   
/*  84 */   public static boolean onlineRewardDiamondsEnabled = false;
/*  85 */   public static int onlineRewardDiamondsInterval = 60;
/*  86 */   public static int onlineRewardDiamondsQuantity = 0;
/*     */   
/*  88 */   private static final Logger log = Logger.getLogger(CometSettings.class.getName());
/*     */   
/*     */   public static void initialize() {
/*  91 */     ConfigDao.getAll();
/*     */     
/*  93 */     log.info("Initialized configuration");
/*     */   }
/*     */   
/*     */   public static void reloadAll() {
/*  97 */     ConfigDao.getAll();
/*     */     
/*  99 */     log.info("Reloaded configuration");
/*     */   }
/*     */   
/*     */   public static void setMotd(String motd) {
/* 103 */     motdEnabled = true;
/* 104 */     motdMessage = motd;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\config\CometSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */