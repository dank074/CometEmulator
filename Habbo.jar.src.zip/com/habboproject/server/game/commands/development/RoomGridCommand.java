/*    */ package com.habboproject.server.game.commands.development;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class RoomGridCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 10 */     client.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer("Item Grid", client.getPlayer().getEntity().getRoom().getMapping().visualiseEntityGrid()));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 15 */     return "dev";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 20 */     return "";
/*    */   }
/*    */   
/*    */   public boolean isHidden()
/*    */   {
/* 25 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\development\RoomGridCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */