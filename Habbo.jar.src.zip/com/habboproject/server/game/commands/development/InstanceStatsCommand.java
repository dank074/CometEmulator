/*    */ package com.habboproject.server.game.commands.development;
/*    */ 
/*    */ import com.habboproject.server.game.groups.GroupManager;
/*    */ import com.habboproject.server.game.players.PlayerManager;
/*    */ import com.habboproject.server.game.rooms.RoomManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import java.util.Map;
/*    */ import org.apache.solr.util.ConcurrentLRUCache;
/*    */ 
/*    */ public class InstanceStatsCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 14 */     StringBuilder message = new StringBuilder("<b>Comet Server - Instance Statistics </b><br><br>");
/*    */     
/* 16 */     message.append("Build: " + com.habboproject.server.boot.Comet.getBuild() + "<br><br>");
/* 17 */     message.append("<b>Game Statistics</b><br>Players online: " + PlayerManager.getInstance().size() + "<br>Active rooms: " + RoomManager.getInstance().getRoomInstances().size() + "<br><br>");
/* 18 */     message.append("<b>Room Data</b><br>Cached data instances: " + RoomManager.getInstance().getRoomDataInstances().size() + "<br>" + "<br>" + "<b>Group Data</b><br>" + "Cached data instances: " + GroupManager.getInstance().getGroupDatas().size() + "<br>" + "Cached instances: " + GroupManager.getInstance().getGroupInstances().size());
/*    */     
/* 20 */     client.send(new com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer(message.toString()));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getPermission()
/*    */   {
/* 33 */     return "dev";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 38 */     return "";
/*    */   }
/*    */   
/*    */   public boolean isHidden()
/*    */   {
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\development\InstanceStatsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */