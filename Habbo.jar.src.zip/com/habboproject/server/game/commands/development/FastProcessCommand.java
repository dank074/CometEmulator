/*    */ package com.habboproject.server.game.commands.development;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class FastProcessCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 10 */     int processTime = 490;
/*    */     
/* 12 */     if ((params.length == 1) && (org.apache.commons.lang.StringUtils.isNumeric(params[0]))) {
/* 13 */       processTime = Integer.parseInt(params[0]);
/*    */     }
/*    */     
/* 16 */     client.getPlayer().getEntity().getRoom().getProcess().setDelay(processTime);
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 21 */     return "dev";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 26 */     return "";
/*    */   }
/*    */   
/*    */   public boolean isHidden()
/*    */   {
/* 31 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\development\FastProcessCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */