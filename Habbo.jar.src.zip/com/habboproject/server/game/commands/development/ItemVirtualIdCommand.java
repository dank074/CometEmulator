/*    */ package com.habboproject.server.game.commands.development;
/*    */ 
/*    */ import com.habboproject.server.game.items.ItemManager;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class ItemVirtualIdCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     if (params.length == 0) {
/* 12 */       client.send(new AlertMessageComposer("There are currently " + ItemManager.getInstance().getItemIdToVirtualIds().size() + " item virtual IDs in memory."));
/* 13 */       return;
/*    */     }
/*    */     try
/*    */     {
/* 17 */       int virtualId = Integer.parseInt(params[0]);
/*    */       
/* 19 */       client.send(new AlertMessageComposer("Virtual ID: " + virtualId + "\nReal ID: " + ItemManager.getInstance().getItemIdByVirtualId(virtualId)));
/*    */     }
/*    */     catch (Exception localException) {}
/*    */   }
/*    */   
/*    */ 
/*    */   public String getPermission()
/*    */   {
/* 27 */     return "dev";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 32 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isHidden()
/*    */   {
/* 37 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\development\ItemVirtualIdCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */