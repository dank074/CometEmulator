/*    */ package com.habboproject.server.game.commands.development;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ProcessComponent;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class ProcessTimesCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     StringBuilder processTimesBuilder = new StringBuilder();
/*    */     
/* 15 */     Room room = client.getPlayer().getEntity().getRoom();
/*    */     
/* 17 */     if (room.getProcess().getProcessTimes() == null) {
/* 18 */       room.getProcess().setProcessTimes(new java.util.ArrayList());
/*    */       
/* 20 */       client.send(new AlertMessageComposer("Process times for this room are now being recorded. (Max: 30)"));
/* 21 */       return;
/*    */     }
/*    */     
/* 24 */     for (Long processTime : room.getProcess().getProcessTimes()) {
/* 25 */       processTimesBuilder.append(processTime + "\n");
/*    */     }
/*    */     
/* 28 */     client.send(new AlertMessageComposer("<b>Process Times</b><br><br>" + processTimesBuilder.toString()));
/*    */     
/* 30 */     room.getProcess().getProcessTimes().clear();
/* 31 */     room.getProcess().setProcessTimes(null);
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 36 */     return "dev";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 41 */     return "";
/*    */   }
/*    */   
/*    */   public boolean isHidden()
/*    */   {
/* 46 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\development\ProcessTimesCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */