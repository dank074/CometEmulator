/*    */ package com.habboproject.server.game.commands.development;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class ReloadMappingCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 10 */     client.getPlayer().getEntity().getRoom().getMapping().init();
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 15 */     return "debug";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 20 */     return "Reloads the room map";
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\development\ReloadMappingCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */