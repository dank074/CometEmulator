/*    */ package com.habboproject.server.game.commands.development;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class PositionCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     sendNotif(
/*    */     
/*    */ 
/* 14 */       "X: " + client.getPlayer().getEntity().getPosition().getX() + "\r\n" + "Y: " + client.getPlayer().getEntity().getPosition().getY() + "\r\n" + "Z: " + client.getPlayer().getEntity().getPosition().getZ() + "\r\n" + "Rotation: " + client.getPlayer().getEntity().getBodyRotation() + "\r\n", 
/* 15 */       client);
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 20 */     return "position_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 25 */     return com.habboproject.server.config.Locale.get("command.position.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\development\PositionCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */