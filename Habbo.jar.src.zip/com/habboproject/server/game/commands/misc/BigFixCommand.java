/*    */ package com.habboproject.server.game.commands.misc;
/*    */ 
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.MotdNotificationMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ 
/*    */ public class BigFixCommand
/*    */   extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     client.send(new MotdNotificationMessageComposer("OH NÃƒO!\n\nTemos sÃ©rios problemas no nosso hotel?! NÃ£o entre em pÃ¢nico, estamos fazendo o possÃ­vel para arrumar todos eles!\nIremos tomar atitudes severas contra os responsÃ¡veis!\nMalditos estagiÃ¡rios!\nSempre eles!\n\n - Frank"));
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isHidden()
/*    */   {
/* 19 */     return true;
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 24 */     return "dev";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 29 */     return "";
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\misc\BigFixCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */