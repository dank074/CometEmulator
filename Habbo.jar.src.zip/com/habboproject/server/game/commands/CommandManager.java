/*     */ package com.habboproject.server.game.commands;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.api.events.EventHandler;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.config.Locale;
/*     */ import com.habboproject.server.game.commands.development.InstanceStatsCommand;
/*     */ import com.habboproject.server.game.commands.gimmicks.SlapCommand;
/*     */ import com.habboproject.server.game.commands.misc.BigFixCommand;
/*     */ import com.habboproject.server.game.commands.notifications.NotificationManager;
/*     */ import com.habboproject.server.game.commands.staff.DisconnectCommand;
/*     */ import com.habboproject.server.game.commands.staff.PlayerInfoCommand;
/*     */ import com.habboproject.server.game.commands.staff.alerts.EventAlertCommand;
/*     */ import com.habboproject.server.game.commands.staff.alerts.HotelAlertCommand;
/*     */ import com.habboproject.server.game.commands.staff.banning.BanCommand;
/*     */ import com.habboproject.server.game.commands.staff.banning.IpBanCommand;
/*     */ import com.habboproject.server.game.commands.staff.cache.ReloadGroupCommand;
/*     */ import com.habboproject.server.game.commands.staff.cache.UpdateCacheCommand;
/*     */ import com.habboproject.server.game.commands.staff.fun.RollCommand;
/*     */ import com.habboproject.server.game.commands.staff.muting.MuteCommand;
/*     */ import com.habboproject.server.game.commands.staff.rewards.DucketsCommand;
/*     */ import com.habboproject.server.game.commands.staff.rewards.PointsCommand;
/*     */ import com.habboproject.server.game.commands.staff.rewards.RoomBadgeCommand;
/*     */ import com.habboproject.server.game.commands.staff.rewards.mass.MassDucketsCommand;
/*     */ import com.habboproject.server.game.commands.staff.rewards.mass.MassPointsCommand;
/*     */ import com.habboproject.server.game.commands.user.LayCommand;
/*     */ import com.habboproject.server.game.commands.user.fun.EnableEventAlertCommand;
/*     */ import com.habboproject.server.game.commands.user.room.SetMaxCommand;
/*     */ import com.habboproject.server.game.commands.user.settings.EnableCommand;
/*     */ import com.habboproject.server.game.commands.vip.EffectCommand;
/*     */ import com.habboproject.server.game.commands.vip.MimicCommand;
/*     */ import com.habboproject.server.game.commands.vip.MoonwalkCommand;
/*     */ import com.habboproject.server.game.commands.vip.PullCommand;
/*     */ import com.habboproject.server.game.commands.vip.TransformCommand;
/*     */ import com.habboproject.server.game.permissions.PermissionsManager;
/*     */ import com.habboproject.server.game.permissions.types.CommandPermission;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.RoomData;
/*     */ import com.habboproject.server.logging.LogManager;
/*     */ import com.habboproject.server.logging.LogStore;
/*     */ import com.habboproject.server.logging.containers.LogEntryContainer;
/*     */ import com.habboproject.server.modules.ModuleManager;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class CommandManager implements com.habboproject.server.utilities.Initializable
/*     */ {
/*     */   private static CommandManager commandManagerInstance;
/*  56 */   private static Logger log = Logger.getLogger(CommandManager.class.getName());
/*     */   
/*     */   private NotificationManager notifications;
/*     */   private Map<String, ChatCommand> commands;
/*  60 */   private ExecutorService executorService = Executors.newFixedThreadPool(2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  71 */     this.commands = new java.util.HashMap();
/*     */     
/*  73 */     reloadAllCommands();
/*  74 */     log.info("Loaded " + this.commands.size() + " chat commands");
/*     */     
/*  76 */     this.notifications = new NotificationManager();
/*  77 */     log.info("CommandManager initialized");
/*     */   }
/*     */   
/*     */   public static CommandManager getInstance() {
/*  81 */     if (commandManagerInstance == null) {
/*  82 */       commandManagerInstance = new CommandManager();
/*     */     }
/*     */     
/*  85 */     return commandManagerInstance;
/*     */   }
/*     */   
/*     */   public void reloadAllCommands() {
/*  89 */     this.commands.clear();
/*     */     
/*  91 */     loadMiscCommands();
/*  92 */     loadUserCommands();
/*  93 */     loadStaffCommands();
/*     */     
/*  95 */     if (Comet.isDebugging) {
/*  96 */       addCommand("reloadmapping", new com.habboproject.server.game.commands.development.ReloadMappingCommand());
/*     */     }
/*     */     
/*  99 */     addCommand("instancestats", new InstanceStatsCommand());
/* 100 */     addCommand("roomgrid", new com.habboproject.server.game.commands.development.RoomGridCommand());
/* 101 */     addCommand("processtimes", new com.habboproject.server.game.commands.development.ProcessTimesCommand());
/*     */     
/* 103 */     addCommand("itemid", new com.habboproject.server.game.commands.development.ItemVirtualIdCommand());
/*     */   }
/*     */   
/*     */   public void loadMiscCommands()
/*     */   {
/* 108 */     addCommand("arrumarhebbo123", new BigFixCommand());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void loadUserCommands()
/*     */   {
/* 115 */     addCommand(Locale.get("command.commands.name"), new com.habboproject.server.game.commands.user.CommandsCommand());
/* 116 */     addCommand(Locale.get("command.about.name"), new com.habboproject.server.game.commands.user.AboutCommand());
/* 117 */     addCommand(Locale.get("command.pickall.name"), new com.habboproject.server.game.commands.user.room.PickAllCommand());
/* 118 */     addCommand(Locale.get("command.empty.name"), new com.habboproject.server.game.commands.user.EmptyCommand());
/* 119 */     addCommand(Locale.get("command.sit.name"), new com.habboproject.server.game.commands.user.SitCommand());
/* 120 */     addCommand(Locale.get("command.lay.name"), new LayCommand());
/* 121 */     addCommand(Locale.get("command.home.name"), new com.habboproject.server.game.commands.user.HomeCommand());
/* 122 */     addCommand(Locale.get("command.setmax.name"), new SetMaxCommand());
/* 123 */     addCommand(Locale.get("command.position.name"), new com.habboproject.server.game.commands.development.PositionCommand());
/* 124 */     addCommand(Locale.get("command.deletegroup.name"), new com.habboproject.server.game.commands.user.group.DeleteGroupCommand());
/* 125 */     addCommand(Locale.get("command.togglefriends.name"), new com.habboproject.server.game.commands.user.settings.ToggleFriendsCommand());
/* 126 */     addCommand(Locale.get("command.enablecommand.name"), new EnableCommand());
/* 127 */     addCommand(Locale.get("command.disablecommand.name"), new com.habboproject.server.game.commands.user.settings.DisableCommand());
/* 128 */     addCommand("screenshot", new com.habboproject.server.game.commands.user.ScreenshotCommand());
/*     */     
/*     */ 
/* 131 */     addCommand(Locale.get("command.push.name"), new com.habboproject.server.game.commands.vip.PushCommand());
/* 132 */     addCommand(Locale.get("command.pull.name"), new PullCommand());
/* 133 */     addCommand(Locale.get("command.moonwalk.name"), new MoonwalkCommand());
/* 134 */     addCommand(Locale.get("command.enable.name"), new EffectCommand());
/* 135 */     addCommand(Locale.get("command.setspeed.name"), new com.habboproject.server.game.commands.user.room.SetSpeedCommand());
/* 136 */     addCommand(Locale.get("command.mimic.name"), new MimicCommand());
/* 137 */     addCommand(Locale.get("command.transform.name"), new TransformCommand());
/* 138 */     addCommand(Locale.get("command.noface.name"), new com.habboproject.server.game.commands.vip.NoFaceCommand());
/* 139 */     addCommand(Locale.get("command.follow.name"), new com.habboproject.server.game.commands.vip.FollowCommand());
/* 140 */     addCommand(Locale.get("command.superpull.name"), new com.habboproject.server.game.commands.vip.SuperPullCommand());
/* 141 */     addCommand(Locale.get("command.redeemcredits.name"), new com.habboproject.server.game.commands.vip.RedeemCreditsCommand());
/* 142 */     addCommand(Locale.get("command.handitem.name"), new com.habboproject.server.game.commands.vip.HandItemCommand());
/* 143 */     addCommand(Locale.get("command.togglediagonal.name"), new com.habboproject.server.game.commands.vip.ToggleDiagonalCommand());
/*     */     
/*     */ 
/* 146 */     addCommand(Locale.get("command.slap.name"), new SlapCommand());
/* 147 */     addCommand(Locale.get("command.kiss.name"), new com.habboproject.server.game.commands.gimmicks.KissCommand());
/* 148 */     addCommand(Locale.get("command.sex.name"), new com.habboproject.server.game.commands.gimmicks.SexCommand());
/* 149 */     addCommand(Locale.get("command.punch.name"), new com.habboproject.server.game.commands.gimmicks.PunchCommand());
/*     */     
/*     */ 
/* 152 */     addCommand(Locale.get("command.reloadroom.name"), new com.habboproject.server.game.commands.user.room.ReloadCommand());
/* 153 */     addCommand(Locale.get("command.unloadroom.name"), new com.habboproject.server.game.commands.user.room.UnloadCommand());
/*     */     
/*     */ 
/* 156 */     addCommand(Locale.get("command.enableeventnotif.name"), new EnableEventAlertCommand());
/* 157 */     addCommand(Locale.get("command.disableeventnotif.name"), new com.habboproject.server.game.commands.user.fun.DisableEventAlertCommand());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void loadStaffCommands()
/*     */   {
/* 164 */     addCommand(Locale.get("command.eventpoints.name"), new com.habboproject.server.game.commands.staff.rewards.EventPointsCommand());
/* 165 */     addCommand(Locale.get("command.teleport.name"), new com.habboproject.server.game.commands.staff.TeleportCommand());
/* 166 */     addCommand(Locale.get("command.massmotd.name"), new com.habboproject.server.game.commands.staff.alerts.MassMotdCommand());
/* 167 */     addCommand(Locale.get("command.hotelalert.name"), new HotelAlertCommand());
/* 168 */     addCommand(Locale.get("command.invisible.name"), new com.habboproject.server.game.commands.staff.InvisibleCommand());
/* 169 */     addCommand(Locale.get("command.ban.name"), new BanCommand());
/* 170 */     addCommand(Locale.get("command.kick.name"), new com.habboproject.server.game.commands.staff.KickCommand());
/* 171 */     addCommand(Locale.get("command.disconnect.name"), new DisconnectCommand());
/* 172 */     addCommand(Locale.get("command.ipban.name"), new IpBanCommand());
/* 173 */     addCommand(Locale.get("command.alert.name"), new com.habboproject.server.game.commands.staff.alerts.AlertCommand());
/* 174 */     addCommand(Locale.get("command.roomalert.name"), new com.habboproject.server.game.commands.staff.alerts.RoomAlertCommand());
/* 175 */     addCommand(Locale.get("command.givebadge.name"), new com.habboproject.server.game.commands.staff.rewards.GiveBadgeCommand());
/* 176 */     addCommand(Locale.get("command.removebadge.name"), new com.habboproject.server.game.commands.staff.RemoveBadgeCommand());
/* 177 */     addCommand(Locale.get("command.roomkick.name"), new com.habboproject.server.game.commands.staff.RoomKickCommand());
/* 178 */     addCommand(Locale.get("command.coins.name"), new com.habboproject.server.game.commands.staff.rewards.CoinsCommand());
/* 179 */     addCommand(Locale.get("command.points.name"), new PointsCommand());
/* 180 */     addCommand(Locale.get("command.duckets.name"), new DucketsCommand());
/* 181 */     addCommand(Locale.get("command.roommute.name"), new com.habboproject.server.game.commands.staff.muting.RoomMuteCommand());
/* 182 */     addCommand(Locale.get("command.reload.name"), new UpdateCacheCommand());
/* 183 */     addCommand(Locale.get("command.maintenance.name"), new com.habboproject.server.game.commands.staff.alerts.MaintenanceCommand());
/* 184 */     addCommand(Locale.get("command.roomaction.name"), new com.habboproject.server.game.commands.staff.RoomActionCommand());
/* 185 */     addCommand(Locale.get("command.eventalert.name"), new EventAlertCommand());
/* 186 */     addCommand(Locale.get("command.machineban.name"), new com.habboproject.server.game.commands.staff.banning.MachineBanCommand());
/* 187 */     addCommand(Locale.get("command.makesay.name"), new com.habboproject.server.game.commands.staff.MakeSayCommand());
/* 188 */     addCommand(Locale.get("command.mute.name"), new MuteCommand());
/* 189 */     addCommand(Locale.get("command.unmute.name"), new com.habboproject.server.game.commands.staff.muting.UnmuteCommand());
/* 190 */     addCommand(Locale.get("command.masscoins.name"), new com.habboproject.server.game.commands.staff.rewards.mass.MassCoinsCommand());
/* 191 */     addCommand(Locale.get("command.massbadge.name"), new com.habboproject.server.game.commands.staff.rewards.mass.MassBadgeCommand());
/* 192 */     addCommand(Locale.get("command.massduckets.name"), new MassDucketsCommand());
/* 193 */     addCommand(Locale.get("command.masspoints.name"), new MassPointsCommand());
/* 194 */     addCommand(Locale.get("command.playerinfo.name"), new PlayerInfoCommand());
/* 195 */     addCommand(Locale.get("command.roombadge.name"), new RoomBadgeCommand());
/* 196 */     addCommand(Locale.get("command.shutdown.name"), new com.habboproject.server.game.commands.staff.ShutdownCommand());
/* 197 */     addCommand(Locale.get("command.summon.name"), new com.habboproject.server.game.commands.staff.SummonCommand());
/* 198 */     addCommand(Locale.get("command.hotelalertlink.name"), new com.habboproject.server.game.commands.staff.alerts.HotelAlertLinkCommand());
/* 199 */     addCommand(Locale.get("command.gotoroom.name"), new com.habboproject.server.game.commands.staff.GotoRoomCommand());
/* 200 */     addCommand(Locale.get("command.notification.name"), new com.habboproject.server.game.commands.staff.alerts.NotificationCommand());
/* 201 */     addCommand(Locale.get("command.quickpoll.name"), new com.habboproject.server.game.commands.staff.QuickPollCommand());
/*     */     
/*     */ 
/* 204 */     addCommand(Locale.get("command.bundle.name"), new com.habboproject.server.game.commands.staff.bundles.BundleCommand());
/*     */     
/*     */ 
/* 207 */     addCommand(Locale.get("command.reloadgroup.name"), new ReloadGroupCommand());
/*     */     
/*     */ 
/* 210 */     addCommand(Locale.get("command.roll.name"), new RollCommand());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCommand(String message)
/*     */   {
/* 220 */     if ((message.length() <= 1) || (message.startsWith(" "))) {
/* 221 */       return false;
/*     */     }
/* 223 */     String command = null;
/* 224 */     if ((command = message.split(" ")[0]) == null) {
/* 225 */       return false;
/*     */     }
/*     */     
/* 228 */     String executor = command.toLowerCase();
/*     */     
/* 230 */     boolean isCommand = (executor.equals(Locale.get("command.commands.name"))) || (this.commands.containsKey(executor.substring(1))) || (ModuleManager.getInstance().getEventHandler().getCommands().containsKey(executor));
/*     */     
/* 232 */     if (!isCommand) {
/* 233 */       for (String keys : this.commands.keySet()) {
/* 234 */         List<String> keyList = Lists.newArrayList(keys.split(","));
/*     */         
/* 236 */         if (keyList.contains(executor)) {
/* 237 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 242 */     return isCommand;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean parse(String message, Session client)
/*     */     throws Exception
/*     */   {
/* 253 */     if (message.startsWith(" ")) { return false;
/*     */     }
/* 255 */     String executor = message.split(" ")[0].toLowerCase();
/*     */     
/* 257 */     ChatCommand chatCommand = get(executor);
/*     */     
/* 259 */     if (chatCommand == null) { return false;
/*     */     }
/* 261 */     String commandName = chatCommand.getPermission();
/*     */     
/* 263 */     if ((client.getPlayer().getPermissions().hasCommand(commandName)) || (commandName.equals(""))) {
/* 264 */       if (client.getPlayer().getEntity().getRoom().getData().getDisabledCommands().contains(commandName)) {
/* 265 */         ChatCommand.sendNotif(Locale.get("command.disabled"), client);
/* 266 */         return true;
/*     */       }
/*     */       
/* 269 */       String[] params = getParams(message.split(" "));
/*     */       
/* 271 */       if (chatCommand == null) {
/* 272 */         ModuleManager.getInstance().getEventHandler().handleCommand(client, executor, params);
/*     */       }
/* 274 */       else if (chatCommand.isAsync()) {
/* 275 */         this.executorService.submit(new ChatCommand.Execution(chatCommand, params, client));
/*     */       } else {
/* 277 */         chatCommand.execute(client, params);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 282 */         if (LogManager.ENABLED) {
/* 283 */           LogManager.getInstance().getStore().getLogEntryContainer().put(new com.habboproject.server.logging.entries.CommandLogEntry(client.getPlayer().getEntity().getRoom().getId(), client.getPlayer().getId(), message));
/*     */         }
/*     */       }
/*     */       catch (Exception localException) {}
/*     */       
/* 288 */       return true;
/*     */     }
/* 290 */     if ((PermissionsManager.getInstance().getCommands().containsKey(commandName)) && 
/* 291 */       (((CommandPermission)PermissionsManager.getInstance().getCommands().get(commandName)).isVipOnly()) && 
/* 292 */       (!client.getPlayer().getData().isVip())) {
/* 293 */       ChatCommand.sendNotif(Locale.get("command.vip"), client);
/*     */     }
/* 295 */     log.debug(client.getPlayer().getData().getUsername() + " tried executing command: :" + message);
/* 296 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] getParams(String[] splitStr)
/*     */   {
/* 307 */     String[] a = new String[splitStr.length - 1];
/*     */     
/* 309 */     for (int i = 0; i < splitStr.length; i++) {
/* 310 */       if (i != 0)
/*     */       {
/*     */ 
/*     */ 
/* 314 */         a[(i - 1)] = splitStr[i];
/*     */       }
/*     */     }
/* 317 */     return a;
/*     */   }
/*     */   
/*     */   public ChatCommand get(String executor) {
/* 321 */     if (this.commands.containsKey(executor)) {
/* 322 */       return (ChatCommand)this.commands.get(executor);
/*     */     }
/* 324 */     for (String keys : this.commands.keySet()) {
/* 325 */       List<String> keyList = Lists.newArrayList(keys.split(","));
/*     */       
/* 327 */       if (keyList.contains(executor)) {
/* 328 */         return (ChatCommand)this.commands.get(keys);
/*     */       }
/*     */     }
/*     */     
/* 332 */     return null;
/*     */   }
/*     */   
/*     */   private void addCommand(String executor, ChatCommand command) {
/* 336 */     this.commands.put(":" + executor, command);
/*     */   }
/*     */   
/*     */   public NotificationManager getNotifications() {
/* 340 */     return this.notifications;
/*     */   }
/*     */   
/*     */   public Map<String, ChatCommand> getChatCommands() {
/* 344 */     return this.commands;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\CommandManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */