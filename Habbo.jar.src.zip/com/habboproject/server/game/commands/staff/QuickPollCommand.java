/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class QuickPollCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     if (params.length == 0) {
/* 12 */       return;
/*    */     }
/*    */     
/* 15 */     Room room = client.getPlayer().getEntity().getRoom();
/*    */     
/* 17 */     if ((!room.getRights().hasRights(client.getPlayer().getId())) && 
/* 18 */       (!client.getPlayer().getPermissions().getRank().modTool())) {
/* 19 */       return;
/*    */     }
/*    */     
/*    */ 
/* 23 */     String question = merge(params);
/*    */     
/* 25 */     if (params[0].equals("end")) {
/* 26 */       room.endQuestion();
/*    */     } else {
/* 28 */       room.startQuestion(question);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 34 */     return "quickpoll_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 39 */     return com.habboproject.server.config.Locale.get("command.quickpoll.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\QuickPollCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */