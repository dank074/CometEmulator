/*     */ package com.habboproject.server.game.commands.staff;
/*     */ 
/*     */ import com.habboproject.server.config.Locale;
/*     */ import com.habboproject.server.game.commands.ChatCommand;
/*     */ import com.habboproject.server.game.players.components.types.inventory.InventoryBot;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.RoomManager;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntityStatus;
/*     */ import com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.game.rooms.types.misc.ChatEmotionsManager;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.DanceMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class RoomActionCommand extends ChatCommand
/*     */ {
/*     */   public void execute(Session client, String[] params)
/*     */   {
/*  26 */     if (params.length < 2) {
/*  27 */       return;
/*     */     }
/*     */     
/*  30 */     String action = params[0];
/*     */     String str1;
/*  32 */     switch ((str1 = action).hashCode()) {case -1306084975:  if (str1.equals("effect")) break; break; case 113643:  if (str1.equals("say")) {} break; case 1993730:  if (str1.equals("handitem")) {} break; case 3029900:  if (str1.equals("bots")) {} break; case 3530173:  if (str1.equals("sign")) {} break; case 95350707:  if (!str1.equals("dance")) {
/*     */         return;
/*  34 */         if (!StringUtils.isNumeric(params[1])) {
/*  35 */           return;
/*     */         }
/*     */         
/*  38 */         int effectId = Integer.parseInt(params[1]);
/*     */         
/*  40 */         for (PlayerEntity playerEntity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/*  41 */           playerEntity.applyEffect(new PlayerEffect(effectId, 0));
/*     */         }
/*  43 */         return;
/*     */         
/*     */ 
/*  46 */         String msg = merge(params, 1);
/*     */         
/*  48 */         for (PlayerEntity playerEntity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/*  49 */           playerEntity.getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer(playerEntity.getId(), msg, RoomManager.getInstance().getEmotions().getEmotion(msg), 0));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  54 */         if (!StringUtils.isNumeric(params[1])) {
/*  55 */           return;
/*     */         }
/*     */         
/*  58 */         int danceId = Integer.parseInt(params[1]);
/*     */         
/*  60 */         for (PlayerEntity playerEntity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/*  61 */           playerEntity.setDanceId(danceId);
/*  62 */           playerEntity.getRoom().getEntities().broadcastMessage(new DanceMessageComposer(playerEntity.getId(), danceId));
/*     */         }
/*  64 */         return;
/*     */         
/*     */ 
/*  67 */         if (!StringUtils.isNumeric(params[1])) {
/*  68 */           return;
/*     */         }
/*     */         
/*  71 */         for (PlayerEntity playerEntity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/*  72 */           playerEntity.addStatus(RoomEntityStatus.SIGN, String.valueOf(params[1]));
/*     */           
/*  74 */           playerEntity.markDisplayingSign();
/*  75 */           playerEntity.markNeedsUpdate();
/*     */         }
/*  77 */         return;
/*     */         
/*     */ 
/*  80 */         if (!StringUtils.isNumeric(params[1])) {
/*  81 */           return;
/*     */         }
/*     */         
/*  84 */         int count = Integer.parseInt(params[1]);
/*  85 */         Position entityPosition = client.getPlayer().getEntity().getPosition();
/*     */         
/*  87 */         if (count > 1000) {
/*  88 */           count = 1000;
/*  89 */         } else if (count < 0) {
/*  90 */           count = 1;
/*     */         }
/*     */         
/*  93 */         List<com.habboproject.server.game.rooms.objects.entities.RoomEntity> addedEntities = com.google.common.collect.Lists.newArrayList();
/*     */         
/*  95 */         for (int i = 0; i < count; i++) {
/*  96 */           BotEntity botEntity = client.getPlayer().getEntity().getRoom().getBots().addBot(new InventoryBot(0 - (i + 1), client.getPlayer().getId(), client.getPlayer().getData().getUsername(), client.getPlayer().getData().getUsername() + "Minion" + i, client.getPlayer().getData().getFigure(), client.getPlayer().getData().getGender(), client.getPlayer().getData().getMotto(), "mimic"), entityPosition.getX(), entityPosition.getY(), entityPosition.getZ());
/*     */           
/*  98 */           if (botEntity != null) {
/*  99 */             addedEntities.add(botEntity);
/*     */           }
/*     */         }
/*     */         
/* 103 */         client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.AvatarsMessageComposer(addedEntities));
/* 104 */         return;
/*     */         
/*     */ 
/* 107 */         int handItem = Integer.parseInt(params[1]);
/*     */         
/* 109 */         for (PlayerEntity playerEntity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/* 110 */           playerEntity.carryItem(handItem, false);
/*     */         }
/*     */       }
/*     */       break;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getPermission()
/*     */   {
/* 119 */     return "roomaction_command";
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 124 */     return Locale.get("command.roomaction.description");
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\RoomActionCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */