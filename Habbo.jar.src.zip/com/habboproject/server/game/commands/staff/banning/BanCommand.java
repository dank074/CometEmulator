/*    */ package com.habboproject.server.game.commands.staff.banning;
/*    */ 
/*    */ import com.habboproject.server.game.moderation.BanManager;
/*    */ import com.habboproject.server.game.permissions.types.Rank;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.players.types.PlayerStatistics;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class BanCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 15 */     if (params.length < 2) {
/* 16 */       return;
/*    */     }
/*    */     
/* 19 */     String username = params[0];
/* 20 */     int length = Integer.parseInt(params[1]);
/*    */     
/* 22 */     Session user = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 24 */     if (user == null) {
/* 25 */       return;
/*    */     }
/*    */     
/* 28 */     if ((user == client) || (!user.getPlayer().getPermissions().getRank().bannable())) {
/* 29 */       return;
/*    */     }
/*    */     
/* 32 */     client.getPlayer().getStats().setBans(client.getPlayer().getStats().getBans() + 1);
/*    */     
/* 34 */     user.disconnect("banned");
/*    */     
/* 36 */     long expire = com.habboproject.server.boot.Comet.getTime() + length * 3600;
/*    */     
/* 38 */     BanManager.getInstance().banPlayer(com.habboproject.server.game.moderation.types.BanType.USER, user.getPlayer().getId(), length, expire, params.length > 2 ? merge(params, 2) : "", client.getPlayer().getId());
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 43 */     return "ban_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 48 */     return com.habboproject.server.config.Locale.get("command.ban.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\banning\BanCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */