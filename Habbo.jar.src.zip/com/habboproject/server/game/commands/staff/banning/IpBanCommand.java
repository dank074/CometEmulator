/*    */ package com.habboproject.server.game.commands.staff.banning;
/*    */ 
/*    */ import com.habboproject.server.game.moderation.BanManager;
/*    */ import com.habboproject.server.game.moderation.types.BanType;
/*    */ import com.habboproject.server.game.permissions.types.Rank;
/*    */ import com.habboproject.server.game.players.PlayerManager;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class IpBanCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 18 */     if (params.length < 2) {
/* 19 */       return;
/*    */     }
/*    */     
/* 22 */     String username = params[0];
/* 23 */     int length = org.apache.commons.lang3.StringUtils.isNumeric(params[1]) ? Integer.parseInt(params[1]) : 0;
/*    */     
/* 25 */     Session user = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 27 */     if (user == null)
/*    */     {
/* 29 */       return;
/*    */     }
/*    */     
/* 32 */     if ((user == client) || (!user.getPlayer().getPermissions().getRank().bannable())) {
/* 33 */       return;
/*    */     }
/*    */     
/* 36 */     long expire = com.habboproject.server.boot.Comet.getTime() + length * 3600;
/*    */     
/* 38 */     String ipAddress = user.getIpAddress();
/*    */     
/* 40 */     if (BanManager.getInstance().hasBan(ipAddress, BanType.IP)) {
/* 41 */       sendNotif("IP: " + ipAddress + " is already banned.", client);
/* 42 */       return;
/*    */     }
/*    */     
/* 45 */     BanManager.getInstance().banPlayer(BanType.IP, user.getIpAddress(), length, expire, params.length > 2 ? merge(params, 2) : "", client.getPlayer().getId());
/*    */     
/* 47 */     sendNotif("User has been IP banned (IP: " + ipAddress + ")", client);
/*    */     
/* 49 */     List<Integer> playerIds = PlayerManager.getInstance().getPlayerIdsByIpAddress(ipAddress);
/*    */     
/* 51 */     for (Iterator localIterator = playerIds.iterator(); localIterator.hasNext();) { int playerId = ((Integer)localIterator.next()).intValue();
/* 52 */       Session player = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);
/*    */       
/* 54 */       if (player != null) {
/* 55 */         player.disconnect("banned");
/*    */       }
/*    */     }
/*    */     
/* 59 */     playerIds.clear();
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 64 */     return "ipban_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 69 */     return "command.ipban.description";
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\banning\IpBanCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */