/*    */ package com.habboproject.server.game.commands.staff.banning;
/*    */ 
/*    */ import com.habboproject.server.game.moderation.BanManager;
/*    */ import com.habboproject.server.game.moderation.types.BanType;
/*    */ import com.habboproject.server.game.permissions.types.Rank;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class MachineBanCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 15 */     if (params.length < 2) {
/* 16 */       return;
/*    */     }
/*    */     
/* 19 */     String username = params[0];
/* 20 */     int length = Integer.parseInt(params[1]);
/*    */     
/* 22 */     Session user = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 24 */     if (user == null)
/*    */     {
/* 26 */       return;
/*    */     }
/*    */     
/* 29 */     if ((user == client) || (!user.getPlayer().getPermissions().getRank().bannable())) {
/* 30 */       return;
/*    */     }
/*    */     
/* 33 */     long expire = com.habboproject.server.boot.Comet.getTime() + length * 3600;
/*    */     
/* 35 */     String uniqueId = user.getUniqueId();
/*    */     
/* 37 */     if (BanManager.getInstance().hasBan(uniqueId, BanType.MACHINE)) {
/* 38 */       sendNotif("Machine ID: " + uniqueId + " is already banned.", client);
/* 39 */       return;
/*    */     }
/*    */     
/* 42 */     BanManager.getInstance().banPlayer(BanType.MACHINE, user.getUniqueId(), length, expire, params.length > 2 ? merge(params, 2) : "", client.getPlayer().getId());
/* 43 */     sendNotif("User has been machine ID banned (" + uniqueId + ")", client);
/*    */     
/* 45 */     user.disconnect("banned");
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 50 */     return "machineban_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 55 */     return com.habboproject.server.config.Locale.get("command.machineban.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\banning\MachineBanCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */