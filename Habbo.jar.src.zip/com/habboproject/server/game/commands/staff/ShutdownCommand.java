/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class ShutdownCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     com.habboproject.server.boot.Comet.exit("Server shutdown by command executor: " + client.getPlayer().getData().getUsername() + " / " + client.getPlayer().getData().getId());
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 16 */     return "shutdown_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 21 */     return com.habboproject.server.config.Locale.get("command.shutdown.description");
/*    */   }
/*    */   
/*    */   public boolean isHidden()
/*    */   {
/* 26 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\ShutdownCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */