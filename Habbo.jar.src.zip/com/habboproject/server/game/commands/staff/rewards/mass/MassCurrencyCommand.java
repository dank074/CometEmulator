/*    */ package com.habboproject.server.game.commands.staff.rewards.mass;
/*    */ 
/*    */ import com.habboproject.server.api.game.players.BasePlayer;
/*    */ import com.habboproject.server.api.game.players.data.IPlayerData;
/*    */ import com.habboproject.server.api.networking.sessions.BaseSession;
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public abstract class MassCurrencyCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 15 */     if ((params.length < 1) || (params[0].isEmpty()) || (!org.apache.commons.lang.StringUtils.isNumeric(params[0]))) {
/* 16 */       return;
/*    */     }
/* 18 */     int amount = Integer.parseInt(params[0]);
/*    */     
/* 20 */     for (BaseSession session : NetworkManager.getInstance().getSessions().getSessions().values()) {
/*    */       try
/*    */       {
/* 23 */         if ((this instanceof MassCoinsCommand)) {
/* 24 */           session.getPlayer().getData().increaseCredits(amount);
/* 25 */           session.send(new AdvancedAlertMessageComposer(Locale.get("command.coins.title"), Locale.get("command.coins.received").replace("%amount%", String.valueOf(amount))));
/*    */         }
/* 27 */         else if ((this instanceof MassDucketsCommand)) {
/* 28 */           session.getPlayer().getData().increaseActivityPoints(amount);
/*    */         }
/* 30 */         else if ((this instanceof MassPointsCommand)) {
/* 31 */           session.getPlayer().getData().increasePoints(amount);
/*    */           
/* 33 */           session.send(new AdvancedAlertMessageComposer(
/* 34 */             Locale.get("command.points.successtitle"), 
/* 35 */             Locale.get("command.points.successmessage").replace("%amount%", String.valueOf(amount))));
/*    */           
/*    */ 
/* 38 */           session.send(session.getPlayer().composeCurrenciesBalance());
/*    */         }
/*    */         
/* 41 */         session.getPlayer().getData().save();
/* 42 */         session.getPlayer().sendBalance();
/*    */       }
/*    */       catch (Exception localException) {}
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isAsync()
/*    */   {
/* 51 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\mass\MassCurrencyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */