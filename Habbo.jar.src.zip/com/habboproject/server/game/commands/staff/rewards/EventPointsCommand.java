/*     */ package com.habboproject.server.game.commands.staff.rewards;
/*     */ 
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.boot.CometServer;
/*     */ import com.habboproject.server.config.CometSettings;
/*     */ import com.habboproject.server.config.Configuration;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.messages.outgoing.notification.NotificationMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.network.sessions.SessionManager;
/*     */ import com.habboproject.server.storage.queries.player.PlayerDao;
/*     */ 
/*     */ public class EventPointsCommand extends com.habboproject.server.game.commands.ChatCommand
/*     */ {
/*     */   public void execute(Session client, String[] params)
/*     */   {
/*  19 */     String image = Comet.getServer().getConfig().get("comet.notification.avatar.prefix");
/*     */     
/*  21 */     if (params.length != 1) {
/*  22 */       sendNotif("Oops! Você deve digitar apenas o nome do usuário que irá receber o ponto.", client);
/*  23 */       return;
/*     */     }
/*     */     
/*  26 */     String username = params[0];
/*  27 */     if (username.isEmpty()) {
/*  28 */       sendNotif("Oops! O nome de usuário não pode estar em branco.", client);
/*  29 */       return;
/*     */     }
/*     */     
/*  32 */     if (username.contains(";")) { String[] arrayOfString;
/*  33 */       int j = (arrayOfString = username.split("[;]")).length; Session session; for (int i = 0; i < j; i++) { String nome = arrayOfString[i];
/*  34 */         session = NetworkManager.getInstance().getSessions().getByPlayerUsername(nome);
/*  35 */         if (session != null) {
/*  36 */           PlayerDao.updateEventPoints(nome);
/*     */           
/*  38 */           String notif = "";
/*  39 */           if (CometSettings.enableEventWinnerReward) {
/*  40 */             if (CometSettings.eventWinnerRewardType.equals("diamonds")) {
/*  41 */               session.getPlayer().getData().increasePoints(CometSettings.eventWinnerRewardQuantity);
/*  42 */               session.getPlayer().getData().save();
/*  43 */               session.getPlayer().sendBalance();
/*  44 */               notif = String.valueOf(notif) + CometSettings.eventWinnerRewardQuantity + (CometSettings.eventWinnerRewardQuantity > 1 ? "diamantes" : "diamante");
/*  45 */               notif = String.valueOf(notif) + " e " + CometSettings.defaultEventPointsQuantity + (CometSettings.defaultEventPointsQuantity > 1 ? "pontos" : "ponto") + " de evento.";
/*  46 */             } else if (CometSettings.eventWinnerRewardType.equals("credits")) {
/*  47 */               session.getPlayer().getData().increaseCredits(CometSettings.eventWinnerRewardQuantity);
/*  48 */               session.getPlayer().getData().save();
/*  49 */               session.getPlayer().sendBalance();
/*  50 */               notif = String.valueOf(notif) + CometSettings.eventWinnerRewardQuantity + (CometSettings.eventWinnerRewardQuantity > 1 ? "moedas" : "moeda");
/*  51 */               notif = String.valueOf(notif) + " e " + CometSettings.defaultEventPointsQuantity + (CometSettings.defaultEventPointsQuantity > 1 ? "pontos" : "ponto") + " de evento.";
/*  52 */             } else if (CometSettings.eventWinnerRewardType.equals("duckets")) {
/*  53 */               session.getPlayer().getData().increaseActivityPoints(CometSettings.eventWinnerRewardQuantity);
/*  54 */               session.getPlayer().getData().save();
/*  55 */               session.getPlayer().sendBalance();
/*  56 */               notif = String.valueOf(notif) + CometSettings.eventWinnerRewardQuantity + (CometSettings.eventWinnerRewardQuantity > 1 ? "ducket" : "duckets");
/*  57 */               notif = String.valueOf(notif) + " e " + CometSettings.defaultEventPointsQuantity + (CometSettings.defaultEventPointsQuantity > 1 ? "pontos" : "ponto") + " de evento.";
/*     */             }
/*     */           }
/*     */           
/*  61 */           sendNotif("Você recebeu " + notif, session);
/*     */         } else {
/*  63 */           PlayerData playerData = PlayerDao.getDataByUsername(nome);
/*  64 */           if (playerData != null) {
/*  65 */             PlayerDao.updateEventPoints(nome);
/*  66 */             if (CometSettings.eventWinnerRewardType.equals("diamonds")) {
/*  67 */               playerData.increasePoints(CometSettings.eventWinnerRewardQuantity);
/*  68 */             } else if (CometSettings.eventWinnerRewardType.equals("credits")) {
/*  69 */               playerData.increaseCredits(CometSettings.eventWinnerRewardQuantity);
/*  70 */             } else if (CometSettings.eventWinnerRewardType.equals("duckets")) {
/*  71 */               playerData.increaseActivityPoints(CometSettings.eventWinnerRewardQuantity);
/*     */             }
/*     */             
/*  74 */             playerData.save();
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*  79 */       String motd = "Os usuários ";
/*     */       
/*  81 */       int k = (session = username.split("[;]")).length; for (j = 0; j < k; j++) { String nome = session[j];
/*  82 */         motd = motd + nome + ", ";
/*     */       }
/*     */       
/*  85 */       sendNotif(String.valueOf(motd) + "foram pagos.", client);
/*     */       
/*  87 */       if (CometSettings.enableEventWinnerNotification) {
/*  88 */         NetworkManager.getInstance().getSessions().broadcast(new NotificationMessageComposer("frank", String.valueOf(motd) + "ganharam o evento. ParabÃ©ns!"));
/*     */       }
/*     */     } else {
/*  91 */       Session session = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*  92 */       if (session != null) {
/*  93 */         PlayerDao.updateEventPoints(username);
/*     */         
/*  95 */         String notif = "";
/*  96 */         if (CometSettings.enableEventWinnerReward) {
/*  97 */           if (CometSettings.eventWinnerRewardType.equals("diamonds")) {
/*  98 */             session.getPlayer().getData().increasePoints(CometSettings.eventWinnerRewardQuantity);
/*  99 */             session.getPlayer().getData().save();
/* 100 */             session.getPlayer().sendBalance();
/* 101 */             notif = String.valueOf(notif) + CometSettings.eventWinnerRewardQuantity + (CometSettings.eventWinnerRewardQuantity > 1 ? " diamantes" : " diamante");
/* 102 */             notif = String.valueOf(notif) + " e " + CometSettings.defaultEventPointsQuantity + (CometSettings.defaultEventPointsQuantity > 1 ? " pontos" : " ponto") + " de evento.";
/* 103 */           } else if (CometSettings.eventWinnerRewardType.equals("credits")) {
/* 104 */             session.getPlayer().getData().increaseCredits(CometSettings.eventWinnerRewardQuantity);
/* 105 */             session.getPlayer().getData().save();
/* 106 */             session.getPlayer().sendBalance();
/* 107 */             notif = String.valueOf(notif) + CometSettings.eventWinnerRewardQuantity + (CometSettings.eventWinnerRewardQuantity > 1 ? " moedas" : " moeda");
/* 108 */             notif = String.valueOf(notif) + " e " + CometSettings.defaultEventPointsQuantity + (CometSettings.defaultEventPointsQuantity > 1 ? " pontos" : " ponto") + " de evento.";
/* 109 */           } else if (CometSettings.eventWinnerRewardType.equals("duckets")) {
/* 110 */             session.getPlayer().getData().increaseActivityPoints(CometSettings.eventWinnerRewardQuantity);
/* 111 */             session.getPlayer().getData().save();
/* 112 */             session.getPlayer().sendBalance();
/* 113 */             notif = String.valueOf(notif) + CometSettings.eventWinnerRewardQuantity + (CometSettings.eventWinnerRewardQuantity > 1 ? " ducket" : " duckets");
/* 114 */             notif = String.valueOf(notif) + " e " + CometSettings.defaultEventPointsQuantity + (CometSettings.defaultEventPointsQuantity > 1 ? " pontos" : " ponto") + " de evento.";
/*     */           }
/*     */         }
/*     */         
/* 118 */         sendNotif("Você recebeu " + notif, session);
/*     */         
/* 120 */         String motd = "O usuário " + username;
/*     */         
/* 122 */         sendNotif(String.valueOf(motd) + " recebeu" + notif, client);
/*     */         
/* 124 */         if (CometSettings.enableEventWinnerNotification) {
/* 125 */           NetworkManager.getInstance().getSessions().broadcast(new NotificationMessageComposer(image.replace("{0}", session.getPlayer().getData().getUsername()), String.valueOf(motd) + " ganhou o evento. " + (username.equals("trylix") ? "Faça sexo com ele! e.e" : "Parabéns!")));
/*     */         }
/*     */         
/* 128 */         return;
/*     */       }
/* 130 */       PlayerData playerData = PlayerDao.getDataByUsername(username);
/* 131 */       if (playerData != null) {
/* 132 */         PlayerDao.updateEventPoints(username);
/*     */         
/* 134 */         if (CometSettings.eventWinnerRewardType.equals("diamonds")) {
/* 135 */           playerData.increasePoints(CometSettings.eventWinnerRewardQuantity);
/* 136 */         } else if (CometSettings.eventWinnerRewardType.equals("credits")) {
/* 137 */           playerData.increaseCredits(CometSettings.eventWinnerRewardQuantity);
/* 138 */         } else if (CometSettings.eventWinnerRewardType.equals("duckets")) {
/* 139 */           playerData.increaseActivityPoints(CometSettings.eventWinnerRewardQuantity);
/*     */         }
/* 141 */         playerData.save();
/* 142 */         return;
/*     */       }
/*     */     }
/*     */     
/* 146 */     sendNotif("Oops! Ocorreu um erro e não foi possível entregar o ponto ao usuário.", client);
/*     */   }
/*     */   
/*     */   public String getPermission()
/*     */   {
/* 151 */     return "eventpoint_command";
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 156 */     return com.habboproject.server.config.Locale.get("command.eventpoint.description");
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\EventPointsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */