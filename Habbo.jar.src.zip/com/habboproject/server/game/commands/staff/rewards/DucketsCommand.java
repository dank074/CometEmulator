/*    */ package com.habboproject.server.game.commands.staff.rewards;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class DucketsCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 15 */     if ((params.length < 2) || (!StringUtils.isNumeric(params[1]))) {
/* 16 */       return;
/*    */     }
/* 18 */     String username = params[0];
/* 19 */     int duckets = Integer.parseInt(params[1]);
/*    */     
/* 21 */     Session session = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 23 */     if (session == null) {
/* 24 */       return;
/*    */     }
/*    */     
/* 27 */     session.getPlayer().getData().increaseActivityPoints(duckets);
/* 28 */     session.getPlayer().getData().save();
/*    */     
/* 30 */     session.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(
/* 31 */       Locale.get("command.duckets.successtitle"), 
/* 32 */       Locale.get("command.duckets.successmessage").replace("%amount%", String.valueOf(duckets))));
/*    */     
/*    */ 
/* 35 */     session.send(new com.habboproject.server.network.messages.outgoing.user.purse.UpdateActivityPointsMessageComposer(session.getPlayer().getData().getActivityPoints(), duckets));
/* 36 */     session.send(session.getPlayer().composeCurrenciesBalance());
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 41 */     return "duckets_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 46 */     return Locale.get("command.duckets.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\DucketsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */