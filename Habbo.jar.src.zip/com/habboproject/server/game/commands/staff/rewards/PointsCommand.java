/*    */ package com.habboproject.server.game.commands.staff.rewards;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import com.habboproject.server.storage.queries.player.PlayerDao;
/*    */ 
/*    */ public class PointsCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 15 */     if (params.length < 2) {
/* 16 */       return;
/*    */     }
/* 18 */     String username = params[0];
/*    */     
/*    */     try
/*    */     {
/* 22 */       points = Integer.parseInt(params[1]);
/*    */     } catch (Exception e) { int points;
/*    */       return;
/*    */     }
/*    */     int points;
/* 27 */     Session session = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 29 */     if (session == null) {
/* 30 */       PlayerData playerData = PlayerDao.getDataByUsername(username);
/*    */       
/* 32 */       if (playerData == null) { return;
/*    */       }
/* 34 */       playerData.increasePoints(points);
/* 35 */       playerData.save();
/* 36 */       return;
/*    */     }
/*    */     
/* 39 */     session.getPlayer().getData().increasePoints(points);
/* 40 */     session.getPlayer().getData().save();
/*    */     
/* 42 */     session.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(
/* 43 */       Locale.get("command.points.successtitle"), 
/* 44 */       Locale.get("command.points.successmessage").replace("%amount%", String.valueOf(points))));
/*    */     
/*    */ 
/* 47 */     session.send(session.getPlayer().composeCurrenciesBalance());
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 52 */     return "points_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 57 */     return Locale.get("command.points.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\PointsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */