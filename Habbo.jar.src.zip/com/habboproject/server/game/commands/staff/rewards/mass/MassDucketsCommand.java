/*    */ package com.habboproject.server.game.commands.staff.rewards.mass;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ 
/*    */ public class MassDucketsCommand extends MassCurrencyCommand
/*    */ {
/*    */   public String getPermission()
/*    */   {
/*  9 */     return "massduckets_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 14 */     return Locale.get("command.massduckets.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\mass\MassDucketsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */