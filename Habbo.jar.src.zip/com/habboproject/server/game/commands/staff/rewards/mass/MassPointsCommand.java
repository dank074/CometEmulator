/*    */ package com.habboproject.server.game.commands.staff.rewards.mass;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ 
/*    */ public class MassPointsCommand extends MassCurrencyCommand
/*    */ {
/*    */   public String getPermission()
/*    */   {
/*  9 */     return "masspoints_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 14 */     return Locale.get("command.masspoints.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\mass\MassPointsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */