/*    */ package com.habboproject.server.game.commands.staff.rewards;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import com.habboproject.server.storage.queries.player.PlayerDao;
/*    */ import com.habboproject.server.storage.queries.player.inventory.InventoryDao;
/*    */ 
/*    */ public class GiveBadgeCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 14 */     if (params.length < 2) {
/* 15 */       return;
/*    */     }
/* 17 */     String username = params[0];
/* 18 */     String badge = params[1];
/*    */     
/* 20 */     Session session = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 22 */     if (session != null) {
/* 23 */       session.getPlayer().getInventory().addBadge(badge, true);
/* 24 */       sendNotif(Locale.get("command.givebadge.success").replace("%username%", username).replace("%badge%", badge), client);
/*    */     } else {
/* 26 */       int playerId = PlayerDao.getIdByUsername(username);
/*    */       
/* 28 */       if (playerId == 0) {
/* 29 */         sendNotif(Locale.get("command.givebadge.fail").replace("%username%", username).replace("%badge%", badge), client);
/*    */       } else {
/* 31 */         InventoryDao.addBadge(badge, playerId);
/* 32 */         sendNotif(Locale.get("command.givebadge.success").replace("%username%", username).replace("%badge%", badge), client);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 39 */     return "givebadge_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 44 */     return Locale.get("command.givebadge.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\GiveBadgeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */