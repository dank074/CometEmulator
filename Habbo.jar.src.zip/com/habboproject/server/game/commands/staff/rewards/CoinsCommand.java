/*    */ package com.habboproject.server.game.commands.staff.rewards;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.storage.queries.player.PlayerDao;
/*    */ 
/*    */ public class CoinsCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 15 */     if (params.length < 2) {
/* 16 */       return;
/*    */     }
/* 18 */     String username = params[0];
/*    */     try
/*    */     {
/* 21 */       int credits = Integer.parseInt(params[1]);
/* 22 */       Session player = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */       
/* 24 */       if (player == null) {
/* 25 */         PlayerData playerData = PlayerDao.getDataByUsername(username);
/*    */         
/* 27 */         if (playerData == null) { return;
/*    */         }
/* 29 */         playerData.increaseCredits(credits);
/* 30 */         playerData.save();
/* 31 */         return;
/*    */       }
/*    */       
/* 34 */       player.getPlayer().getData().increaseCredits(credits);
/* 35 */       player.send(new AdvancedAlertMessageComposer(Locale.get("command.coins.title"), Locale.get("command.coins.received").replace("%amount%", String.valueOf(credits))));
/*    */       
/* 37 */       player.getPlayer().getData().save();
/* 38 */       player.getPlayer().sendBalance();
/*    */     } catch (Exception e) {
/* 40 */       client.send(new AdvancedAlertMessageComposer(Locale.get("command.coins.errortitle"), Locale.get("command.coins.formaterror")));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 46 */     return "coins_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 51 */     return Locale.get("command.coins.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\CoinsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */