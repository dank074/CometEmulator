/*    */ package com.habboproject.server.game.commands.staff.rewards;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class RoomBadgeCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     if (params.length != 1) {
/* 12 */       return;
/*    */     }
/*    */     
/* 15 */     String badge = params[0];
/*    */     
/* 17 */     for (PlayerEntity playerEntity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/* 18 */       playerEntity.getPlayer().getInventory().addBadge(badge, true);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 24 */     return "roombadge_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 29 */     return com.habboproject.server.config.Locale.get("command.roombadge.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\RoomBadgeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */