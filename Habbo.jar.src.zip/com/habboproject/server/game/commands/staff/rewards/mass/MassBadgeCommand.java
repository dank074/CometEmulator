/*    */ package com.habboproject.server.game.commands.staff.rewards.mass;
/*    */ 
/*    */ import com.habboproject.server.api.game.players.BasePlayer;
/*    */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*    */ import com.habboproject.server.api.networking.sessions.BaseSession;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import com.habboproject.server.storage.queries.player.inventory.InventoryDao;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MassBadgeCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 18 */     if (params.length < 1) {
/* 19 */       return;
/*    */     }
/* 21 */     String badgeCode = params[0];
/* 22 */     List<Integer> playersToInsertBadge = com.google.common.collect.Lists.newArrayList();
/*    */     
/* 24 */     for (BaseSession session : NetworkManager.getInstance().getSessions().getSessions().values()) {
/*    */       try {
/* 26 */         ((Player)session.getPlayer()).getInventory().addBadge(badgeCode, false);
/* 27 */         playersToInsertBadge.add(Integer.valueOf(session.getPlayer().getId()));
/*    */       }
/*    */       catch (Exception localException) {}
/*    */     }
/*    */     
/*    */ 
/* 33 */     InventoryDao.addBadges(badgeCode, playersToInsertBadge);
/* 34 */     playersToInsertBadge.clear();
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 39 */     return "massbadge_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 44 */     return com.habboproject.server.config.Locale.get("command.massbadge.description");
/*    */   }
/*    */   
/*    */   public boolean isAsync()
/*    */   {
/* 49 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\rewards\mass\MassBadgeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */