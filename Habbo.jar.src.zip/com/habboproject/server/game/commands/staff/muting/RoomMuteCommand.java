/*    */ package com.habboproject.server.game.commands.staff.muting;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class RoomMuteCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 12 */     if (client.getPlayer().getEntity().getRoom().hasRoomMute()) {
/* 13 */       for (PlayerEntity playerEntity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/* 14 */         playerEntity.setRoomMuted(false);
/*    */       }
/*    */       
/* 17 */       client.getPlayer().getEntity().getRoom().setRoomMute(false);
/*    */     } else {
/* 19 */       for (PlayerEntity playerEntity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/* 20 */         playerEntity.setRoomMuted(true);
/*    */       }
/*    */       
/* 23 */       client.getPlayer().getEntity().getRoom().setRoomMute(true);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 29 */     return "roommute_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 34 */     return com.habboproject.server.config.Locale.get("command.roommute.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\muting\RoomMuteCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */