/*    */ package com.habboproject.server.game.commands.staff.muting;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.game.moderation.BanManager;
/*    */ import com.habboproject.server.game.players.PlayerManager;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class MuteCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 16 */     if (params.length != 1) {
/* 17 */       return;
/*    */     }
/*    */     
/* 20 */     int playerId = PlayerManager.getInstance().getPlayerIdByUsername(params[0]);
/*    */     
/* 22 */     if (playerId != -1) {
/* 23 */       Session session = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);
/*    */       
/* 25 */       if (session != null) {
/* 26 */         session.send(new AdvancedAlertMessageComposer(Locale.get("command.mute.muted")));
/*    */       }
/*    */       
/* 29 */       BanManager.getInstance().mute(playerId);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 35 */     return "mute_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 40 */     return Locale.get("command.mute.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\muting\MuteCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */