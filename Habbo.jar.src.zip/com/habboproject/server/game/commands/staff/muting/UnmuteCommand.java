/*    */ package com.habboproject.server.game.commands.staff.muting;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.moderation.BanManager;
/*    */ import com.habboproject.server.game.players.PlayerManager;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class UnmuteCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 16 */     if (params.length != 1) {
/* 17 */       return;
/*    */     }
/*    */     
/* 20 */     int playerId = PlayerManager.getInstance().getPlayerIdByUsername(params[0]);
/*    */     
/* 22 */     if (playerId != -1) {
/* 23 */       Session session = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);
/*    */       
/* 25 */       if (session != null) {
/* 26 */         session.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(Locale.get("command.unmute.unmuted")));
/*    */         
/* 28 */         if (BanManager.getInstance().isMuted(playerId)) {
/* 29 */           BanManager.getInstance().unmute(playerId);
/*    */         } else {
/* 31 */           PlayerEntity entity = session.getPlayer().getEntity();
/*    */           
/* 33 */           if ((entity != null) && (entity.isRoomMuted())) {
/* 34 */             entity.setRoomMuted(false);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 43 */     return "unmute_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 48 */     return Locale.get("command.unmute.name");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\muting\UnmuteCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */