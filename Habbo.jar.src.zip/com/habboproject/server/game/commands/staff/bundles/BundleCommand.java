/*     */ package com.habboproject.server.game.commands.staff.bundles;
/*     */ 
/*     */ import com.habboproject.server.game.catalog.CatalogManager;
/*     */ import com.habboproject.server.game.commands.ChatCommand;
/*     */ import com.habboproject.server.game.rooms.bundles.RoomBundleManager;
/*     */ import com.habboproject.server.game.rooms.bundles.types.RoomBundle;
/*     */ import com.habboproject.server.game.rooms.bundles.types.RoomBundleItem;
/*     */ import com.habboproject.server.game.rooms.models.CustomModel;
/*     */ import com.habboproject.server.game.rooms.models.RoomModel;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemWall;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.jukebox.SoundMachineFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.RoomData;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class BundleCommand extends ChatCommand
/*     */ {
/*     */   public void execute(Session client, String[] params)
/*     */   {
/*  29 */     if (params.length < 2) {
/*  30 */       client.send(new com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer("Use :bundle create [alias] to create a bundle."));
/*  31 */       return;
/*     */     }
/*     */     
/*  34 */     String commandName = params[0];
/*     */     String str1;
/*  36 */     switch ((str1 = commandName).hashCode()) {case -1352294148:  if (str1.equals("create")) break;  case 1557372922:  if ((goto 501) && (!str1.equals("destroy")))
/*     */       {
/*  38 */         return;String alias = params[1];
/*     */         
/*  40 */         Room room = client.getPlayer().getEntity().getRoom();
/*     */         
/*  42 */         CustomModel modelData = new CustomModel(
/*  43 */           room.getModel().getDoorX(), room.getModel().getDoorY(), room.getModel().getDoorZ(), 
/*  44 */           room.getModel().getDoorRotation(), room.getModel().getMap(), room.getModel().getWallHeight());
/*     */         
/*  46 */         List<RoomBundleItem> bundleItems = new ArrayList();
/*     */         
/*  48 */         for (RoomItemFloor floorItem : room.getItems().getFloorItems().values()) {
/*  49 */           if ((!(floorItem instanceof SoundMachineFloorItem)) && (!(floorItem instanceof com.habboproject.server.game.rooms.objects.items.types.floor.teleport.TeleportFloorItem)) && (!(floorItem instanceof WiredFloorItem)))
/*     */           {
/*     */ 
/*     */ 
/*  53 */             bundleItems.add(new RoomBundleItem(floorItem.getItemId(), 
/*  54 */               floorItem.getPosition().getX(), floorItem.getPosition().getY(), 
/*  55 */               floorItem.getPosition().getZ(), floorItem.getRotation(), null, 
/*  56 */               floorItem.getDataObject()));
/*     */           }
/*     */         }
/*     */         
/*  60 */         for (RoomItemWall wallItem : room.getItems().getWallItems().values()) {
/*  61 */           bundleItems.add(new RoomBundleItem(wallItem.getItemId(), 
/*  62 */             -1, -1, -1.0D, -1, wallItem.getWallPosition(), 
/*  63 */             wallItem.getExtraData()));
/*     */         }
/*     */         
/*     */ 
/*  67 */         RoomBundle roomBundle = new RoomBundle(-1, room.getId(), alias, modelData, bundleItems, 20, 0, 0, new com.habboproject.server.game.rooms.bundles.types.RoomBundleConfig("%username%'s new room", room.getData().getDecorationString(), room.getData().getWallThickness(), room.getData().getFloorThickness(), room.getData().getHideWalls()));
/*     */         
/*  69 */         com.habboproject.server.storage.queries.rooms.BundleDao.saveBundle(roomBundle);
/*     */         
/*  71 */         boolean updateCatalog = false;
/*     */         
/*  73 */         if (RoomBundleManager.getInstance().getBundle(alias) != null) {
/*  74 */           updateCatalog = true;
/*     */         }
/*     */         
/*  77 */         RoomBundleManager.getInstance().addBundle(roomBundle);
/*     */         
/*  79 */         if (updateCatalog) {
/*  80 */           CatalogManager.getInstance().loadItemsAndPages();
/*  81 */           NetworkManager.getInstance().getSessions().broadcast(new com.habboproject.server.network.messages.outgoing.catalog.CatalogPublishMessageComposer(true));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPermission()
/*     */   {
/*  96 */     return "bundle_command";
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 101 */     return com.habboproject.server.config.Locale.get("command.bundle.description");
/*     */   }
/*     */   
/*     */   public boolean isAsync()
/*     */   {
/* 106 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\bundles\BundleCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */