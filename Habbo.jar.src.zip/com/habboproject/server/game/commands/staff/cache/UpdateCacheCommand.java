/*     */ package com.habboproject.server.game.commands.staff.cache;
/*     */ 
/*     */ import com.habboproject.server.api.networking.sessions.BaseSession;
/*     */ import com.habboproject.server.config.CometSettings;
/*     */ import com.habboproject.server.config.Locale;
/*     */ import com.habboproject.server.game.achievements.AchievementManager;
/*     */ import com.habboproject.server.game.catalog.CatalogManager;
/*     */ import com.habboproject.server.game.commands.CommandManager;
/*     */ import com.habboproject.server.game.effects.EffectManager;
/*     */ import com.habboproject.server.game.groups.GroupManager;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.landing.LandingManager;
/*     */ import com.habboproject.server.game.moderation.BanManager;
/*     */ import com.habboproject.server.game.moderation.ModerationManager;
/*     */ import com.habboproject.server.game.navigator.NavigatorManager;
/*     */ import com.habboproject.server.game.permissions.PermissionsManager;
/*     */ import com.habboproject.server.game.pets.PetManager;
/*     */ import com.habboproject.server.game.pets.commands.PetCommandManager;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.polls.PollManager;
/*     */ import com.habboproject.server.game.polls.types.Poll;
/*     */ import com.habboproject.server.game.quests.QuestManager;
/*     */ import com.habboproject.server.game.rooms.RoomManager;
/*     */ import com.habboproject.server.game.rooms.filter.WordFilter;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.messages.outgoing.moderation.ModToolMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.network.sessions.SessionManager;
/*     */ 
/*     */ public class UpdateCacheCommand extends com.habboproject.server.game.commands.ChatCommand
/*     */ {
/*     */   public void execute(Session client, String[] params)
/*     */   {
/*  36 */     String command = params.length == 0 ? "" : params[0];
/*     */     String str1;
/*  38 */     switch ((str1 = command).hashCode()) {case -1833928446:  if (str1.equals("effects")) break label947; break; case -1658366172:  if (str1.equals("achievements")) break label791; break; case -1354792126:  if (str1.equals("config")) break label543; break; case -1274492040:  if (str1.equals("filter")) break label594; break; case -1097462182:  if (str1.equals("locale")) break label615; break; case -1068799382:  if (str1.equals("models")) break label734; break; case -948698159:  if (str1.equals("quests")) break label772; break; case -840020942:  if (str1.equals("modpresets")) break label636; break; case 3016260:  if (str1.equals("bans")) break label424; break; case 3377875:  if (str1.equals("news")) break label558; break; case 3437364:  if (str1.equals("pets")) break label810; break; case 100526016:  if (str1.equals("items")) break label576; break; case 104263205:  if (str1.equals("music")) break label753; break; case 106848404:  if (str1.equals("polls")) break label847; break; case 555704345:  if (str1.equals("catalog")) break label442; break; case 752822871:  if (str1.equals("navigator")) break label483; break; case 1133704324:  if (str1.equals("permissions")) break label513; break; case 1291724961:  if (str1.equals("groupitems"))
/*     */         break label712; }
/*  40 */     client.send(new com.habboproject.server.network.messages.outgoing.notification.MotdNotificationMessageComposer(
/*  41 */       "Here's a list of what you can reload using the :reload <type> command!\n\n- bans\n- catalog\n- navigator\n- permissions\n- catalog\n- news\n- config\n- items\n- filter\n- locale\n- modpresets\n- groupitems\n- models\n- music\n- quests\n- achievements\n- pets\n- polls\n- effects"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */     return;
/*     */     label424:
/*  65 */     BanManager.getInstance().loadBans();
/*     */     
/*  67 */     sendNotif(Locale.get("command.reload.bans"), client);
/*  68 */     return;
/*     */     
/*     */     label442:
/*  71 */     CatalogManager.getInstance().loadItemsAndPages();
/*  72 */     CatalogManager.getInstance().loadGiftBoxes();
/*     */     
/*  74 */     NetworkManager.getInstance().getSessions().broadcast(new com.habboproject.server.network.messages.outgoing.catalog.CatalogPublishMessageComposer(true));
/*  75 */     sendNotif(Locale.get("command.reload.catalog"), client);
/*  76 */     return;
/*     */     
/*     */     label483:
/*  79 */     NavigatorManager.getInstance().loadCategories();
/*  80 */     NavigatorManager.getInstance().loadPublicRooms();
/*  81 */     NavigatorManager.getInstance().loadStaffPicks();
/*     */     
/*  83 */     sendNotif(Locale.get("command.reload.navigator"), client);
/*  84 */     return;
/*     */     
/*     */     label513:
/*  87 */     PermissionsManager.getInstance().loadRankPermissions();
/*  88 */     PermissionsManager.getInstance().loadPerks();
/*  89 */     PermissionsManager.getInstance().loadCommands();
/*     */     
/*  91 */     sendNotif(Locale.get("command.reload.permissions"), client);
/*  92 */     return;
/*     */     
/*     */     label543:
/*  95 */     CometSettings.initialize();
/*     */     
/*  97 */     sendNotif(Locale.get("command.reload.config"), client);
/*  98 */     return;
/*     */     
/*     */     label558:
/* 101 */     LandingManager.getInstance().loadArticles();
/*     */     
/* 103 */     sendNotif(Locale.get("command.reload.news"), client);
/* 104 */     return;
/*     */     
/*     */     label576:
/* 107 */     ItemManager.getInstance().loadItemDefinitions();
/*     */     
/* 109 */     sendNotif(Locale.get("command.reload.items"), client);
/* 110 */     return;
/*     */     
/*     */     label594:
/* 113 */     RoomManager.getInstance().getFilter().loadFilter();
/*     */     
/* 115 */     sendNotif(Locale.get("command.reload.filter"), client);
/* 116 */     return;
/*     */     
/*     */     label615:
/* 119 */     Locale.reload();
/* 120 */     CommandManager.getInstance().reloadAllCommands();
/*     */     
/* 122 */     sendNotif(Locale.get("command.reload.locale"), client);
/* 123 */     return;
/*     */     
/*     */     label636:
/* 126 */     ModerationManager.getInstance().loadPresets();
/*     */     
/* 128 */     sendNotif(Locale.get("command.reload.modpresets"), client);
/*     */     
/* 130 */     for (BaseSession session : NetworkManager.getInstance().getSessions().getByPlayerPermission("mod_tool")) {
/* 131 */       session.send(new ModToolMessageComposer());
/*     */     }
/* 133 */     return;
/*     */     
/*     */     label712:
/* 136 */     GroupManager.getInstance().getGroupItems().load();
/* 137 */     sendNotif(Locale.get("command.reload.groupitems"), client);
/* 138 */     return;
/*     */     
/*     */     label734:
/* 141 */     RoomManager.getInstance().loadModels();
/* 142 */     sendNotif(Locale.get("command.reload.models"), client);
/* 143 */     return;
/*     */     
/*     */     label753:
/* 146 */     ItemManager.getInstance().loadMusicData();
/* 147 */     sendNotif(Locale.get("command.reload.music"), client);
/* 148 */     return;
/*     */     
/*     */     label772:
/* 151 */     QuestManager.getInstance().loadQuests();
/* 152 */     sendNotif(Locale.get("command.reload.quests"), client);
/* 153 */     return;
/*     */     
/*     */     label791:
/* 156 */     AchievementManager.getInstance().loadAchievements();
/*     */     
/* 158 */     sendNotif(Locale.get("command.reload.achievements"), client);
/* 159 */     return;
/*     */     
/*     */     label810:
/* 162 */     PetManager.getInstance().loadPetRaces();
/* 163 */     PetManager.getInstance().loadPetSpeech();
/* 164 */     PetManager.getInstance().loadTransformablePets();
/* 165 */     PetCommandManager.getInstance().initialize();
/*     */     
/* 167 */     sendNotif(Locale.get("command.reload.pets"), client);
/* 168 */     return;
/*     */     
/*     */     label847:
/* 171 */     PollManager.getInstance().initialize();
/*     */     
/* 173 */     if (PollManager.getInstance().roomHasPoll(client.getPlayer().getEntity().getRoom().getId())) {
/* 174 */       Poll poll = PollManager.getInstance().getPollByRoomId(client.getPlayer().getEntity().getRoom().getId());
/*     */       
/* 176 */       client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.polls.InitializePollMessageComposer(poll.getPollId(), poll.getPollTitle(), poll.getThanksMessage()));
/*     */     }
/*     */     
/* 179 */     sendNotif(Locale.get("command.reload.polls"), client);
/* 180 */     return;
/*     */     
/*     */     label947:
/*     */     
/* 184 */     EffectManager.getInstance().initialize();
/*     */     
/* 186 */     sendNotif(Locale.get("command.reload.effects"), client);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAsync()
/*     */   {
/* 194 */     return true;
/*     */   }
/*     */   
/*     */   public String getPermission()
/*     */   {
/* 199 */     return "reload_command";
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 204 */     return Locale.get("command.reload.description");
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\cache\UpdateCacheCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */