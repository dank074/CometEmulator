/*    */ package com.habboproject.server.game.commands.staff.cache;
/*    */ 
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.game.groups.GroupManager;
/*    */ import com.habboproject.server.game.groups.types.GroupData;
/*    */ import com.habboproject.server.game.rooms.RoomManager;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.storage.queries.groups.GroupDao;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class ReloadGroupCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 17 */     if (params.length != 1) {
/* 18 */       return;
/*    */     }
/*    */     
/* 21 */     if (!StringUtils.isNumeric(params[0])) {
/* 22 */       return;
/*    */     }
/*    */     
/* 25 */     int groupId = Integer.parseInt(params[0]);
/*    */     
/* 27 */     GroupData groupData = GroupManager.getInstance().getData(groupId);
/* 28 */     GroupData newGroupData = GroupDao.getDataById(groupId);
/*    */     
/* 30 */     if (groupData.getRoomId() != newGroupData.getRoomId()) {
/* 31 */       if (RoomManager.getInstance().isActive(groupData.getRoomId())) {
/* 32 */         Room oldRoom = RoomManager.getInstance().get(groupData.getRoomId());
/*    */         
/* 34 */         if (oldRoom != null) {
/* 35 */           oldRoom.setIdleNow();
/*    */         }
/*    */       }
/*    */       
/* 39 */       if (RoomManager.getInstance().isActive(newGroupData.getRoomId())) {
/* 40 */         Room newRoom = RoomManager.getInstance().get(newGroupData.getRoomId());
/*    */         
/* 42 */         if (newRoom != null) {
/* 43 */           newRoom.setIdleNow();
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 48 */     groupData.setCanMembersDecorate(newGroupData.canMembersDecorate());
/* 49 */     groupData.setOwnerId(newGroupData.getOwnerId());
/* 50 */     groupData.setRoomId(newGroupData.getRoomId());
/* 51 */     groupData.setBadge(newGroupData.getBadge());
/* 52 */     groupData.setColourA(newGroupData.getColourA());
/* 53 */     groupData.setColourB(newGroupData.getColourB());
/* 54 */     groupData.setDescription(newGroupData.getDescription());
/* 55 */     groupData.setTitle(newGroupData.getTitle());
/* 56 */     groupData.setType(newGroupData.getType());
/*    */     
/* 58 */     client.send(new AlertMessageComposer(com.habboproject.server.config.Locale.getOrDefault("command.reloadgroup.done", "Group data reloaded successfully!")));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 63 */     return "reloadgroup_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 68 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isHidden()
/*    */   {
/* 73 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\cache\ReloadGroupCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */