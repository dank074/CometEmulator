/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.RoomManager;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.game.rooms.types.misc.ChatEmotionsManager;
/*    */ import com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class MakeSayCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 16 */     if (params.length < 2) { return;
/*    */     }
/* 18 */     String player = params[0];
/* 19 */     String message = merge(params, 1);
/*    */     
/* 21 */     Room room = client.getPlayer().getEntity().getRoom();
/* 22 */     PlayerEntity playerEntity = (PlayerEntity)room.getEntities().getEntityByName(player, com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER);
/*    */     
/* 24 */     room.getEntities().broadcastMessage(new TalkMessageComposer(playerEntity.getId(), message, RoomManager.getInstance().getEmotions().getEmotion(message), 0));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 29 */     return "makesay_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 34 */     return com.habboproject.server.config.Locale.get("command.makesay.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\MakeSayCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */