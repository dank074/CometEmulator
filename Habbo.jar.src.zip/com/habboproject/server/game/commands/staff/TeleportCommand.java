/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class TeleportCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] message)
/*    */   {
/* 12 */     if (client.getPlayer().getEntity().hasAttribute("teleport")) {
/* 13 */       client.getPlayer().getEntity().removeAttribute("teleport");
/* 14 */       sendNotif(Locale.get("command.teleport.disabled"), client);
/*    */     } else {
/* 16 */       client.getPlayer().getEntity().setAttribute("teleport", Boolean.valueOf(true));
/* 17 */       sendNotif(Locale.get("command.teleport.enabled"), client);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 23 */     return "teleport_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 28 */     return Locale.get("command.teleport.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\TeleportCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */