/*    */ package com.habboproject.server.game.commands.staff.fun;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class RollCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     if (params.length != 1) { return;
/*    */     }
/* 13 */     if (!StringUtils.isNumeric(params[0])) {
/* 14 */       return;
/*    */     }
/*    */     
/* 17 */     int number = Integer.parseInt(params[0]);
/*    */     
/* 19 */     if (number < 1) number = 1;
/* 20 */     if (number > 6) { number = 6;
/*    */     }
/* 22 */     client.getPlayer().getEntity().setAttribute("diceRoll", Integer.valueOf(number));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 27 */     return "roll_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 32 */     return com.habboproject.server.config.Locale.get("command.roll.description");
/*    */   }
/*    */   
/*    */   public boolean isHidden()
/*    */   {
/* 37 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\fun\RollCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */