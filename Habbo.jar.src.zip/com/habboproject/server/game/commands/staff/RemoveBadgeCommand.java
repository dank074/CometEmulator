/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class RemoveBadgeCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 12 */     if (params.length < 2) {
/* 13 */       return;
/*    */     }
/* 15 */     Session session = NetworkManager.getInstance().getSessions().getByPlayerUsername(params[0]);
/*    */     
/* 17 */     if (session != null) {
/* 18 */       session.getPlayer().getInventory().removeBadge(params[1], true);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission() {
/* 23 */     return "removebadge_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 28 */     return com.habboproject.server.config.Locale.get("command.removebadge.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\RemoveBadgeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */