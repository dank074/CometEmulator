/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.PlayerManager;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class SummonCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 14 */     if (params.length != 1) {
/* 15 */       return;
/*    */     }
/*    */     
/* 18 */     String username = params[0];
/*    */     
/* 20 */     if (!PlayerManager.getInstance().isOnline(username)) {
/* 21 */       client.send(new AlertMessageComposer(Locale.getOrDefault("command.summon.offline", "This player is not online!")));
/* 22 */       return;
/*    */     }
/*    */     
/* 25 */     Session session = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 27 */     if (session == null) { return;
/*    */     }
/* 29 */     session.send(new AlertMessageComposer(Locale.get("command.summon.summoned").replace("%summoner%", client.getPlayer().getData().getUsername())));
/* 30 */     session.send(new com.habboproject.server.network.messages.outgoing.room.engine.RoomForwardMessageComposer(client.getPlayer().getEntity().getRoom().getId()));
/*    */     
/* 32 */     session.getPlayer().bypassRoomAuth(true);
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 37 */     return "summon_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 42 */     return Locale.get("command.summon.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\SummonCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */