/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class DisconnectCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 12 */     if (params.length != 1) { return;
/*    */     }
/* 14 */     String username = params[0];
/*    */     
/* 16 */     Session session = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 18 */     if (session == null) {
/* 19 */       return;
/*    */     }
/*    */     
/* 22 */     if (session == client) {
/* 23 */       sendNotif(Locale.get("command.disconnect.himself"), client);
/* 24 */       return;
/*    */     }
/*    */     
/* 27 */     if (!session.getPlayer().getPermissions().getRank().disconnectable()) {
/* 28 */       sendNotif(Locale.get("command.disconnect.undisconnectable"), client);
/* 29 */       return;
/*    */     }
/*    */     
/* 32 */     session.disconnect();
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 37 */     return "disconnect_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 42 */     return Locale.get("command.disconnect.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\DisconnectCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */