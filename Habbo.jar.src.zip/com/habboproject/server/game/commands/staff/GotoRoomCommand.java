/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.network.messages.outgoing.room.engine.RoomForwardMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ 
/*    */ public class GotoRoomCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 12 */     if (params.length != 1) {
/* 13 */       return;
/*    */     }
/*    */     
/* 16 */     if (!StringUtils.isNumeric(params[0])) {
/* 17 */       return;
/*    */     }
/*    */     
/* 20 */     int roomId = Integer.parseInt(params[0]);
/*    */     
/* 22 */     client.send(new RoomForwardMessageComposer(roomId));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 27 */     return "gotoroom_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 32 */     return com.habboproject.server.config.Locale.get("command.gotoroom.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\GotoRoomCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */