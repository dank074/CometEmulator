/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class InvisibleCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 12 */     boolean isVisible = false;
/*    */     
/* 14 */     if (!client.getPlayer().getEntity().isVisible()) {
/* 15 */       isVisible = true;
/*    */     }
/*    */     
/* 18 */     client.send(new com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer(client.getPlayer().getEntity().getId(), Locale.get("command.invisible." + (isVisible ? "disabled" : "enabled"))));
/*    */     
/* 20 */     client.getPlayer().setInvisible(!isVisible);
/* 21 */     client.getPlayer().getEntity().updateVisibility(isVisible);
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 26 */     return "invisible_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 31 */     return Locale.get("command.invisible.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\InvisibleCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */