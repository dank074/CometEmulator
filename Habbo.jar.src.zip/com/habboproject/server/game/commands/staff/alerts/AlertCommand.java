/*    */ package com.habboproject.server.game.commands.staff.alerts;
/*    */ 
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class AlertCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     if (params.length < 2) {
/* 14 */       return;
/*    */     }
/* 16 */     Session user = NetworkManager.getInstance().getSessions().getByPlayerUsername(params[0]);
/*    */     
/* 18 */     if (user == null) {
/* 19 */       return;
/*    */     }
/* 21 */     user.send(new AlertMessageComposer(merge(params, 1)));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 26 */     return "alert_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 31 */     return com.habboproject.server.config.Locale.get("command.alert.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\alerts\AlertCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */