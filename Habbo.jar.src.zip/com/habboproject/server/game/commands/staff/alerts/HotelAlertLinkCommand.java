/*    */ package com.habboproject.server.game.commands.staff.alerts;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class HotelAlertLinkCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 12 */     if (params.length < 2) {
/* 13 */       sendNotif(Locale.getOrDefault("command.hotelalertlink.args", "This command requires at least 2 arguments!"), client);
/*    */     }
/*    */     
/* 16 */     String link = params[0];
/*    */     
/* 18 */     NetworkManager.getInstance().getSessions().broadcast(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(Locale.getOrDefault("command.hotelalertlink.title", "Alert"), merge(params, 1) + "<br><br><i> " + client.getPlayer().getData().getUsername() + "</i>", Locale.getOrDefault("command.hotelalertlink.buttontitle", "Click here"), link, ""));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 23 */     return "hotelalertlink_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 28 */     return Locale.get("command.hotelalertlink.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\alerts\HotelAlertLinkCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */