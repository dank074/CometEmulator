/*    */ package com.habboproject.server.game.commands.staff.alerts;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.HotelMaintenanceMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ public class MaintenanceCommand
/*    */   extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/*    */     int hour;
/*    */     int minute;
/* 18 */     if (params.length == 2) {
/* 19 */       int hour = Integer.parseInt(params[0]);
/* 20 */       int minute = Integer.parseInt(params[1]);
/*    */       
/* 22 */       if ((hour > 23) || (hour < 0)) {
/* 23 */         hour = 0;
/*    */       }
/* 25 */       if ((minute > 59) || (minute < 0))
/* 26 */         minute = 0;
/*    */     } else {
/* 28 */       Calendar calendar = Calendar.getInstance();
/*    */       
/* 30 */       hour = calendar.get(11);
/* 31 */       minute = calendar.get(12) + 10;
/*    */     }
/*    */     
/* 34 */     NetworkManager.getInstance().getSessions().broadcast(new HotelMaintenanceMessageComposer(hour, minute, false));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 39 */     return "maintenance_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 44 */     return Locale.get("command.maintenance.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\alerts\MaintenanceCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */