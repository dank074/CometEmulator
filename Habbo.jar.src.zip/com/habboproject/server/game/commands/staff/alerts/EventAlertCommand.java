/*    */ package com.habboproject.server.game.commands.staff.alerts;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class EventAlertCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 14 */     if (params.length == 0) {
/* 15 */       return;
/*    */     }
/*    */     
/* 18 */     com.habboproject.server.network.NetworkManager.getInstance().getSessions().broadcastEventAlert(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(Locale.get("command.eventalert.alerttitle"), String.valueOf(Locale.get("command.eventalert.message").replace("%message%", merge(params)).replace("%username%", client.getPlayer().getData().getUsername())) + "<br><br><i> " + client.getPlayer().getData().getUsername() + "</i>", Locale.get("command.eventalert.buttontitle"), "event:navigator/goto/" + client.getPlayer().getEntity().getRoom().getId(), "game_promo_small"), new com.habboproject.server.network.messages.outgoing.notification.NotificationMessageComposer("frank", Locale.get("command.eventalert.message.small"), "event:navigator/goto/" + client.getPlayer().getEntity().getRoom().getId()));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 23 */     return "eventalert_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 28 */     return Locale.get("command.eventalert.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\alerts\EventAlertCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */