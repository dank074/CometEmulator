/*    */ package com.habboproject.server.game.commands.staff.alerts;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.MotdNotificationMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class MassMotdCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] message)
/*    */   {
/* 13 */     MotdNotificationMessageComposer msg = new MotdNotificationMessageComposer(merge(message) + "\n\n- " + client.getPlayer().getData().getUsername());
/*    */     
/* 15 */     NetworkManager.getInstance().getSessions().broadcast(msg);
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 20 */     return "massmotd_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 25 */     return com.habboproject.server.config.Locale.get("command.massmotd.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\alerts\MassMotdCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */