/*    */ package com.habboproject.server.game.commands.staff.alerts;
/*    */ 
/*    */ import com.habboproject.server.config.Configuration;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class NotificationCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     String image = com.habboproject.server.boot.Comet.getServer().getConfig().get("comet.notification.avatar.prefix");
/* 14 */     String message = merge(params);
/*    */     
/* 16 */     NetworkManager.getInstance().getSessions().broadcast(new com.habboproject.server.network.messages.outgoing.notification.NotificationMessageComposer(
/* 17 */       image.replace("{0}", client.getPlayer().getData().getUsername()), message));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 22 */     return "notification_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 27 */     return com.habboproject.server.config.Locale.get("command.notification.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\alerts\NotificationCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */