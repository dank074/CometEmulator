/*    */ package com.habboproject.server.game.commands.staff.alerts;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ 
/*    */ public class HotelAlertCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] message)
/*    */   {
/* 13 */     if (message.length == 0) {
/* 14 */       return;
/*    */     }
/*    */     
/* 17 */     NetworkManager.getInstance().getSessions().broadcast(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(Locale.get("command.hotelalert.title"), merge(message) + "<br><br><i> " + client.getPlayer().getData().getUsername() + "</i>"));
/*    */   }
/*    */   
/*    */   public boolean isAsync()
/*    */   {
/* 22 */     return true;
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 27 */     return "hotelalert_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 32 */     return Locale.get("command.hotelalert.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\alerts\HotelAlertCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */