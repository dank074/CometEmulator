/*    */ package com.habboproject.server.game.commands.staff.alerts;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class RoomAlertCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     for (PlayerEntity entity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/* 14 */       entity.getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer(merge(params)));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 20 */     return "roomalert_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 25 */     return com.habboproject.server.config.Locale.get("command.roomalert.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\alerts\RoomAlertCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */