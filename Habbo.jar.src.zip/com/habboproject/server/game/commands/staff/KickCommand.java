/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.permissions.types.Rank;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class KickCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     if (params.length < 1) {
/* 14 */       return;
/*    */     }
/* 16 */     String username = params[0];
/*    */     
/* 18 */     PlayerEntity entity = (PlayerEntity)client.getPlayer().getEntity().getRoom().getEntities().getEntityByName(username, com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER);
/*    */     
/* 20 */     if (entity == null) {
/* 21 */       return;
/*    */     }
/* 23 */     if (entity.getUsername().equals(client.getPlayer().getData().getUsername())) {
/* 24 */       return;
/*    */     }
/*    */     
/* 27 */     if (!entity.getPlayer().getPermissions().getRank().roomKickable())
/*    */     {
/* 29 */       sendNotif(Locale.get("command.kick.unkickable"), client);
/* 30 */       return;
/*    */     }
/*    */     
/* 33 */     entity.kick();
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 38 */     return "kick_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 43 */     return Locale.get("command.kick.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\KickCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */