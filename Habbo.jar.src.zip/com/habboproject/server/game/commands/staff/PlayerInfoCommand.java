/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.permissions.types.Rank;
/*    */ import com.habboproject.server.game.players.components.PermissionComponent;
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class PlayerInfoCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 16 */     if (params.length != 1) { return;
/*    */     }
/* 18 */     String username = params[0];
/* 19 */     Session session = com.habboproject.server.network.NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/*    */     PlayerData playerData;
/*    */     PlayerData playerData;
/* 23 */     if ((session == null) || (session.getPlayer() == null) || (session.getPlayer().getData() == null)) {
/* 24 */       playerData = com.habboproject.server.storage.queries.player.PlayerDao.getDataByUsername(username);
/*    */     } else {
/* 26 */       playerData = session.getPlayer().getData();
/*    */     }
/*    */     
/* 29 */     if (playerData == null) { return;
/*    */     }
/* 31 */     Rank playerRank = com.habboproject.server.game.permissions.PermissionsManager.getInstance().getRank(playerData.getRank());
/*    */     
/* 33 */     if ((playerRank.modTool()) && (!client.getPlayer().getPermissions().getRank().modTool()))
/*    */     {
/* 35 */       client.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(Locale.getOrDefault("command.playerinfo.title", "Player Information") + ": " + username, Locale.getOrDefault("command.playerinfo.staff", "You cannot view the information of a staff member!")));
/* 36 */       return;
/*    */     }
/*    */     
/* 39 */     StringBuilder userInfo = new StringBuilder();
/*    */     
/* 41 */     if (client.getPlayer().getPermissions().getRank().modTool()) {
/* 42 */       userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.id", "ID") + "</b>: " + playerData.getId() + "<br>");
/*    */     }
/*    */     
/* 45 */     userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.username", "Username") + "</b>: " + playerData.getUsername() + "<br>");
/* 46 */     userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.motto", "Motto") + "</b>: " + playerData.getMotto() + "<br>");
/* 47 */     userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.gender", "Gender") + "</b>: " + (playerData.getGender().toLowerCase().equals("m") ? Locale.getOrDefault("command.playerinfo.male", "Male") : Locale.getOrDefault("command.playerinfo.female", "Female")) + "<br>");
/* 48 */     userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.status", "Status") + "</b>: " + (session == null ? Locale.getOrDefault("command.playerinfo.offline", "Offline") : Locale.getOrDefault("command.playerinfo.online", "Online")) + "<br>");
/* 49 */     userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.achievementPoints", "Achievement Points") + "</b>: " + playerData.getAchievementPoints() + "<br>");
/*    */     
/* 51 */     if (client.getPlayer().getPermissions().getRank().modTool()) {
/* 52 */       userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.rank", "Rank") + "</b>: " + playerData.getRank() + "<br><br>");
/*    */     }
/*    */     
/* 55 */     userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.currencyBalances", "Currency Balances") + "</b><br>");
/* 56 */     userInfo.append("<i>" + playerData.getCredits() + " " + Locale.getOrDefault("command.playerinfo.credits", "credits") + "</i><br>");
/*    */     
/* 58 */     if (client.getPlayer().getPermissions().getRank().modTool()) {
/* 59 */       userInfo.append("<i>" + playerData.getVipPoints() + " " + Locale.getOrDefault("command.playerinfo.diamonds", "diamonds") + "</i><br>");
/*    */     }
/*    */     
/* 62 */     userInfo.append("<i>" + playerData.getActivityPoints() + " " + Locale.getOrDefault("command.playerinfo.activityPoints", "duckets") + "</i><br><br>");
/*    */     
/*    */ 
/* 65 */     userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.roomInfo", "Room Info") + "</b><br>");
/*    */     
/* 67 */     if ((session != null) && (session.getPlayer().getEntity() != null)) {
/* 68 */       userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.roomId", "Room ID") + "</b>: " + session.getPlayer().getEntity().getRoom().getData().getId() + "<br>");
/* 69 */       userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.roomName", "Room Name") + "</b>: " + session.getPlayer().getEntity().getRoom().getData().getName() + "<br>");
/* 70 */       userInfo.append("<b>" + Locale.getOrDefault("command.playerinfo.roomOwner", "Room Owner") + "</b>: " + session.getPlayer().getEntity().getRoom().getData().getOwner() + "<br>");
/*    */     }
/* 72 */     else if (session == null) {
/* 73 */       userInfo.append("<i>" + Locale.getOrDefault("command.playerinfo.notOnline", "This player is not online!") + "</i>");
/*    */     } else {
/* 75 */       userInfo.append("<i>" + Locale.getOrDefault("command.playerinfo.notInRoom", "This player is not in a room!") + "</i>");
/*    */     }
/*    */     
/* 78 */     client.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(Locale.getOrDefault("command.playerinfo.title", "Player Information") + ": " + username, userInfo.toString()));
/*    */   }
/*    */   
/*    */   public boolean isAsync()
/*    */   {
/* 83 */     return true;
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 88 */     return "playerinfo_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 93 */     return Locale.get("command.playerinfo.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\PlayerInfoCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */