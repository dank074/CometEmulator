/*    */ package com.habboproject.server.game.commands.staff;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.permissions.types.Rank;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class RoomKickCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 15 */     for (RoomEntity entity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
/* 16 */       if (entity.getEntityType() == com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER) {
/* 17 */         PlayerEntity playerEntity = (PlayerEntity)entity;
/*    */         
/* 19 */         if (playerEntity.getPlayer().getPermissions().getRank().roomKickable()) {
/* 20 */           playerEntity.getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(Locale.get("command.roomkick.title"), merge(params)));
/* 21 */           playerEntity.kick();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 29 */     return "roomkick_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 34 */     return Locale.get("command.roomkick.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\staff\RoomKickCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */