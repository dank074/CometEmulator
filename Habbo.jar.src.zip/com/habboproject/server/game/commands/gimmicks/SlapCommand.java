/*    */ package com.habboproject.server.game.commands.gimmicks;
/*    */ 
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class SlapCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/* 11 */   private static final String[] objects = {
/* 12 */     "a large black dildo", 
/* 13 */     "a rotten fish", 
/* 14 */     "a large trout", 
/* 15 */     "a big black boot", 
/* 16 */     "the back of %g hand", 
/* 17 */     "%g floppy shlong" };
/*    */   
/*    */ 
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 22 */     if (params.length != 1) { return;
/*    */     }
/* 24 */     String slappedPlayer = params[0];
/* 25 */     String object = objects[com.habboproject.server.utilities.RandomInteger.getRandom(0, objects.length - 1)].replace("%g", client.getPlayer().getData().getGender().toLowerCase().equals("m") ? "his" : "her");
/*    */     
/* 27 */     client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer(client.getPlayer().getEntity().getId(), "* " + client.getPlayer().getData().getUsername() + " slapped " + slappedPlayer + " with " + object + " *", 34));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 32 */     return "slap_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 37 */     return com.habboproject.server.config.Locale.get("command.slap.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\gimmicks\SlapCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */