/*    */ package com.habboproject.server.game.commands.gimmicks;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class PunchCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 14 */     if (params.length != 1) { return;
/*    */     }
/* 16 */     String punchedPlayer = params[0];
/*    */     
/*    */ 
/* 19 */     RoomEntity entity = client.getPlayer().getEntity().getRoom().getEntities().getEntityByName(punchedPlayer, com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER);
/*    */     
/* 21 */     if (entity == null) { return;
/*    */     }
/* 23 */     client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer(client.getPlayer().getEntity().getId(), "* " + client.getPlayer().getData().getUsername() + " punched " + entity.getUsername() + " *", 34));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 28 */     return "punch_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 33 */     return com.habboproject.server.config.Locale.get("command.punch.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\gimmicks\PunchCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */