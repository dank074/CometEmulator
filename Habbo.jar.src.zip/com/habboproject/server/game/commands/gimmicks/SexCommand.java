/*    */ package com.habboproject.server.game.commands.gimmicks;
/*    */ 
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.network.messages.outgoing.room.avatar.ActionMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class SexCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 16 */     if (params.length != 1) { return;
/*    */     }
/* 18 */     String sexedPlayer = params[0];
/*    */     
/* 20 */     RoomEntity entity = client.getPlayer().getEntity().getRoom().getEntities().getEntityByName(sexedPlayer, com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER);
/*    */     
/* 22 */     if (entity == null) { return;
/*    */     }
/* 24 */     client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer(client.getPlayer().getEntity().getId(), "* " + client.getPlayer().getData().getUsername() + " sexed " + entity.getUsername() + " *", 34));
/* 25 */     client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new ActionMessageComposer(entity.getId(), 7));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 30 */     return "sex_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 35 */     return com.habboproject.server.config.Locale.get("command.sex.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\gimmicks\SexCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */