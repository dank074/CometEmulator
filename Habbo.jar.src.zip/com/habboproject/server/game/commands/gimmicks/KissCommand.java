/*    */ package com.habboproject.server.game.commands.gimmicks;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.network.messages.outgoing.room.avatar.ActionMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class KissCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 15 */     if (params.length != 1) { return;
/*    */     }
/* 17 */     String kissedPlayer = params[0];
/*    */     
/* 19 */     RoomEntity entity = client.getPlayer().getEntity().getRoom().getEntities().getEntityByName(kissedPlayer, com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER);
/*    */     
/* 21 */     if (entity == null) { return;
/*    */     }
/* 23 */     client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer(client.getPlayer().getEntity().getId(), "* " + client.getPlayer().getData().getUsername() + " snogs " + entity.getUsername() + " *", 34));
/* 24 */     client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new ActionMessageComposer(client.getPlayer().getEntity().getId(), 2));
/*    */   }
/*    */   
/*    */ 
/*    */   public String getPermission()
/*    */   {
/* 30 */     return "kiss_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 35 */     return com.habboproject.server.config.Locale.get("command.kiss.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\gimmicks\KissCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */