/*    */ package com.habboproject.server.game.commands;
/*    */ 
/*    */ import com.habboproject.server.api.networking.messages.IMessageComposer;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.NotificationMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public abstract class ChatCommand
/*    */ {
/*    */   public abstract void execute(Session paramSession, String[] paramArrayOfString);
/*    */   
/*    */   public abstract String getPermission();
/*    */   
/*    */   public abstract String getDescription();
/*    */   
/*    */   public final IMessageComposer success(String msg)
/*    */   {
/* 18 */     return new AdvancedAlertMessageComposer(com.habboproject.server.config.Locale.get("command.successful"), msg);
/*    */   }
/*    */   
/*    */   public static void sendNotif(String msg, Session session) {
/* 22 */     session.send(new NotificationMessageComposer("generic", msg));
/*    */   }
/*    */   
/*    */   public final String merge(String[] params) {
/* 26 */     StringBuilder stringBuilder = new StringBuilder();
/*    */     String[] arrayOfString;
/* 28 */     int j = (arrayOfString = params).length; for (int i = 0; i < j; i++) { String s = arrayOfString[i];
/* 29 */       if (!params[(params.length - 1)].equals(s)) {
/* 30 */         stringBuilder.append(s).append(" ");
/*    */       } else {
/* 32 */         stringBuilder.append(s);
/*    */       }
/*    */     }
/* 35 */     return stringBuilder.toString();
/*    */   }
/*    */   
/*    */   public String merge(String[] params, int begin) {
/* 39 */     StringBuilder mergedParams = new StringBuilder();
/*    */     
/* 41 */     for (int i = 0; i < params.length; i++) {
/* 42 */       if (i >= begin) {
/* 43 */         mergedParams.append(params[i]).append(" ");
/*    */       }
/*    */     }
/*    */     
/* 47 */     return mergedParams.toString();
/*    */   }
/*    */   
/*    */   public boolean isHidden() {
/* 51 */     return false;
/*    */   }
/*    */   
/*    */   public boolean canDisable() {
/* 55 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isAsync() {
/* 59 */     return false;
/*    */   }
/*    */   
/*    */   public static class Execution implements Runnable {
/*    */     private ChatCommand command;
/*    */     private String[] params;
/*    */     private Session session;
/*    */     
/*    */     public Execution(ChatCommand command, String[] params, Session session) {
/* 68 */       this.command = command;
/* 69 */       this.params = params;
/* 70 */       this.session = session;
/*    */     }
/*    */     
/*    */     public void run()
/*    */     {
/* 75 */       this.command.execute(this.session, this.params);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\ChatCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */