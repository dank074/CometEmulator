/*    */ package com.habboproject.server.game.commands.notifications;
/*    */ 
/*    */ import com.habboproject.server.game.commands.notifications.types.Notification;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.storage.queries.system.NotificationCommandsDao;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationManager
/*    */ {
/*    */   private Map<String, Notification> notifications;
/* 14 */   private Logger log = Logger.getLogger(NotificationManager.class.getName());
/*    */   
/*    */   public NotificationManager() {
/* 17 */     this.notifications = NotificationCommandsDao.getAll();
/*    */     
/* 19 */     this.log.info("Loaded " + this.notifications.size() + " notification commands");
/*    */   }
/*    */   
/*    */   public boolean isNotificationExecutor(String text, int rank) {
/* 23 */     return (this.notifications.containsKey(text.substring(1))) && (((Notification)this.notifications.get(text.substring(1))).getMinRank() <= rank);
/*    */   }
/*    */   
/*    */   public void execute(Player player, String command) {
/* 27 */     Notification notification = (Notification)this.notifications.get(command);
/*    */     
/* 29 */     if (notification == null) {
/* 30 */       return;
/*    */     }
/* 32 */     notification.execute(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\notifications\NotificationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */