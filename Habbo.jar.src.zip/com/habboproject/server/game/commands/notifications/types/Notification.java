/*    */ package com.habboproject.server.game.commands.notifications.types;
/*    */ 
/*    */ import com.habboproject.server.boot.Comet;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class Notification
/*    */ {
/*    */   private String trigger;
/*    */   private String text;
/*    */   private NotificationType type;
/*    */   private int minRank;
/*    */   private int coolDown;
/*    */   
/*    */   public Notification(ResultSet data) throws SQLException
/*    */   {
/* 20 */     this.trigger = data.getString("name");
/* 21 */     this.text = data.getString("text");
/* 22 */     this.type = NotificationType.valueOf(data.getString("type").toUpperCase());
/* 23 */     this.minRank = data.getInt("min_rank");
/* 24 */     this.coolDown = data.getInt("cooldown");
/*    */   }
/*    */   
/*    */   public void execute(Player player) {
/* 28 */     if (player.getNotifCooldown() + this.coolDown >= Comet.getTime()) {
/* 29 */       return;
/*    */     }
/*    */     
/* 32 */     switch (this.type) {
/*    */     case GLOBAL: 
/* 34 */       NetworkManager.getInstance().getSessions().broadcast(new AdvancedAlertMessageComposer(this.text + "\n\n-" + player.getData().getUsername()));
/* 35 */       break;
/*    */     
/*    */     case LOCAL: 
/* 38 */       player.getSession().send(new AdvancedAlertMessageComposer(this.text));
/*    */     }
/*    */     
/*    */     
/* 42 */     player.setNotifCooldown((int)Comet.getTime());
/*    */   }
/*    */   
/*    */   public String getTrigger() {
/* 46 */     return this.trigger;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 50 */     return this.text;
/*    */   }
/*    */   
/*    */   public NotificationType getType() {
/* 54 */     return this.type;
/*    */   }
/*    */   
/*    */   public int getMinRank() {
/* 58 */     return this.minRank;
/*    */   }
/*    */   
/*    */   public int getCoolDown() {
/* 62 */     return this.coolDown;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\notifications\types\Notification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */