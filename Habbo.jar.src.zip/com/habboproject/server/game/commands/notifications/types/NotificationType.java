package com.habboproject.server.game.commands.notifications.types;

public enum NotificationType
{
  GLOBAL,  LOCAL;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\notifications\types\NotificationType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */