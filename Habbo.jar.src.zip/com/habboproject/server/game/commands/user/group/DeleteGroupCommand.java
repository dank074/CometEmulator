/*     */ package com.habboproject.server.game.commands.user.group;
/*     */ 
/*     */ import com.habboproject.server.config.Locale;
/*     */ import com.habboproject.server.game.groups.GroupManager;
/*     */ import com.habboproject.server.game.groups.types.Group;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemWall;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.RoomData;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DeleteGroupCommand extends com.habboproject.server.game.commands.ChatCommand
/*     */ {
/*     */   public void execute(Session client, String[] params)
/*     */   {
/*  23 */     if ((client.getPlayer().getId() != client.getPlayer().getEntity().getRoom().getData().getOwnerId()) && (!client.getPlayer().getPermissions().getRank().roomFullControl())) {
/*  24 */       client.send(new AlertMessageComposer(Locale.getOrDefault("command.deletegroup.permission", "You don't have permission to delete this group!")));
/*  25 */       return;
/*     */     }
/*     */     
/*  28 */     if ((!client.getPlayer().isDeletingGroup()) || (com.habboproject.server.boot.Comet.getTime() - client.getPlayer().getDeletingGroupAttempt() >= 30L)) {
/*  29 */       client.send(new AlertMessageComposer(Locale.getOrDefault("command.deletegroup.confirm", "Are you sure you want to delete this group? All items in the room will be returned to the rightful owner and the group will be deleted forever.<br><br>Use the command :deletegroup again to confirm!")));
/*     */       
/*  31 */       client.getPlayer().setDeletingGroup(true);
/*  32 */       client.getPlayer().setDeletingGroupAttempt(com.habboproject.server.boot.Comet.getTime());
/*  33 */       return;
/*     */     }
/*     */     
/*  36 */     Room room = client.getPlayer().getEntity().getRoom();
/*     */     
/*  38 */     if (GroupManager.getInstance().getGroupByRoomId(room.getId()) != null) {
/*  39 */       Group group = GroupManager.getInstance().getGroupByRoomId(room.getId());
/*     */       
/*  41 */       for (Integer groupMemberId : group.getMembershipComponent().getMembers().keySet()) {
/*  42 */         Session groupMemberSession = com.habboproject.server.network.NetworkManager.getInstance().getSessions().getByPlayerId(groupMemberId.intValue());
/*     */         
/*  44 */         List<RoomItem> floorItemsOwnedByPlayer = com.google.common.collect.Lists.newArrayList();
/*     */         
/*  46 */         if (groupMemberId.intValue() != group.getData().getOwnerId()) {
/*  47 */           for (RoomItemFloor floorItem : room.getItems().getFloorItems().values()) {
/*  48 */             if (floorItem.getOwner() == groupMemberId.intValue()) {
/*  49 */               floorItemsOwnedByPlayer.add(floorItem);
/*     */             }
/*     */           }
/*     */           
/*  53 */           for (RoomItemWall wallItem : room.getItems().getWallItems().values()) {
/*  54 */             if (wallItem.getOwner() == groupMemberId.intValue()) {
/*  55 */               floorItemsOwnedByPlayer.add(wallItem);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*  60 */         if ((groupMemberSession != null) && (groupMemberSession.getPlayer() != null)) {
/*  61 */           groupMemberSession.getPlayer().getGroups().remove(new Integer(group.getId()));
/*     */           
/*  63 */           if (groupMemberSession.getPlayer().getData().getFavouriteGroup() == group.getId()) {
/*  64 */             groupMemberSession.getPlayer().getData().setFavouriteGroup(0);
/*     */           }
/*     */           
/*  67 */           for (RoomItem roomItem : floorItemsOwnedByPlayer) {
/*  68 */             if ((roomItem instanceof RoomItemFloor)) {
/*  69 */               room.getItems().removeItem((RoomItemFloor)roomItem, groupMemberSession);
/*  70 */             } else if ((roomItem instanceof RoomItemWall))
/*  71 */               room.getItems().removeItem((RoomItemWall)roomItem, groupMemberSession, true);
/*     */           }
/*     */         } else {
/*  74 */           for (RoomItem roomItem : floorItemsOwnedByPlayer) {
/*  75 */             com.habboproject.server.storage.queries.rooms.RoomItemDao.removeItemFromRoom(roomItem.getId(), groupMemberId.intValue());
/*     */           }
/*     */         }
/*     */         
/*  79 */         floorItemsOwnedByPlayer.clear();
/*     */       }
/*     */       
/*  82 */       client.send(new AlertMessageComposer(Locale.getOrDefault("command.deletegroup.done", "The group was deleted successfully.")));
/*  83 */       GroupManager.getInstance().removeGroup(group.getId());
/*     */       
/*  85 */       room.setGroup(null);
/*     */       
/*  87 */       room.getData().setGroupId(0);
/*  88 */       room.getData().save();
/*     */       
/*  90 */       room.setIdleNow();
/*     */     } else {
/*  92 */       client.send(new AlertMessageComposer(Locale.getOrDefault("command.deletegroup.nogroup", "This room doesn't have a group to delete!")));
/*     */     }
/*     */   }
/*     */   
/*     */   public String getPermission()
/*     */   {
/*  98 */     return "deletegroup_command";
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 103 */     return Locale.get("command.deletegroup.description");
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\group\DeleteGroupCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */