/*    */ package com.habboproject.server.game.commands.user.fun;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.players.types.PlayerSettings;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class EnableEventAlertCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     if ((client == null) || (client.getPlayer() == null) || (client.getPlayer().getSettings() == null)) {
/* 14 */       return;
/*    */     }
/*    */     
/* 17 */     client.getPlayer().getSettings().setEnableEventNotif(true);
/*    */     
/* 19 */     sendNotif(Locale.get("command.enableeventnotif.txt"), client);
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 24 */     return "enableeventnotif_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 29 */     return Locale.get("command.enableeventnotif.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\fun\EnableEventAlertCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */