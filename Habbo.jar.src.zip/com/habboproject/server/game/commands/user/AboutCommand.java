/*    */ package com.habboproject.server.game.commands.user;
/*    */ 
/*    */ import com.habboproject.server.config.CometSettings;
/*    */ import com.habboproject.server.game.GameCycle;
/*    */ import com.habboproject.server.game.permissions.types.Rank;
/*    */ import com.habboproject.server.game.players.components.PermissionComponent;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.utilities.CometStats;
/*    */ import java.text.NumberFormat;
/*    */ 
/*    */ public class AboutCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] message)
/*    */   {
/* 17 */     StringBuilder about = new StringBuilder();
/* 18 */     NumberFormat format = NumberFormat.getInstance();
/*    */     
/* 20 */     CometStats cometStats = CometStats.get();
/*    */     
/* 22 */     boolean aboutDetailed = client.getPlayer().getPermissions().getRank().aboutDetailed();
/* 23 */     boolean aboutStats = client.getPlayer().getPermissions().getRank().aboutStats();
/*    */     
/* 25 */     if ((CometSettings.aboutShowRoomsActive) || (CometSettings.aboutShowRoomsActive) || (CometSettings.aboutShowUptime) || (aboutDetailed)) {
/* 26 */       about.append("<b>Server Status</b><br>");
/*    */       
/* 28 */       if ((CometSettings.aboutShowPlayersOnline) || (aboutDetailed)) {
/* 29 */         about.append("Users online: " + format.format(cometStats.getPlayers()) + "<br>");
/*    */       }
/* 31 */       if ((CometSettings.aboutShowRoomsActive) || (aboutDetailed)) {
/* 32 */         about.append("Active rooms: " + format.format(cometStats.getRooms()) + "<br>");
/*    */       }
/* 34 */       if ((CometSettings.aboutShowUptime) || (aboutDetailed)) {
/* 35 */         about.append("Uptime: " + cometStats.getUptime() + "<br>");
/*    */       }
/* 37 */       about.append("Client version: " + Session.CLIENT_VERSION + "<br>");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 52 */     if (aboutStats) {
/* 53 */       about.append("<br><br><b>Hotel Stats</b><br>");
/* 54 */       about.append("Online record: " + GameCycle.getInstance().getOnlineRecord() + "<br>");
/* 55 */       about.append("Record since last reboot: " + GameCycle.getInstance().getCurrentOnlineRecord() + " ");
/*    */     }
/*    */     
/* 58 */     client.send(new AdvancedAlertMessageComposer(
/* 59 */       "Aurora Server - " + com.habboproject.server.boot.Comet.getBuild(), 
/* 60 */       about.toString(), 
/* 61 */       CometSettings.aboutImg));
/*    */   }
/*    */   
/*    */ 
/*    */   public String getPermission()
/*    */   {
/* 67 */     return "about_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 72 */     return com.habboproject.server.config.Locale.get("command.about.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\AboutCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */