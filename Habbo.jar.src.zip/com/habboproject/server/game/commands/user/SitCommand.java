/*    */ package com.habboproject.server.game.commands.user;
/*    */ 
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntityStatus;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class SitCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     PlayerEntity playerEntity = client.getPlayer().getEntity();
/* 14 */     if (!playerEntity.hasStatus(RoomEntityStatus.SIT)) {
/* 15 */       double height = 0.5D;
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 21 */       int rotation = playerEntity.getBodyRotation();
/*    */       
/* 23 */       switch (rotation) {
/*    */       case 1: 
/* 25 */         rotation++;
/* 26 */         break;
/*    */       
/*    */       case 3: 
/* 29 */         rotation++;
/* 30 */         break;
/*    */       
/*    */       case 5: 
/* 33 */         rotation++;
/*    */       }
/*    */       
/*    */       
/* 37 */       playerEntity.addStatus(RoomEntityStatus.SIT, String.valueOf(height));
/* 38 */       playerEntity.setBodyRotation(rotation);
/* 39 */       playerEntity.markNeedsUpdate();
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 45 */     return "sit_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 50 */     return com.habboproject.server.config.Locale.get("command.sit.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\SitCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */