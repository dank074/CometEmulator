/*    */ package com.habboproject.server.game.commands.user;
/*    */ 
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CometCommand
/*    */   extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] message) {}
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 17 */     return "dev";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 22 */     return "";
/*    */   }
/*    */   
/*    */   public boolean isHidden()
/*    */   {
/* 27 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\CometCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */