/*    */ package com.habboproject.server.game.commands.user;
/*    */ 
/*    */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.components.PetComponent;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.messages.outgoing.user.inventory.PetInventoryMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.storage.queries.bots.PlayerBotDao;
/*    */ import com.habboproject.server.storage.queries.pets.PetDao;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class EmptyCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 17 */     if (params.length != 1) {
/* 18 */       client.getPlayer().getInventory().getFloorItems().clear();
/* 19 */       client.getPlayer().getInventory().getWallItems().clear();
/*    */       
/* 21 */       com.habboproject.server.storage.queries.player.inventory.InventoryDao.clearInventory(client.getPlayer().getId());
/*    */       
/* 23 */       sendNotif(Locale.getOrDefault("command.empty.emptied", "Your inventory was cleared."), client);
/*    */     } else { String str;
/* 25 */       switch ((str = params[0]).hashCode()) {case 3029900:  if (str.equals("bots")) break;  case 3437364:  if ((goto 222) || (!str.equals("pets"))) {
/*    */           break label222;
/*    */         }
/*    */       
/*    */ 
/*    */       default: 
/* 31 */         PetDao.deletePets(client.getPlayer().getId());
/* 32 */         client.getPlayer().getPets().clearPets();
/*    */         
/* 34 */         client.send(new PetInventoryMessageComposer(client.getPlayer().getPets().getPets()));
/*    */         
/* 36 */         sendNotif(Locale.getOrDefault("command.empty.emptied_pets", "Your inventory was cleared."), client);
/* 37 */         return;
/*    */       }
/*    */       
/* 40 */       PlayerBotDao.deleteBots(client.getPlayer().getId());
/* 41 */       client.getPlayer().getBots().clearBots();
/* 42 */       client.send(new com.habboproject.server.network.messages.outgoing.user.inventory.BotInventoryMessageComposer());
/*    */       
/* 44 */       sendNotif(Locale.getOrDefault("command.empty.emptied_bots", "Your inventory was cleared."), client);
/* 45 */       return;
/*    */     }
/*    */     
/*    */     label222:
/* 49 */     client.send(new com.habboproject.server.network.messages.outgoing.user.inventory.UpdateInventoryMessageComposer());
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 54 */     return "empty_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 59 */     return Locale.get("command.empty.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\EmptyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */