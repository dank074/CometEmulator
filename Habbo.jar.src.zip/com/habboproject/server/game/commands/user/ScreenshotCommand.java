/*    */ package com.habboproject.server.game.commands.user;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ 
/*    */ public class ScreenshotCommand
/*    */   extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params) {}
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 15 */     return "dev";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 20 */     return Locale.getOrDefault("command.screenshot.description", "Takes a screenshot of the room you're in.");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\ScreenshotCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */