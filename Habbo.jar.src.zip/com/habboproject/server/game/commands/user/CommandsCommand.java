/*    */ package com.habboproject.server.game.commands.user;
/*    */ 
/*    */ import com.habboproject.server.api.commands.CommandInfo;
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.game.commands.CommandManager;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.modules.ModuleManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ public class CommandsCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 17 */     StringBuilder list = new StringBuilder();
/*    */     
/* 19 */     for (Map.Entry<String, CommandInfo> commandInfoEntry : ModuleManager.getInstance().getEventHandler().getCommands().entrySet()) {
/* 20 */       if ((client.getPlayer().getPermissions().hasCommand(((CommandInfo)commandInfoEntry.getValue()).getPermission())) || (((CommandInfo)commandInfoEntry.getValue()).getPermission().isEmpty())) {
/* 21 */         list.append((String)commandInfoEntry.getKey() + " - " + ((CommandInfo)commandInfoEntry.getValue()).getDescription() + "\n");
/*    */       }
/*    */     }
/*    */     
/* 25 */     for (Map.Entry<String, ChatCommand> command : CommandManager.getInstance().getChatCommands().entrySet()) {
/* 26 */       if (!((ChatCommand)command.getValue()).isHidden())
/*    */       {
/* 28 */         if (client.getPlayer().getPermissions().hasCommand(((ChatCommand)command.getValue()).getPermission())) {
/* 29 */           list.append(((String)command.getKey()).split(",")[0] + " - " + ((ChatCommand)command.getValue()).getDescription() + "\n");
/*    */         }
/*    */       }
/*    */     }
/* 33 */     client.send(new com.habboproject.server.network.messages.outgoing.notification.MotdNotificationMessageComposer(Locale.get("command.commands.title") + "\n================================================\n" + list.toString()));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 38 */     return "commands_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 43 */     return Locale.get("command.commands.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\CommandsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */