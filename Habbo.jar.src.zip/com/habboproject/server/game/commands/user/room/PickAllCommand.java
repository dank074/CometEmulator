/*    */ package com.habboproject.server.game.commands.user.room;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemWall;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PickAllCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] message)
/*    */   {
/* 18 */     Room room = client.getPlayer().getEntity().getRoom();
/*    */     
/* 20 */     if ((room == null) || (!room.getData().getOwner().equals(client.getPlayer().getData().getUsername()))) {
/* 21 */       return;
/*    */     }
/*    */     
/* 24 */     List<RoomItem> itemsToRemove = new ArrayList();
/*    */     
/* 26 */     itemsToRemove.addAll(room.getItems().getFloorItems().values());
/* 27 */     itemsToRemove.addAll(room.getItems().getWallItems().values());
/*    */     
/* 29 */     for (RoomItem item : itemsToRemove) {
/* 30 */       if ((item instanceof RoomItemFloor)) {
/* 31 */         room.getItems().removeItem((RoomItemFloor)item, client);
/* 32 */       } else if ((item instanceof RoomItemWall)) {
/* 33 */         room.getItems().removeItem((RoomItemWall)item, client, true);
/*    */       }
/*    */     }
/*    */     
/* 37 */     itemsToRemove.clear();
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 42 */     return "pickall_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 47 */     return com.habboproject.server.config.Locale.get("command.pickall.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\room\PickAllCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */