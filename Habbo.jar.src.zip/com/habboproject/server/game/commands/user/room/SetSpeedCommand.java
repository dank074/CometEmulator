/*    */ package com.habboproject.server.game.commands.user.room;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class SetSpeedCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 12 */     if (params.length != 1) {
/* 13 */       return;
/*    */     }
/*    */     
/* 16 */     if ((!org.apache.commons.lang.StringUtils.isNumeric(params[0])) || (params[0].length() >= 10)) { return;
/*    */     }
/* 18 */     if ((client.getPlayer().getEntity() != null) && 
/* 19 */       (client.getPlayer().getEntity().getRoom() != null)) {
/* 20 */       if ((!client.getPlayer().getEntity().getRoom().getRights().hasRights(client.getPlayer().getId())) && (!client.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 21 */         return;
/*    */       }
/*    */       
/* 24 */       int speed = Integer.parseInt(params[0]);
/*    */       
/* 26 */       if (speed < 0) {
/* 27 */         speed = 0;
/* 28 */       } else if (speed > 20) {
/* 29 */         speed = 20;
/*    */       }
/*    */       
/* 32 */       client.getPlayer().getEntity().getRoom().setAttribute("customRollerSpeed", Integer.valueOf(speed));
/* 33 */       sendNotif(com.habboproject.server.config.Locale.get("command.setspeed.set").replace("%s", speed), client);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 39 */     return "setspeed_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 44 */     return com.habboproject.server.config.Locale.get("command.setspeed.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\room\SetSpeedCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */