/*    */ package com.habboproject.server.game.commands.user.room;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.RoomManager;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.RoomData;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import com.habboproject.server.game.rooms.types.components.RightsComponent;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class UnloadCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 15 */     Room room = client.getPlayer().getEntity().getRoom();
/*    */     
/* 17 */     if ((room == null) || (!room.getRights().hasRights(client.getPlayer().getId()))) { return;
/*    */     }
/* 19 */     room.getData().save();
/* 20 */     room.getItems().commit();
/*    */     
/* 22 */     RoomManager.getInstance().forceUnload(room.getId());
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 27 */     return "unloadroom_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 32 */     return com.habboproject.server.config.Locale.get("command.unloadroom.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\room\UnloadCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */