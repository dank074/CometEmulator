/*    */ package com.habboproject.server.game.commands.user.room;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.RoomManager;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.RoomData;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import com.habboproject.server.game.rooms.types.components.RightsComponent;
/*    */ import com.habboproject.server.network.messages.outgoing.room.engine.RoomForwardMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.threads.CometThread;
/*    */ import com.habboproject.server.threads.ThreadManager;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ReloadCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 23 */     Room room = client.getPlayer().getEntity().getRoom();
/*    */     
/* 25 */     if ((room == null) || (!room.getRights().hasRights(client.getPlayer().getId()))) { return;
/*    */     }
/* 27 */     final int roomId = room.getId();
/*    */     
/* 29 */     final List<Player> players = Lists.newArrayList();
/* 30 */     for (PlayerEntity entity : room.getEntities().getPlayerEntities()) {
/* 31 */       players.add(entity.getPlayer());
/*    */     }
/*    */     
/* 34 */     room.getData().save();
/* 35 */     room.getItems().commit();
/*    */     
/* 37 */     RoomManager.getInstance().forceUnload(roomId);
/*    */     
/* 39 */     ThreadManager.getInstance().execute(new CometThread()
/*    */     {
/*    */       public void run() {
/*    */         try {
/* 43 */           Thread.sleep(1000L);
/*    */         }
/*    */         catch (InterruptedException localInterruptedException) {}
/*    */         
/*    */ 
/* 48 */         for (Player player : players) {
/* 49 */           if ((player != null) && (player.getSession() != null))
/*    */           {
/*    */ 
/* 52 */             player.getSession().send(new RoomForwardMessageComposer(roomId));
/*    */           }
/*    */         }
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   public String getPermission() {
/* 60 */     return "reloadroom_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 65 */     return com.habboproject.server.config.Locale.get("command.reloadroom.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\room\ReloadCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */