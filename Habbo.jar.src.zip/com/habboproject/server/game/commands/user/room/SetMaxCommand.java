/*    */ package com.habboproject.server.game.commands.user.room;
/*    */ 
/*    */ import com.habboproject.server.config.CometSettings;
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.RoomData;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class SetMaxCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 14 */     if ((params.length != 1) || (!org.apache.commons.lang.StringUtils.isNumeric(params[0]))) {
/* 15 */       sendNotif(Locale.get("command.setmax.invalid"), client);
/* 16 */       return;
/*    */     }
/*    */     
/* 19 */     Room room = client.getPlayer().getEntity().getRoom();
/* 20 */     boolean hasRights = room.getRights().hasRights(client.getPlayer().getId());
/* 21 */     boolean isStaff = client.getPlayer().getPermissions().getRank().roomFullControl();
/*    */     
/* 23 */     if ((hasRights) || (isStaff)) {
/* 24 */       int maxPlayers = Integer.parseInt(params[0]);
/*    */       
/* 26 */       if (((maxPlayers > CometSettings.roomMaxPlayers) && (!isStaff)) || (maxPlayers < 1)) {
/* 27 */         sendNotif(Locale.get("command.setmax.toomany").replace("%i", CometSettings.roomMaxPlayers), client);
/* 28 */         return;
/*    */       }
/*    */       
/* 31 */       room.getData().setMaxUsers(maxPlayers);
/*    */       try
/*    */       {
/* 34 */         room.getData().save();
/*    */         
/* 36 */         sendNotif(Locale.get("command.setmax.done").replace("%i", maxPlayers), client);
/* 37 */         room.getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.engine.RoomDataMessageComposer(room));
/*    */       }
/*    */       catch (Exception localException) {}
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public String getPermission()
/*    */   {
/* 46 */     return "setmax_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 51 */     return Locale.get("command.setmax.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\room\SetMaxCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */