/*    */ package com.habboproject.server.game.commands.user.settings;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.RoomData;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class EnableCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     Room room = client.getPlayer().getEntity().getRoom();
/*    */     
/* 15 */     if ((room.getData().getOwnerId() != client.getPlayer().getId()) && (!client.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 16 */       return;
/*    */     }
/*    */     
/* 19 */     if (params.length != 1) {
/* 20 */       return;
/*    */     }
/*    */     
/* 23 */     String command = !params[0].contains(":") ? ":" + params[0] : params[0];
/*    */     
/* 25 */     ChatCommand chatCommand = com.habboproject.server.game.commands.CommandManager.getInstance().get(command);
/* 26 */     if (chatCommand != null) {
/* 27 */       if (room.getData().getDisabledCommands().contains(chatCommand.getPermission())) {
/* 28 */         room.getData().getDisabledCommands().remove(chatCommand.getPermission());
/* 29 */         room.getData().save();
/* 30 */         sendNotif(Locale.get("command.enablecommand.success"), client);
/*    */       } else {
/* 32 */         client.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(Locale.get("command.enablecommand.error")));
/*    */       }
/*    */     } else {
/* 35 */       client.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(Locale.get("command.enablecommand.error")));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 41 */     return "enablecommand_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 46 */     return Locale.get("command.enablecommand.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\settings\EnableCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */