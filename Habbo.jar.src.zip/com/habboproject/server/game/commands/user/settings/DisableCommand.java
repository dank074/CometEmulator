/*    */ package com.habboproject.server.game.commands.user.settings;
/*    */ 
/*    */ import com.habboproject.server.game.commands.ChatCommand;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.RoomData;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class DisableCommand extends ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     Room room = client.getPlayer().getEntity().getRoom();
/*    */     
/* 15 */     if ((room.getData().getOwnerId() != client.getPlayer().getId()) && (!client.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 16 */       return;
/*    */     }
/*    */     
/* 19 */     if (params.length != 1) {
/* 20 */       return;
/*    */     }
/*    */     
/* 23 */     String command = !params[0].contains(":") ? ":" + params[0] : params[0];
/*    */     
/* 25 */     ChatCommand chatCommand = com.habboproject.server.game.commands.CommandManager.getInstance().get(command);
/*    */     
/* 27 */     if (chatCommand != null) {
/* 28 */       if (!client.getPlayer().getPermissions().hasCommand(chatCommand.getPermission())) {
/* 29 */         client.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(com.habboproject.server.config.Locale.get("command.disablecommand.error")));
/* 30 */         return;
/*    */       }
/*    */       
/* 33 */       if (!room.getData().getDisabledCommands().contains(chatCommand.getPermission())) {
/* 34 */         room.getData().getDisabledCommands().add(chatCommand.getPermission());
/* 35 */         room.getData().save();
/*    */         
/* 37 */         sendNotif(com.habboproject.server.config.Locale.get("command.disablecommand.success"), client);
/*    */       } else {
/* 39 */         client.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer("This command is already disabled"));
/*    */       }
/*    */     } else {
/* 42 */       client.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(com.habboproject.server.config.Locale.get("command.disablecommand.error")));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 48 */     return "disablecommand_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 53 */     return com.habboproject.server.config.Locale.get("command.disablecommand.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\settings\DisableCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */