/*    */ package com.habboproject.server.game.commands.user.settings;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.players.types.PlayerSettings;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class ToggleFriendsCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     if (client.getPlayer().getSettings().getAllowFriendRequests()) {
/* 12 */       client.getPlayer().getSettings().setAllowFriendRequests(false);
/* 13 */       sendNotif(com.habboproject.server.config.Locale.getOrDefault("command.togglefriends.disabled", "You have disabled friend requests."), client);
/*    */     } else {
/* 15 */       client.getPlayer().getSettings().setAllowFriendRequests(true);
/* 16 */       sendNotif(com.habboproject.server.config.Locale.getOrDefault("command.togglefriends.enabled", "You have enabled friend requests."), client);
/*    */     }
/*    */     
/*    */ 
/* 20 */     com.habboproject.server.storage.queries.player.PlayerDao.saveAllowFriendRequests(client.getPlayer().getSettings().getAllowFriendRequests(), client.getPlayer().getId());
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 25 */     return "togglefriends_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 30 */     return com.habboproject.server.config.Locale.get("command.togglefriends.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\settings\ToggleFriendsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */