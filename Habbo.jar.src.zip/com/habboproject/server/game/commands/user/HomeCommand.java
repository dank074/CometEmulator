/*    */ package com.habboproject.server.game.commands.user;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.players.types.PlayerSettings;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class HomeCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     if (client.getPlayer().getSettings().getHomeRoom() > 0) {
/* 12 */       client.send(new com.habboproject.server.network.messages.outgoing.room.engine.RoomForwardMessageComposer(client.getPlayer().getSettings().getHomeRoom()));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 18 */     return "home_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 23 */     return com.habboproject.server.config.Locale.get("command.home.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\user\HomeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */