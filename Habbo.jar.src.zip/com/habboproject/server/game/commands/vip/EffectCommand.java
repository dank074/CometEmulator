/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.game.effects.EffectManager;
/*    */ import com.habboproject.server.game.effects.types.EffectItem;
/*    */ import com.habboproject.server.game.players.components.EffectComponent;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class EffectCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 16 */     if (params.length == 0) {
/* 17 */       return;
/*    */     }
/*    */     try
/*    */     {
/* 21 */       int effectId = Integer.parseInt(params[0]);
/*    */       
/* 23 */       EffectItem effectItem = null;
/* 24 */       if (EffectManager.getInstance().getEffects().containsKey(Integer.valueOf(effectId))) {
/* 25 */         effectItem = (EffectItem)EffectManager.getInstance().getEffects().get(Integer.valueOf(effectId));
/*    */       }
/*    */       
/* 28 */       if (effectItem != null) {
/* 29 */         if ((effectItem.isFurniEffect()) && (!client.getPlayer().getEffectComponent().hasEffect(effectId))) {
/* 30 */           sendNotif("Você não tem permissão para usar este efeito!", client);
/* 31 */           return;
/*    */         }
/* 33 */         if ((effectItem.isBuyableEffect()) && (!client.getPlayer().getEffectComponent().hasEffect(effectId))) {
/* 34 */           sendNotif("Você não tem permissão para usar este efeito!", client);
/* 35 */           return;
/*    */         }
/* 37 */         if (effectItem.getMinRank() > client.getPlayer().getPermissions().getRank().getId()) {
/* 38 */           sendNotif("Você não tem permissão para usar este efeito!", client); return;
/*    */         }
/*    */       }
/*    */       
/*    */       PlayerEntity entity;
/*    */       
/* 44 */       if ((entity = client.getPlayer().getEntity()).getCurrentEffect() != null) {
/* 45 */         if ((entity.getGameTeam() != null) && (entity.getGameTeam() != com.habboproject.server.game.rooms.types.components.games.GameTeam.NONE)) {
/* 46 */           return;
/*    */         }
/* 48 */         if (entity.getCurrentEffect().isItemEffect()) {
/* 49 */           return;
/*    */         }
/*    */       }
/*    */       
/* 53 */       entity.applyEffect(new PlayerEffect(effectId, 0));
/*    */     }
/*    */     catch (Exception e) {
/* 56 */       sendNotif(com.habboproject.server.config.Locale.get("command.enable.invalidid"), client);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 62 */     return "enable_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 67 */     return com.habboproject.server.config.Locale.get("command.enable.description");
/*    */   }
/*    */   
/*    */   public boolean canDisable()
/*    */   {
/* 72 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\EffectCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */