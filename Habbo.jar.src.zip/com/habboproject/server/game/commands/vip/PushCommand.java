/*     */ package com.habboproject.server.game.commands.vip;
/*     */ 
/*     */ import com.habboproject.server.config.Locale;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.models.RoomModel;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.Square;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.types.EntityPathfinder;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PushCommand extends com.habboproject.server.game.commands.ChatCommand
/*     */ {
/*     */   public void execute(Session client, String[] params)
/*     */   {
/*  19 */     if (params.length == 0) {
/*  20 */       sendNotif(Locale.get("command.push.invalidusername"), client);
/*  21 */       return;
/*     */     }
/*     */     
/*  24 */     if ((client.getPlayer().getEntity().isRoomMuted()) || (client.getPlayer().getEntity().getRoom().getRights().hasMute(client.getPlayer().getId()))) {
/*  25 */       return;
/*     */     }
/*     */     
/*  28 */     String username = params[0];
/*  29 */     Session user = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*     */     
/*  31 */     if (user == null) {
/*  32 */       return;
/*     */     }
/*     */     
/*  35 */     if (user.getPlayer().getEntity() == null) {
/*  36 */       return;
/*     */     }
/*     */     
/*  39 */     if (user == client) {
/*  40 */       sendNotif(Locale.get("command.push.playerhimself"), client);
/*  41 */       return;
/*     */     }
/*     */     
/*  44 */     if (user.getPlayer().getEntity().isOverriden()) {
/*  45 */       return;
/*     */     }
/*     */     
/*  48 */     int posX = user.getPlayer().getEntity().getPosition().getX();
/*  49 */     int posY = user.getPlayer().getEntity().getPosition().getY();
/*  50 */     int playerX = client.getPlayer().getEntity().getPosition().getX();
/*  51 */     int playerY = client.getPlayer().getEntity().getPosition().getY();
/*  52 */     int rot = client.getPlayer().getEntity().getBodyRotation();
/*     */     
/*  54 */     if ((Math.abs(posX - playerX) < 2) && (Math.abs(posY - playerY) < 2)) {
/*  55 */       switch (rot) {
/*     */       case 4: 
/*  57 */         posY++;
/*  58 */         break;
/*     */       
/*     */       case 0: 
/*  61 */         posY--;
/*  62 */         break;
/*     */       
/*     */       case 6: 
/*  65 */         posX--;
/*  66 */         break;
/*     */       
/*     */       case 2: 
/*  69 */         posX++;
/*  70 */         break;
/*     */       
/*     */       case 3: 
/*  73 */         posX++;
/*  74 */         posY++;
/*  75 */         break;
/*     */       
/*     */       case 1: 
/*  78 */         posX++;
/*  79 */         posY--;
/*  80 */         break;
/*     */       
/*     */       case 7: 
/*  83 */         posX--;
/*  84 */         posY--;
/*  85 */         break;
/*     */       
/*     */       case 5: 
/*  88 */         posX--;
/*  89 */         posY++;
/*     */       }
/*     */       
/*     */       
/*  93 */       RoomModel model = client.getPlayer().getEntity().getRoom().getModel();
/*     */       
/*  95 */       if ((model.getDoorX() == posX) && (model.getDoorY() == posY)) {
/*  96 */         return;
/*     */       }
/*     */       
/*  99 */       user.getPlayer().getEntity().setWalkingGoal(posX, posY);
/*     */       
/* 101 */       List<Square> path = EntityPathfinder.getInstance().makePath(user.getPlayer().getEntity(), user.getPlayer().getEntity().getWalkingGoal());
/* 102 */       user.getPlayer().getEntity().unIdle();
/*     */       
/* 104 */       if (user.getPlayer().getEntity().getWalkingPath() != null) {
/* 105 */         user.getPlayer().getEntity().getWalkingPath().clear();
/*     */       }
/* 107 */       user.getPlayer().getEntity().setWalkingPath(path);
/*     */       
/* 109 */       client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(
/* 110 */         new com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer(client.getPlayer().getEntity().getId(), Locale.get("command.push.message").replace("%playername%", user.getPlayer().getData().getUsername()), com.habboproject.server.game.rooms.types.misc.ChatEmotion.NONE, 0));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getPermission()
/*     */   {
/* 117 */     return "push_command";
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 122 */     return Locale.get("command.push.description");
/*     */   }
/*     */   
/*     */   public boolean canDisable()
/*     */   {
/* 127 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\PushCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */