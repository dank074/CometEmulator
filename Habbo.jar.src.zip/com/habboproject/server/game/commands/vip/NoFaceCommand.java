/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.messages.outgoing.room.avatar.UpdateInfoMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class NoFaceCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     String figure = client.getPlayer().getData().getFigure();
/*    */     
/* 15 */     if (client.getPlayer().getData().getTemporaryFigure() != null) {
/* 16 */       client.getPlayer().getData().setFigure(client.getPlayer().getData().getTemporaryFigure());
/* 17 */       client.getPlayer().getData().setTemporaryFigure(null);
/* 18 */       client.getPlayer().getData().save();
/*    */     }
/* 20 */     else if (figure.contains("hd-")) {
/* 21 */       String[] head = ("hd-" + figure.split("hd-")[1].split("\\.")[0]).split("-");
/*    */       
/* 23 */       if (head.length < 2) {
/* 24 */         return;
/*    */       }
/* 26 */       client.getPlayer().getData().setTemporaryFigure(figure);
/* 27 */       client.getPlayer().getData().setFigure(figure.replace(org.apache.commons.lang.StringUtils.join(head, "-"), "hd-99999-" + (head.length != 3 ? head[(head.length - 1)] : head.length == 0 ? "" : head[2])));
/*    */     }
/*    */     
/*    */ 
/* 31 */     client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new UpdateInfoMessageComposer(client.getPlayer().getEntity()));
/* 32 */     client.send(new UpdateInfoMessageComposer(-1, client.getPlayer().getEntity()));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 37 */     return "noface_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 42 */     return com.habboproject.server.config.Locale.get("command.noface.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\NoFaceCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */