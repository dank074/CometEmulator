/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.api.networking.messages.IComposer;
/*    */ import com.habboproject.server.game.pets.PetManager;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class TransformCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 16 */     String type = "human";
/*    */     
/* 18 */     if (params.length == 1) {
/* 19 */       type = params[0].toLowerCase();
/*    */     }
/*    */     
/* 22 */     if (type.equals("human")) {
/* 23 */       client.getPlayer().getEntity().removeAttribute("transformation");
/*    */     } else {
/* 25 */       String data = PetManager.getInstance().getTransformationData(type);
/*    */       
/* 27 */       if ((data == null) || (data.isEmpty())) {
/* 28 */         return;
/*    */       }
/*    */       
/* 31 */       client.getPlayer().getEntity().setAttribute("transformation", data);
/*    */     }
/*    */     
/* 34 */     client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.LeaveRoomMessageComposer(client.getPlayer().getEntity().getId()));
/* 35 */     client.getPlayer().getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.AvatarsMessageComposer(client.getPlayer().getEntity()));
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 40 */     return "transform_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 45 */     return com.habboproject.server.config.Locale.get("command.transform.description");
/*    */   }
/*    */   
/*    */   public boolean canDisable()
/*    */   {
/* 50 */     return true;
/*    */   }
/*    */   
/*    */   public static void composeTransformation(IComposer msg, String[] transformationData, PlayerEntity entity)
/*    */   {
/* 55 */     msg.writeInt(entity.getPlayerId());
/* 56 */     msg.writeString(entity.getUsername());
/* 57 */     msg.writeString(entity.getMotto());
/* 58 */     msg.writeString(transformationData[0]);
/* 59 */     msg.writeInt(entity.getId());
/*    */     
/* 61 */     msg.writeInt(entity.getPosition().getX());
/* 62 */     msg.writeInt(entity.getPosition().getY());
/* 63 */     msg.writeDouble(entity.getPosition().getZ());
/*    */     
/* 65 */     msg.writeInt(0);
/* 66 */     msg.writeInt(2);
/*    */     
/* 68 */     msg.writeInt(Integer.parseInt(transformationData[1]));
/* 69 */     msg.writeInt(entity.getPlayerId());
/* 70 */     msg.writeString(entity.getUsername());
/* 71 */     msg.writeInt(1);
/* 72 */     msg.writeBoolean(Boolean.valueOf(true));
/* 73 */     msg.writeBoolean(Boolean.valueOf(false));
/*    */     
/* 75 */     msg.writeInt(0);
/* 76 */     msg.writeInt(0);
/* 77 */     msg.writeString("");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\TransformCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */