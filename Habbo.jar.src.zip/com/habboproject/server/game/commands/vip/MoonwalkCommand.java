/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class MoonwalkCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     if (client.getPlayer().getEntity().isMoonwalking()) {
/* 12 */       client.getPlayer().getEntity().setIsMoonwalking(false);
/*    */       
/* 14 */       sendNotif(com.habboproject.server.config.Locale.get("command.moonwalk.disabled"), client);
/* 15 */       return;
/*    */     }
/*    */     
/* 18 */     if (client.getPlayer().getEntity().getMountedEntity() != null) {
/* 19 */       return;
/*    */     }
/*    */     
/* 22 */     client.getPlayer().getEntity().setIsMoonwalking(true);
/*    */     
/* 24 */     sendNotif(com.habboproject.server.config.Locale.get("command.moonwalk.enabled"), client);
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 29 */     return "moonwalk_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 34 */     return com.habboproject.server.config.Locale.get("command.moonwalk.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\MoonwalkCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */