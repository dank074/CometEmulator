/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.models.RoomModel;
/*    */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.Square;
/*    */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.types.EntityPathfinder;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.RightsComponent;
/*    */ import com.habboproject.server.game.rooms.types.misc.ChatEmotion;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import java.util.List;
/*    */ 
/*    */ public class PullCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 22 */     if (params.length == 0) {
/* 23 */       sendNotif("Invalid username", client);
/* 24 */       return;
/*    */     }
/*    */     
/* 27 */     if ((client.getPlayer().getEntity().isRoomMuted()) || (client.getPlayer().getEntity().getRoom().getRights().hasMute(client.getPlayer().getId()))) {
/* 28 */       return;
/*    */     }
/*    */     
/* 31 */     String username = params[0];
/* 32 */     Session pulledSession = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 34 */     if (pulledSession == null) {
/* 35 */       return;
/*    */     }
/*    */     
/* 38 */     if (pulledSession.getPlayer().getEntity() == null) {
/* 39 */       return;
/*    */     }
/*    */     
/* 42 */     if (username.equals(client.getPlayer().getData().getUsername())) {
/* 43 */       sendNotif(Locale.get("command.pull.playerhimself"), client);
/* 44 */       return;
/*    */     }
/*    */     
/* 47 */     Room room = client.getPlayer().getEntity().getRoom();
/* 48 */     PlayerEntity pulledEntity = pulledSession.getPlayer().getEntity();
/*    */     
/* 50 */     if (pulledEntity.isOverriden()) {
/* 51 */       return;
/*    */     }
/*    */     
/* 54 */     if (pulledEntity.getPosition().distanceTo(client.getPlayer().getEntity()) != 2.0D) {
/* 55 */       return;
/*    */     }
/*    */     
/* 58 */     Position squareInFront = client.getPlayer().getEntity().getPosition().squareInFront(client.getPlayer().getEntity().getBodyRotation());
/*    */     
/* 60 */     if ((room.getModel().getDoorX() == squareInFront.getX()) && (room.getModel().getDoorY() == squareInFront.getY())) {
/* 61 */       return;
/*    */     }
/*    */     
/* 64 */     pulledEntity.setWalkingGoal(squareInFront.getX(), squareInFront.getY());
/*    */     
/* 66 */     List<Square> path = EntityPathfinder.getInstance().makePath(pulledEntity, pulledEntity.getWalkingGoal());
/* 67 */     pulledEntity.unIdle();
/*    */     
/* 69 */     if (pulledEntity.getWalkingPath() != null) {
/* 70 */       pulledEntity.getWalkingPath().clear();
/*    */     }
/* 72 */     pulledEntity.setWalkingPath(path);
/*    */     
/* 74 */     room.getEntities().broadcastMessage(
/* 75 */       new com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer(client.getPlayer().getEntity().getId(), Locale.get("command.pull.message").replace("%playername%", pulledEntity.getUsername()), ChatEmotion.NONE, 0));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getPermission()
/*    */   {
/* 82 */     return "pull_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 87 */     return Locale.get("command.pull.description");
/*    */   }
/*    */   
/*    */   public boolean canDisable()
/*    */   {
/* 92 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\PullCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */