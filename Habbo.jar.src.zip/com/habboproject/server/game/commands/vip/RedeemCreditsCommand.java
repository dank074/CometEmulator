/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.api.game.furniture.types.FurnitureDefinition;
/*    */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*    */ import com.habboproject.server.api.game.players.data.components.inventory.PlayerItem;
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class RedeemCreditsCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 17 */     int coinsToGive = 0;
/* 18 */     int diamondsToGive = 0;
/*    */     
/* 20 */     List<Long> itemsToRemove = com.google.common.collect.Lists.newArrayList();
/*    */     
/* 22 */     if (!client.getPlayer().getInventory().itemsLoaded()) {
/* 23 */       sendNotif(Locale.getOrDefault("command.redeemcredits.inventory", "Please open your inventory before executing this command!"), client);
/* 24 */       return;
/*    */     }
/*    */     
/* 27 */     for (PlayerItem playerItem : client.getPlayer().getInventory().getFloorItems().values()) {
/* 28 */       if ((playerItem != null) && (playerItem.getDefinition() != null))
/*    */       {
/* 30 */         itemName = playerItem.getDefinition().getItemName();
/*    */         
/* 32 */         if ((itemName.startsWith("CF_")) || (itemName.startsWith("CFC_"))) {
/*    */           try {
/* 34 */             if (itemName.contains("_diamond_")) {
/* 35 */               diamondsToGive += Integer.parseInt(itemName.split("_diamond_")[1]);
/*    */             } else {
/* 37 */               coinsToGive += Integer.parseInt(itemName.split("_")[1]);
/*    */             }
/*    */             
/* 40 */             itemsToRemove.add(Long.valueOf(playerItem.getId()));
/*    */             
/* 42 */             com.habboproject.server.storage.queries.rooms.RoomItemDao.deleteItem(playerItem.getId());
/*    */           }
/*    */           catch (Exception localException) {}
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 49 */     if (itemsToRemove.size() == 0) {
/* 50 */       return;
/*    */     }
/*    */     
/* 53 */     for (String itemName = itemsToRemove.iterator(); itemName.hasNext();) { long itemId = ((Long)itemName.next()).longValue();
/* 54 */       client.getPlayer().getInventory().removeFloorItem(itemId);
/*    */     }
/*    */     
/* 57 */     itemsToRemove.clear();
/*    */     
/* 59 */     client.send(new com.habboproject.server.network.messages.outgoing.user.inventory.UpdateInventoryMessageComposer());
/*    */     
/* 61 */     if (diamondsToGive > 0) {
/* 62 */       client.getPlayer().getData().increasePoints(diamondsToGive);
/*    */     }
/*    */     
/* 65 */     if (coinsToGive > 0) {
/* 66 */       client.getPlayer().getData().increaseCredits(coinsToGive);
/*    */     }
/*    */     
/* 69 */     if ((diamondsToGive > 0) || (coinsToGive > 0)) {
/* 70 */       client.getPlayer().sendBalance();
/* 71 */       client.getPlayer().getData().save();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public String getPermission()
/*    */   {
/* 78 */     return "redeemcredits_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 83 */     return Locale.get("command.redeemcredits.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\RedeemCreditsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */