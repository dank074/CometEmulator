/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class ToggleDiagonalCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     if ((client.getPlayer().getEntity().getRoom().getData().getOwnerId() != client.getPlayer().getId()) && (!client.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 12 */       sendNotif(com.habboproject.server.config.Locale.getOrDefault("command.togglediagonal.nopermission", "You don't have permission to use this command!"), client);
/* 13 */       return;
/*    */     }
/*    */     
/* 16 */     Room room = client.getPlayer().getEntity().getRoom();
/*    */     
/* 18 */     if (room.hasAttribute("disableDiagonal")) {
/* 19 */       sendNotif(com.habboproject.server.config.Locale.getOrDefault("command.togglediagonal.enabled", "Diagonal walking has been enabled!"), client);
/* 20 */       room.removeAttribute("disableDiagonal");
/*    */     } else {
/* 22 */       sendNotif(com.habboproject.server.config.Locale.getOrDefault("command.togglediagonal.disabled", "Diagonal walking has been disabled!"), client);
/* 23 */       room.setAttribute("disableDiagonal", Boolean.valueOf(true));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 29 */     return "togglediagonal_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 34 */     return com.habboproject.server.config.Locale.get("command.togglediagonal.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\ToggleDiagonalCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */