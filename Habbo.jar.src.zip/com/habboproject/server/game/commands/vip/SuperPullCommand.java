/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.Square;
/*    */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.types.EntityPathfinder;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.RightsComponent;
/*    */ import com.habboproject.server.game.rooms.types.misc.ChatEmotion;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SuperPullCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 21 */     if (params.length == 0) {
/* 22 */       sendNotif("Invalid username", client);
/* 23 */       return;
/*    */     }
/*    */     
/* 26 */     if ((client.getPlayer().getEntity().isRoomMuted()) || (client.getPlayer().getEntity().getRoom().getRights().hasMute(client.getPlayer().getId()))) {
/* 27 */       return;
/*    */     }
/*    */     
/* 30 */     String username = params[0];
/* 31 */     Session pulledSession = NetworkManager.getInstance().getSessions().getByPlayerUsername(username);
/*    */     
/* 33 */     if (pulledSession == null) {
/* 34 */       return;
/*    */     }
/*    */     
/* 37 */     if (pulledSession.getPlayer().getEntity() == null) {
/* 38 */       return;
/*    */     }
/*    */     
/* 41 */     if (username.equals(client.getPlayer().getData().getUsername())) {
/* 42 */       sendNotif(Locale.get("command.pull.playerhimself"), client);
/* 43 */       return;
/*    */     }
/*    */     
/* 46 */     Room room = client.getPlayer().getEntity().getRoom();
/* 47 */     PlayerEntity pulledEntity = pulledSession.getPlayer().getEntity();
/*    */     
/* 49 */     Position squareInFront = client.getPlayer().getEntity().getPosition().squareInFront(client.getPlayer().getEntity().getBodyRotation());
/*    */     
/* 51 */     pulledEntity.setWalkingGoal(squareInFront.getX(), squareInFront.getY());
/*    */     
/* 53 */     List<Square> path = EntityPathfinder.getInstance().makePath(pulledEntity, pulledEntity.getWalkingGoal());
/* 54 */     pulledEntity.unIdle();
/*    */     
/* 56 */     if (pulledEntity.getWalkingPath() != null) {
/* 57 */       pulledEntity.getWalkingPath().clear();
/*    */     }
/* 59 */     pulledEntity.setWalkingPath(path);
/*    */     
/* 61 */     room.getEntities().broadcastMessage(
/* 62 */       new com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer(client.getPlayer().getEntity().getId(), Locale.get("command.pull.message").replace("%playername%", pulledEntity.getUsername()), ChatEmotion.NONE, 0));
/*    */   }
/*    */   
/*    */ 
/*    */   public String getPermission()
/*    */   {
/* 68 */     return "superpull_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 73 */     return Locale.get("command.superpull.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\SuperPullCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */