/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class MimicCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     if (params.length < 1) {
/* 14 */       return;
/*    */     }
/* 16 */     String username = params[0];
/*    */     
/* 18 */     PlayerEntity entity = (PlayerEntity)client.getPlayer().getEntity().getRoom().getEntities().getEntityByName(username, com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER);
/*    */     
/* 20 */     if (entity == null) {
/* 21 */       return;
/*    */     }
/* 23 */     if (entity.getUsername().equals(client.getPlayer().getData().getUsername())) {
/* 24 */       return;
/*    */     }
/*    */     
/* 27 */     PlayerEntity playerEntity = client.getPlayer().getEntity();
/*    */     
/* 29 */     playerEntity.getPlayer().getData().setFigure(entity.getFigure());
/* 30 */     playerEntity.getPlayer().getData().setGender(entity.getGender());
/* 31 */     playerEntity.getPlayer().getData().save();
/*    */     
/* 33 */     playerEntity.getPlayer().poof();
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 38 */     return "mimic_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 43 */     return com.habboproject.server.config.Locale.get("command.mimic.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\MimicCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */