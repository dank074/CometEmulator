/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class HandItemCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 11 */     if (params.length != 1) {
/* 12 */       return;
/*    */     }
/*    */     
/* 15 */     if (!StringUtils.isNumeric(params[0])) {
/* 16 */       return;
/*    */     }
/*    */     
/* 19 */     int handItem = Integer.parseInt(params[0]);
/*    */     
/* 21 */     if (handItem > 0) {
/* 22 */       client.getPlayer().getEntity().carryItem(handItem, false);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 28 */     return Locale.get("handitem_command");
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 33 */     return Locale.get("command.handitem.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\HandItemCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */