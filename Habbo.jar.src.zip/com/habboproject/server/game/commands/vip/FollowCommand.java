/*    */ package com.habboproject.server.game.commands.vip;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.permissions.types.Rank;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class FollowCommand extends com.habboproject.server.game.commands.ChatCommand
/*    */ {
/*    */   public void execute(Session client, String[] params)
/*    */   {
/* 13 */     if (params.length != 1) {
/* 14 */       return;
/*    */     }
/*    */     
/* 17 */     Session leader = NetworkManager.getInstance().getSessions().getByPlayerUsername(params[0]);
/*    */     
/* 19 */     if ((leader != null) && (leader.getPlayer() != null) && (leader.getPlayer().getEntity() != null))
/*    */     {
/*    */ 
/* 22 */       if ((leader.getPlayer().getPermissions().getRank().modTool()) && 
/* 23 */         (!client.getPlayer().getPermissions().getRank().modTool())) {
/* 24 */         return;
/*    */       }
/*    */       
/*    */ 
/* 28 */       client.send(new com.habboproject.server.network.messages.outgoing.room.engine.RoomForwardMessageComposer(leader.getPlayer().getEntity().getRoom().getId()));
/*    */     }
/* 30 */     else if ((leader == null) || (leader.getPlayer() == null)) {
/* 31 */       sendNotif(Locale.get("command.follow.online"), client);
/*    */     } else {
/* 33 */       sendNotif(Locale.get("command.follow.room"), client);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPermission()
/*    */   {
/* 39 */     return "follow_command";
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 44 */     return Locale.get("command.follow.description");
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\commands\vip\FollowCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */