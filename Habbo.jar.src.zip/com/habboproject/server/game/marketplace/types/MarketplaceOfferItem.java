/*     */ package com.habboproject.server.game.marketplace.types;
/*     */ 
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import com.habboproject.server.storage.queries.marketplace.MarketplaceDao;
/*     */ import com.habboproject.server.threads.CometThread;
/*     */ import com.habboproject.server.threads.ThreadManager;
/*     */ 
/*     */ 
/*     */ public class MarketplaceOfferItem
/*     */   implements CometThread
/*     */ {
/*     */   private final int offerId;
/*     */   private final int itemId;
/*     */   private final ItemDefinition definition;
/*     */   private final int playerId;
/*     */   private final int type;
/*     */   private final int limitedStack;
/*     */   private final int limitedNumber;
/*     */   private int state;
/*     */   private int price;
/*     */   private int finalPrice;
/*     */   private int time;
/*     */   private boolean needsUpdate;
/*     */   
/*     */   public MarketplaceOfferItem(int offerId, int itemId, int playerId, int type, int limitedStack, int limitedNumber, int state, int price, int finalPrice, int time)
/*     */   {
/*  28 */     this.offerId = offerId;
/*  29 */     this.itemId = itemId;
/*  30 */     this.definition = ItemManager.getInstance().getDefinition(itemId);
/*  31 */     this.playerId = playerId;
/*  32 */     this.type = type;
/*  33 */     this.limitedStack = limitedStack;
/*  34 */     this.limitedNumber = limitedNumber;
/*  35 */     this.state = state;
/*  36 */     this.price = price;
/*  37 */     this.finalPrice = finalPrice;
/*  38 */     this.time = time;
/*     */     
/*  40 */     this.needsUpdate = false;
/*     */   }
/*     */   
/*     */   public void stateUpdate(int state) {
/*  44 */     this.needsUpdate = true;
/*  45 */     this.state = state;
/*     */     
/*  47 */     ThreadManager.getInstance().execute(this);
/*     */   }
/*     */   
/*     */   public void run() {
/*  51 */     if (this.needsUpdate) {
/*  52 */       this.needsUpdate = false;
/*  53 */       MarketplaceDao.updateOffer(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getOfferId() {
/*  58 */     return this.offerId;
/*     */   }
/*     */   
/*     */   public int getItemId() {
/*  62 */     return this.itemId;
/*     */   }
/*     */   
/*     */   public ItemDefinition getDefinition() {
/*  66 */     return this.definition;
/*     */   }
/*     */   
/*     */   public int getPlayerId() {
/*  70 */     return this.playerId;
/*     */   }
/*     */   
/*     */   public int getType() {
/*  74 */     return this.type;
/*     */   }
/*     */   
/*     */   public int getLimitedStack() {
/*  78 */     return this.limitedStack;
/*     */   }
/*     */   
/*     */   public int getLimitedNumber() {
/*  82 */     return this.limitedNumber;
/*     */   }
/*     */   
/*     */   public int getPrice() {
/*  86 */     return this.price;
/*     */   }
/*     */   
/*     */   public int getFinalPrice() {
/*  90 */     return this.finalPrice;
/*     */   }
/*     */   
/*     */   public int getTime() {
/*  94 */     return this.time;
/*     */   }
/*     */   
/*     */   public int getState() {
/*  98 */     return this.state;
/*     */   }
/*     */   
/*     */   public void needsUpdate(boolean needsUpdate) {
/* 102 */     this.needsUpdate = needsUpdate;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\marketplace\types\MarketplaceOfferItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */