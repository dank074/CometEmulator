/*    */ package com.habboproject.server.game.navigator.types.publics;
/*    */ 
/*    */ public class PublicRoom {
/*    */   private final int roomId;
/*    */   private final String caption;
/*    */   private final String description;
/*    */   private final String imageUrl;
/*    */   
/*    */   public PublicRoom(int roomId, String caption, String description, String imageUrl) {
/* 10 */     this.roomId = roomId;
/* 11 */     this.caption = caption;
/* 12 */     this.description = description;
/* 13 */     this.imageUrl = imageUrl;
/*    */   }
/*    */   
/*    */   public int getRoomId() {
/* 17 */     return this.roomId;
/*    */   }
/*    */   
/*    */   public String getCaption() {
/* 21 */     return this.caption;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 25 */     return this.description;
/*    */   }
/*    */   
/*    */   public String getImageUrl() {
/* 29 */     return this.imageUrl;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\navigator\types\publics\PublicRoom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */