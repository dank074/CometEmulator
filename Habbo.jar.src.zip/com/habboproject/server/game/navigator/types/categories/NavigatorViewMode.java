package com.habboproject.server.game.navigator.types.categories;

public enum NavigatorViewMode
{
  REGULAR,  THUMBNAIL;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\navigator\types\categories\NavigatorViewMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */