/*    */ package com.habboproject.server.game.navigator.types.categories;
/*    */ 
/*    */ public enum NavigatorSearchAllowance {
/*  4 */   NOTHING, 
/*  5 */   SHOW_MORE, 
/*  6 */   GO_BACK;
/*    */   
/*    */   public static int getIntValue(NavigatorSearchAllowance allowance) {
/*  9 */     switch (allowance) {
/*    */     case GO_BACK: 
/*    */     default: 
/* 12 */       return 0;
/*    */     case NOTHING: 
/* 14 */       return 1;
/*    */     }
/* 16 */     return 2;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\navigator\types\categories\NavigatorSearchAllowance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */