/*    */ package com.habboproject.server.game.navigator.types.featured;
/*    */ 
/*    */ public enum ImageType {
/*  4 */   INTERNAL, 
/*  5 */   EXTERNAL;
/*    */   
/*    */   public static ImageType get(String t) {
/*  8 */     if (t.equals("internal")) {
/*  9 */       return INTERNAL;
/*    */     }
/* 11 */     return EXTERNAL;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\navigator\types\featured\ImageType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */