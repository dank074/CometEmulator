/*    */ package com.habboproject.server.game.navigator.types.featured;
/*    */ 
/*    */ public enum BannerType {
/*  4 */   BIG, 
/*  5 */   SMALL;
/*    */   
/*    */   public static BannerType get(String t) {
/*  8 */     if (t.equals("big")) {
/*  9 */       return BIG;
/*    */     }
/* 11 */     return SMALL;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\navigator\types\featured\BannerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */