/*     */ package com.habboproject.server.game.navigator.types.featured;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.rooms.RoomManager;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.RoomData;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ public class FeaturedRoom
/*     */ {
/*     */   private int id;
/*     */   private boolean isCategory;
/*     */   private BannerType bannerType;
/*     */   private String caption;
/*     */   private String description;
/*     */   private String image;
/*     */   private ImageType imageType;
/*     */   private int roomId;
/*     */   private int categoryId;
/*     */   private boolean enabled;
/*     */   private boolean recommended;
/*     */   private RoomData room;
/*     */   
/*     */   public FeaturedRoom(ResultSet data) throws SQLException
/*     */   {
/*  28 */     this.id = data.getInt("id");
/*  29 */     this.bannerType = BannerType.get(data.getString("banner_type"));
/*  30 */     this.caption = data.getString("caption");
/*  31 */     this.description = data.getString("description");
/*  32 */     this.image = data.getString("image");
/*  33 */     this.imageType = ImageType.get(data.getString("image_type"));
/*  34 */     this.roomId = data.getInt("room_id");
/*  35 */     this.categoryId = data.getInt("category_id");
/*  36 */     this.enabled = Boolean.parseBoolean(data.getString("enabled"));
/*  37 */     this.recommended = data.getString("recommended").equals("1");
/*  38 */     this.isCategory = data.getString("type").equals("category");
/*     */     
/*     */ 
/*  41 */     if (!this.isCategory) this.room = RoomManager.getInstance().getRoomData(this.roomId);
/*     */   }
/*     */   
/*     */   public FeaturedRoom(int id, BannerType bannerType, String caption, String description, String image, ImageType imageType, int roomId, int categoryId, boolean enabled, boolean recommended, boolean isCategory) {
/*  45 */     this.id = id;
/*  46 */     this.bannerType = bannerType;
/*  47 */     this.caption = caption;
/*  48 */     this.description = description;
/*  49 */     this.image = image;
/*  50 */     this.imageType = imageType;
/*  51 */     this.roomId = roomId;
/*  52 */     this.categoryId = categoryId;
/*  53 */     this.enabled = enabled;
/*  54 */     this.recommended = recommended;
/*  55 */     this.isCategory = isCategory;
/*     */     
/*  57 */     if (!isCategory) this.room = RoomManager.getInstance().getRoomData(roomId);
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg) {
/*  61 */     boolean isActive = (!this.isCategory) && (this.room != null) && (RoomManager.getInstance().isActive(this.room.getId()));
/*     */     
/*  63 */     msg.writeInt(this.id);
/*  64 */     msg.writeString(!this.isCategory ? this.room.getName() : this.caption);
/*  65 */     msg.writeString(!this.isCategory ? this.description : (this.description != null) && (this.description.isEmpty()) ? this.room.getDescription() : this.description);
/*     */     
/*  67 */     msg.writeInt(this.bannerType == BannerType.BIG ? 0 : 1);
/*  68 */     msg.writeString(!this.isCategory ? this.caption : "");
/*  69 */     msg.writeString(this.imageType == ImageType.EXTERNAL ? this.image : "");
/*  70 */     msg.writeInt(this.categoryId);
/*     */     
/*  72 */     msg.writeInt(isActive ? RoomManager.getInstance().get(this.roomId).getEntities().playerCount() : 0);
/*  73 */     msg.writeInt(this.isCategory ? 4 : 2);
/*     */     
/*  75 */     if (this.isCategory) {
/*  76 */       msg.writeBoolean(Boolean.valueOf(false));
/*     */     } else {
/*  78 */       com.habboproject.server.game.rooms.types.RoomWriter.write(this.room, msg);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getId() {
/*  83 */     return this.id;
/*     */   }
/*     */   
/*     */   public BannerType getBannerType() {
/*  87 */     return this.bannerType;
/*     */   }
/*     */   
/*     */   public String getCaption() {
/*  91 */     return this.caption;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/*  95 */     return this.description;
/*     */   }
/*     */   
/*     */   public String getImage() {
/*  99 */     return this.image;
/*     */   }
/*     */   
/*     */   public ImageType getImageType() {
/* 103 */     return this.imageType;
/*     */   }
/*     */   
/*     */   public int getRoomId() {
/* 107 */     return this.roomId;
/*     */   }
/*     */   
/*     */   public int getCategoryId() {
/* 111 */     return this.categoryId;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 115 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public boolean isRecommended() {
/* 119 */     return this.recommended;
/*     */   }
/*     */   
/*     */   public boolean isCategory() {
/* 123 */     return this.isCategory;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\navigator\types\featured\FeaturedRoom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */