/*    */ package com.habboproject.server.game.navigator.types;
/*    */ 
/*    */ import com.habboproject.server.game.navigator.types.categories.NavigatorSearchAllowance;
/*    */ import com.habboproject.server.game.navigator.types.categories.NavigatorViewMode;
/*    */ 
/*    */ public class Category implements com.habboproject.server.api.game.rooms.RoomCategory
/*    */ {
/*    */   private final int id;
/*    */   private final String category;
/*    */   private final String categoryId;
/*    */   private final String publicName;
/*    */   private final boolean canDoActions;
/*    */   private final int colour;
/*    */   private final int requiredRank;
/*    */   private final NavigatorViewMode viewMode;
/*    */   private final com.habboproject.server.game.navigator.types.categories.NavigatorCategoryType categoryType;
/*    */   private final NavigatorSearchAllowance searchAllowance;
/*    */   private final int orderId;
/*    */   private final boolean visible;
/*    */   private final int roomCount;
/*    */   private final int roomCountExpanded;
/*    */   
/*    */   public Category(int id, String category, String categoryId, String publicName, boolean canDoActions, int colour, int requiredRank, NavigatorViewMode viewMode, String categoryType, String searchAllowance, int orderId, boolean visible, int roomCount, int roomCountExpanded)
/*    */   {
/* 25 */     this.id = id;
/* 26 */     this.category = category;
/* 27 */     this.categoryId = categoryId;
/* 28 */     this.publicName = publicName;
/* 29 */     this.canDoActions = canDoActions;
/* 30 */     this.colour = colour;
/* 31 */     this.requiredRank = requiredRank;
/* 32 */     this.viewMode = viewMode;
/* 33 */     this.categoryType = com.habboproject.server.game.navigator.types.categories.NavigatorCategoryType.valueOf(categoryType.toUpperCase());
/* 34 */     this.searchAllowance = NavigatorSearchAllowance.valueOf(searchAllowance.toUpperCase());
/* 35 */     this.orderId = orderId;
/* 36 */     this.visible = visible;
/* 37 */     this.roomCount = roomCount;
/* 38 */     this.roomCountExpanded = roomCountExpanded;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 42 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getCategory() {
/* 46 */     return this.category;
/*    */   }
/*    */   
/*    */   public String getCategoryId() {
/* 50 */     return this.categoryId;
/*    */   }
/*    */   
/*    */   public String getPublicName() {
/* 54 */     return this.publicName;
/*    */   }
/*    */   
/*    */   public boolean canDoActions() {
/* 58 */     return this.canDoActions;
/*    */   }
/*    */   
/*    */   public int getColour() {
/* 62 */     return this.colour;
/*    */   }
/*    */   
/*    */   public int getRequiredRank() {
/* 66 */     return this.requiredRank;
/*    */   }
/*    */   
/*    */   public NavigatorViewMode getViewMode() {
/* 70 */     return this.viewMode;
/*    */   }
/*    */   
/*    */   public com.habboproject.server.game.navigator.types.categories.NavigatorCategoryType getCategoryType() {
/* 74 */     return this.categoryType;
/*    */   }
/*    */   
/*    */   public NavigatorSearchAllowance getSearchAllowance() {
/* 78 */     return this.searchAllowance;
/*    */   }
/*    */   
/*    */   public int getOrderId() {
/* 82 */     return this.orderId;
/*    */   }
/*    */   
/*    */   public boolean isVisible() {
/* 86 */     return this.visible;
/*    */   }
/*    */   
/*    */   public int getRoomCount() {
/* 90 */     return this.roomCount;
/*    */   }
/*    */   
/*    */   public int getRoomCountExpanded() {
/* 94 */     return this.roomCountExpanded;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\navigator\types\Category.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */