/*     */ package com.habboproject.server.game.navigator;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.game.navigator.types.Category;
/*     */ import com.habboproject.server.game.navigator.types.categories.NavigatorCategoryType;
/*     */ import com.habboproject.server.game.navigator.types.publics.PublicRoom;
/*     */ import com.habboproject.server.storage.queries.navigator.NavigatorDao;
/*     */ import com.habboproject.server.utilities.Initializable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NavigatorManager
/*     */   implements Initializable
/*     */ {
/*     */   private static NavigatorManager navigatorManagerInstance;
/*     */   private Map<Integer, Category> categories;
/*     */   private List<Category> userCategories;
/*     */   private Map<Integer, PublicRoom> publicRooms;
/*     */   private Set<Integer> staffPicks;
/*  25 */   Logger log = Logger.getLogger(NavigatorManager.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  32 */     loadCategories();
/*  33 */     loadPublicRooms();
/*  34 */     loadStaffPicks();
/*     */     
/*  36 */     this.log.info("NavigatorManager initialized");
/*     */   }
/*     */   
/*     */   public static NavigatorManager getInstance() {
/*  40 */     if (navigatorManagerInstance == null) {
/*  41 */       navigatorManagerInstance = new NavigatorManager();
/*     */     }
/*  43 */     return navigatorManagerInstance;
/*     */   }
/*     */   
/*     */   public void loadPublicRooms() {
/*     */     try {
/*  48 */       if ((this.publicRooms != null) && (this.publicRooms.size() != 0)) {
/*  49 */         this.publicRooms.clear();
/*     */       }
/*     */       
/*  52 */       this.publicRooms = NavigatorDao.getPublicRooms();
/*     */     }
/*     */     catch (Exception e) {
/*  55 */       this.log.error("Error while loading public rooms", e);
/*     */     }
/*     */     
/*  58 */     this.log.info("Loaded " + this.publicRooms.size() + " featured rooms");
/*     */   }
/*     */   
/*     */   public void loadStaffPicks() {
/*     */     try {
/*  63 */       if ((this.staffPicks != null) && (this.staffPicks.size() != 0)) {
/*  64 */         this.staffPicks.clear();
/*     */       }
/*     */       
/*  67 */       this.staffPicks = NavigatorDao.getStaffPicks();
/*     */     }
/*     */     catch (Exception e) {
/*  70 */       this.log.error("Error while loading staff picked rooms", e);
/*     */     }
/*     */     
/*  73 */     this.log.info("Loaded " + this.publicRooms.size() + " staff picks");
/*     */   }
/*     */   
/*     */   public void loadCategories() {
/*     */     try {
/*  78 */       if ((this.categories != null) && (this.categories.size() != 0)) {
/*  79 */         this.categories.clear();
/*     */       }
/*     */       
/*  82 */       if (this.userCategories == null) {
/*  83 */         this.userCategories = Lists.newArrayList();
/*     */       } else {
/*  85 */         this.userCategories.clear();
/*     */       }
/*     */       
/*  88 */       this.categories = NavigatorDao.getCategories();
/*     */       
/*  90 */       for (Category category : this.categories.values()) {
/*  91 */         if (category.getCategoryType() == NavigatorCategoryType.CATEGORY) {
/*  92 */           this.userCategories.add(category);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/*  96 */       this.log.error("Error while loading navigator categories", e);
/*     */     }
/*     */     
/*  99 */     this.log.info("Loaded " + (getCategories() == null ? 0 : getCategories().size()) + " room categories");
/*     */   }
/*     */   
/*     */   public Category getCategory(int id) {
/* 103 */     for (Category c : getCategories().values()) {
/* 104 */       if (c.getId() == id) {
/* 105 */         return c;
/*     */       }
/*     */     }
/*     */     
/* 109 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isStaffPicked(int roomId) {
/* 113 */     return this.staffPicks.contains(Integer.valueOf(roomId));
/*     */   }
/*     */   
/*     */   public PublicRoom getPublicRoom(int roomId) {
/* 117 */     return (PublicRoom)this.publicRooms.get(Integer.valueOf(roomId));
/*     */   }
/*     */   
/*     */   public Map<Integer, Category> getCategories() {
/* 121 */     return this.categories;
/*     */   }
/*     */   
/*     */   public Map<Integer, PublicRoom> getPublicRooms() {
/* 125 */     return this.publicRooms;
/*     */   }
/*     */   
/*     */   public Set<Integer> getStaffPicks() {
/* 129 */     return this.staffPicks;
/*     */   }
/*     */   
/*     */   public List<Category> getUserCategories() {
/* 133 */     return this.userCategories;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\navigator\NavigatorManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */