/*     */ package com.habboproject.server.game.pets;
/*     */ 
/*     */ import com.habboproject.server.game.pets.data.PetSpeech;
/*     */ import com.habboproject.server.game.pets.races.PetRace;
/*     */ import com.habboproject.server.storage.queries.pets.PetDao;
/*     */ import com.habboproject.server.utilities.Initializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class PetManager
/*     */   implements Initializable
/*     */ {
/*     */   private static PetManager petManagerInstance;
/*  17 */   private Logger log = Logger.getLogger(PetManager.class.getName());
/*     */   
/*     */ 
/*     */   private List<PetRace> petRaces;
/*     */   
/*     */ 
/*     */   private Map<Integer, PetSpeech> petMessages;
/*     */   
/*     */ 
/*     */   private Map<String, String> transformablePets;
/*     */   
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  31 */     loadPetRaces();
/*  32 */     loadPetSpeech();
/*  33 */     loadTransformablePets();
/*     */     
/*  35 */     this.log.info("PetManager initialized");
/*     */   }
/*     */   
/*     */   public static PetManager getInstance() {
/*  39 */     if (petManagerInstance == null) {
/*  40 */       petManagerInstance = new PetManager();
/*     */     }
/*  42 */     return petManagerInstance;
/*     */   }
/*     */   
/*     */   public void loadPetRaces() {
/*  46 */     if (this.petRaces != null) {
/*  47 */       this.petRaces.clear();
/*     */     }
/*     */     try
/*     */     {
/*  51 */       this.petRaces = PetDao.getRaces();
/*     */       
/*  53 */       this.log.info("Loaded " + this.petRaces.size() + " pet races");
/*     */     } catch (Exception e) {
/*  55 */       this.log.error("Error while loading pet races", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadPetSpeech() {
/*  60 */     if (this.petMessages != null) {
/*  61 */       this.petMessages.clear();
/*     */     }
/*     */     try
/*     */     {
/*  65 */       AtomicInteger petSpeechCount = new AtomicInteger(0);
/*  66 */       this.petMessages = PetDao.getMessages(petSpeechCount);
/*     */       
/*  68 */       this.log.info("Loaded " + this.petMessages.size() + " pet message sets and " + petSpeechCount.get() + " total messages");
/*     */     } catch (Exception e) {
/*  70 */       this.log.error("Error while loading pet messages");
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadTransformablePets() {
/*  75 */     if (this.transformablePets != null) {
/*  76 */       this.transformablePets.clear();
/*     */     }
/*     */     try
/*     */     {
/*  80 */       this.transformablePets = PetDao.getTransformablePets();
/*     */       
/*  82 */       this.log.info("Loaded " + this.transformablePets.size() + " transformable pets");
/*     */     } catch (Exception e) {
/*  84 */       this.log.error("Error while loading transformable pets");
/*     */     }
/*     */   }
/*     */   
/*     */   public int validatePetName(String petName) {
/*  89 */     String pattern = "^[a-zA-Z0-9]*$";
/*     */     
/*  91 */     if (petName.length() <= 0) {
/*  92 */       return 1;
/*     */     }
/*     */     
/*  95 */     if (petName.length() > 16) {
/*  96 */       return 2;
/*     */     }
/*     */     
/*  99 */     if (!petName.matches(pattern)) {
/* 100 */       return 3;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 105 */     return 0;
/*     */   }
/*     */   
/*     */   public List<PetRace> getRacesByRaceId(int raceId) {
/* 109 */     List<PetRace> races = new ArrayList();
/*     */     
/* 111 */     for (PetRace race : getPetRaces()) {
/* 112 */       if (raceId == race.getRaceId()) {
/* 113 */         races.add(race);
/*     */       }
/*     */     }
/* 116 */     return races;
/*     */   }
/*     */   
/*     */   public List<PetRace> getPetRaces() {
/* 120 */     return this.petRaces;
/*     */   }
/*     */   
/*     */   public PetSpeech getSpeech(int petType) {
/* 124 */     return (PetSpeech)this.petMessages.get(Integer.valueOf(petType));
/*     */   }
/*     */   
/*     */   public Map<String, String> getTransformablePets() {
/* 128 */     return this.transformablePets;
/*     */   }
/*     */   
/*     */   public String getTransformationData(String type) {
/* 132 */     return (String)this.transformablePets.get(type);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\PetManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */