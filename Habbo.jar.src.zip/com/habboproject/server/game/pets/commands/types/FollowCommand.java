/*    */ package com.habboproject.server.game.pets.commands.types;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PetEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ 
/*    */ public class FollowCommand extends com.habboproject.server.game.pets.commands.PetCommand
/*    */ {
/*    */   public boolean execute(PlayerEntity executor, PetEntity entity)
/*    */   {
/* 10 */     entity.moveTo(executor.getPosition().squareInFront(executor.getBodyRotation()));
/* 11 */     entity.getPetAI().free();
/*    */     
/* 13 */     entity.getPetAI().setFollowingPlayer(executor);
/*    */     
/* 15 */     executor.getFollowingEntities().add(entity);
/*    */     
/* 17 */     return false;
/*    */   }
/*    */   
/*    */   public int getRequiredLevel()
/*    */   {
/* 22 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean requiresOwner()
/*    */   {
/* 27 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\commands\types\FollowCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */