/*    */ package com.habboproject.server.game.pets.commands.types;
/*    */ 
/*    */ import com.habboproject.server.game.pets.commands.PetCommand;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PetEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.ai.pets.PetAI;
/*    */ 
/*    */ public class BreedCommand
/*    */   extends PetCommand
/*    */ {
/*    */   public boolean execute(PlayerEntity executor, PetEntity entity)
/*    */   {
/* 13 */     entity.getPetAI().breed();
/*    */     
/* 15 */     return true;
/*    */   }
/*    */   
/*    */   public int getRequiredLevel()
/*    */   {
/* 20 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean requiresOwner()
/*    */   {
/* 25 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\commands\types\BreedCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */