/*    */ package com.habboproject.server.game.pets.commands.types;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PetEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ 
/*    */ public class SitCommand extends com.habboproject.server.game.pets.commands.PetCommand
/*    */ {
/*    */   public boolean execute(PlayerEntity executor, PetEntity entity)
/*    */   {
/* 10 */     entity.cancelWalk();
/* 11 */     entity.getPetAI().sit();
/*    */     
/* 13 */     return true;
/*    */   }
/*    */   
/*    */   public int getRequiredLevel()
/*    */   {
/* 18 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean requiresOwner()
/*    */   {
/* 23 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\commands\types\SitCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */