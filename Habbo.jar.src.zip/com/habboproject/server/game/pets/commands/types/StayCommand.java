/*    */ package com.habboproject.server.game.pets.commands.types;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PetEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.ai.pets.PetAI;
/*    */ 
/*    */ public class StayCommand extends com.habboproject.server.game.pets.commands.PetCommand
/*    */ {
/*    */   public boolean execute(com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity executor, PetEntity entity)
/*    */   {
/* 10 */     entity.getPetAI().setFollowingPlayer(null);
/*    */     
/* 12 */     entity.cancelWalk();
/*    */     
/* 14 */     entity.getPetAI().stay();
/*    */     
/* 16 */     return false;
/*    */   }
/*    */   
/*    */   public int getRequiredLevel()
/*    */   {
/* 21 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean requiresOwner()
/*    */   {
/* 26 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\commands\types\StayCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */