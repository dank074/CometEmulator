/*    */ package com.habboproject.server.game.pets.commands;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.pets.commands.types.BreedCommand;
/*    */ import com.habboproject.server.game.pets.data.PetData;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PetEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PetCommandManager
/*    */ {
/*    */   private static PetCommandManager petCommandManager;
/*    */   private Map<String, PetCommand> petCommands;
/*    */   
/*    */   public PetCommandManager()
/*    */   {
/* 17 */     initialize();
/*    */   }
/*    */   
/*    */   public void initialize() {
/* 21 */     if (this.petCommands != null) {
/* 22 */       this.petCommands.clear();
/*    */     }
/*    */     
/* 25 */     this.petCommands = new java.util.HashMap() {};
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean executeCommand(String commandKey, PlayerEntity executor, PetEntity petEntity)
/*    */   {
/* 38 */     if (!this.petCommands.containsKey(commandKey)) {
/* 39 */       return false;
/*    */     }
/*    */     
/* 42 */     PetCommand command = (PetCommand)this.petCommands.get(commandKey);
/*    */     
/* 44 */     if (command.getRequiredLevel() > petEntity.getData().getLevel())
/*    */     {
/* 46 */       return false;
/*    */     }
/*    */     
/* 49 */     if ((command.requiresOwner()) && (executor.getPlayerId() != petEntity.getData().getOwnerId())) {
/* 50 */       return false;
/*    */     }
/* 52 */     return command.execute(executor, petEntity);
/*    */   }
/*    */   
/*    */   public static PetCommandManager getInstance() {
/* 56 */     if (petCommandManager == null) {
/* 57 */       petCommandManager = new PetCommandManager();
/*    */     }
/* 59 */     return petCommandManager;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\commands\PetCommandManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */