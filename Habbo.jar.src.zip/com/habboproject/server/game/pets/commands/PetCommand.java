/*    */ package com.habboproject.server.game.pets.commands;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ 
/*    */ public abstract class PetCommand {
/*    */   public abstract boolean execute(PlayerEntity paramPlayerEntity, com.habboproject.server.game.rooms.objects.entities.types.PetEntity paramPetEntity);
/*    */   
/*    */   public abstract int getRequiredLevel();
/*    */   
/*    */   public abstract boolean requiresOwner();
/*    */   
/* 12 */   public int experienceGain() { return 0; }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\commands\PetCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */