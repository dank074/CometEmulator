/*    */ package com.habboproject.server.game.pets.data;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PetSpeech
/*    */ {
/*    */   private Map<PetMessageType, List<String>> messages;
/*    */   
/*    */   public PetSpeech()
/*    */   {
/* 13 */     this.messages = new HashMap();
/*    */   }
/*    */   
/*    */   public String getMessageByType(PetMessageType type) {
/* 17 */     List<String> availableMessages = (List)this.messages.get(type);
/*    */     
/* 19 */     if (availableMessages.size() == 0) {
/* 20 */       return null;
/*    */     }
/*    */     
/* 23 */     int index = com.habboproject.server.utilities.RandomInteger.getRandom(0, availableMessages.size() - 1);
/* 24 */     return (String)availableMessages.get(index);
/*    */   }
/*    */   
/*    */   public Map<PetMessageType, List<String>> getMessages() {
/* 28 */     return this.messages;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\data\PetSpeech.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */