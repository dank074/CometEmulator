package com.habboproject.server.game.pets.data;

public enum PetMessageType
{
  GENERIC,  SCRATCHED,  WELCOME_HOME,  HUNGRY,  TIRED;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\data\PetMessageType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */