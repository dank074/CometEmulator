/*     */ package com.habboproject.server.game.pets.data;
/*     */ 
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.game.pets.PetManager;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.storage.queries.pets.PetDao;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PetData
/*     */ {
/*     */   private int id;
/*     */   private String name;
/*     */   private int scratches;
/*     */   private int level;
/*     */   private int happiness;
/*     */   private int experience;
/*     */   private int energy;
/*     */   private int ownerId;
/*     */   private String colour;
/*     */   private int raceId;
/*     */   private int typeId;
/*  26 */   private int hairDye = 0;
/*  27 */   private int hair = -1;
/*     */   
/*  29 */   private boolean anyRider = false;
/*  30 */   private boolean saddled = false;
/*     */   
/*     */   private int birthday;
/*     */   
/*     */   private String extraData;
/*     */   
/*     */   private Position roomPosition;
/*     */   
/*  38 */   private boolean needsUpdate = false;
/*     */   
/*     */   public PetData(ResultSet data) throws SQLException {
/*  41 */     this.id = data.getInt("id");
/*  42 */     this.name = data.getString("pet_name");
/*  43 */     this.level = data.getInt("level");
/*  44 */     this.happiness = data.getInt("happiness");
/*  45 */     this.experience = data.getInt("experience");
/*  46 */     this.energy = data.getInt("energy");
/*  47 */     this.ownerId = data.getInt("owner_id");
/*  48 */     this.colour = data.getString("colour");
/*  49 */     this.raceId = data.getInt("race_id");
/*  50 */     this.typeId = data.getInt("type");
/*  51 */     this.saddled = data.getBoolean("saddled");
/*  52 */     this.hair = data.getInt("hair_style");
/*  53 */     this.hairDye = data.getInt("hair_colour");
/*  54 */     this.anyRider = data.getBoolean("any_rider");
/*  55 */     this.birthday = data.getInt("birthday");
/*  56 */     this.extraData = data.getString("extra_data");
/*     */     
/*  58 */     this.roomPosition = new Position(data.getInt("x"), data.getInt("y"));
/*     */   }
/*     */   
/*     */   public PetData(int id, String name, int scratches, int level, int happiness, int experience, int energy, int ownerId, String colour, int raceId, int typeId, String extraData)
/*     */   {
/*  63 */     this.id = id;
/*  64 */     this.name = name;
/*  65 */     this.scratches = scratches;
/*  66 */     this.level = level;
/*  67 */     this.happiness = happiness;
/*  68 */     this.experience = experience;
/*  69 */     this.energy = energy;
/*  70 */     this.ownerId = ownerId;
/*  71 */     this.colour = colour;
/*  72 */     this.raceId = raceId;
/*  73 */     this.typeId = typeId;
/*  74 */     this.extraData = extraData;
/*     */   }
/*     */   
/*     */   public void saveStats() {
/*  78 */     PetDao.saveStats(this.scratches, this.level, this.happiness, this.experience, this.energy, this.id);
/*     */     
/*  80 */     if (this.needsUpdate) this.needsUpdate = false;
/*     */   }
/*     */   
/*     */   public void saveHorseData() {
/*  84 */     PetDao.saveHorseData(getId(), isSaddled(), this.hair, this.hairDye, this.anyRider, this.raceId);
/*     */   }
/*     */   
/*     */   public void increaseExperience(int amount) {
/*  88 */     this.experience += amount;
/*     */     
/*  90 */     if (!this.needsUpdate) this.needsUpdate = true;
/*     */   }
/*     */   
/*     */   public void increaseHappiness(int amount) {
/*  94 */     this.happiness += amount;
/*     */     
/*  96 */     if (!this.needsUpdate) this.needsUpdate = true;
/*     */   }
/*     */   
/*     */   public void incrementLevel() {
/* 100 */     this.level += 1;
/*     */     
/* 102 */     if (!this.needsUpdate) this.needsUpdate = true;
/*     */   }
/*     */   
/*     */   public void incrementScratches() {
/* 106 */     this.scratches += 1;
/*     */     
/* 108 */     if (!this.needsUpdate) this.needsUpdate = true;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 112 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 116 */     return this.name;
/*     */   }
/*     */   
/*     */   public int getLevel() {
/* 120 */     return this.level;
/*     */   }
/*     */   
/*     */   public int getHappiness() {
/* 124 */     return this.happiness;
/*     */   }
/*     */   
/*     */   public int getExperience() {
/* 128 */     return this.experience;
/*     */   }
/*     */   
/*     */   public int getEnergy() {
/* 132 */     return this.energy;
/*     */   }
/*     */   
/*     */   public int getOwnerId() {
/* 136 */     return this.ownerId;
/*     */   }
/*     */   
/*     */   public String getColour() {
/* 140 */     return this.colour;
/*     */   }
/*     */   
/*     */   public int getRaceId() {
/* 144 */     return this.raceId;
/*     */   }
/*     */   
/*     */   public String getLook() {
/* 148 */     return getTypeId() + " " + getRaceId() + " " + getColour();
/*     */   }
/*     */   
/*     */   public int getHairDye() {
/* 152 */     return this.hairDye;
/*     */   }
/*     */   
/*     */   public int getHair() {
/* 156 */     return this.hair;
/*     */   }
/*     */   
/*     */   public int getTypeId() {
/* 160 */     return this.typeId;
/*     */   }
/*     */   
/*     */   public PetSpeech getSpeech() {
/* 164 */     return PetManager.getInstance().getSpeech(this.typeId);
/*     */   }
/*     */   
/*     */   public Position getRoomPosition() {
/* 168 */     return this.roomPosition;
/*     */   }
/*     */   
/*     */   public void setRoomPosition(Position position) {
/* 172 */     this.roomPosition = position;
/*     */   }
/*     */   
/*     */   public void setHairDye(int hairDye) {
/* 176 */     this.hairDye = hairDye;
/*     */   }
/*     */   
/*     */   public void setHair(int hair) {
/* 180 */     this.hair = hair;
/*     */   }
/*     */   
/*     */   public boolean isSaddled() {
/* 184 */     return this.saddled;
/*     */   }
/*     */   
/*     */   public void setSaddled(boolean saddled) {
/* 188 */     this.saddled = saddled;
/*     */   }
/*     */   
/*     */   public boolean isAnyRider() {
/* 192 */     return this.anyRider;
/*     */   }
/*     */   
/*     */   public void setAnyRider(boolean anyRider) {
/* 196 */     this.anyRider = anyRider;
/*     */   }
/*     */   
/*     */   public int getScratches() {
/* 200 */     return this.scratches;
/*     */   }
/*     */   
/*     */   public void setRaceId(int raceId) {
/* 204 */     this.raceId = raceId;
/*     */   }
/*     */   
/*     */   public int getAge() {
/* 208 */     return (int)Math.floor((Comet.getTime() - this.birthday) / 86400L);
/*     */   }
/*     */   
/*     */   public String getExtraData() {
/* 212 */     return this.extraData;
/*     */   }
/*     */   
/*     */   public boolean needsUpdate() {
/* 216 */     return this.needsUpdate;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\data\PetData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */