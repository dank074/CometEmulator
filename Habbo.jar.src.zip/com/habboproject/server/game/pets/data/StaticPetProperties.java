package com.habboproject.server.game.pets.data;

public class StaticPetProperties
{
  public static final int DEFAULT_LEVEL = 1;
  public static final int DEFAULT_ENERGY = 100;
  public static final int DEFAULT_HAPPINESS = 100;
  public static final int DEFAULT_EXPERIENCE = 0;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\data\StaticPetProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */