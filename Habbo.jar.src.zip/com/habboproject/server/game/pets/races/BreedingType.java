/*    */ package com.habboproject.server.game.pets.races;
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BreedingType
/*    */ {
/*  7 */   DOG(0), 
/*  8 */   CAT(1), 
/*  9 */   TERRIER(3), 
/* 10 */   BEAR(4), 
/* 11 */   PIG(5);
/*    */   
/*    */   private final int breedingId;
/*    */   
/*    */   private BreedingType(int breedingId) {
/* 16 */     this.breedingId = breedingId;
/*    */   }
/*    */   
/*    */   public int getBreedingId() {
/* 20 */     return this.breedingId;
/*    */   }
/*    */   
/*    */   public static BreedingType getType(int typeId) {
/* 24 */     switch (typeId) {
/*    */     case 0: 
/* 26 */       return DOG;
/*    */     
/*    */     case 1: 
/* 29 */       return CAT;
/*    */     
/*    */     case 3: 
/* 32 */       return TERRIER;
/*    */     
/*    */     case 4: 
/* 35 */       return BEAR;
/*    */     
/*    */     case 5: 
/* 38 */       return PIG;
/*    */     }
/*    */     
/* 41 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\races\BreedingType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */