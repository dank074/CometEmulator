/*    */ package com.habboproject.server.game.pets.races;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class PetRace
/*    */ {
/*    */   private int raceId;
/*    */   private int colour1;
/*    */   private int colour2;
/*    */   private boolean hasColour1;
/*    */   private boolean hasColour2;
/*    */   
/*    */   public PetRace(ResultSet data) throws SQLException
/*    */   {
/* 16 */     this.raceId = data.getInt("race_id");
/*    */     
/* 18 */     this.colour1 = data.getInt("colour1");
/* 19 */     this.colour2 = data.getInt("colour2");
/*    */     
/* 21 */     this.hasColour1 = data.getString("has1colour").equals("1");
/* 22 */     this.hasColour2 = data.getString("has2colour").equals("1");
/*    */   }
/*    */   
/*    */   public int getRaceId() {
/* 26 */     return this.raceId;
/*    */   }
/*    */   
/*    */   public int getColour1() {
/* 30 */     return this.colour1;
/*    */   }
/*    */   
/*    */   public int getColour2() {
/* 34 */     return this.colour2;
/*    */   }
/*    */   
/*    */   public boolean hasColour1() {
/* 38 */     return this.hasColour1;
/*    */   }
/*    */   
/*    */   public boolean hasColour2() {
/* 42 */     return this.hasColour2;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\pets\races\PetRace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */