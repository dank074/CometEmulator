package com.habboproject.server.game.polls.types;

public enum PollQuestionType
{
  WORDED,  MULTIPLE_CHOICE;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\polls\types\PollQuestionType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */