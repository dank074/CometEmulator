/*   */ package com.habboproject.server.game.polls.types.questions;
/*   */ 
/*   */ import com.habboproject.server.game.polls.types.PollQuestion;
/*   */ 
/*   */ public class WordedPollQuestion extends PollQuestion {
/*   */   public WordedPollQuestion(String question) {
/* 7 */     super(question);
/*   */   }
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\polls\types\questions\WordedPollQuestion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */