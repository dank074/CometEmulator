/*    */ package com.habboproject.server.game.polls.types.questions;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.habboproject.server.game.polls.types.PollQuestion;
/*    */ import com.habboproject.server.utilities.JsonFactory;
/*    */ import java.util.List;
/*    */ 
/*    */ public class MultipleChoiceQuestion extends PollQuestion
/*    */ {
/*    */   private List<String> choices;
/*    */   
/*    */   public MultipleChoiceQuestion(String question, String questionData)
/*    */   {
/* 14 */     super(question);
/*    */     
/* 16 */     this.choices = ((List)JsonFactory.getInstance().fromJson(questionData, new com.google.gson.reflect.TypeToken() {}.getType()));
/*    */   }
/*    */   
/*    */   public MultipleChoiceQuestion(String question, List<String> choices)
/*    */   {
/* 21 */     super(question);
/*    */     
/* 23 */     this.choices = choices;
/*    */   }
/*    */   
/*    */   public List<String> getChoices() {
/* 27 */     return this.choices;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\polls\types\questions\MultipleChoiceQuestion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */