/*    */ package com.habboproject.server.game.polls.types;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ public class Poll
/*    */ {
/*    */   private final int pollId;
/*    */   private final int roomId;
/*    */   private final String pollTitle;
/*    */   private final String thanksMessage;
/*    */   private final String badgeReward;
/*    */   private final Map<Integer, PollQuestion> pollQuestions;
/*    */   private final Set<Integer> playersAnswered;
/*    */   
/*    */   public Poll(int pollId, int roomId, String pollTitle, String thanksMessage, String badgeReward)
/*    */   {
/* 21 */     this.pollId = pollId;
/* 22 */     this.roomId = roomId;
/* 23 */     this.pollTitle = pollTitle;
/* 24 */     this.thanksMessage = thanksMessage;
/* 25 */     this.badgeReward = badgeReward;
/*    */     
/* 27 */     this.pollQuestions = new ConcurrentHashMap();
/* 28 */     this.playersAnswered = new HashSet();
/*    */   }
/*    */   
/*    */   public void addQuestion(int questionId, PollQuestion pollQuestion) {
/* 32 */     this.pollQuestions.put(Integer.valueOf(questionId), pollQuestion);
/*    */   }
/*    */   
/*    */   public int getPollId() {
/* 36 */     return this.pollId;
/*    */   }
/*    */   
/*    */   public int getRoomId() {
/* 40 */     return this.roomId;
/*    */   }
/*    */   
/*    */   public String getPollTitle() {
/* 44 */     return this.pollTitle;
/*    */   }
/*    */   
/*    */   public Map<Integer, PollQuestion> getPollQuestions() {
/* 48 */     return this.pollQuestions;
/*    */   }
/*    */   
/*    */   public String getThanksMessage() {
/* 52 */     return this.thanksMessage;
/*    */   }
/*    */   
/*    */   public Set<Integer> getPlayersAnswered() {
/* 56 */     return this.playersAnswered;
/*    */   }
/*    */   
/*    */   public String getBadgeReward() {
/* 60 */     return this.badgeReward;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\polls\types\Poll.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */