/*    */ package com.habboproject.server.game.polls.types;
/*    */ 
/*    */ public abstract class PollQuestion {
/*    */   private String question;
/*    */   
/*    */   public PollQuestion(String question) {
/*  7 */     this.question = question;
/*    */   }
/*    */   
/*    */   public String getQuestion() {
/* 11 */     return this.question;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\polls\types\PollQuestion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */