/*    */ package com.habboproject.server.game.polls;
/*    */ 
/*    */ import com.habboproject.server.game.polls.types.Poll;
/*    */ import com.habboproject.server.game.polls.types.PollQuestion;
/*    */ import com.habboproject.server.game.polls.types.questions.MultipleChoiceQuestion;
/*    */ import com.habboproject.server.storage.queries.polls.PollDao;
/*    */ import com.habboproject.server.utilities.Initializable;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class PollManager implements Initializable
/*    */ {
/*    */   private static PollManager pollManagerInstance;
/* 15 */   private static Logger log = Logger.getLogger(PollManager.class.getName());
/*    */   private Map<Integer, Poll> polls;
/*    */   private final Map<Integer, Integer> roomIdToPollId;
/*    */   
/*    */   public PollManager()
/*    */   {
/* 21 */     this.polls = new ConcurrentHashMap();
/* 22 */     this.roomIdToPollId = new ConcurrentHashMap();
/*    */   }
/*    */   
/*    */   public void initialize()
/*    */   {
/* 27 */     if (this.polls != null) {
/* 28 */       for (Poll poll : this.polls.values()) {
/* 29 */         for (PollQuestion pollQuestion : poll.getPollQuestions().values()) {
/* 30 */           if ((pollQuestion instanceof MultipleChoiceQuestion)) {
/* 31 */             ((MultipleChoiceQuestion)pollQuestion).getChoices().clear();
/*    */           }
/*    */         }
/*    */         
/* 35 */         poll.getPollQuestions().clear();
/*    */       }
/*    */       
/* 38 */       this.polls.clear();
/* 39 */       this.roomIdToPollId.clear();
/*    */     }
/*    */     
/* 42 */     this.polls = PollDao.getAllPolls();
/*    */     
/* 44 */     for (Poll poll : getPolls().values()) {
/* 45 */       if (!this.roomIdToPollId.containsKey(Integer.valueOf(poll.getRoomId()))) {
/* 46 */         this.roomIdToPollId.put(Integer.valueOf(poll.getRoomId()), Integer.valueOf(poll.getPollId()));
/*    */       }
/*    */     }
/*    */     
/* 50 */     log.info("Loaded " + getPolls().size() + " poll(s)");
/*    */   }
/*    */   
/*    */   public boolean roomHasPoll(int roomId) {
/* 54 */     return this.roomIdToPollId.containsKey(Integer.valueOf(roomId));
/*    */   }
/*    */   
/*    */   public Poll getPollByRoomId(int roomId) {
/* 58 */     if (!this.roomIdToPollId.containsKey(Integer.valueOf(roomId))) {
/* 59 */       return null;
/*    */     }
/*    */     
/* 62 */     return getPollbyId(((Integer)this.roomIdToPollId.get(Integer.valueOf(roomId))).intValue());
/*    */   }
/*    */   
/*    */   public Poll getPollbyId(int pollId) {
/* 66 */     return (Poll)this.polls.get(Integer.valueOf(pollId));
/*    */   }
/*    */   
/*    */   public Map<Integer, Poll> getPolls() {
/* 70 */     return this.polls;
/*    */   }
/*    */   
/*    */   public static PollManager getInstance() {
/* 74 */     if (pollManagerInstance == null) {
/* 75 */       pollManagerInstance = new PollManager();
/*    */     }
/*    */     
/* 78 */     return pollManagerInstance;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\polls\PollManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */