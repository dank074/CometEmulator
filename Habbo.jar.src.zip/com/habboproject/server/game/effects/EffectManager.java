/*    */ package com.habboproject.server.game.effects;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import com.habboproject.server.game.effects.types.EffectItem;
/*    */ import com.habboproject.server.storage.queries.effects.EffectDao;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EffectManager
/*    */ {
/*    */   public static EffectManager instance;
/* 15 */   private final Logger log = Logger.getLogger(EffectManager.class.getName());
/* 16 */   private final Map<Integer, EffectItem> effects = Maps.newConcurrentMap();
/*    */   
/*    */ 
/*    */ 
/*    */   public static EffectManager getInstance()
/*    */   {
/* 22 */     if (instance == null) {
/* 23 */       instance = new EffectManager();
/*    */     }
/* 25 */     return instance;
/*    */   }
/*    */   
/*    */   public void initialize() {
/* 29 */     if ((this.effects != null) && (this.effects.size() > 0)) {
/* 30 */       this.effects.clear();
/*    */     }
/*    */     try {
/* 33 */       EffectDao.loadEffectsPermissions(this.effects);
/*    */     } catch (Exception e) {
/* 35 */       this.log.error("Error while loading effects permissions", e);
/*    */     }
/*    */     
/* 38 */     this.log.info("Loaded " + this.effects.size() + " effects permissions");
/*    */   }
/*    */   
/*    */   public Map<Integer, EffectItem> getEffects() {
/* 42 */     return this.effects;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\effects\EffectManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */