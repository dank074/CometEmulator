/*    */ package com.habboproject.server.game.effects.types;
/*    */ 
/*    */ 
/*    */ public class EffectItem
/*    */ {
/*    */   private final int effectId;
/*    */   private final int minRank;
/*    */   private final boolean furniEffect;
/*    */   private final boolean buyableEffect;
/*    */   
/*    */   public EffectItem(int effectId, int minRank, boolean furniEffect, boolean buyableEffect)
/*    */   {
/* 13 */     this.effectId = effectId;
/* 14 */     this.minRank = minRank;
/* 15 */     this.furniEffect = furniEffect;
/* 16 */     this.buyableEffect = buyableEffect;
/*    */   }
/*    */   
/*    */   public int getEffectId() {
/* 20 */     return this.effectId;
/*    */   }
/*    */   
/*    */   public int getMinRank() {
/* 24 */     return this.minRank;
/*    */   }
/*    */   
/*    */   public boolean isFurniEffect() {
/* 28 */     return this.furniEffect;
/*    */   }
/*    */   
/*    */   public boolean isBuyableEffect() {
/* 32 */     return this.buyableEffect;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\effects\types\EffectItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */