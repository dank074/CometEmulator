/*    */ package com.habboproject.server.game.items.rares;
/*    */ import com.habboproject.server.api.game.furniture.types.LimitedEditionItem;
/*    */ 
/*  4 */ public class LimitedEditionItemData implements LimitedEditionItem { public static final LimitedEditionItemData NONE = new LimitedEditionItemData(0L, 0, 0);
/*    */   private long itemId;
/*    */   private int limitedRare;
/*    */   private int limitedRareTotal;
/*    */   
/*    */   public LimitedEditionItemData(long itemId, int limitedRare, int limitedRareTotal)
/*    */   {
/* 11 */     this.itemId = itemId;
/* 12 */     this.limitedRare = limitedRare;
/* 13 */     this.limitedRareTotal = limitedRareTotal;
/*    */   }
/*    */   
/*    */   public long getItemId() {
/* 17 */     return this.itemId;
/*    */   }
/*    */   
/*    */   public int getLimitedRare() {
/* 21 */     return this.limitedRare;
/*    */   }
/*    */   
/*    */   public int getLimitedRareTotal() {
/* 25 */     return this.limitedRareTotal;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\items\rares\LimitedEditionItemData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */