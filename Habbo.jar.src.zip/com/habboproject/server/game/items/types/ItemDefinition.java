/*     */ package com.habboproject.server.game.items.types;
/*     */ 
/*     */ import com.habboproject.server.api.game.furniture.types.FurnitureDefinition;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemDefinition
/*     */   implements FurnitureDefinition
/*     */ {
/*     */   private final int id;
/*     */   private final String publicName;
/*     */   private final String itemName;
/*     */   private final String type;
/*     */   private final int width;
/*     */   private final int length;
/*     */   private final double height;
/*     */   private final int spriteId;
/*     */   private final boolean canStack;
/*     */   private final boolean canSit;
/*     */   private final boolean canWalk;
/*     */   private final boolean canTrade;
/*     */   private final boolean canRecycle;
/*     */   private final boolean canMarket;
/*     */   private final boolean canGift;
/*     */   private final boolean canInventoryStack;
/*     */   private final int effectId;
/*     */   private final int offerId;
/*     */   private final String interaction;
/*     */   private final int interactionCycleCount;
/*     */   private final String[] vendingIds;
/*     */   private final boolean requiresRights;
/*     */   private int songId;
/*     */   private final Double[] variableHeights;
/*     */   
/*     */   public ItemDefinition(ResultSet data)
/*     */     throws SQLException
/*     */   {
/*  40 */     this.id = data.getInt("id");
/*  41 */     this.publicName = data.getString("public_name");
/*  42 */     this.itemName = data.getString("item_name");
/*  43 */     this.type = data.getString("type");
/*  44 */     this.width = data.getInt("width");
/*  45 */     this.length = data.getInt("length");
/*  46 */     double height = data.getDouble("stack_height");
/*  47 */     this.spriteId = data.getInt("sprite_id");
/*     */     
/*  49 */     this.canStack = data.getString("can_stack").equals("1");
/*  50 */     this.canSit = data.getString("can_sit").equals("1");
/*  51 */     this.canWalk = data.getString("is_walkable").equals("1");
/*  52 */     this.canTrade = data.getString("allow_trade").equals("1");
/*  53 */     this.canInventoryStack = data.getString("allow_inventory_stack").equals("1");
/*     */     
/*  55 */     this.offerId = data.getInt("flat_id");
/*     */     
/*  57 */     this.canRecycle = false;
/*  58 */     this.canMarket = false;
/*  59 */     this.canGift = data.getString("allow_gift").equals("1");
/*     */     
/*  61 */     this.effectId = data.getInt("effect_id");
/*  62 */     this.interaction = data.getString("interaction_type");
/*  63 */     this.interactionCycleCount = data.getInt("interaction_modes_count");
/*  64 */     this.vendingIds = (data.getString("vending_ids").isEmpty() ? new String[0] : data.getString("vending_ids").split(","));
/*     */     
/*  66 */     this.requiresRights = data.getString("requires_rights").equals("1");
/*     */     
/*  68 */     this.songId = data.getInt("song_id");
/*     */     
/*  70 */     String variableHeightData = data.getString("variable_heights");
/*     */     
/*  72 */     if ((!variableHeightData.isEmpty()) && (variableHeightData.contains(","))) {
/*  73 */       String[] variableHeightArray = variableHeightData.split(",");
/*  74 */       this.variableHeights = new Double[variableHeightArray.length];
/*     */       
/*  76 */       for (int i = 0; i < variableHeightArray.length; i++) {
/*     */         try {
/*  78 */           this.variableHeights[i] = Double.valueOf(Double.parseDouble(variableHeightArray[i]));
/*     */         }
/*     */         catch (Exception localException) {}
/*     */       }
/*     */     }
/*     */     else {
/*  84 */       this.variableHeights = null;
/*     */     }
/*     */     
/*  87 */     if (height == 0.0D) {
/*  88 */       this.height = 0.001D;
/*     */     } else {
/*  90 */       this.height = height;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isAdFurni() {
/*  95 */     return (this.itemName.equals("ads_mpu_720")) || (this.itemName.equals("ads_background")) || (this.itemName.equals("ads_mpu_300")) || (this.itemName.equals("ads_mpu_160")) || (this.itemName.equals("backgroundk")) || (this.interaction.equals("ads_background"));
/*     */   }
/*     */   
/*     */   public boolean isRoomDecor() {
/*  99 */     return (this.itemName.startsWith("wallpaper")) || (this.itemName.startsWith("landscape")) || (this.itemName.startsWith("a2 "));
/*     */   }
/*     */   
/*     */   public boolean isTeleporter() {
/* 103 */     return (getInteraction().equals("teleport")) || (getInteraction().equals("teleport_door")) || (getInteraction().equals("teleport_pad"));
/*     */   }
/*     */   
/*     */   public boolean isSong() {
/* 107 */     return this.songId != 0;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 111 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getPublicName() {
/* 115 */     return this.publicName;
/*     */   }
/*     */   
/*     */   public String getItemName() {
/* 119 */     return this.itemName;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 123 */     return this.type;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 127 */     return this.width;
/*     */   }
/*     */   
/*     */   public double getHeight() {
/* 131 */     return this.height;
/*     */   }
/*     */   
/*     */   public int getSpriteId() {
/* 135 */     return this.spriteId;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 139 */     return this.length;
/*     */   }
/*     */   
/*     */   public String getInteraction() {
/* 143 */     return this.interaction;
/*     */   }
/*     */   
/*     */   public int getInteractionCycleCount() {
/* 147 */     return this.interactionCycleCount;
/*     */   }
/*     */   
/*     */   public int getEffectId() {
/* 151 */     return this.effectId;
/*     */   }
/*     */   
/*     */   public String[] getVendingIds() {
/* 155 */     return this.vendingIds;
/*     */   }
/*     */   
/*     */   public int getOfferId() {
/* 159 */     return this.offerId;
/*     */   }
/*     */   
/*     */   public boolean canStack() {
/* 163 */     return this.canStack;
/*     */   }
/*     */   
/*     */   public boolean canSit() {
/* 167 */     return this.canSit;
/*     */   }
/*     */   
/*     */   public boolean canWalk() {
/* 171 */     return this.canWalk;
/*     */   }
/*     */   
/*     */   public boolean canTrade() {
/* 175 */     return this.canTrade;
/*     */   }
/*     */   
/*     */   public boolean canRecycle() {
/* 179 */     return this.canRecycle;
/*     */   }
/*     */   
/*     */   public boolean canMarket() {
/* 183 */     return this.canMarket;
/*     */   }
/*     */   
/*     */   public boolean canGift() {
/* 187 */     return this.canGift;
/*     */   }
/*     */   
/*     */   public boolean canInventoryStack() {
/* 191 */     return this.canInventoryStack;
/*     */   }
/*     */   
/*     */   public Double[] getVariableHeights() {
/* 195 */     return this.variableHeights;
/*     */   }
/*     */   
/*     */   public boolean requiresRights() {
/* 199 */     return this.requiresRights;
/*     */   }
/*     */   
/*     */   public int getSongId() {
/* 203 */     return this.songId;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\items\types\ItemDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */