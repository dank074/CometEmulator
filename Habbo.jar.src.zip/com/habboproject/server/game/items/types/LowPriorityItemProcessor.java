/*    */ package com.habboproject.server.game.items.types;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.threads.CometThread;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.CopyOnWriteArrayList;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ public class LowPriorityItemProcessor implements CometThread
/*    */ {
/*    */   private final ScheduledExecutorService asyncItemEventQueue;
/*    */   private static final int processTime = 50;
/*    */   private List<RoomItemFloor> itemsToProcess;
/*    */   private static LowPriorityItemProcessor instance;
/*    */   
/*    */   public LowPriorityItemProcessor()
/*    */   {
/* 21 */     this.asyncItemEventQueue = Executors.newScheduledThreadPool(2, new org.apache.lucene.util.NamedThreadFactory("LowPriorityItemProcessor-%d"));
/* 22 */     this.itemsToProcess = new CopyOnWriteArrayList();
/*    */     
/* 24 */     this.asyncItemEventQueue.scheduleWithFixedDelay(this, 50L, 50L, TimeUnit.MILLISECONDS);
/*    */   }
/*    */   
/*    */   public void run()
/*    */   {
/* 29 */     List<RoomItemFloor> itemsToRemove = new ArrayList();
/*    */     
/* 31 */     for (RoomItemFloor roomItemFloor : this.itemsToProcess) {
/* 32 */       if (roomItemFloor.requiresTick()) {
/* 33 */         roomItemFloor.tick();
/*    */       } else {
/* 35 */         itemsToRemove.add(roomItemFloor);
/*    */       }
/*    */     }
/*    */     
/* 39 */     for (RoomItemFloor roomItemFloor : itemsToRemove) {
/* 40 */       this.itemsToProcess.remove(roomItemFloor);
/*    */     }
/*    */     
/* 43 */     itemsToRemove.clear();
/*    */   }
/*    */   
/*    */   public void submit(RoomItemFloor floorItem) {
/* 47 */     this.itemsToProcess.add(floorItem);
/*    */   }
/*    */   
/*    */ 
/*    */   public static LowPriorityItemProcessor getInstance()
/*    */   {
/* 53 */     if (instance == null) {
/* 54 */       instance = new LowPriorityItemProcessor();
/*    */     }
/*    */     
/* 57 */     return instance;
/*    */   }
/*    */   
/*    */   public static int getProcessTime(double time) {
/* 61 */     long realTime = Math.round(time * 1000.0D / 50.0D);
/*    */     
/* 63 */     if (realTime < 1L) {
/* 64 */       realTime = 1L;
/*    */     }
/*    */     
/* 67 */     return (int)realTime;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\items\types\LowPriorityItemProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */