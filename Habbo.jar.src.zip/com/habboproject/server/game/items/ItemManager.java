/*     */ package com.habboproject.server.game.items;
/*     */ 
/*     */ import com.habboproject.server.game.items.music.MusicData;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import com.habboproject.server.storage.queries.items.ItemDao;
/*     */ import com.habboproject.server.storage.queries.items.MusicDao;
/*     */ import com.habboproject.server.storage.queries.items.TeleporterDao;
/*     */ import com.habboproject.server.storage.queries.rooms.RoomItemDao;
/*     */ import com.habboproject.server.utilities.Initializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ public class ItemManager
/*     */   implements Initializable
/*     */ {
/*     */   private static ItemManager itemManagerInstance;
/*  21 */   private Logger log = Logger.getLogger(ItemManager.class.getName());
/*     */   
/*     */   private Map<Integer, ItemDefinition> itemDefinitions;
/*     */   
/*     */   private Map<Integer, Integer> itemSpriteIdToDefinitionId;
/*     */   
/*     */   private Map<Integer, MusicData> musicData;
/*     */   
/*     */   private Map<Long, Integer> itemIdToVirtualId;
/*     */   
/*     */   private Map<Integer, Long> virtualIdToItemId;
/*     */   
/*     */   private AtomicInteger itemIdCounter;
/*     */   
/*     */   private Integer saddleId;
/*     */   
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  40 */     this.itemDefinitions = new HashMap();
/*  41 */     this.musicData = new HashMap();
/*     */     
/*  43 */     this.itemIdToVirtualId = new ConcurrentHashMap();
/*  44 */     this.virtualIdToItemId = new ConcurrentHashMap();
/*     */     
/*  46 */     this.itemIdCounter = new AtomicInteger(1);
/*     */     
/*  48 */     loadItemDefinitions();
/*  49 */     loadMusicData();
/*     */     
/*  51 */     this.log.info("ItemManager initialized");
/*     */   }
/*     */   
/*     */   public static ItemManager getInstance() {
/*  55 */     if (itemManagerInstance == null) {
/*  56 */       itemManagerInstance = new ItemManager();
/*     */     }
/*     */     
/*  59 */     return itemManagerInstance;
/*     */   }
/*     */   
/*     */   public void loadItemDefinitions() {
/*  63 */     Map<Integer, ItemDefinition> tempMap = this.itemDefinitions;
/*  64 */     Map<Integer, Integer> tempSpriteIdItemMap = this.itemSpriteIdToDefinitionId;
/*     */     try
/*     */     {
/*  67 */       this.itemDefinitions = ItemDao.getDefinitions();
/*  68 */       this.itemSpriteIdToDefinitionId = new HashMap();
/*     */     } catch (Exception e) {
/*  70 */       this.log.error("Error while loading item definitions", e);
/*     */     }
/*     */     
/*  73 */     if (tempMap.size() >= 1) {
/*  74 */       tempMap.clear();
/*  75 */       tempSpriteIdItemMap.clear();
/*     */     }
/*     */     
/*  78 */     if (this.itemDefinitions != null) {
/*  79 */       for (ItemDefinition itemDefinition : this.itemDefinitions.values()) {
/*  80 */         if (itemDefinition.getItemName().equals("horse_saddle1")) {
/*  81 */           this.saddleId = Integer.valueOf(itemDefinition.getId());
/*     */         }
/*     */         
/*  84 */         this.itemSpriteIdToDefinitionId.put(Integer.valueOf(itemDefinition.getSpriteId()), Integer.valueOf(itemDefinition.getId()));
/*     */       }
/*     */     }
/*     */     
/*  88 */     this.log.info("Loaded " + getItemDefinitions().size() + " item definitions");
/*     */   }
/*     */   
/*     */   public void loadMusicData() {
/*  92 */     if (!this.musicData.isEmpty()) {
/*  93 */       this.musicData.clear();
/*     */     }
/*     */     
/*  96 */     MusicDao.getMusicData(this.musicData);
/*  97 */     this.log.info("Loaded " + this.musicData.size() + " songs");
/*     */   }
/*     */   
/*     */   public int getItemVirtualId(long itemId) {
/* 101 */     if (this.itemIdToVirtualId.containsKey(Long.valueOf(itemId))) {
/* 102 */       return ((Integer)this.itemIdToVirtualId.get(Long.valueOf(itemId))).intValue();
/*     */     }
/*     */     
/* 105 */     int virtualId = this.itemIdCounter.getAndIncrement();
/*     */     
/* 107 */     this.itemIdToVirtualId.put(Long.valueOf(itemId), Integer.valueOf(virtualId));
/* 108 */     this.virtualIdToItemId.put(Integer.valueOf(virtualId), Long.valueOf(itemId));
/*     */     
/* 110 */     return virtualId;
/*     */   }
/*     */   
/*     */   public void disposeItemVirtualId(long itemId) {
/* 114 */     int virtualId = getItemVirtualId(itemId);
/*     */     
/* 116 */     this.itemIdToVirtualId.remove(Long.valueOf(itemId));
/* 117 */     this.virtualIdToItemId.remove(Integer.valueOf(virtualId));
/*     */   }
/*     */   
/*     */   public Long getItemIdByVirtualId(int virtualId) {
/* 121 */     return (Long)this.virtualIdToItemId.get(Integer.valueOf(virtualId));
/*     */   }
/*     */   
/*     */   public long getTeleportPartner(long itemId) {
/* 125 */     return TeleporterDao.getPairId(itemId);
/*     */   }
/*     */   
/*     */   public int roomIdByItemId(long itemId) {
/* 129 */     return RoomItemDao.getRoomIdById(itemId);
/*     */   }
/*     */   
/*     */   public ItemDefinition getDefinition(int itemId) {
/* 133 */     if (getItemDefinitions().containsKey(Integer.valueOf(itemId))) {
/* 134 */       return (ItemDefinition)getItemDefinitions().get(Integer.valueOf(itemId));
/*     */     }
/*     */     
/* 137 */     return null;
/*     */   }
/*     */   
/*     */   public MusicData getMusicData(int songId) {
/* 141 */     if (this.musicData.containsKey(Integer.valueOf(songId))) {
/* 142 */       return (MusicData)this.musicData.get(Integer.valueOf(songId));
/*     */     }
/*     */     
/* 145 */     return null;
/*     */   }
/*     */   
/*     */   public MusicData getMusicDataByName(String name) {
/* 149 */     for (MusicData musicData : this.musicData.values()) {
/* 150 */       if (musicData.getName().equals(name)) {
/* 151 */         return musicData;
/*     */       }
/*     */     }
/*     */     
/* 155 */     return null;
/*     */   }
/*     */   
/*     */   public Map<Long, Integer> getItemIdToVirtualIds() {
/* 159 */     return this.itemIdToVirtualId;
/*     */   }
/*     */   
/*     */   public ItemDefinition getBySpriteId(int spriteId) {
/* 163 */     return (ItemDefinition)this.itemDefinitions.get(this.itemSpriteIdToDefinitionId.get(Integer.valueOf(spriteId)));
/*     */   }
/*     */   
/*     */   public Logger getLogger() {
/* 167 */     return this.log;
/*     */   }
/*     */   
/*     */   public Map<Integer, ItemDefinition> getItemDefinitions() {
/* 171 */     return this.itemDefinitions;
/*     */   }
/*     */   
/*     */   public Integer getSaddleId() {
/* 175 */     return this.saddleId;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\items\ItemManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */