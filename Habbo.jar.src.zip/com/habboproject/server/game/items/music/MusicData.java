/*    */ package com.habboproject.server.game.items.music;
/*    */ 
/*    */ public class MusicData
/*    */ {
/*    */   private int songId;
/*    */   private String name;
/*    */   private String title;
/*    */   private String artist;
/*    */   private String data;
/*    */   private int lengthSeconds;
/*    */   
/*    */   public MusicData(int songId, String name, String title, String artist, String data, int lengthSeconds)
/*    */   {
/* 14 */     this.songId = songId;
/* 15 */     this.name = name;
/* 16 */     this.title = title;
/* 17 */     this.artist = artist;
/* 18 */     this.data = data;
/* 19 */     this.lengthSeconds = lengthSeconds;
/*    */   }
/*    */   
/*    */   public int getSongId() {
/* 23 */     return this.songId;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 27 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getTitle() {
/* 31 */     return this.title;
/*    */   }
/*    */   
/*    */   public String getArtist() {
/* 35 */     return this.artist;
/*    */   }
/*    */   
/*    */   public String getData() {
/* 39 */     return this.data;
/*    */   }
/*    */   
/*    */   public int getLengthSeconds() {
/* 43 */     return this.lengthSeconds;
/*    */   }
/*    */   
/*    */   public int getLengthMilliseconds() {
/* 47 */     return this.lengthSeconds * 1000;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\items\music\MusicData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */