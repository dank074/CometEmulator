/*    */ package com.habboproject.server.game.items.music;
/*    */ 
/*    */ import com.habboproject.server.api.game.players.data.components.inventory.PlayerItemSnapshot;
/*    */ import com.habboproject.server.game.players.components.types.inventory.InventoryItemSnapshot;
/*    */ 
/*    */ public class SongItemData implements com.habboproject.server.api.game.furniture.types.SongItem
/*    */ {
/*    */   private InventoryItemSnapshot itemSnapshot;
/*    */   private int songId;
/*    */   
/*    */   public SongItemData(InventoryItemSnapshot itemSnapshot, int songId)
/*    */   {
/* 13 */     this.itemSnapshot = itemSnapshot;
/* 14 */     this.songId = songId;
/*    */   }
/*    */   
/*    */   public int getSongId() {
/* 18 */     return this.songId;
/*    */   }
/*    */   
/*    */   public void setSongId(int songId) {
/* 22 */     this.songId = songId;
/*    */   }
/*    */   
/*    */   public PlayerItemSnapshot getItemSnapshot() {
/* 26 */     return this.itemSnapshot;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\items\music\SongItemData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */