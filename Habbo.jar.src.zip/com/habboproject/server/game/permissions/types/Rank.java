/*     */ package com.habboproject.server.game.permissions.types;
/*     */ 
/*     */ import com.habboproject.server.api.game.players.data.components.permissions.PlayerRank;
/*     */ 
/*     */ public class Rank implements PlayerRank
/*     */ {
/*     */   private final int id;
/*     */   private final String name;
/*     */   private final boolean floodBypass;
/*     */   private final int floodTime;
/*     */   private final boolean disconnectable;
/*     */   private final boolean modTool;
/*     */   private final boolean bannable;
/*     */   private final boolean roomKickable;
/*     */   private final boolean roomFullControl;
/*     */   private final boolean roomMuteBypass;
/*     */   private final boolean roomFilterBypass;
/*     */   private final boolean roomIgnorable;
/*     */   private final boolean roomEnterFull;
/*     */   private final boolean roomEnterLocked;
/*     */   private final boolean roomStaffPick;
/*     */   private final boolean roomSeeWhispers;
/*     */   private final boolean messengerStaffChat;
/*     */   private final int messengerMaxFriends;
/*     */   private boolean aboutDetailed;
/*     */   private boolean aboutStats;
/*     */   private boolean ambassador;
/*     */   private boolean helper;
/*     */   
/*     */   public Rank(int id, String name, boolean floodBypass, int floodTime, boolean disconnectable, boolean modTool, boolean bannable, boolean roomKickable, boolean roomFullControl, boolean roomMuteBypass, boolean roomFilterBypass, boolean roomIgnorable, boolean roomEnterFull, boolean roomEnterLocked, boolean roomStaffPick, boolean roomSeeWhispers, boolean messengerStaffChat, int messengerMaxFriends, boolean aboutDetailed, boolean aboutStats, boolean ambassador, boolean helper) {
/*  31 */     this.id = id;
/*  32 */     this.name = name;
/*  33 */     this.floodBypass = floodBypass;
/*  34 */     this.floodTime = floodTime;
/*  35 */     this.disconnectable = disconnectable;
/*  36 */     this.modTool = modTool;
/*  37 */     this.bannable = bannable;
/*  38 */     this.roomKickable = roomKickable;
/*  39 */     this.roomFullControl = roomFullControl;
/*  40 */     this.roomMuteBypass = roomMuteBypass;
/*  41 */     this.roomFilterBypass = roomFilterBypass;
/*  42 */     this.roomIgnorable = roomIgnorable;
/*  43 */     this.roomEnterFull = roomEnterFull;
/*  44 */     this.roomEnterLocked = roomEnterLocked;
/*  45 */     this.roomStaffPick = roomStaffPick;
/*  46 */     this.roomSeeWhispers = roomSeeWhispers;
/*  47 */     this.messengerStaffChat = messengerStaffChat;
/*  48 */     this.messengerMaxFriends = messengerMaxFriends;
/*  49 */     this.aboutDetailed = aboutDetailed;
/*  50 */     this.aboutStats = aboutStats;
/*  51 */     this.ambassador = ambassador;
/*  52 */     this.helper = helper;
/*     */   }
/*     */   
/*     */   public int getId()
/*     */   {
/*  57 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  62 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean floodBypass()
/*     */   {
/*  67 */     return this.floodBypass;
/*     */   }
/*     */   
/*     */   public int floodTime()
/*     */   {
/*  72 */     return this.floodTime;
/*     */   }
/*     */   
/*     */   public boolean disconnectable()
/*     */   {
/*  77 */     return this.disconnectable;
/*     */   }
/*     */   
/*     */   public boolean bannable()
/*     */   {
/*  82 */     return this.bannable;
/*     */   }
/*     */   
/*     */   public boolean modTool()
/*     */   {
/*  87 */     return this.modTool;
/*     */   }
/*     */   
/*     */   public boolean roomKickable()
/*     */   {
/*  92 */     return this.roomKickable;
/*     */   }
/*     */   
/*     */   public boolean roomFullControl()
/*     */   {
/*  97 */     return this.roomFullControl;
/*     */   }
/*     */   
/*     */   public boolean roomMuteBypass()
/*     */   {
/* 102 */     return this.roomMuteBypass;
/*     */   }
/*     */   
/*     */   public boolean roomFilterBypass()
/*     */   {
/* 107 */     return this.roomFilterBypass;
/*     */   }
/*     */   
/*     */   public boolean roomIgnorable()
/*     */   {
/* 112 */     return this.roomIgnorable;
/*     */   }
/*     */   
/*     */   public boolean roomEnterFull()
/*     */   {
/* 117 */     return this.roomEnterFull;
/*     */   }
/*     */   
/*     */   public boolean messengerStaffChat()
/*     */   {
/* 122 */     return this.messengerStaffChat;
/*     */   }
/*     */   
/*     */   public boolean roomEnterLocked()
/*     */   {
/* 127 */     return this.roomEnterLocked;
/*     */   }
/*     */   
/*     */   public boolean roomStaffPick()
/*     */   {
/* 132 */     return this.roomStaffPick;
/*     */   }
/*     */   
/*     */   public int messengerMaxFriends()
/*     */   {
/* 137 */     return this.messengerMaxFriends;
/*     */   }
/*     */   
/*     */   public boolean aboutDetailed()
/*     */   {
/* 142 */     return this.aboutDetailed;
/*     */   }
/*     */   
/*     */   public boolean aboutStats()
/*     */   {
/* 147 */     return this.aboutStats;
/*     */   }
/*     */   
/*     */   public boolean isAmbassador()
/*     */   {
/* 152 */     return this.ambassador;
/*     */   }
/*     */   
/*     */   public boolean isHelper()
/*     */   {
/* 157 */     return this.helper;
/*     */   }
/*     */   
/*     */   public boolean roomSeeWhispers() {
/* 161 */     return this.roomSeeWhispers;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\permissions\types\Rank.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */