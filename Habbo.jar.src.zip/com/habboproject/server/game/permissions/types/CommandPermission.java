/*    */ package com.habboproject.server.game.permissions.types;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ 
/*    */ public class CommandPermission
/*    */ {
/*    */   private String commandId;
/*    */   private int minimumRank;
/*    */   private boolean vipOnly;
/*    */   
/*    */   public CommandPermission(ResultSet data) throws java.sql.SQLException
/*    */   {
/* 13 */     this.commandId = data.getString("command_id");
/* 14 */     this.minimumRank = data.getInt("minimum_rank");
/* 15 */     this.vipOnly = data.getString("vip_only").equals("1");
/*    */   }
/*    */   
/*    */   public String getCommandId() {
/* 19 */     return this.commandId;
/*    */   }
/*    */   
/*    */   public int getMinimumRank() {
/* 23 */     return this.minimumRank;
/*    */   }
/*    */   
/*    */   public boolean isVipOnly() {
/* 27 */     return this.vipOnly;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\permissions\types\CommandPermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */