/*    */ package com.habboproject.server.game.permissions.types;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ 
/*    */ public class Perk
/*    */ {
/*    */   private int id;
/*    */   private String title;
/*    */   private String data;
/*    */   private int rank;
/*    */   private boolean overrideRank;
/*    */   private boolean overrideDefault;
/*    */   
/*    */   public Perk(ResultSet result) throws java.sql.SQLException
/*    */   {
/* 16 */     this.id = result.getInt("id");
/* 17 */     this.title = result.getString("title");
/* 18 */     this.data = result.getString("data");
/* 19 */     this.rank = result.getInt("min_rank");
/* 20 */     this.overrideRank = result.getString("override_rank").equals("1");
/* 21 */     this.overrideDefault = result.getString("override_default").equals("1");
/*    */   }
/*    */   
/*    */   public int getId() {
/* 25 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getTitle() {
/* 29 */     return this.title;
/*    */   }
/*    */   
/*    */   public String getData() {
/* 33 */     return this.data;
/*    */   }
/*    */   
/*    */   public int getRank() {
/* 37 */     return this.rank;
/*    */   }
/*    */   
/*    */   public boolean doesOverride() {
/* 41 */     return this.overrideRank;
/*    */   }
/*    */   
/*    */   public boolean getDefault() {
/* 45 */     return this.overrideDefault;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\permissions\types\Perk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */