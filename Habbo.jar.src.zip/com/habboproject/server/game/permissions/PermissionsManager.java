/*     */ package com.habboproject.server.game.permissions;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.game.permissions.types.CommandPermission;
/*     */ import com.habboproject.server.game.permissions.types.Perk;
/*     */ import com.habboproject.server.game.permissions.types.Rank;
/*     */ import com.habboproject.server.storage.queries.permissions.PermissionsDao;
/*     */ import com.habboproject.server.utilities.Initializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PermissionsManager
/*     */   implements Initializable
/*     */ {
/*     */   private static PermissionsManager permissionsManagerInstance;
/*     */   private Map<Integer, Perk> perks;
/*     */   private Map<Integer, Rank> ranks;
/*     */   private Map<String, CommandPermission> commands;
/*  23 */   private static Logger log = Logger.getLogger(PermissionsManager.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  31 */     this.perks = new HashMap();
/*  32 */     this.commands = new HashMap();
/*  33 */     this.ranks = new HashMap();
/*     */     
/*  35 */     loadPerks();
/*  36 */     loadRankPermissions();
/*  37 */     loadCommands();
/*     */     
/*     */ 
/*  40 */     log.info("PermissionsManager initialized");
/*     */   }
/*     */   
/*     */   public static PermissionsManager getInstance() {
/*  44 */     if (permissionsManagerInstance == null) {
/*  45 */       permissionsManagerInstance = new PermissionsManager();
/*     */     }
/*  47 */     return permissionsManagerInstance;
/*     */   }
/*     */   
/*     */   public void loadPerks() {
/*     */     try {
/*  52 */       if (getPerks().size() != 0) {
/*  53 */         getPerks().clear();
/*     */       }
/*     */       
/*  56 */       this.perks = PermissionsDao.getPerks();
/*     */     }
/*     */     catch (Exception e) {
/*  59 */       log.error("Error while loading perk permissions", e);
/*  60 */       return;
/*     */     }
/*     */     
/*  63 */     log.info("Loaded " + getPerks().size() + " perks");
/*     */   }
/*     */   
/*     */   public void loadRankPermissions() {
/*     */     try {
/*  68 */       if (getRankPermissions().size() != 0) {
/*  69 */         getRankPermissions().clear();
/*     */       }
/*     */       
/*  72 */       this.ranks = PermissionsDao.getRankPermissions();
/*     */     } catch (Exception e) {
/*  74 */       log.error("Error while loading rank permissions", e);
/*  75 */       return;
/*     */     }
/*     */     
/*  78 */     log.info("Loaded " + getRankPermissions().size() + " ranks");
/*     */   }
/*     */   
/*     */   public void loadCommands() {
/*     */     try {
/*  83 */       if (getCommands().size() != 0) {
/*  84 */         getCommands().clear();
/*     */       }
/*     */       
/*  87 */       this.commands = PermissionsDao.getCommandPermissions();
/*     */     }
/*     */     catch (Exception e) {
/*  90 */       log.error("Error while reloading command permissions", e);
/*  91 */       return;
/*     */     }
/*     */     
/*  94 */     log.info("Loaded " + getCommands().size() + " command permissions");
/*     */   }
/*     */   
/*     */   public Rank getRank(int playerRankId) {
/*  98 */     Rank rank = (Rank)this.ranks.get(Integer.valueOf(playerRankId));
/*     */     
/* 100 */     if (rank == null) {
/* 101 */       log.warn("Failed to find rank by rank ID: " + playerRankId + ", are you sure it exists?");
/* 102 */       return (Rank)this.ranks.get(Integer.valueOf(1));
/*     */     }
/*     */     
/* 105 */     return rank;
/*     */   }
/*     */   
/*     */   public List<Integer> getRankByPermission(String permission) {
/* 109 */     List<Integer> enabledRanks = Lists.newArrayList();
/*     */     
/* 111 */     for (Rank rank : this.ranks.values()) { String str;
/* 112 */       switch ((str = permission).hashCode()) {case -2079084663:  if (str.equals("helper_tool")) {} break; case -1988804538:  if (str.equals("ambassador_tool")) {} break; case -1855953895:  if (str.equals("bannable")) {} break; case -1606855165:  if (str.equals("messenger_staff_chat")) {} break; case -1268536966:  if (str.equals("room_enter_full")) {} break; case -624325451:  if (str.equals("mod_tool")) {} break; case -595290991:  if (str.equals("room_full_control")) {} break; case -369803274:  if (str.equals("disconnectable")) {} break; case -255806588:  if (str.equals("room_kickable")) {} break; case -188968956:  if (str.equals("room_staff_pick")) {} break; case -96113591:  if (str.equals("flood_bypass")) break; break; case 658079531:  if (str.equals("room_filter_bypass")) {} break; case 872655669:  if (str.equals("room_enter_locked")) {} break; case 984617250:  if (str.equals("about_detailed")) {} break; case 1179297898:  if (str.equals("room_mute_bypass")) {} break; case 1398058349:  if (str.equals("about_stats")) {} break; case 2019938433:  if (str.equals("room_see_whispers")) {} break; case 2092001897:  if (!str.equals("room_ignorable")) {
/*     */           continue;
/* 114 */           if (rank.floodBypass()) {
/* 115 */             enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */             
/* 117 */             continue;
/*     */             
/*     */ 
/* 120 */             if (rank.disconnectable()) {
/* 121 */               enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */               
/* 123 */               continue;
/*     */               
/*     */ 
/* 126 */               if (rank.modTool()) {
/* 127 */                 enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                 
/* 129 */                 continue;
/*     */                 
/*     */ 
/* 132 */                 if (rank.bannable()) {
/* 133 */                   enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                   
/* 135 */                   continue;
/*     */                   
/*     */ 
/* 138 */                   if (rank.roomKickable()) {
/* 139 */                     enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                     
/* 141 */                     continue;
/*     */                     
/*     */ 
/* 144 */                     if (rank.roomFullControl()) {
/* 145 */                       enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                       
/* 147 */                       continue;
/*     */                       
/*     */ 
/* 150 */                       if (rank.roomMuteBypass()) {
/* 151 */                         enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                         
/* 153 */                         continue;
/*     */                         
/*     */ 
/* 156 */                         if (rank.roomFilterBypass())
/* 157 */                           enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/* 162 */               } } } } else if (rank.roomIgnorable()) {
/* 163 */           enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */           
/* 165 */           continue;
/*     */           
/*     */ 
/* 168 */           if (rank.roomEnterFull()) {
/* 169 */             enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */             
/* 171 */             continue;
/*     */             
/*     */ 
/* 174 */             if (rank.roomEnterLocked()) {
/* 175 */               enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */               
/* 177 */               continue;
/*     */               
/*     */ 
/* 180 */               if (rank.roomStaffPick()) {
/* 181 */                 enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                 
/* 183 */                 continue;
/*     */                 
/*     */ 
/* 186 */                 if (rank.roomSeeWhispers()) {
/* 187 */                   enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                   
/* 189 */                   continue;
/*     */                   
/*     */ 
/* 192 */                   if (rank.messengerStaffChat()) {
/* 193 */                     enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                     
/* 195 */                     continue;
/*     */                     
/*     */ 
/* 198 */                     if (rank.aboutDetailed()) {
/* 199 */                       enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                       
/* 201 */                       continue;
/*     */                       
/*     */ 
/* 204 */                       if (rank.aboutStats()) {
/* 205 */                         enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                         
/* 207 */                         continue;
/*     */                         
/*     */ 
/* 210 */                         if (rank.isAmbassador()) {
/* 211 */                           enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                           
/* 213 */                           continue;
/*     */                           
/*     */ 
/* 216 */                           if (rank.isHelper())
/* 217 */                             enabledRanks.add(Integer.valueOf(rank.getId()));
/*     */                         }
/*     */                       }
/*     */                     }
/*     */                   } } } } } }
/*     */         break; } }
/* 223 */     return enabledRanks;
/*     */   }
/*     */   
/*     */   public Map<Integer, Rank> getRankPermissions() {
/* 227 */     return this.ranks;
/*     */   }
/*     */   
/*     */   public Map<String, CommandPermission> getCommands() {
/* 231 */     return this.commands;
/*     */   }
/*     */   
/*     */   public Map<Integer, Perk> getPerks() {
/* 235 */     return this.perks;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\permissions\PermissionsManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */