package com.habboproject.server.game.catalog.types;

public enum CatalogPageType
{
  NORMAL,  BUILDERS,  BUNDLE;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\catalog\types\CatalogPageType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */