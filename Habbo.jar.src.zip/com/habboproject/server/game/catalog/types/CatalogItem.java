/*     */ package com.habboproject.server.game.catalog.types;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.boot.CometServer;
/*     */ import com.habboproject.server.game.catalog.CatalogManager;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CatalogItem
/*     */ {
/*     */   private int id;
/*     */   private String itemId;
/*     */   private String displayName;
/*     */   private int costCredits;
/*     */   private int costActivityPoints;
/*     */   private int costOther;
/*     */   private int amount;
/*     */   private boolean vip;
/*     */   private List<CatalogBundledItem> items;
/*     */   private int limitedTotal;
/*     */   private int limitedSells;
/*     */   private boolean allowOffer;
/*     */   private String badgeId;
/*     */   private String presetData;
/*     */   private int pageId;
/*  91 */   private boolean canAdd = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CatalogItem(ResultSet data)
/*     */     throws Exception
/*     */   {
/* 114 */     this(data.getInt("id"), data.getString("item_ids"), data.getString("catalog_name"), data.getInt("cost_credits"), data.getInt("cost_pixels"), data.getInt("cost_snow"), data.getInt("amount"), data.getString("vip").equals("1"), data.getInt("limited_stack"), data.getInt("limited_sells"), data.getString("offer_active").equals("1"), data.getString("badge_id"), data.getString("extradata"), data.getInt("page_id"));
/*     */   }
/*     */   
/*     */   public CatalogItem(int id, String itemId, String displayName, int costCredits, int costActivityPoints, int costOther, int amount, boolean vip, int limitedTotal, int limitedSells, boolean allowOffer, String badgeId, String presetData, int pageId) {
/* 118 */     this(id, itemId, null, displayName, costCredits, costActivityPoints, costOther, amount, vip, limitedTotal, limitedSells, allowOffer, badgeId, presetData, pageId);
/*     */   }
/*     */   
/*     */   public CatalogItem(int id, String itemId, List<CatalogBundledItem> bundledItems, String displayName, int costCredits, int costActivityPoints, int costOther, int amount, boolean vip, int limitedTotal, int limitedSells, boolean allowOffer, String badgeId, String presetData, int pageId) {
/* 122 */     this.id = id;
/* 123 */     this.itemId = itemId;
/* 124 */     this.displayName = displayName;
/* 125 */     this.costCredits = costCredits;
/* 126 */     this.costActivityPoints = costActivityPoints;
/* 127 */     this.costOther = costOther;
/* 128 */     this.amount = amount;
/* 129 */     this.vip = vip;
/* 130 */     this.limitedTotal = limitedTotal;
/* 131 */     this.limitedSells = limitedSells;
/* 132 */     this.allowOffer = allowOffer;
/* 133 */     this.badgeId = badgeId;
/* 134 */     this.presetData = presetData;
/* 135 */     this.pageId = pageId;
/*     */     
/* 137 */     this.items = (bundledItems != null ? bundledItems : new ArrayList());
/*     */     
/* 139 */     if (this.items.size() == 0) {
/* 140 */       if (!this.itemId.equals("-1")) {
/* 141 */         if (bundledItems != null) {
/* 142 */           this.items = bundledItems;
/*     */ 
/*     */         }
/* 145 */         else if (itemId.contains(",")) {
/* 146 */           String[] split = itemId.replace("\n", "").split(",");
/*     */           String[] arrayOfString1;
/* 148 */           int j = (arrayOfString1 = split).length; for (int i = 0; i < j; i++) { String str = arrayOfString1[i];
/* 149 */             if (!str.equals("")) {
/* 150 */               String[] parts = str.split(":");
/* 151 */               if (parts.length == 3)
/*     */                 try
/*     */                 {
/* 154 */                   int aItemId = Integer.parseInt(parts[0]);
/* 155 */                   int aAmount = Integer.parseInt(parts[1]);
/* 156 */                   String aPresetData = parts[2];
/*     */                   
/* 158 */                   this.items.add(new CatalogBundledItem(aPresetData, aAmount, aItemId));
/*     */                 } catch (Exception ignored) {
/* 160 */                   Comet.getServer().getLogger().warn("Invalid item data for catalog item: " + this.id);
/*     */                 }
/*     */             }
/*     */           }
/*     */         } else {
/* 165 */           if (ItemManager.getInstance().getDefinition(Integer.valueOf(this.itemId).intValue()) == null) {
/* 166 */             this.canAdd = false;
/*     */           }
/*     */           
/* 169 */           this.items.add(new CatalogBundledItem(this.presetData, this.amount, Integer.valueOf(this.itemId).intValue()));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 174 */       if (getItems().size() == 0) { return;
/*     */       }
/* 176 */       List<CatalogBundledItem> itemsToRemove = new ArrayList();
/*     */       
/* 178 */       for (CatalogBundledItem catalogBundledItem : this.items) {
/* 179 */         ItemDefinition itemDefinition = ItemManager.getInstance().getDefinition(catalogBundledItem.getItemId());
/*     */         
/* 181 */         if (itemDefinition == null) {
/* 182 */           itemsToRemove.add(catalogBundledItem);
/*     */         }
/*     */       }
/*     */       
/* 186 */       for (CatalogBundledItem itemToRemove : itemsToRemove) {
/* 187 */         this.items.remove(itemToRemove);
/*     */       }
/*     */       
/* 190 */       itemsToRemove.clear();
/*     */       
/* 192 */       if (this.items.size() == 0) {
/* 193 */         return;
/*     */       }
/*     */       
/* 196 */       if (ItemManager.getInstance().getDefinition(((CatalogBundledItem)getItems().get(0)).getItemId()) == null) return;
/* 197 */       int offerId = ItemManager.getInstance().getDefinition(((CatalogBundledItem)getItems().get(0)).getItemId()).getOfferId();
/*     */       
/* 199 */       if (!CatalogManager.getCatalogOffers().containsKey(Integer.valueOf(offerId))) {
/* 200 */         CatalogManager.getCatalogOffers().put(Integer.valueOf(offerId), new CatalogOffer(offerId, getPageId(), getId()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg) {
/* 206 */     ItemDefinition firstItem = this.itemId.equals("-1") ? null : ItemManager.getInstance().getDefinition(((CatalogBundledItem)getItems().get(0)).getItemId());
/*     */     
/* 208 */     msg.writeInt(getId());
/* 209 */     msg.writeString(getDisplayName());
/* 210 */     msg.writeBoolean(Boolean.valueOf(false));
/*     */     
/* 212 */     msg.writeInt(getCostCredits());
/*     */     
/* 214 */     if (getCostOther() > 0) {
/* 215 */       msg.writeInt(getCostOther());
/* 216 */       msg.writeInt(105);
/* 217 */     } else if (getCostActivityPoints() > 0) {
/* 218 */       msg.writeInt(getCostActivityPoints());
/* 219 */       msg.writeInt(0);
/*     */     } else {
/* 221 */       msg.writeInt(0);
/* 222 */       msg.writeInt(0);
/*     */     }
/*     */     
/* 225 */     msg.writeBoolean(Boolean.valueOf((firstItem != null) && (firstItem.canGift())));
/*     */     
/* 227 */     if (!hasBadge()) {
/* 228 */       msg.writeInt(getItems().size());
/*     */     } else {
/* 230 */       msg.writeInt(isBadgeOnly() ? 1 : 2);
/* 231 */       msg.writeString("b");
/* 232 */       msg.writeString(getBadgeId());
/*     */     }
/*     */     
/* 235 */     for (CatalogBundledItem bundledItem : getItems()) {
/* 236 */       ItemDefinition def = ItemManager.getInstance().getDefinition(bundledItem.getItemId());
/* 237 */       msg.writeString(def.getType());
/*     */       
/* 239 */       if (def.getType().equals("b")) {
/* 240 */         msg.writeString(def.getItemName());
/*     */       }
/*     */       else
/*     */       {
/* 244 */         msg.writeInt(def.getSpriteId());
/*     */         
/* 246 */         if ((getDisplayName().contains("wallpaper_single")) || (getDisplayName().contains("floor_single")) || (getDisplayName().contains("landscape_single"))) {
/* 247 */           msg.writeString(getDisplayName().split("_")[2]);
/* 248 */         } else if (def.isSong()) {
/* 249 */           msg.writeString(Integer.valueOf(def.getSongId()));
/*     */         } else {
/* 251 */           msg.writeString(bundledItem.getPresetData());
/*     */         }
/*     */         
/* 254 */         msg.writeInt(bundledItem.getAmount());
/* 255 */         msg.writeBoolean(Boolean.valueOf(getLimitedTotal() != 0));
/*     */         
/* 257 */         if (getLimitedTotal() > 0)
/*     */         {
/* 259 */           msg.writeInt(getLimitedTotal());
/* 260 */           msg.writeInt(getLimitedTotal() - getLimitedSells());
/*     */         }
/*     */       } }
/* 263 */     msg.writeInt(0);
/* 264 */     msg.writeBoolean(Boolean.valueOf((getLimitedTotal() <= 0) && (allowOffer())));
/*     */     
/* 266 */     msg.writeBoolean(Boolean.valueOf(false));
/* 267 */     msg.writeString("");
/*     */   }
/*     */   
/*     */   public int getId() {
/* 271 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getItemId() {
/* 275 */     return this.itemId;
/*     */   }
/*     */   
/*     */   public List<CatalogBundledItem> getItems() {
/* 279 */     return this.items;
/*     */   }
/*     */   
/*     */   public String getDisplayName() {
/* 283 */     return this.displayName;
/*     */   }
/*     */   
/*     */   public int getCostCredits() {
/* 287 */     return this.costCredits;
/*     */   }
/*     */   
/*     */   public int getCostActivityPoints() {
/* 291 */     return this.costActivityPoints;
/*     */   }
/*     */   
/*     */   public int getCostOther() {
/* 295 */     return this.costOther;
/*     */   }
/*     */   
/*     */   public int getAmount() {
/* 299 */     return this.amount;
/*     */   }
/*     */   
/*     */   public boolean isVip() {
/* 303 */     return this.vip;
/*     */   }
/*     */   
/*     */   public int getLimitedTotal() {
/* 307 */     return this.limitedTotal;
/*     */   }
/*     */   
/*     */   public int getLimitedSells() {
/* 311 */     return this.limitedSells;
/*     */   }
/*     */   
/*     */   public boolean allowOffer() {
/* 315 */     return this.allowOffer;
/*     */   }
/*     */   
/*     */   public void increaseLimitedSells(int amount) {
/* 319 */     this.limitedSells += amount;
/*     */   }
/*     */   
/*     */   public boolean hasBadge() {
/* 323 */     return !this.badgeId.isEmpty();
/*     */   }
/*     */   
/*     */   public boolean isBadgeOnly() {
/* 327 */     return (this.items.size() == 0) && (hasBadge());
/*     */   }
/*     */   
/*     */   public String getBadgeId() {
/* 331 */     return this.badgeId;
/*     */   }
/*     */   
/*     */   public String getPresetData() {
/* 335 */     return this.presetData;
/*     */   }
/*     */   
/*     */   public int getPageId() {
/* 339 */     return this.pageId;
/*     */   }
/*     */   
/*     */   public boolean canAdd() {
/* 343 */     return this.canAdd;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\catalog\types\CatalogItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */