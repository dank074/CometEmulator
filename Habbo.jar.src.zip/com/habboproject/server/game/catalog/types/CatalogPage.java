/*     */ package com.habboproject.server.game.catalog.types;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import com.habboproject.server.game.rooms.bundles.RoomBundleManager;
/*     */ import com.habboproject.server.game.rooms.bundles.types.RoomBundle;
/*     */ import com.habboproject.server.game.rooms.bundles.types.RoomBundleItem;
/*     */ import com.habboproject.server.utilities.JsonFactory;
/*     */ import java.lang.reflect.Type;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class CatalogPage
/*     */ {
/*  21 */   private static final Type listType = new com.google.gson.reflect.TypeToken() {}.getType();
/*     */   
/*     */   private int id;
/*     */   
/*     */   private CatalogPageType type;
/*     */   
/*     */   private String caption;
/*     */   private int icon;
/*     */   private int minRank;
/*     */   private String template;
/*     */   private int parentId;
/*     */   private String linkName;
/*     */   private boolean enabled;
/*     */   private List<String> images;
/*     */   private List<String> texts;
/*     */   private Map<Integer, CatalogItem> items;
/*     */   private String extraData;
/*     */   
/*     */   public CatalogPage(ResultSet data, Map<Integer, CatalogItem> items)
/*     */     throws SQLException
/*     */   {
/*  42 */     this.id = data.getInt("id");
/*  43 */     this.caption = data.getString("caption");
/*  44 */     this.icon = data.getInt("icon_image");
/*  45 */     this.minRank = data.getInt("min_rank");
/*  46 */     this.template = data.getString("page_layout");
/*  47 */     this.parentId = data.getInt("parent_id");
/*  48 */     this.linkName = "";
/*  49 */     this.type = CatalogPageType.valueOf(data.getString("type"));
/*  50 */     this.extraData = data.getString("extra_data");
/*     */     
/*  52 */     if ((data.getString("page_images") == null) || (data.getString("page_images").isEmpty())) {
/*  53 */       this.images = new ArrayList();
/*     */     } else {
/*  55 */       this.images = ((List)JsonFactory.getInstance().fromJson(data.getString("page_images"), listType));
/*     */     }
/*     */     
/*  58 */     if ((data.getString("page_texts") == null) || (data.getString("page_texts").isEmpty())) {
/*  59 */       this.texts = new ArrayList();
/*     */     } else {
/*  61 */       this.texts = ((List)JsonFactory.getInstance().fromJson(data.getString("page_texts"), listType));
/*     */     }
/*     */     
/*  64 */     this.enabled = data.getString("enabled").equals("1");
/*     */     
/*  66 */     if (this.type == CatalogPageType.BUNDLE) {
/*  67 */       String bundleAlias = this.extraData;
/*     */       
/*  69 */       RoomBundle roomBundle = RoomBundleManager.getInstance().getBundle(bundleAlias);
/*     */       
/*  71 */       if (roomBundle != null) {
/*  72 */         List<CatalogBundledItem> bundledItems = new ArrayList();
/*  73 */         Map<Integer, List<RoomBundleItem>> bundleItems = new HashMap();
/*     */         
/*  75 */         for (RoomBundleItem bundleItem : roomBundle.getRoomBundleData()) {
/*  76 */           if (bundleItems.containsKey(Integer.valueOf(bundleItem.getItemId()))) {
/*  77 */             ((List)bundleItems.get(Integer.valueOf(bundleItem.getItemId()))).add(bundleItem);
/*     */           } else {
/*  79 */             bundleItems.put(Integer.valueOf(bundleItem.getItemId()), com.google.common.collect.Lists.newArrayList(new RoomBundleItem[] { bundleItem }));
/*     */           }
/*     */         }
/*     */         
/*  83 */         for (Map.Entry<Integer, List<RoomBundleItem>> bundledItem : bundleItems.entrySet()) {
/*  84 */           bundledItems.add(new CatalogBundledItem("0", ((List)bundledItem.getValue()).size(), ((Integer)bundledItem.getKey()).intValue()));
/*     */         }
/*     */         
/*  87 */         CatalogItem catalogItem = new CatalogItem(roomBundle.getId(), "-1", bundledItems, "single_bundle", 
/*  88 */           roomBundle.getCostCredits(), roomBundle.getCostSeasonal(), roomBundle.getCostVip(), 1, false, 0, 0, false, "", "", this.id);
/*     */         
/*  90 */         this.items = new HashMap();
/*  91 */         this.items.put(Integer.valueOf(catalogItem.getId()), catalogItem);
/*     */       } else {
/*  93 */         this.items = new HashMap();
/*     */       }
/*     */     } else {
/*  96 */       this.items = items;
/*     */     }
/*     */   }
/*     */   
/*     */   public int getOfferSize() {
/* 101 */     int size = 0;
/*     */     
/* 103 */     for (CatalogItem item : this.items.values()) {
/* 104 */       if (!item.getItemId().equals("-1"))
/*     */       {
/* 106 */         if ((ItemManager.getInstance().getDefinition(((CatalogBundledItem)item.getItems().get(0)).getItemId()) != null) && 
/* 107 */           (ItemManager.getInstance().getDefinition(((CatalogBundledItem)item.getItems().get(0)).getItemId()).getOfferId() != -1) && (ItemManager.getInstance().getDefinition(((CatalogBundledItem)item.getItems().get(0)).getItemId()).getOfferId() != 0)) {
/* 108 */           size++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 113 */     return size;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 117 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getCaption() {
/* 121 */     return this.caption;
/*     */   }
/*     */   
/*     */   public int getIcon() {
/* 125 */     return this.icon;
/*     */   }
/*     */   
/*     */   public int getMinRank() {
/* 129 */     return this.minRank;
/*     */   }
/*     */   
/*     */   public String getTemplate() {
/* 133 */     return this.template;
/*     */   }
/*     */   
/*     */   public int getParentId() {
/* 137 */     return this.parentId;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 141 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public Map<Integer, CatalogItem> getItems() {
/* 145 */     return this.items;
/*     */   }
/*     */   
/*     */   public List<String> getImages() {
/* 149 */     return this.images;
/*     */   }
/*     */   
/*     */   public List<String> getTexts() {
/* 153 */     return this.texts;
/*     */   }
/*     */   
/*     */   public String getLinkName() {
/* 157 */     return this.linkName;
/*     */   }
/*     */   
/*     */   public String getExtraData() {
/* 161 */     return this.extraData;
/*     */   }
/*     */   
/*     */   public CatalogPageType getType() {
/* 165 */     return this.type;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\catalog\types\CatalogPage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */