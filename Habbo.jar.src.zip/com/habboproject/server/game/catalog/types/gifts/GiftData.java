/*     */ package com.habboproject.server.game.catalog.types.gifts;
/*     */ 
/*     */ import com.habboproject.server.api.game.furniture.types.GiftItemData;
/*     */ import com.habboproject.server.utilities.JsonData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GiftData
/*     */   implements JsonData, GiftItemData
/*     */ {
/*     */   private int pageId;
/*     */   private int itemId;
/*     */   private int senderId;
/*     */   private String receiver;
/*     */   private String message;
/*     */   private int spriteId;
/*     */   private int wrappingPaper;
/*     */   private int decorationType;
/*     */   private boolean showUsername;
/*     */   private String extraData;
/*     */   
/*     */   public GiftData(int pageId, int itemId, int senderId, String receiver, String message, int spriteId, int wrappingPaper, int decorationType, boolean showUsername, String extraData)
/*     */   {
/*  72 */     this.pageId = pageId;
/*  73 */     this.itemId = itemId;
/*  74 */     this.senderId = senderId;
/*  75 */     this.receiver = receiver;
/*  76 */     this.message = message;
/*  77 */     this.spriteId = spriteId;
/*  78 */     this.wrappingPaper = wrappingPaper;
/*  79 */     this.decorationType = decorationType;
/*  80 */     this.showUsername = showUsername;
/*  81 */     this.extraData = extraData;
/*     */   }
/*     */   
/*     */   public GiftData() {
/*  85 */     this.pageId = 0;
/*  86 */     this.itemId = 0;
/*  87 */     this.senderId = 0;
/*  88 */     this.receiver = "";
/*  89 */     this.message = "";
/*  90 */     this.spriteId = 0;
/*  91 */     this.wrappingPaper = 0;
/*  92 */     this.decorationType = 0;
/*  93 */     this.showUsername = false;
/*  94 */     this.extraData = "0";
/*     */   }
/*     */   
/*     */   public int getPageId() {
/*  98 */     return this.pageId;
/*     */   }
/*     */   
/*     */   public int getItemId() {
/* 102 */     return this.itemId;
/*     */   }
/*     */   
/*     */   public String getReceiver() {
/* 106 */     return this.receiver;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/* 110 */     return this.message;
/*     */   }
/*     */   
/*     */   public int getSpriteId() {
/* 114 */     return this.spriteId;
/*     */   }
/*     */   
/*     */   public int getWrappingPaper() {
/* 118 */     return this.wrappingPaper;
/*     */   }
/*     */   
/*     */   public int getDecorationType() {
/* 122 */     return this.decorationType;
/*     */   }
/*     */   
/*     */   public boolean isShowUsername() {
/* 126 */     return this.showUsername;
/*     */   }
/*     */   
/*     */   public int getSenderId() {
/* 130 */     return this.senderId;
/*     */   }
/*     */   
/*     */   public String getExtraData() {
/* 134 */     return this.extraData;
/*     */   }
/*     */   
/*     */   public void setExtraData(String extraData) {
/* 138 */     this.extraData = extraData;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\catalog\types\gifts\GiftData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */