/*    */ package com.habboproject.server.game.catalog.types;
/*    */ 
/*    */ 
/*    */ public class CatalogFrontPage
/*    */ {
/*    */   private final int id;
/*    */   private final String caption;
/*    */   private final String image;
/*    */   private final String pageLink;
/*    */   private final int pageId;
/*    */   
/*    */   public CatalogFrontPage(int id, String caption, String image, String pageLink, int pageId)
/*    */   {
/* 14 */     this.id = id;
/* 15 */     this.caption = caption;
/* 16 */     this.image = image;
/* 17 */     this.pageLink = pageLink;
/* 18 */     this.pageId = pageId;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 22 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getCaption() {
/* 26 */     return this.caption;
/*    */   }
/*    */   
/*    */   public String getImage() {
/* 30 */     return this.image;
/*    */   }
/*    */   
/*    */   public String getPageLink() {
/* 34 */     return this.pageLink;
/*    */   }
/*    */   
/*    */   public int getPageId() {
/* 38 */     return this.pageId;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\catalog\types\CatalogFrontPage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */