/*    */ package com.habboproject.server.game.catalog.types;
/*    */ 
/*    */ public class CatalogOffer {
/*    */   private int offerId;
/*    */   private int catalogPageId;
/*    */   private int catalogItemId;
/*    */   
/*    */   public CatalogOffer(int offerId, int catalogPageId, int catalogItemId) {
/*  9 */     this.offerId = offerId;
/* 10 */     this.catalogPageId = catalogPageId;
/* 11 */     this.catalogItemId = catalogItemId;
/*    */   }
/*    */   
/*    */   public int getOfferId() {
/* 15 */     return this.offerId;
/*    */   }
/*    */   
/*    */   public int getCatalogPageId() {
/* 19 */     return this.catalogPageId;
/*    */   }
/*    */   
/*    */   public int getCatalogItemId() {
/* 23 */     return this.catalogItemId;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\catalog\types\CatalogOffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */