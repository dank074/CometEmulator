/*    */ package com.habboproject.server.game.catalog.types;
/*    */ 
/*    */ public class CatalogBundledItem
/*    */ {
/*    */   private final int itemId;
/*    */   private final int amount;
/*    */   private final String presetData;
/*    */   
/*    */   public CatalogBundledItem(String presetData, int amount, int itemId) {
/* 10 */     this.presetData = presetData;
/* 11 */     this.amount = amount;
/* 12 */     this.itemId = itemId;
/*    */   }
/*    */   
/*    */   public int getItemId() {
/* 16 */     return this.itemId;
/*    */   }
/*    */   
/*    */   public int getAmount() {
/* 20 */     return this.amount;
/*    */   }
/*    */   
/*    */   public String getPresetData() {
/* 24 */     return this.presetData;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\catalog\types\CatalogBundledItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */