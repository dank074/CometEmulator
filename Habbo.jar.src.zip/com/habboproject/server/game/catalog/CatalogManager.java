/*     */ package com.habboproject.server.game.catalog;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import com.habboproject.server.game.catalog.purchase.PurchaseEvent;
/*     */ import com.habboproject.server.game.catalog.types.CatalogFrontPage;
/*     */ import com.habboproject.server.game.catalog.types.CatalogItem;
/*     */ import com.habboproject.server.game.catalog.types.CatalogOffer;
/*     */ import com.habboproject.server.game.catalog.types.CatalogPage;
/*     */ import com.habboproject.server.storage.queries.catalog.CatalogDao;
/*     */ import com.habboproject.server.utilities.Initializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.collections4.map.ListOrderedMap;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CatalogManager
/*     */   implements Initializable
/*     */ {
/*     */   private static CatalogManager catalogManagerInstance;
/*     */   private Map<Integer, CatalogPage> pages;
/*     */   private Map<Integer, CatalogItem> items;
/*     */   private Map<Integer, CatalogFrontPage> news;
/*     */   private Map<Integer, Integer> catalogItemIdToPageId;
/*  47 */   private static final Map<Integer, CatalogOffer> catalogOffers = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private final List<Integer> giftBoxesNew = Lists.newArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  57 */   private final List<Integer> giftBoxesOld = Lists.newArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private PurchaseEvent purchaseHandler;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private Logger log = Logger.getLogger(CatalogManager.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  78 */     this.pages = new ListOrderedMap();
/*  79 */     this.items = new ListOrderedMap();
/*  80 */     this.news = new ListOrderedMap();
/*     */     
/*  82 */     this.catalogItemIdToPageId = new HashMap();
/*     */     
/*  84 */     this.purchaseHandler = new PurchaseEvent();
/*     */     
/*  86 */     loadItemsAndPages();
/*  87 */     loadGiftBoxes();
/*     */     
/*  89 */     this.log.info("CatalogManager initialized");
/*     */   }
/*     */   
/*     */   public static CatalogManager getInstance() {
/*  93 */     if (catalogManagerInstance == null) {
/*  94 */       catalogManagerInstance = new CatalogManager();
/*     */     }
/*  96 */     return catalogManagerInstance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void loadItemsAndPages()
/*     */   {
/* 103 */     if (this.items.size() >= 1) {
/* 104 */       this.items.clear();
/*     */     }
/*     */     
/* 107 */     if (getPages().size() >= 1) {
/* 108 */       getPages().clear();
/*     */     }
/*     */     
/* 111 */     if (this.news.size() >= 1) {
/* 112 */       this.news.clear();
/*     */     }
/*     */     
/* 115 */     if (getCatalogOffers().size() >= 1) {
/* 116 */       getCatalogOffers().clear();
/*     */     }
/*     */     
/* 119 */     if (this.catalogItemIdToPageId.size() >= 1) {
/* 120 */       this.catalogItemIdToPageId.clear();
/*     */     }
/*     */     try
/*     */     {
/* 124 */       CatalogDao.getItems(this.items);
/* 125 */       CatalogDao.getPages(this.pages);
/* 126 */       CatalogDao.getNews(this.news);
/*     */     } catch (Exception e) {
/* 128 */       this.log.error("Error while loading catalog pages/items", e);
/*     */     }
/*     */     Iterator localIterator2;
/* 131 */     for (Iterator localIterator1 = this.pages.values().iterator(); localIterator1.hasNext(); 
/* 132 */         localIterator2.hasNext())
/*     */     {
/* 131 */       CatalogPage page = (CatalogPage)localIterator1.next();
/* 132 */       localIterator2 = page.getItems().keySet().iterator(); continue;Integer item = (Integer)localIterator2.next();
/* 133 */       this.catalogItemIdToPageId.put(item, Integer.valueOf(page.getId()));
/*     */     }
/*     */     
/*     */ 
/* 137 */     this.log.info("Loaded " + getPages().size() + " catalog pages and " + this.items.size() + " catalog items");
/*     */   }
/*     */   
/*     */   public void loadGiftBoxes() {
/* 141 */     if (this.giftBoxesNew.size() >= 1) {
/* 142 */       this.giftBoxesNew.clear();
/*     */     }
/*     */     
/* 145 */     if (this.giftBoxesOld.size() >= 1) {
/* 146 */       this.giftBoxesOld.clear();
/*     */     }
/*     */     
/* 149 */     CatalogDao.loadGiftBoxes(this.giftBoxesOld, this.giftBoxesNew);
/* 150 */     this.log.info("Loaded " + (this.giftBoxesNew.size() + this.giftBoxesOld.size()) + " gift wrappings");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<CatalogPage> getPagesForRank(int rank)
/*     */   {
/* 160 */     List<CatalogPage> pages = new ArrayList();
/*     */     
/* 162 */     for (CatalogPage page : getPages().values()) {
/* 163 */       if (rank >= page.getMinRank()) {
/* 164 */         pages.add(page);
/*     */       }
/*     */     }
/*     */     
/* 168 */     return pages;
/*     */   }
/*     */   
/*     */   public CatalogItem getCatalogItemByOfferId(int offerId) {
/* 172 */     CatalogOffer offer = (CatalogOffer)getCatalogOffers().get(Integer.valueOf(offerId));
/*     */     
/* 174 */     if (offer == null) {
/* 175 */       return null;
/*     */     }
/* 177 */     CatalogPage page = getPage(offer.getCatalogPageId());
/* 178 */     if (page == null) {
/* 179 */       return null;
/*     */     }
/* 181 */     return (CatalogItem)page.getItems().get(Integer.valueOf(offer.getCatalogItemId()));
/*     */   }
/*     */   
/*     */   public CatalogPage getCatalogPageByCatalogItemId(int id) {
/* 185 */     if (!this.catalogItemIdToPageId.containsKey(Integer.valueOf(id))) {
/* 186 */       return null;
/*     */     }
/*     */     
/* 189 */     return (CatalogPage)this.pages.get(this.catalogItemIdToPageId.get(Integer.valueOf(id)));
/*     */   }
/*     */   
/*     */   public CatalogItem getCatalogItemByItemId(int itemId) {
/* 193 */     if (!this.items.containsKey(Integer.valueOf(itemId))) {
/* 194 */       return null;
/*     */     }
/*     */     
/* 197 */     return (CatalogItem)this.items.get(Integer.valueOf(itemId));
/*     */   }
/*     */   
/*     */   public Map<Integer, CatalogItem> getItemsForPage(int pageId) {
/* 201 */     Map<Integer, CatalogItem> items = Maps.newHashMap();
/*     */     
/* 203 */     for (Map.Entry<Integer, CatalogItem> catalogItem : this.items.entrySet()) {
/* 204 */       if (((CatalogItem)catalogItem.getValue()).getPageId() == pageId) {
/* 205 */         items.put((Integer)catalogItem.getKey(), (CatalogItem)catalogItem.getValue());
/*     */       }
/*     */     }
/*     */     
/* 209 */     return items;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CatalogPage getPage(int id)
/*     */   {
/* 219 */     if (pageExists(id)) {
/* 220 */       return (CatalogPage)getPages().get(Integer.valueOf(id));
/*     */     }
/*     */     
/* 223 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean pageExists(int id)
/*     */   {
/* 233 */     return getPages().containsKey(Integer.valueOf(id));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Integer, CatalogPage> getPages()
/*     */   {
/* 242 */     return this.pages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PurchaseEvent getPurchaseHandler()
/*     */   {
/* 251 */     return this.purchaseHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<Integer, CatalogOffer> getCatalogOffers()
/*     */   {
/* 260 */     return catalogOffers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Integer> getGiftBoxesNew()
/*     */   {
/* 269 */     return this.giftBoxesNew;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Integer> getGiftBoxesOld()
/*     */   {
/* 278 */     return this.giftBoxesOld;
/*     */   }
/*     */   
/*     */   public Map<Integer, CatalogFrontPage> getNews() {
/* 282 */     return this.news;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\catalog\CatalogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */