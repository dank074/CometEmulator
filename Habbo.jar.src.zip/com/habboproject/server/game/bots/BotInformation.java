package com.habboproject.server.game.bots;

public abstract interface BotInformation
{
  public abstract String getUsername();
  
  public abstract String getMotto();
  
  public abstract String getFigure();
  
  public abstract String getGender();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\bots\BotInformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */