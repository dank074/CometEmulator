/*     */ package com.habboproject.server.game.bots;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.habboproject.server.storage.queries.bots.RoomBotDao;
/*     */ import com.habboproject.server.utilities.JsonFactory;
/*     */ import com.habboproject.server.utilities.RandomInteger;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BotData
/*     */   implements BotInformation
/*     */ {
/*     */   private int id;
/*     */   private int chatDelay;
/*     */   private int ownerId;
/*     */   private String username;
/*     */   private String motto;
/*     */   private String figure;
/*     */   private String gender;
/*     */   private String ownerName;
/*     */   private boolean isAutomaticChat;
/*     */   private String[] messages;
/*     */   private String botType;
/*     */   private String mode;
/*     */   private String data;
/*     */   private int forcedUserTargetMovement;
/*     */   private long forcedFurniTargetMovement;
/*     */   private boolean carryingItemToUser;
/*     */   
/*     */   public BotData(int id, String username, String motto, String figure, String gender, String ownerName, int ownerId, String messages, boolean automaticChat, int chatDelay, String botType, String mode, String data)
/*     */   {
/*  86 */     this.id = id;
/*  87 */     this.username = username;
/*  88 */     this.motto = motto;
/*  89 */     this.figure = figure;
/*  90 */     this.gender = gender;
/*  91 */     this.ownerId = ownerId;
/*  92 */     this.ownerName = ownerName;
/*  93 */     this.botType = botType;
/*  94 */     this.mode = mode;
/*  95 */     this.data = data;
/*  96 */     this.messages = ((messages == null) || (messages.isEmpty()) ? new String[0] : (String[])JsonFactory.getInstance().fromJson(messages, String[].class));
/*  97 */     this.chatDelay = chatDelay;
/*  98 */     this.isAutomaticChat = automaticChat;
/*  99 */     this.forcedUserTargetMovement = 0;
/* 100 */     this.forcedFurniTargetMovement = 0L;
/* 101 */     this.carryingItemToUser = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRandomMessage()
/*     */   {
/* 110 */     if (getMessages().length > 0) {
/* 111 */       int index = RandomInteger.getRandom(0, getMessages().length - 1);
/*     */       
/* 113 */       return stripNonAlphanumeric(getMessages()[index]);
/*     */     }
/*     */     
/* 116 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String stripNonAlphanumeric(String msg)
/*     */   {
/* 126 */     return msg.replace("<", "").replace(">", "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void save()
/*     */   {
/* 133 */     RoomBotDao.saveData(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getId()
/*     */   {
/* 142 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 151 */     return this.username;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 160 */     this.username = stripNonAlphanumeric(username);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMotto()
/*     */   {
/* 169 */     return this.motto;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMotto(String motto)
/*     */   {
/* 178 */     this.motto = motto;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFigure()
/*     */   {
/* 187 */     return this.figure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFigure(String figure)
/*     */   {
/* 196 */     this.figure = figure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getGender()
/*     */   {
/* 205 */     return this.gender;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGender(String gender)
/*     */   {
/* 214 */     this.gender = gender;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getChatDelay()
/*     */   {
/* 223 */     return this.chatDelay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChatDelay(int delay)
/*     */   {
/* 232 */     this.chatDelay = delay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getMessages()
/*     */   {
/* 241 */     return this.messages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessages(String[] messages)
/*     */   {
/* 250 */     this.messages = messages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutomaticChat()
/*     */   {
/* 259 */     return this.isAutomaticChat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutomaticChat(boolean isAutomaticChat)
/*     */   {
/* 268 */     this.isAutomaticChat = isAutomaticChat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOwnerName()
/*     */   {
/* 277 */     return this.ownerName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOwnerId()
/*     */   {
/* 286 */     return this.ownerId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 293 */     Arrays.fill(this.messages, null);
/*     */   }
/*     */   
/*     */   public String getBotType() {
/* 297 */     return this.botType;
/*     */   }
/*     */   
/*     */   public void setBotType(String botType) {
/* 301 */     this.botType = botType;
/*     */   }
/*     */   
/*     */   public String getMode() {
/* 305 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setMode(String mode) {
/* 309 */     this.mode = mode;
/*     */   }
/*     */   
/*     */   public String getData() {
/* 313 */     return this.data;
/*     */   }
/*     */   
/*     */   public void setData(String data) {
/* 317 */     this.data = data;
/*     */   }
/*     */   
/*     */   public int getForcedUserTargetMovement() {
/* 321 */     return this.forcedUserTargetMovement;
/*     */   }
/*     */   
/*     */   public void setForcedUserTargetMovement(int forcedUserTargetMovement) {
/* 325 */     this.forcedUserTargetMovement = forcedUserTargetMovement;
/*     */   }
/*     */   
/*     */   public long getForcedFurniTargetMovement() {
/* 329 */     return this.forcedFurniTargetMovement;
/*     */   }
/*     */   
/*     */   public void setForcedFurniTargetMovement(long forcedFurniTargetMovement) {
/* 333 */     this.forcedFurniTargetMovement = forcedFurniTargetMovement;
/*     */   }
/*     */   
/*     */   public boolean isCarryingItemToUser() {
/* 337 */     return this.carryingItemToUser;
/*     */   }
/*     */   
/*     */   public void setCarryingItemToUser(boolean carryingItemToUser) {
/* 341 */     this.carryingItemToUser = carryingItemToUser;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\bots\BotData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */