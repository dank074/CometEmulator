package com.habboproject.server.game.bots;

public enum BotEntityType
{
  GENERIC_BOT,  PET;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\bots\BotEntityType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */