/*    */ package com.habboproject.server.game.achievements;
/*    */ 
/*    */ import com.habboproject.server.game.achievements.types.Achievement;
/*    */ import com.habboproject.server.game.achievements.types.AchievementCategory;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AchievementGroup
/*    */ {
/*    */   private Map<Integer, Achievement> achievements;
/*    */   private int id;
/*    */   private String groupName;
/*    */   private AchievementCategory category;
/*    */   
/*    */   public AchievementGroup(int id, Map<Integer, Achievement> achievements, String groupName, AchievementCategory category)
/*    */   {
/* 16 */     this.id = id;
/* 17 */     this.achievements = achievements;
/* 18 */     this.groupName = groupName;
/* 19 */     this.category = category;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 23 */     return this.id;
/*    */   }
/*    */   
/*    */   public int getLevelCount() {
/* 27 */     return this.achievements.size();
/*    */   }
/*    */   
/*    */   public Achievement getAchievement(int level) {
/* 31 */     return (Achievement)this.achievements.get(Integer.valueOf(level));
/*    */   }
/*    */   
/*    */   public Map<Integer, Achievement> getAchievements() {
/* 35 */     return this.achievements;
/*    */   }
/*    */   
/*    */   public String getGroupName() {
/* 39 */     return this.groupName;
/*    */   }
/*    */   
/*    */   public AchievementCategory getCategory() {
/* 43 */     return this.category;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\achievements\AchievementGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */