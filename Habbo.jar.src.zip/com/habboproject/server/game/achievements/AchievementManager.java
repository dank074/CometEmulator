/*    */ package com.habboproject.server.game.achievements;
/*    */ 
/*    */ import com.habboproject.server.game.achievements.types.AchievementType;
/*    */ import com.habboproject.server.storage.queries.achievements.AchievementDao;
/*    */ import com.habboproject.server.utilities.Initializable;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class AchievementManager implements Initializable
/*    */ {
/*    */   private static AchievementManager achievementManager;
/* 13 */   private static final Logger log = Logger.getLogger(AchievementManager.class.getName());
/*    */   private final Map<AchievementType, AchievementGroup> achievementGroups;
/*    */   
/*    */   public AchievementManager()
/*    */   {
/* 18 */     this.achievementGroups = new ConcurrentHashMap();
/*    */   }
/*    */   
/*    */   public void initialize()
/*    */   {
/* 23 */     loadAchievements();
/*    */     
/* 25 */     log.info("AchievementManager initialized");
/*    */   }
/*    */   
/*    */   public void loadAchievements() {
/* 29 */     if (this.achievementGroups.size() != 0) {
/* 30 */       for (AchievementGroup achievementGroup : this.achievementGroups.values()) {
/* 31 */         if (achievementGroup.getAchievements().size() != 0) {
/* 32 */           achievementGroup.getAchievements().clear();
/*    */         }
/*    */       }
/*    */       
/* 36 */       this.achievementGroups.clear();
/*    */     }
/*    */     
/* 39 */     int achievementCount = AchievementDao.getAchievements(this.achievementGroups);
/*    */     
/* 41 */     log.info("Loaded " + achievementCount + " achievements (" + this.achievementGroups.size() + " groups)");
/*    */   }
/*    */   
/*    */   public AchievementGroup getAchievementGroup(AchievementType groupName)
/*    */   {
/* 46 */     return (AchievementGroup)this.achievementGroups.get(groupName);
/*    */   }
/*    */   
/*    */   public Map<AchievementType, AchievementGroup> getAchievementGroups() {
/* 50 */     return this.achievementGroups;
/*    */   }
/*    */   
/*    */   public static AchievementManager getInstance() {
/* 54 */     if (achievementManager == null) {
/* 55 */       achievementManager = new AchievementManager();
/*    */     }
/*    */     
/* 58 */     return achievementManager;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\achievements\AchievementManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */