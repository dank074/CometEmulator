package com.habboproject.server.game.achievements.types;

public enum AchievementCategory
{
  IDENTITY,  EXPLORE,  MUSIC,  SOCIAL,  GAMES,  ROOM_BUILDER,  PETS;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\achievements\types\AchievementCategory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */