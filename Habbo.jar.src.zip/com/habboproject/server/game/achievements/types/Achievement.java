/*    */ package com.habboproject.server.game.achievements.types;
/*    */ 
/*    */ public class Achievement {
/*    */   private final int level;
/*    */   private final int rewardActivityPoints;
/*    */   private final int rewardAchievement;
/*    */   private final int progressNeeded;
/*    */   
/*    */   public Achievement(int level, int rewardActivityPoints, int rewardAchievement, int progressNeeded) {
/* 10 */     this.level = level;
/* 11 */     this.rewardActivityPoints = rewardActivityPoints;
/* 12 */     this.rewardAchievement = rewardAchievement;
/* 13 */     this.progressNeeded = progressNeeded;
/*    */   }
/*    */   
/*    */   public int getLevel() {
/* 17 */     return this.level;
/*    */   }
/*    */   
/*    */   public int getRewardActivityPoints() {
/* 21 */     return this.rewardActivityPoints;
/*    */   }
/*    */   
/*    */   public int getRewardAchievement() {
/* 25 */     return this.rewardAchievement;
/*    */   }
/*    */   
/*    */   public int getProgressNeeded() {
/* 29 */     return this.progressNeeded;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\achievements\types\Achievement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */