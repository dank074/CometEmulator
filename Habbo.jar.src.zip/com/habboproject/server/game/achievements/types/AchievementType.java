/*    */ package com.habboproject.server.game.achievements.types;
/*    */ 
/*    */ public enum AchievementType {
/*  4 */   AVATAR_LOOKS("ACH_AvatarLooks"), 
/*  5 */   MOTTO("ACH_Motto"), 
/*  6 */   RESPECT_GIVEN("ACH_RespectGiven"), 
/*  7 */   RESPECT_EARNED("ACH_RespectEarned"), 
/*  8 */   ROOM_ENTRY("ACH_RoomEntry"), 
/*  9 */   REGISTRATION_DURATION("ACH_RegistrationDuration"), 
/* 10 */   PET_RESPECT_GIVEN("ACH_PetRespectGiver"), 
/* 11 */   PET_LOVER("ACH_PetLover"), 
/* 12 */   GIFT_GIVER("ACH_GiftGiver"), 
/* 13 */   GIFT_RECEIVER("ACH_GiftReceiver"), 
/* 14 */   BB_TILES_LOCKED("ACH_BattleBallTilesLocked"), 
/* 15 */   BB_PLAYER("ACH_BattleBallPlayer"), 
/* 16 */   BB_WINNER("ACH_BattleBallWinner"), 
/* 17 */   ONLINE_TIME("ACH_AllTimeHotelPresence"), 
/* 18 */   LOGIN("ACH_Login"), 
/* 19 */   FRIENDS_LIST("ACH_FriendListSize"), 
/* 20 */   CAMERA_PHOTO("ACH_CameraPhotoCount"), 
/* 21 */   FOOTBALL_GOAL("ACH_FootballGoalScoredInRoom");
/*    */   
/*    */   private String groupName;
/*    */   
/*    */   private AchievementType(String groupName) {
/* 26 */     this.groupName = groupName;
/*    */   }
/*    */   
/*    */ 
/* 30 */   public String getGroupName() { return this.groupName; }
/*    */   
/*    */   public static AchievementType getTypeByName(String name) {
/*    */     AchievementType[] arrayOfAchievementType;
/* 34 */     int j = (arrayOfAchievementType = values()).length; for (int i = 0; i < j; i++) { AchievementType type = arrayOfAchievementType[i];
/* 35 */       if (type.groupName.equals(name)) {
/* 36 */         return type;
/*    */       }
/*    */     }
/*    */     
/* 40 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\achievements\types\AchievementType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */