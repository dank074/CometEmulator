/*     */ package com.habboproject.server.game.players;
/*     */ 
/*     */ import com.habboproject.server.config.Configuration;
/*     */ import com.habboproject.server.game.players.data.PlayerAvatar;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.login.PlayerLoginRequest;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.network.sessions.SessionManager;
/*     */ import com.habboproject.server.storage.queries.player.PlayerDao;
/*     */ import com.habboproject.server.utilities.Initializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import net.sf.ehcache.Cache;
/*     */ import net.sf.ehcache.CacheManager;
/*     */ import net.sf.ehcache.Element;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class PlayerManager implements Initializable
/*     */ {
/*     */   private static PlayerManager playerManagerInstance;
/*  27 */   private static Logger log = Logger.getLogger(PlayerManager.class.getName());
/*     */   
/*     */   private Map<Integer, Integer> playerIdToSessionId;
/*     */   
/*     */   private Map<String, Integer> playerUsernameToPlayerId;
/*     */   
/*     */   private Map<String, List<Integer>> ipAddressToPlayerIds;
/*     */   
/*     */   private CacheManager cacheManager;
/*     */   
/*     */   private Cache playerAvatarCache;
/*     */   
/*     */   private Cache playerDataCache;
/*     */   
/*     */   private ExecutorService playerLoginService;
/*     */   
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  46 */     this.playerIdToSessionId = new ConcurrentHashMap();
/*  47 */     this.playerUsernameToPlayerId = new ConcurrentHashMap();
/*  48 */     this.ipAddressToPlayerIds = new ConcurrentHashMap();
/*     */     
/*  50 */     this.playerLoginService = java.util.concurrent.Executors.newFixedThreadPool(2);
/*     */     
/*     */ 
/*  53 */     if (((Boolean)com.habboproject.server.boot.Comet.getServer().getConfig().getOrDefault("comet.cache.players.enabled", Boolean.valueOf(true))).booleanValue()) {
/*  54 */       log.info("Initializing Player cache");
/*     */       
/*  56 */       int oneDay = 86400;
/*  57 */       this.playerAvatarCache = new Cache("playerAvatarCache", 75000, false, false, 86400L, 86400L);
/*  58 */       this.playerDataCache = new Cache("playerDataCache", 15000, false, false, 86400L, 86400L);
/*     */       
/*  60 */       this.cacheManager = CacheManager.newInstance("./config/ehcache.xml");
/*     */       
/*  62 */       this.cacheManager.addCache(this.playerAvatarCache);
/*  63 */       this.cacheManager.addCache(this.playerDataCache);
/*     */     } else {
/*  65 */       log.info("Player data cache is disabled.");
/*     */     }
/*     */     
/*  68 */     log.info("Resetting player online status");
/*  69 */     PlayerDao.resetOnlineStatus();
/*     */     
/*  71 */     log.info("PlayerManager initialized");
/*     */   }
/*     */   
/*     */   public static PlayerManager getInstance() {
/*  75 */     if (playerManagerInstance == null) {
/*  76 */       playerManagerInstance = new PlayerManager();
/*     */     }
/*  78 */     return playerManagerInstance;
/*     */   }
/*     */   
/*     */   public void submitLoginRequest(Session client, String ticket) {
/*  82 */     this.playerLoginService.submit(new PlayerLoginRequest(client, ticket));
/*     */   }
/*     */   
/*     */   public PlayerAvatar getAvatarByPlayerId(int playerId, byte mode) {
/*  86 */     if (isOnline(playerId)) {
/*  87 */       Session session = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);
/*     */       
/*  89 */       if ((session != null) && (session.getPlayer() != null) && (session.getPlayer().getData() != null)) {
/*  90 */         return session.getPlayer().getData();
/*     */       }
/*     */     }
/*     */     
/*  94 */     if (this.playerDataCache != null) {
/*  95 */       Element cachedElement = this.playerDataCache.get(Integer.valueOf(playerId));
/*     */       
/*  97 */       if ((cachedElement != null) && (cachedElement.getObjectValue() != null)) {
/*  98 */         return (PlayerData)cachedElement.getObjectValue();
/*     */       }
/*     */     }
/*     */     
/* 102 */     if (this.playerAvatarCache != null) {
/* 103 */       Element cachedElement = this.playerAvatarCache.get(Integer.valueOf(playerId));
/*     */       
/* 105 */       if ((cachedElement != null) && (cachedElement.getObjectValue() != null)) {
/* 106 */         PlayerAvatar playerAvatar = (PlayerAvatar)cachedElement.getObjectValue();
/*     */         
/* 108 */         if ((playerAvatar.getMotto() == null) && (mode == 1)) {
/* 109 */           playerAvatar.setMotto(PlayerDao.getMottoByPlayerId(playerId));
/*     */         }
/*     */         
/* 112 */         return playerAvatar;
/*     */       }
/*     */     }
/*     */     
/* 116 */     PlayerAvatar playerAvatar = PlayerDao.getAvatarById(playerId, mode);
/*     */     
/* 118 */     if ((playerAvatar != null) && (this.playerAvatarCache != null)) {
/* 119 */       this.playerAvatarCache.put(new Element(Integer.valueOf(playerId), playerAvatar));
/*     */     }
/*     */     
/* 122 */     return playerAvatar;
/*     */   }
/*     */   
/*     */   public PlayerData getDataByPlayerId(int playerId) {
/* 126 */     if (isOnline(playerId)) {
/* 127 */       Session session = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);
/*     */       
/* 129 */       if ((session != null) && (session.getPlayer() != null) && (session.getPlayer().getData() != null)) {
/* 130 */         return session.getPlayer().getData();
/*     */       }
/*     */     }
/*     */     
/* 134 */     if (this.playerDataCache != null) {
/* 135 */       Element cachedElement = this.playerDataCache.get(Integer.valueOf(playerId));
/*     */       
/* 137 */       if ((cachedElement != null) && (cachedElement.getObjectValue() != null)) {
/* 138 */         return (PlayerData)cachedElement.getObjectValue();
/*     */       }
/*     */     }
/*     */     
/* 142 */     PlayerData playerData = PlayerDao.getDataById(playerId);
/*     */     
/* 144 */     if ((playerData != null) && (this.playerDataCache != null)) {
/* 145 */       this.playerDataCache.put(new Element(Integer.valueOf(playerId), playerData));
/*     */     }
/*     */     
/* 148 */     return playerData;
/*     */   }
/*     */   
/*     */   public int getPlayerCountByIpAddress(String ipAddress) {
/* 152 */     if (this.ipAddressToPlayerIds.containsKey(ipAddress)) {
/* 153 */       return ((List)this.ipAddressToPlayerIds.get(ipAddress)).size();
/*     */     }
/*     */     
/* 156 */     return 0;
/*     */   }
/*     */   
/*     */   public void put(int playerId, int sessionId, String username, String ipAddress) {
/* 160 */     if (this.playerIdToSessionId.containsKey(Integer.valueOf(playerId))) {
/* 161 */       this.playerIdToSessionId.remove(Integer.valueOf(playerId));
/*     */     }
/*     */     
/* 164 */     if (this.playerUsernameToPlayerId.containsKey(username.toLowerCase())) {
/* 165 */       this.playerUsernameToPlayerId.remove(username.toLowerCase());
/*     */     }
/*     */     
/* 168 */     if (!this.ipAddressToPlayerIds.containsKey(ipAddress)) {
/* 169 */       this.ipAddressToPlayerIds.put(ipAddress, com.google.common.collect.Lists.newArrayList(new Integer[] { Integer.valueOf(playerId) }));
/*     */     } else {
/* 171 */       ((List)this.ipAddressToPlayerIds.get(ipAddress)).add(Integer.valueOf(playerId));
/*     */     }
/*     */     
/* 174 */     this.playerIdToSessionId.put(Integer.valueOf(playerId), Integer.valueOf(sessionId));
/* 175 */     this.playerUsernameToPlayerId.put(username.toLowerCase(), Integer.valueOf(playerId));
/*     */   }
/*     */   
/*     */   public void remove(int playerId, String username, int sessionId, String ipAddress) {
/* 179 */     if (getSessionIdByPlayerId(playerId) != sessionId) {
/* 180 */       return;
/*     */     }
/*     */     
/* 183 */     if (this.ipAddressToPlayerIds.containsKey(ipAddress)) {
/* 184 */       List<Integer> playerIds = (List)this.ipAddressToPlayerIds.get(ipAddress);
/*     */       
/* 186 */       if (!playerIds.isEmpty()) {
/* 187 */         playerIds.remove(Integer.valueOf(playerId));
/*     */       }
/*     */       
/* 190 */       if (playerIds.isEmpty()) {
/* 191 */         this.ipAddressToPlayerIds.remove(ipAddress);
/*     */       }
/*     */     }
/*     */     
/* 195 */     this.playerIdToSessionId.remove(Integer.valueOf(playerId));
/* 196 */     this.playerUsernameToPlayerId.remove(username.toLowerCase());
/*     */   }
/*     */   
/*     */   public int getPlayerIdByUsername(String username) {
/* 200 */     if (this.playerUsernameToPlayerId.containsKey(username.toLowerCase())) {
/* 201 */       return ((Integer)this.playerUsernameToPlayerId.get(username.toLowerCase())).intValue();
/*     */     }
/*     */     
/* 204 */     return -1;
/*     */   }
/*     */   
/*     */   public int getSessionIdByPlayerId(int playerId) {
/* 208 */     if (this.playerIdToSessionId.containsKey(Integer.valueOf(playerId))) {
/* 209 */       return ((Integer)this.playerIdToSessionId.get(Integer.valueOf(playerId))).intValue();
/*     */     }
/*     */     
/* 212 */     return -1;
/*     */   }
/*     */   
/*     */   public List<Integer> getPlayerIdsByIpAddress(String ipAddress) {
/* 216 */     return new ArrayList((Collection)this.ipAddressToPlayerIds.get(ipAddress));
/*     */   }
/*     */   
/*     */   public boolean isOnline(int playerId) {
/* 220 */     return this.playerIdToSessionId.containsKey(Integer.valueOf(playerId));
/*     */   }
/*     */   
/*     */   public boolean isOnline(String username) {
/* 224 */     return this.playerUsernameToPlayerId.containsKey(username.toLowerCase());
/*     */   }
/*     */   
/*     */   public int size() {
/* 228 */     return this.playerIdToSessionId.size();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\PlayerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */