/*     */ package com.habboproject.server.game.players.types;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import com.habboproject.server.api.game.players.data.IPlayerSettings;
/*     */ import com.habboproject.server.api.game.players.data.types.IPlaylistItem;
/*     */ import com.habboproject.server.api.game.players.data.types.IVolumeData;
/*     */ import com.habboproject.server.api.game.players.data.types.IWardrobeItem;
/*     */ import com.habboproject.server.game.players.components.types.settings.NavigatorData;
/*     */ import com.habboproject.server.game.players.components.types.settings.PlaylistItem;
/*     */ import com.habboproject.server.game.players.components.types.settings.VolumeData;
/*     */ import com.habboproject.server.game.players.components.types.settings.WardrobeItem;
/*     */ import com.habboproject.server.utilities.JsonFactory;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerSettings
/*     */   implements IPlayerSettings
/*     */ {
/*     */   private VolumeData volumes;
/*     */   private NavigatorData navigator;
/*     */   private List<IWardrobeItem> wardrobe;
/*     */   private List<IPlaylistItem> playlist;
/*     */   private boolean hideOnline;
/*     */   private boolean hideInRoom;
/*     */   private boolean allowFriendRequests;
/*     */   private boolean allowTrade;
/*     */   private int homeRoom;
/*     */   private boolean useOldChat;
/*     */   private boolean ignoreInvites;
/*     */   private boolean cameraFollow;
/*  37 */   private boolean enableEventNotif = true;
/*     */   
/*     */   public PlayerSettings(ResultSet data, boolean isLogin) throws SQLException {
/*  40 */     if (isLogin) {
/*  41 */       String volumeData = data.getString("playerSettings_volume");
/*  42 */       this.volumes = ((volumeData != null) && (volumeData.startsWith("{")) ? (VolumeData)JsonFactory.getInstance().fromJson(volumeData, VolumeData.class) : new VolumeData(100, 100, 100));
/*     */       
/*  44 */       String navigatorData = data.getString("playerSettings_navigator");
/*  45 */       this.navigator = ((navigatorData != null) && (navigatorData.startsWith("{")) ? (NavigatorData)JsonFactory.getInstance().fromJson(navigatorData, NavigatorData.class) : new NavigatorData(68, 42, 425, 592, false));
/*     */       
/*  47 */       this.hideOnline = data.getString("playerSettings_hideOnline").equals("1");
/*  48 */       this.hideInRoom = data.getString("playerSettings_hideInRoom").equals("1");
/*  49 */       this.allowFriendRequests = data.getString("playerSettings_allowFriendRequests").equals("1");
/*  50 */       this.allowTrade = data.getString("playerSettings_allowTrade").equals("1");
/*     */       
/*  52 */       this.homeRoom = data.getInt("playerSettings_homeRoom");
/*     */       
/*  54 */       String wardrobeText = data.getString("playerSettings_wardrobe");
/*     */       
/*  56 */       if ((wardrobeText == null) || (wardrobeText.isEmpty())) {
/*  57 */         this.wardrobe = new ArrayList();
/*     */       } else {
/*  59 */         this.wardrobe = ((List)JsonFactory.getInstance().fromJson(wardrobeText, new TypeToken() {}.getType()));
/*     */       }
/*     */       
/*     */ 
/*  63 */       String playlistText = data.getString("playerSettings_playlist");
/*     */       
/*  65 */       if ((playlistText == null) || (playlistText.isEmpty())) {
/*  66 */         this.playlist = new ArrayList();
/*     */       } else {
/*  68 */         this.playlist = ((List)JsonFactory.getInstance().fromJson(playlistText, new TypeToken() {}.getType()));
/*     */       }
/*     */       
/*     */ 
/*  72 */       this.useOldChat = data.getString("playerSettings_useOldChat").equals("1");
/*  73 */       this.ignoreInvites = data.getString("playerSettings_ignoreInvites").equals("1");
/*  74 */       this.cameraFollow = data.getString("playerSettings_cameraFollow").equals("1");
/*     */     } else {
/*  76 */       String volumeData = data.getString("volume");
/*  77 */       this.volumes = ((volumeData != null) && (volumeData.startsWith("{")) ? (VolumeData)JsonFactory.getInstance().fromJson(volumeData, VolumeData.class) : new VolumeData(100, 100, 100));
/*     */       
/*  79 */       String navigatorData = data.getString("navigator");
/*  80 */       this.navigator = ((navigatorData != null) && (navigatorData.startsWith("{")) ? (NavigatorData)JsonFactory.getInstance().fromJson(navigatorData, NavigatorData.class) : new NavigatorData(68, 42, 425, 592, false));
/*     */       
/*  82 */       this.hideOnline = data.getString("hide_online").equals("1");
/*  83 */       this.hideInRoom = data.getString("hide_inroom").equals("1");
/*  84 */       this.allowFriendRequests = data.getString("allow_friend_requests").equals("1");
/*  85 */       this.allowTrade = data.getString("allow_trade").equals("1");
/*     */       
/*  87 */       this.homeRoom = data.getInt("home_room");
/*     */       
/*  89 */       String wardrobeText = data.getString("wardrobe");
/*     */       
/*  91 */       if ((wardrobeText == null) || (wardrobeText.isEmpty())) {
/*  92 */         this.wardrobe = new ArrayList();
/*     */       } else {
/*  94 */         this.wardrobe = ((List)JsonFactory.getInstance().fromJson(wardrobeText, new TypeToken() {}.getType()));
/*     */       }
/*     */       
/*     */ 
/*  98 */       String playlistText = data.getString("playlist");
/*     */       
/* 100 */       if ((playlistText == null) || (playlistText.isEmpty())) {
/* 101 */         this.playlist = new ArrayList();
/*     */       } else {
/* 103 */         this.playlist = ((List)JsonFactory.getInstance().fromJson(playlistText, new TypeToken() {}.getType()));
/*     */       }
/*     */       
/*     */ 
/* 107 */       this.useOldChat = data.getString("chat_oldstyle").equals("1");
/* 108 */       this.ignoreInvites = data.getString("ignore_invites").equals("1");
/* 109 */       this.cameraFollow = data.getString("camera_follow").equals("1");
/*     */     }
/*     */   }
/*     */   
/*     */   public PlayerSettings() {
/* 114 */     this.volumes = new VolumeData(100, 100, 100);
/* 115 */     this.navigator = new NavigatorData(68, 42, 425, 592, false);
/* 116 */     this.hideInRoom = false;
/* 117 */     this.homeRoom = 0;
/* 118 */     this.hideOnline = false;
/* 119 */     this.allowFriendRequests = true;
/* 120 */     this.allowTrade = true;
/* 121 */     this.wardrobe = new ArrayList();
/* 122 */     this.playlist = new ArrayList();
/* 123 */     this.useOldChat = false;
/* 124 */     this.cameraFollow = false;
/*     */   }
/*     */   
/*     */   public IVolumeData getVolumes() {
/* 128 */     return this.volumes;
/*     */   }
/*     */   
/*     */   public NavigatorData getNavigator() {
/* 132 */     return this.navigator;
/*     */   }
/*     */   
/*     */   public boolean getHideOnline() {
/* 136 */     return this.hideOnline;
/*     */   }
/*     */   
/*     */   public boolean getHideInRoom() {
/* 140 */     return this.hideInRoom;
/*     */   }
/*     */   
/*     */   public boolean getAllowFriendRequests() {
/* 144 */     return this.allowFriendRequests;
/*     */   }
/*     */   
/*     */   public void setAllowFriendRequests(boolean allowFriendRequests) {
/* 148 */     this.allowFriendRequests = allowFriendRequests;
/*     */   }
/*     */   
/*     */   public boolean getAllowTrade() {
/* 152 */     return this.allowTrade;
/*     */   }
/*     */   
/*     */   public int getHomeRoom() {
/* 156 */     return this.homeRoom;
/*     */   }
/*     */   
/*     */   public void setHomeRoom(int homeRoom) {
/* 160 */     this.homeRoom = homeRoom;
/*     */   }
/*     */   
/*     */   public List<IWardrobeItem> getWardrobe() {
/* 164 */     return this.wardrobe;
/*     */   }
/*     */   
/*     */   public void setWardrobe(List<IWardrobeItem> wardrobe) {
/* 168 */     this.wardrobe = wardrobe;
/*     */   }
/*     */   
/*     */   public List<IPlaylistItem> getPlaylist() {
/* 172 */     return this.playlist;
/*     */   }
/*     */   
/*     */   public boolean isUseOldChat() {
/* 176 */     return this.useOldChat;
/*     */   }
/*     */   
/*     */   public void setUseOldChat(boolean useOldChat) {
/* 180 */     this.useOldChat = useOldChat;
/*     */   }
/*     */   
/*     */   public boolean isIgnoreInvites() {
/* 184 */     return this.ignoreInvites;
/*     */   }
/*     */   
/*     */   public void setIgnoreInvites(boolean ignoreInvites) {
/* 188 */     this.ignoreInvites = ignoreInvites;
/*     */   }
/*     */   
/*     */   public boolean enableEventNotif() {
/* 192 */     return this.enableEventNotif;
/*     */   }
/*     */   
/*     */   public void setEnableEventNotif(boolean enableEventNotif) {
/* 196 */     this.enableEventNotif = enableEventNotif;
/*     */   }
/*     */   
/*     */   public boolean cameraFollow() {
/* 200 */     return this.cameraFollow;
/*     */   }
/*     */   
/*     */   public void setCameraFollow(boolean cameraFollow) {
/* 204 */     this.cameraFollow = cameraFollow;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\types\PlayerSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */