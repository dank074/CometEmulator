/*     */ package com.habboproject.server.game.players.types;
/*     */ 
/*     */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*     */ import com.habboproject.server.api.networking.sessions.BaseSession;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.config.CometSettings;
/*     */ import com.habboproject.server.game.players.components.AchievementComponent;
/*     */ import com.habboproject.server.game.players.components.EffectComponent;
/*     */ import com.habboproject.server.game.players.components.InventoryBotComponent;
/*     */ import com.habboproject.server.game.players.components.InventoryComponent;
/*     */ import com.habboproject.server.game.players.components.MessengerComponent;
/*     */ import com.habboproject.server.game.players.components.PermissionComponent;
/*     */ import com.habboproject.server.game.players.components.PetComponent;
/*     */ import com.habboproject.server.game.players.components.QuestComponent;
/*     */ import com.habboproject.server.game.players.components.RelationshipComponent;
/*     */ import com.habboproject.server.game.players.components.SubscriptionComponent;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.quests.QuestManager;
/*     */ import com.habboproject.server.game.quests.types.Quest;
/*     */ import com.habboproject.server.game.quests.types.QuestType;
/*     */ import com.habboproject.server.game.rooms.RoomManager;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.network.messages.composers.MessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.UpdateInfoMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.user.purse.SendCreditsMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.storage.queries.groups.GroupDao;
/*     */ import com.habboproject.server.storage.queries.player.PlayerDao;
/*     */ import com.habboproject.server.storage.queue.types.PlayerDataStorageQueue;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class Player implements com.habboproject.server.api.game.players.BasePlayer
/*     */ {
/*     */   private int id;
/*     */   private PlayerSettings settings;
/*     */   private PlayerData data;
/*     */   private PlayerStatistics stats;
/*     */   private PlayerFreeze freeze;
/*     */   private PlayerEntity entity;
/*     */   private Session session;
/*     */   private final PermissionComponent permissions;
/*     */   private final InventoryComponent inventory;
/*     */   private final SubscriptionComponent subscription;
/*     */   private final MessengerComponent messenger;
/*     */   private final RelationshipComponent relationships;
/*     */   private final InventoryBotComponent bots;
/*     */   private final PetComponent pets;
/*     */   private final QuestComponent quests;
/*     */   private final AchievementComponent achievements;
/*     */   private final EffectComponent effect;
/*  58 */   private List<Integer> rooms = new ArrayList();
/*  59 */   private List<Integer> enteredRooms = new ArrayList();
/*     */   
/*  61 */   private List<Integer> groups = new ArrayList();
/*     */   
/*  63 */   private List<Integer> ignoredPlayers = new ArrayList();
/*  64 */   private long roomLastMessageTime = 0L;
/*  65 */   private double roomFloodTime = 0.0D;
/*  66 */   private int lastForumPost = 0;
/*     */   
/*  68 */   private long lastRoomRequest = 0L;
/*  69 */   private long lastBadgeUpdate = 0L;
/*  70 */   private int lastFigureUpdate = 0;
/*     */   
/*  72 */   private int roomFloodFlag = 0;
/*  73 */   private long messengerLastMessageTime = 0L;
/*     */   
/*  75 */   private double messengerFloodTime = 0.0D;
/*  76 */   private int messengerFloodFlag = 0;
/*     */   
/*  78 */   private long teleportId = 0L;
/*  79 */   private int teleportRoomId = 0;
/*  80 */   private String lastMessage = "";
/*     */   
/*  82 */   private int notifCooldown = 0;
/*     */   
/*     */   private int lastRoomId;
/*  85 */   private int lastGift = 0;
/*     */   
/*  87 */   private int lastRoomCreated = 0;
/*  88 */   public boolean cancelPageOpen = false;
/*     */   
/*  90 */   private boolean isDeletingGroup = false;
/*     */   
/*  92 */   private long deletingGroupAttempt = 0L;
/*     */   
/*     */   private boolean bypassRoomAuth;
/*     */   
/*  96 */   public boolean isDisposed = false;
/*     */   
/*  98 */   private long lastReward = 0L;
/*     */   
/* 100 */   private boolean invisible = false;
/*     */   
/* 102 */   private int lastTradePlayer = 0;
/* 103 */   private long lastTradeTime = 0L;
/* 104 */   private int lastTradeFlag = 0;
/*     */   
/* 106 */   private int lastTradeFlood = 0;
/*     */   
/*     */   public Player(ResultSet data, boolean isFallback) throws SQLException {
/* 109 */     this.id = data.getInt("playerId");
/*     */     
/* 111 */     if (isFallback) {
/* 112 */       this.settings = PlayerDao.getSettingsById(this.id);
/* 113 */       this.stats = PlayerDao.getStatisticsById(this.id);
/*     */     } else {
/* 115 */       this.settings = new PlayerSettings(data, true);
/* 116 */       this.stats = new PlayerStatistics(data, true);
/*     */     }
/*     */     
/* 119 */     if (PlayerDataStorageQueue.getInstance().isPlayerSaving(this.id)) {
/* 120 */       this.data = PlayerDataStorageQueue.getInstance().getPlayerData(this.id);
/*     */     } else {
/* 122 */       this.data = new PlayerData(data);
/*     */     }
/*     */     
/* 125 */     this.freeze = new PlayerFreeze(this);
/*     */     
/* 127 */     this.permissions = new PermissionComponent(this);
/* 128 */     this.inventory = new InventoryComponent(this);
/* 129 */     this.messenger = new MessengerComponent(this);
/* 130 */     this.subscription = new SubscriptionComponent(this);
/* 131 */     this.relationships = new RelationshipComponent(this);
/* 132 */     this.bots = new InventoryBotComponent(this);
/* 133 */     this.pets = new PetComponent(this);
/* 134 */     this.quests = new QuestComponent(this);
/* 135 */     this.achievements = new AchievementComponent(this);
/* 136 */     this.effect = new EffectComponent(this);
/*     */     
/* 138 */     this.groups = GroupDao.getIdsByPlayerId(this.id);
/*     */     
/* 140 */     this.entity = null;
/* 141 */     this.lastReward = Comet.getTime();
/*     */   }
/*     */   
/*     */   public void dispose()
/*     */   {
/* 146 */     if (getEntity() != null) {
/*     */       try {
/* 148 */         getEntity().leaveRoom(true, false, false);
/*     */       }
/*     */       catch (Exception e) {
/* 151 */         getSession().getLogger().error("Error while disposing entity when player disconnects", e);
/*     */       }
/*     */     }
/*     */     
/* 155 */     getData().save();
/* 156 */     getPets().dispose();
/* 157 */     getBots().dispose();
/* 158 */     getInventory().dispose();
/* 159 */     getMessenger().dispose();
/* 160 */     getRelationships().dispose();
/* 161 */     getQuests().dispose();
/*     */     
/* 163 */     this.session.getLogger().debug(getData().getUsername() + " logged out");
/*     */     
/* 165 */     PlayerDao.updatePlayerStatus(this, false, false);
/*     */     
/* 167 */     this.rooms.clear();
/* 168 */     this.rooms = null;
/*     */     
/* 170 */     this.groups.clear();
/* 171 */     this.groups = null;
/*     */     
/* 173 */     this.ignoredPlayers.clear();
/* 174 */     this.ignoredPlayers = null;
/*     */     
/* 176 */     this.enteredRooms.clear();
/* 177 */     this.enteredRooms = null;
/*     */     
/* 179 */     this.settings = null;
/* 180 */     this.data = null;
/*     */     
/* 182 */     this.isDisposed = true;
/*     */   }
/*     */   
/*     */   public void sendBalance()
/*     */   {
/* 187 */     this.session.send(composeCurrenciesBalance());
/* 188 */     this.session.send(composeCreditBalance());
/*     */   }
/*     */   
/*     */   public void sendNotif(String title, String message)
/*     */   {
/* 193 */     this.session.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(title, message));
/*     */   }
/*     */   
/*     */   public void sendMotd(String message)
/*     */   {
/* 198 */     this.session.send(new com.habboproject.server.network.messages.outgoing.notification.MotdNotificationMessageComposer(message));
/*     */   }
/*     */   
/*     */   public MessageComposer composeCreditBalance()
/*     */   {
/* 203 */     return new SendCreditsMessageComposer(CometSettings.playerInfiniteBalance ? 999999 : this.session.getPlayer().getData().getCredits());
/*     */   }
/*     */   
/*     */   public MessageComposer composeCurrenciesBalance()
/*     */   {
/* 208 */     Map<Integer, Integer> currencies = new java.util.HashMap();
/*     */     
/* 210 */     currencies.put(Integer.valueOf(0), Integer.valueOf(CometSettings.playerInfiniteBalance ? 999999 : getData().getActivityPoints()));
/* 211 */     currencies.put(Integer.valueOf(105), Integer.valueOf(getData().getVipPoints()));
/* 212 */     currencies.put(Integer.valueOf(5), Integer.valueOf(getData().getVipPoints()));
/*     */     
/* 214 */     return new com.habboproject.server.network.messages.outgoing.user.purse.CurrenciesMessageComposer(currencies);
/*     */   }
/*     */   
/*     */   public void loadRoom(int id, String password)
/*     */   {
/* 219 */     if ((this.entity != null) && (this.entity.getRoom() != null)) {
/* 220 */       this.entity.leaveRoom(true, false, false);
/* 221 */       setEntity(null);
/*     */     }
/*     */     
/* 224 */     Room room = RoomManager.getInstance().get(id);
/*     */     
/* 226 */     if (room == null) {
/* 227 */       this.session.send(new com.habboproject.server.network.messages.outgoing.room.engine.HotelViewMessageComposer());
/* 228 */       return;
/*     */     }
/*     */     
/* 231 */     if (room.getEntities() == null) {
/* 232 */       return;
/*     */     }
/*     */     
/* 235 */     if (room.getEntities().getEntityByPlayerId(this.id) != null) {
/* 236 */       room.getEntities().getEntityByPlayerId(this.id).leaveRoom(true, false, false);
/*     */     }
/*     */     
/* 239 */     PlayerEntity playerEntity = room.getEntities().createEntity(this);
/*     */     
/* 241 */     setEntity(playerEntity);
/*     */     
/* 243 */     playerEntity.joinRoom(room, password);
/*     */     
/* 245 */     if (getData().getQuestId() != 0) {
/* 246 */       Quest quest = QuestManager.getInstance().getById(getData().getQuestId());
/*     */       
/* 248 */       if ((quest != null) && (getQuests().hasStartedQuest(quest.getId())) && (!getQuests().hasCompletedQuest(quest.getId()))) {
/* 249 */         getSession().send(new com.habboproject.server.network.messages.outgoing.quests.QuestStartedMessageComposer(quest, this));
/*     */         
/* 251 */         if (quest.getType() == QuestType.SOCIAL_VISIT) {
/* 252 */           getQuests().progressQuest(QuestType.SOCIAL_VISIT);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 257 */     if ((!this.enteredRooms.contains(Integer.valueOf(id))) && (!this.rooms.contains(Integer.valueOf(id)))) {
/* 258 */       this.enteredRooms.add(Integer.valueOf(id));
/*     */     }
/*     */   }
/*     */   
/*     */   public void poof()
/*     */   {
/* 264 */     getSession().send(new UpdateInfoMessageComposer(-1, getData().getFigure(), getData().getGender(), getData().getMotto(), getData().getAchievementPoints()));
/*     */     
/* 266 */     if ((getEntity() != null) && (getEntity().getRoom() != null) && (getEntity().getRoom().getEntities() != null)) {
/* 267 */       getEntity().unIdle();
/* 268 */       getEntity().getRoom().getEntities().broadcastMessage(new UpdateInfoMessageComposer(getEntity()));
/*     */     }
/*     */   }
/*     */   
/*     */   public void ignorePlayer(int playerId)
/*     */   {
/* 274 */     if (this.ignoredPlayers == null) {
/* 275 */       this.ignoredPlayers = new ArrayList();
/*     */     }
/*     */     
/* 278 */     this.ignoredPlayers.add(Integer.valueOf(playerId));
/*     */   }
/*     */   
/*     */   public void unignorePlayer(int playerId)
/*     */   {
/* 283 */     this.ignoredPlayers.remove(Integer.valueOf(playerId));
/*     */   }
/*     */   
/*     */   public boolean ignores(int playerId)
/*     */   {
/* 288 */     return (this.ignoredPlayers != null) && (this.ignoredPlayers.contains(Integer.valueOf(playerId)));
/*     */   }
/*     */   
/*     */   public List<Integer> getRooms()
/*     */   {
/* 293 */     return this.rooms;
/*     */   }
/*     */   
/*     */   public void setRooms(List<Integer> rooms)
/*     */   {
/* 298 */     this.rooms = rooms;
/*     */   }
/*     */   
/*     */   public void setSession(BaseSession client)
/*     */   {
/* 303 */     this.session = ((Session)client);
/*     */   }
/*     */   
/*     */   public void setEntity(PlayerEntity avatar)
/*     */   {
/* 308 */     this.entity = avatar;
/*     */   }
/*     */   
/*     */   public PlayerEntity getEntity()
/*     */   {
/* 313 */     return this.entity;
/*     */   }
/*     */   
/*     */   public Session getSession()
/*     */   {
/* 318 */     return this.session;
/*     */   }
/*     */   
/*     */   public PlayerData getData()
/*     */   {
/* 323 */     return this.data;
/*     */   }
/*     */   
/*     */   public PlayerStatistics getStats()
/*     */   {
/* 328 */     return this.stats;
/*     */   }
/*     */   
/*     */   public PermissionComponent getPermissions()
/*     */   {
/* 333 */     return this.permissions;
/*     */   }
/*     */   
/*     */   public MessengerComponent getMessenger()
/*     */   {
/* 338 */     return this.messenger;
/*     */   }
/*     */   
/*     */   public PlayerInventory getInventory()
/*     */   {
/* 343 */     return this.inventory;
/*     */   }
/*     */   
/*     */   public SubscriptionComponent getSubscription()
/*     */   {
/* 348 */     return this.subscription;
/*     */   }
/*     */   
/*     */   public RelationshipComponent getRelationships()
/*     */   {
/* 353 */     return this.relationships;
/*     */   }
/*     */   
/*     */   public InventoryBotComponent getBots()
/*     */   {
/* 358 */     return this.bots;
/*     */   }
/*     */   
/*     */   public PetComponent getPets()
/*     */   {
/* 363 */     return this.pets;
/*     */   }
/*     */   
/*     */   public QuestComponent getQuests()
/*     */   {
/* 368 */     return this.quests;
/*     */   }
/*     */   
/*     */   public AchievementComponent getAchievements() {
/* 372 */     return this.achievements;
/*     */   }
/*     */   
/*     */   public PlayerSettings getSettings()
/*     */   {
/* 377 */     return this.settings;
/*     */   }
/*     */   
/*     */   public int getId()
/*     */   {
/* 382 */     return this.id;
/*     */   }
/*     */   
/*     */   public boolean isTeleporting()
/*     */   {
/* 387 */     return this.teleportId != 0L;
/*     */   }
/*     */   
/*     */   public long getTeleportId()
/*     */   {
/* 392 */     return this.teleportId;
/*     */   }
/*     */   
/*     */   public void setTeleportId(long teleportId)
/*     */   {
/* 397 */     this.teleportId = teleportId;
/*     */   }
/*     */   
/*     */   public long getRoomLastMessageTime()
/*     */   {
/* 402 */     return this.roomLastMessageTime;
/*     */   }
/*     */   
/*     */   public void setRoomLastMessageTime(long roomLastMessageTime)
/*     */   {
/* 407 */     this.roomLastMessageTime = roomLastMessageTime;
/*     */   }
/*     */   
/*     */   public double getRoomFloodTime()
/*     */   {
/* 412 */     return this.roomFloodTime;
/*     */   }
/*     */   
/*     */   public void setRoomFloodTime(double roomFloodTime)
/*     */   {
/* 417 */     this.roomFloodTime = roomFloodTime;
/*     */   }
/*     */   
/*     */   public int getRoomFloodFlag()
/*     */   {
/* 422 */     return this.roomFloodFlag;
/*     */   }
/*     */   
/*     */   public void setRoomFloodFlag(int roomFloodFlag)
/*     */   {
/* 427 */     this.roomFloodFlag = roomFloodFlag;
/*     */   }
/*     */   
/*     */   public String getLastMessage()
/*     */   {
/* 432 */     return this.lastMessage;
/*     */   }
/*     */   
/*     */   public void setLastMessage(String lastMessage)
/*     */   {
/* 437 */     this.lastMessage = lastMessage;
/*     */   }
/*     */   
/*     */   public List<Integer> getGroups()
/*     */   {
/* 442 */     return this.groups;
/*     */   }
/*     */   
/*     */   public int getNotifCooldown()
/*     */   {
/* 447 */     return this.notifCooldown;
/*     */   }
/*     */   
/*     */   public void setNotifCooldown(int notifCooldown)
/*     */   {
/* 452 */     this.notifCooldown = notifCooldown;
/*     */   }
/*     */   
/*     */   public int getLastRoomId()
/*     */   {
/* 457 */     return this.lastRoomId;
/*     */   }
/*     */   
/*     */   public void setLastRoomId(int lastRoomId)
/*     */   {
/* 462 */     this.lastRoomId = lastRoomId;
/*     */   }
/*     */   
/*     */   public int getLastGift()
/*     */   {
/* 467 */     return this.lastGift;
/*     */   }
/*     */   
/*     */   public void setLastGift(int lastGift)
/*     */   {
/* 472 */     this.lastGift = lastGift;
/*     */   }
/*     */   
/*     */   public long getMessengerLastMessageTime()
/*     */   {
/* 477 */     return this.messengerLastMessageTime;
/*     */   }
/*     */   
/*     */   public void setMessengerLastMessageTime(long messengerLastMessageTime)
/*     */   {
/* 482 */     this.messengerLastMessageTime = messengerLastMessageTime;
/*     */   }
/*     */   
/*     */   public double getMessengerFloodTime()
/*     */   {
/* 487 */     return this.messengerFloodTime;
/*     */   }
/*     */   
/*     */   public void setMessengerFloodTime(double messengerFloodTime)
/*     */   {
/* 492 */     this.messengerFloodTime = messengerFloodTime;
/*     */   }
/*     */   
/*     */   public int getMessengerFloodFlag()
/*     */   {
/* 497 */     return this.messengerFloodFlag;
/*     */   }
/*     */   
/*     */   public void setMessengerFloodFlag(int messengerFloodFlag)
/*     */   {
/* 502 */     this.messengerFloodFlag = messengerFloodFlag;
/*     */   }
/*     */   
/*     */   public boolean isDeletingGroup()
/*     */   {
/* 507 */     return this.isDeletingGroup;
/*     */   }
/*     */   
/*     */   public void setDeletingGroup(boolean isDeletingGroup)
/*     */   {
/* 512 */     this.isDeletingGroup = isDeletingGroup;
/*     */   }
/*     */   
/*     */   public long getDeletingGroupAttempt()
/*     */   {
/* 517 */     return this.deletingGroupAttempt;
/*     */   }
/*     */   
/*     */   public void setDeletingGroupAttempt(long deletingGroupAttempt)
/*     */   {
/* 522 */     this.deletingGroupAttempt = deletingGroupAttempt;
/*     */   }
/*     */   
/*     */   public void bypassRoomAuth(boolean bypassRoomAuth)
/*     */   {
/* 527 */     this.bypassRoomAuth = bypassRoomAuth;
/*     */   }
/*     */   
/*     */   public boolean isBypassingRoomAuth()
/*     */   {
/* 532 */     return this.bypassRoomAuth;
/*     */   }
/*     */   
/*     */   public int getLastFigureUpdate()
/*     */   {
/* 537 */     return this.lastFigureUpdate;
/*     */   }
/*     */   
/*     */   public void setLastFigureUpdate(int lastFigureUpdate)
/*     */   {
/* 542 */     this.lastFigureUpdate = lastFigureUpdate;
/*     */   }
/*     */   
/*     */   public int getTeleportRoomId() {
/* 546 */     return this.teleportRoomId;
/*     */   }
/*     */   
/*     */   public void setTeleportRoomId(int teleportRoomId) {
/* 550 */     this.teleportRoomId = teleportRoomId;
/*     */   }
/*     */   
/*     */   public long getLastReward()
/*     */   {
/* 555 */     return this.lastReward;
/*     */   }
/*     */   
/*     */   public void setLastReward(long lastReward)
/*     */   {
/* 560 */     this.lastReward = lastReward;
/*     */   }
/*     */   
/*     */   public int getLastForumPost() {
/* 564 */     return this.lastForumPost;
/*     */   }
/*     */   
/*     */   public void setLastForumPost(int lastForumPost) {
/* 568 */     this.lastForumPost = lastForumPost;
/*     */   }
/*     */   
/* 571 */   private int roomQueueId = 0;
/*     */   
/* 573 */   private int spectatorRoomId = 0;
/*     */   
/*     */   public boolean hasQueued(int id) {
/* 576 */     if (this.roomQueueId == id) { return true;
/*     */     }
/* 578 */     return false;
/*     */   }
/*     */   
/*     */   public void setRoomQueueId(int id) {
/* 582 */     this.roomQueueId = id;
/*     */   }
/*     */   
/*     */   public boolean isSpectating(int id) {
/* 586 */     if (this.spectatorRoomId == id) {
/* 587 */       return true;
/*     */     }
/*     */     
/* 590 */     return false;
/*     */   }
/*     */   
/*     */   public void setSpectatorRoomId(int id) {
/* 594 */     this.spectatorRoomId = id;
/*     */   }
/*     */   
/*     */   public int getLastRoomCreated() {
/* 598 */     return this.lastRoomCreated;
/*     */   }
/*     */   
/*     */   public void setLastRoomCreated(int lastRoomCreated) {
/* 602 */     this.lastRoomCreated = lastRoomCreated;
/*     */   }
/*     */   
/*     */   public long getLastRoomRequest() {
/* 606 */     return this.lastRoomRequest;
/*     */   }
/*     */   
/*     */   public void setLastRoomRequest(long lastRoomRequest) {
/* 610 */     this.lastRoomRequest = lastRoomRequest;
/*     */   }
/*     */   
/*     */   public long getLastBadgeUpdate() {
/* 614 */     return this.lastBadgeUpdate;
/*     */   }
/*     */   
/*     */   public void setLastBadgeUpdate(long lastBadgeUpdate) {
/* 618 */     this.lastBadgeUpdate = lastBadgeUpdate;
/*     */   }
/*     */   
/*     */   public boolean isInvisible() {
/* 622 */     return this.invisible;
/*     */   }
/*     */   
/*     */   public void setInvisible(boolean invisible) {
/* 626 */     this.invisible = invisible;
/*     */   }
/*     */   
/*     */   public int getLastTradePlayer() {
/* 630 */     return this.lastTradePlayer;
/*     */   }
/*     */   
/*     */   public void setLastTradePlayer(int lastTradePlayer) {
/* 634 */     this.lastTradePlayer = lastTradePlayer;
/*     */   }
/*     */   
/*     */   public long getLastTradeTime() {
/* 638 */     return this.lastTradeTime;
/*     */   }
/*     */   
/*     */   public void setLastTradeTime(long lastTradeTime) {
/* 642 */     this.lastTradeTime = lastTradeTime;
/*     */   }
/*     */   
/*     */   public int getLastTradeFlag() {
/* 646 */     return this.lastTradeFlag;
/*     */   }
/*     */   
/*     */   public void setLastTradeFlag(int lastTradeFlag) {
/* 650 */     this.lastTradeFlag = lastTradeFlag;
/*     */   }
/*     */   
/*     */   public int getLastTradeFlood() {
/* 654 */     return this.lastTradeFlood;
/*     */   }
/*     */   
/*     */   public void setLastTradeFlood(int lastTradeFlood) {
/* 658 */     this.lastTradeFlood = lastTradeFlood;
/*     */   }
/*     */   
/*     */   public PlayerFreeze getFreeze() {
/* 662 */     return this.freeze;
/*     */   }
/*     */   
/*     */   public EffectComponent getEffectComponent() {
/* 666 */     return this.effect;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\types\Player.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */