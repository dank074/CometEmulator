package com.habboproject.server.game.players.types;

public abstract interface PlayerComponent
  extends com.habboproject.server.api.game.players.data.PlayerComponent
{}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\types\PlayerComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */