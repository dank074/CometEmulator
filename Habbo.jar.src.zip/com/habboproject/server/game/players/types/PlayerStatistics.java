/*     */ package com.habboproject.server.game.players.types;
/*     */ 
/*     */ import com.habboproject.server.api.game.players.data.IPlayerStatistics;
/*     */ import com.habboproject.server.storage.queries.player.PlayerDao;
/*     */ import com.habboproject.server.storage.queries.player.messenger.MessengerDao;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerStatistics
/*     */   implements IPlayerStatistics
/*     */ {
/*     */   private int playerId;
/*     */   private int achievementPoints;
/*     */   private int dailyRespects;
/*     */   private int respectPoints;
/*     */   private int scratches;
/*     */   private int helpTickets;
/*     */   private int abusiveHelpTickets;
/*     */   private int cautions;
/*     */   private int bans;
/*     */   private String lastTotemEffect;
/*     */   
/*     */   public PlayerStatistics(ResultSet data, boolean isLogin)
/*     */     throws SQLException
/*     */   {
/*  28 */     if (isLogin) {
/*  29 */       this.playerId = data.getInt("playerId");
/*  30 */       this.achievementPoints = data.getInt("playerStats_achievementPoints");
/*  31 */       this.dailyRespects = data.getInt("playerStats_dailyRespects");
/*  32 */       this.respectPoints = data.getInt("playerStats_totalRespectPoints");
/*  33 */       this.helpTickets = data.getInt("playerStats_helpTickets");
/*  34 */       this.abusiveHelpTickets = data.getInt("playerStats_helpTicketsAbusive");
/*  35 */       this.cautions = data.getInt("playerStats_cautions");
/*  36 */       this.bans = data.getInt("playerStats_bans");
/*  37 */       this.scratches = data.getInt("playerStats_scratches");
/*  38 */       this.lastTotemEffect = data.getString("playerStats_lastTotemEffect");
/*     */     } else {
/*  40 */       this.playerId = data.getInt("player_id");
/*  41 */       this.achievementPoints = data.getInt("achievement_score");
/*  42 */       this.dailyRespects = data.getInt("daily_respects");
/*  43 */       this.respectPoints = data.getInt("total_respect_points");
/*  44 */       this.helpTickets = data.getInt("help_tickets");
/*  45 */       this.abusiveHelpTickets = data.getInt("help_tickets_abusive");
/*  46 */       this.cautions = data.getInt("cautions");
/*  47 */       this.bans = data.getInt("bans");
/*  48 */       this.scratches = data.getInt("daily_scratches");
/*  49 */       this.lastTotemEffect = data.getString("last_totem_effect");
/*     */     }
/*     */   }
/*     */   
/*     */   public PlayerStatistics(int userId) {
/*  54 */     this.playerId = userId;
/*  55 */     this.achievementPoints = 0;
/*  56 */     this.respectPoints = 0;
/*  57 */     this.dailyRespects = 3;
/*  58 */     this.scratches = 3;
/*  59 */     this.helpTickets = 0;
/*  60 */     this.abusiveHelpTickets = 0;
/*  61 */     this.cautions = 0;
/*  62 */     this.bans = 0;
/*  63 */     this.lastTotemEffect = "";
/*     */   }
/*     */   
/*     */   public void save() {
/*  67 */     PlayerDao.updatePlayerStatistics(this);
/*     */   }
/*     */   
/*     */   public void incrementAchievementPoints(int amount) {
/*  71 */     this.achievementPoints += amount;
/*  72 */     save();
/*     */   }
/*     */   
/*     */   public void incrementCautions(int amount) {
/*  76 */     this.cautions += amount;
/*  77 */     save();
/*     */   }
/*     */   
/*     */   public void incrementRespectPoints(int amount) {
/*  81 */     this.respectPoints += amount;
/*  82 */     save();
/*     */   }
/*     */   
/*     */   public void decrementDailyRespects(int amount) {
/*  86 */     this.dailyRespects -= amount;
/*  87 */     save();
/*     */   }
/*     */   
/*     */   public void incrementBans(int amount) {
/*  91 */     this.bans += amount;
/*     */   }
/*     */   
/*     */   public void incrementAbusiveHelpTickets(int amount) {
/*  95 */     this.abusiveHelpTickets += amount;
/*     */   }
/*     */   
/*     */   public int getPlayerId() {
/*  99 */     return this.playerId;
/*     */   }
/*     */   
/*     */   public int getDailyRespects() {
/* 103 */     return this.dailyRespects;
/*     */   }
/*     */   
/*     */   public int getRespectPoints() {
/* 107 */     return this.respectPoints;
/*     */   }
/*     */   
/*     */   public int getAchievementPoints() {
/* 111 */     return this.achievementPoints;
/*     */   }
/*     */   
/*     */   public int getFriendCount() {
/* 115 */     return MessengerDao.getFriendCount(this.playerId);
/*     */   }
/*     */   
/*     */   public int getHelpTickets() {
/* 119 */     return this.helpTickets;
/*     */   }
/*     */   
/*     */   public void setHelpTickets(int helpTickets) {
/* 123 */     this.helpTickets = helpTickets;
/*     */   }
/*     */   
/*     */   public int getAbusiveHelpTickets() {
/* 127 */     return this.abusiveHelpTickets;
/*     */   }
/*     */   
/*     */   public void setAbusiveHelpTickets(int abusiveHelpTickets) {
/* 131 */     this.abusiveHelpTickets = abusiveHelpTickets;
/*     */   }
/*     */   
/*     */   public int getCautions() {
/* 135 */     return this.cautions;
/*     */   }
/*     */   
/*     */   public void setCautions(int cautions) {
/* 139 */     this.cautions = cautions;
/*     */   }
/*     */   
/*     */   public int getBans() {
/* 143 */     return this.bans;
/*     */   }
/*     */   
/*     */   public void setBans(int bans) {
/* 147 */     this.bans = bans;
/*     */   }
/*     */   
/*     */   public void setDailyRespects(int points)
/*     */   {
/* 152 */     this.dailyRespects = points;
/*     */   }
/*     */   
/*     */   public void setScratches(int scratches)
/*     */   {
/* 157 */     this.scratches = scratches;
/*     */   }
/*     */   
/*     */   public int getScratches()
/*     */   {
/* 162 */     return this.scratches;
/*     */   }
/*     */   
/*     */   public String getLastTotemEffect() {
/* 166 */     return this.lastTotemEffect;
/*     */   }
/*     */   
/*     */   public void setLastTotemEffect(String lastTotemEffect) {
/* 170 */     this.lastTotemEffect = lastTotemEffect;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\types\PlayerStatistics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */