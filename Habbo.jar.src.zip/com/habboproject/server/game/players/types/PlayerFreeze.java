/*     */ package com.habboproject.server.game.players.types;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*     */ import com.habboproject.server.game.rooms.types.components.games.freeze.FreezeGame;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ 
/*     */ public class PlayerFreeze
/*     */ {
/*     */   private final Player player;
/*     */   private int lives;
/*     */   private int balls;
/*     */   private int boost;
/*     */   private boolean explosionPowerUp;
/*     */   private boolean diagonalExplosion;
/*     */   private boolean horizontalExplosion;
/*     */   private boolean isFreezed;
/*     */   private boolean hasFreezed;
/*     */   private int freezeTime;
/*     */   private boolean isProtected;
/*     */   private int protectionTime;
/*     */   private boolean isDead;
/*     */   
/*     */   public PlayerFreeze(Player player)
/*     */   {
/*  29 */     this.player = player;
/*  30 */     reset();
/*     */   }
/*     */   
/*     */   public void reset() {
/*  34 */     this.lives = 3;
/*  35 */     this.balls = 1;
/*  36 */     this.boost = 2;
/*     */     
/*  38 */     this.explosionPowerUp = false;
/*  39 */     this.diagonalExplosion = false;
/*  40 */     this.horizontalExplosion = true;
/*  41 */     this.isFreezed = false;
/*  42 */     this.hasFreezed = false;
/*  43 */     this.freezeTime = 0;
/*  44 */     this.isProtected = false;
/*  45 */     this.protectionTime = 0;
/*  46 */     this.isDead = false;
/*     */   }
/*     */   
/*     */   public void cycle() {
/*  50 */     boolean needsUpdate = false;
/*  51 */     if (this.isFreezed) {
/*  52 */       this.freezeTime += 1;
/*  53 */       if (this.freezeTime > 10) {
/*  54 */         this.isFreezed = false;
/*  55 */         this.freezeTime = 0;
/*     */         
/*  57 */         if (!this.hasFreezed) {
/*  58 */           protect();
/*     */         } else {
/*  60 */           needsUpdate = true;
/*     */         }
/*     */         
/*  63 */         this.hasFreezed = true;
/*     */       }
/*     */     }
/*     */     
/*  67 */     if (this.isProtected) {
/*  68 */       this.protectionTime += 1;
/*  69 */       if (this.protectionTime > 10) {
/*  70 */         this.isProtected = false;
/*  71 */         this.protectionTime = 0;
/*  72 */         needsUpdate = true;
/*     */       }
/*     */     }
/*     */     
/*  76 */     if (needsUpdate) {
/*  77 */       updateMyself();
/*     */     }
/*     */   }
/*     */   
/*     */   public void increaseLife() {
/*  82 */     this.lives += 1;
/*  83 */     updateMyLife();
/*     */   }
/*     */   
/*     */   public void decreaseLife() {
/*  87 */     FreezeGame freeze = (FreezeGame)this.player.getEntity().getRoom().getGame().getInstance();
/*  88 */     if (freeze == null) {
/*  89 */       return;
/*     */     }
/*     */     
/*  92 */     this.lives -= 1;
/*     */     
/*  94 */     if (this.lives <= 0) {
/*  95 */       this.isDead = true;
/*     */       
/*  97 */       freeze.getGameComponent().decreaseTeamScore(this.player.getEntity().getGameTeam(), 20);
/*  98 */       freeze.getGameComponent().removeFromTeam(this.player.getEntity().getGameTeam(), Integer.valueOf(this.player.getEntity().getPlayerId()));
/*  99 */       freeze.playerDies(this.player.getEntity());
/* 100 */       return;
/*     */     }
/*     */     
/* 103 */     freeze.getGameComponent().decreaseTeamScore(this.player.getEntity().getGameTeam(), 10);
/*     */     
/* 105 */     updateMyself();
/* 106 */     updateMyLife();
/*     */   }
/*     */   
/*     */   public void updateMyLife() {
/* 110 */     this.player.getSession().send(new com.habboproject.server.network.messages.outgoing.room.freeze.UpdateFreezeLivesMessageComposer(this.player.getId(), this.lives));
/*     */   }
/*     */   
/*     */   public boolean canThrowBall() {
/* 114 */     return !this.isFreezed;
/*     */   }
/*     */   
/*     */   public void decreaseBoost() {
/* 118 */     if (this.boost > 0) {
/* 119 */       this.boost -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public void increaseBoost() {
/* 124 */     this.boost += 1;
/*     */   }
/*     */   
/*     */   public void increaseBall() {
/* 128 */     this.balls += 1;
/*     */   }
/*     */   
/*     */   public void decreaseBall() {
/* 132 */     if (this.balls > 0) {
/* 133 */       this.balls -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean canFreeze() {
/* 138 */     if ((this.isFreezed) || (this.isProtected)) {
/* 139 */       return false;
/*     */     }
/* 141 */     return true;
/*     */   }
/*     */   
/*     */   public void freeze() {
/* 145 */     if ((this.protectionTime > 0) || (this.freezeTime > 0)) {
/* 146 */       return;
/*     */     }
/*     */     
/* 149 */     this.isFreezed = true;
/* 150 */     this.freezeTime = 5;
/* 151 */     this.protectionTime = 0;
/*     */     
/* 153 */     decreaseBall();
/* 154 */     decreaseBoost();
/* 155 */     decreaseLife();
/*     */   }
/*     */   
/*     */   public void protect() {
/* 159 */     this.isProtected = true;
/* 160 */     updateMyself();
/*     */   }
/*     */   
/*     */   public void updateMyself() {
/* 164 */     if (this.isDead) {
/* 165 */       return;
/*     */     }
/*     */     
/* 168 */     this.player.getEntity().applyEffect(new PlayerEffect(needsEffect(), 0));
/*     */   }
/*     */   
/*     */   private int needsEffect() {
/* 172 */     if (this.isDead) {
/* 173 */       return 0;
/*     */     }
/*     */     
/* 176 */     if (this.isFreezed) {
/* 177 */       return 12;
/*     */     }
/*     */     
/* 180 */     int needsEffect = this.player.getEntity().getGameTeam().getFreezeEffect();
/* 181 */     if (this.isProtected) {
/* 182 */       needsEffect += 9;
/*     */     }
/*     */     
/* 185 */     return needsEffect;
/*     */   }
/*     */   
/*     */   public int getBoost() {
/* 189 */     if (this.explosionPowerUp) {
/* 190 */       this.explosionPowerUp = false;
/* 191 */       return 6;
/*     */     }
/*     */     
/* 194 */     return this.boost < 1 ? 1 : this.boost;
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/* 198 */     return this.player;
/*     */   }
/*     */   
/*     */   public int getLives() {
/* 202 */     return this.lives;
/*     */   }
/*     */   
/*     */   public void setExplosionPowerUp(boolean explosionPowerUp) {
/* 206 */     this.explosionPowerUp = explosionPowerUp;
/*     */   }
/*     */   
/*     */   public boolean diagonalExplosion() {
/* 210 */     return this.diagonalExplosion;
/*     */   }
/*     */   
/*     */   public void setDiagonalExplosion(boolean diagonalExplosion) {
/* 214 */     this.diagonalExplosion = diagonalExplosion;
/*     */   }
/*     */   
/*     */   public boolean horizontalExplosion() {
/* 218 */     return this.horizontalExplosion;
/*     */   }
/*     */   
/*     */   public void setHorizontalExplosion(boolean horizontalExplosion) {
/* 222 */     this.horizontalExplosion = horizontalExplosion;
/*     */   }
/*     */   
/*     */   public boolean isFreezed() {
/* 226 */     return this.isFreezed;
/*     */   }
/*     */   
/*     */   public void setFreezed(boolean freezed) {
/* 230 */     this.isFreezed = freezed;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\types\PlayerFreeze.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */