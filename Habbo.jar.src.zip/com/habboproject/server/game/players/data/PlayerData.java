/*     */ package com.habboproject.server.game.players.data;
/*     */ 
/*     */ import com.habboproject.server.api.game.players.data.IPlayerData;
/*     */ import com.habboproject.server.game.utilities.validator.PlayerFigureValidator;
/*     */ import com.habboproject.server.threads.CometThread;
/*     */ import com.habboproject.server.threads.ThreadManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerData
/*     */   implements PlayerAvatar, IPlayerData, CometThread
/*     */ {
/*     */   public static final String DEFAULT_FIGURE = "hr-100-61.hd-180-2.sh-290-91.ch-210-66.lg-270-82";
/*     */   private int id;
/*     */   private int rank;
/*     */   private String username;
/*     */   private String motto;
/*     */   private String figure;
/*     */   private String gender;
/*     */   private String email;
/*     */   private String ipAddress;
/*     */   private int credits;
/*     */   private int vipPoints;
/*     */   private int activityPoints;
/*     */   private String regDate;
/*     */   private int lastVisit;
/*     */   private int regTimestamp;
/*     */   private int achievementPoints;
/*     */   private int favouriteGroup;
/*     */   private String temporaryFigure;
/*     */   private boolean vip;
/*     */   private int questId;
/*     */   private int forumPosts;
/*     */   private String newbieStep;
/*     */   
/*     */   public PlayerData(int id, String username, String motto, String figure, String gender, String email, int rank, int credits, int vipPoints, int activityPoints, String reg, int lastVisit, boolean vip, int achievementPoints, int regTimestamp, int favouriteGroup, String ipAddress, int questId, int forumPosts, String newbieStep)
/*     */   {
/*  53 */     this.id = id;
/*  54 */     this.username = username;
/*  55 */     this.motto = motto;
/*  56 */     this.figure = figure;
/*  57 */     this.rank = rank;
/*  58 */     this.credits = credits;
/*  59 */     this.vipPoints = vipPoints;
/*  60 */     this.activityPoints = activityPoints;
/*  61 */     this.gender = gender;
/*  62 */     this.vip = vip;
/*  63 */     this.achievementPoints = achievementPoints;
/*  64 */     this.email = email;
/*  65 */     this.regDate = reg;
/*  66 */     this.lastVisit = lastVisit;
/*  67 */     this.regTimestamp = regTimestamp;
/*  68 */     this.favouriteGroup = favouriteGroup;
/*  69 */     this.ipAddress = ipAddress;
/*  70 */     this.questId = questId;
/*  71 */     this.forumPosts = forumPosts;
/*  72 */     this.newbieStep = newbieStep;
/*     */     
/*  74 */     if ((this.figure != null) && 
/*  75 */       (!PlayerFigureValidator.isValidFigureCode(this.figure, this.gender.toLowerCase()))) {
/*  76 */       this.figure = "hr-100-61.hd-180-2.sh-290-91.ch-210-66.lg-270-82";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PlayerData(ResultSet data)
/*     */     throws SQLException
/*     */   {
/* 101 */     this(data.getInt("playerId"), data.getString("playerData_username"), data.getString("playerData_motto"), data.getString("playerData_figure"), data.getString("playerData_gender"), data.getString("playerData_email"), data.getInt("playerData_rank"), data.getInt("playerData_credits"), data.getInt("playerData_vipPoints"), data.getInt("playerData_activityPoints"), data.getString("playerData_regDate"), data.getInt("playerData_lastOnline"), data.getString("playerData_vip").equals("1"), data.getInt("playerData_achievementPoints"), data.getInt("playerData_regTimestamp"), data.getInt("playerData_favouriteGroup"), data.getString("playerData_lastIp"), data.getInt("playerData_questId"), data.getInt("playerData_forumPosts"), data.getString("playerData_newbieStep"));
/*     */   }
/*     */   
/*     */   public void save()
/*     */   {
/* 106 */     ThreadManager.getInstance().execute(this);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void run()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_1
/*     */     //   2: aconst_null
/*     */     //   3: astore_2
/*     */     //   4: invokestatic 179	com/habboproject/server/storage/SqlHelper:getConnection	()Ljava/sql/Connection;
/*     */     //   7: astore_1
/*     */     //   8: ldc -71
/*     */     //   10: aload_1
/*     */     //   11: invokestatic 187	com/habboproject/server/storage/SqlHelper:prepare	(Ljava/lang/String;Ljava/sql/Connection;)Ljava/sql/PreparedStatement;
/*     */     //   14: astore_2
/*     */     //   15: aload_2
/*     */     //   16: iconst_1
/*     */     //   17: aload_0
/*     */     //   18: getfield 47	com/habboproject/server/game/players/data/PlayerData:username	Ljava/lang/String;
/*     */     //   21: invokeinterface 191 3 0
/*     */     //   26: aload_2
/*     */     //   27: iconst_2
/*     */     //   28: aload_0
/*     */     //   29: getfield 49	com/habboproject/server/game/players/data/PlayerData:motto	Ljava/lang/String;
/*     */     //   32: invokeinterface 191 3 0
/*     */     //   37: aload_2
/*     */     //   38: iconst_3
/*     */     //   39: aload_0
/*     */     //   40: getfield 51	com/habboproject/server/game/players/data/PlayerData:figure	Ljava/lang/String;
/*     */     //   43: invokeinterface 191 3 0
/*     */     //   48: aload_2
/*     */     //   49: iconst_4
/*     */     //   50: aload_0
/*     */     //   51: getfield 55	com/habboproject/server/game/players/data/PlayerData:credits	I
/*     */     //   54: invokeinterface 197 3 0
/*     */     //   59: aload_2
/*     */     //   60: iconst_5
/*     */     //   61: aload_0
/*     */     //   62: getfield 57	com/habboproject/server/game/players/data/PlayerData:vipPoints	I
/*     */     //   65: invokeinterface 197 3 0
/*     */     //   70: aload_2
/*     */     //   71: bipush 6
/*     */     //   73: aload_0
/*     */     //   74: getfield 61	com/habboproject/server/game/players/data/PlayerData:gender	Ljava/lang/String;
/*     */     //   77: invokeinterface 191 3 0
/*     */     //   82: aload_2
/*     */     //   83: bipush 7
/*     */     //   85: aload_0
/*     */     //   86: getfield 75	com/habboproject/server/game/players/data/PlayerData:favouriteGroup	I
/*     */     //   89: invokeinterface 197 3 0
/*     */     //   94: aload_2
/*     */     //   95: bipush 8
/*     */     //   97: aload_0
/*     */     //   98: getfield 59	com/habboproject/server/game/players/data/PlayerData:activityPoints	I
/*     */     //   101: invokeinterface 197 3 0
/*     */     //   106: aload_2
/*     */     //   107: bipush 9
/*     */     //   109: aload_0
/*     */     //   110: getfield 79	com/habboproject/server/game/players/data/PlayerData:questId	I
/*     */     //   113: invokeinterface 197 3 0
/*     */     //   118: aload_2
/*     */     //   119: bipush 10
/*     */     //   121: aload_0
/*     */     //   122: getfield 65	com/habboproject/server/game/players/data/PlayerData:achievementPoints	I
/*     */     //   125: invokeinterface 197 3 0
/*     */     //   130: aload_2
/*     */     //   131: bipush 11
/*     */     //   133: aload_0
/*     */     //   134: getfield 81	com/habboproject/server/game/players/data/PlayerData:forumPosts	I
/*     */     //   137: invokeinterface 197 3 0
/*     */     //   142: aload_2
/*     */     //   143: bipush 12
/*     */     //   145: aload_0
/*     */     //   146: getfield 83	com/habboproject/server/game/players/data/PlayerData:newbieStep	Ljava/lang/String;
/*     */     //   149: invokeinterface 191 3 0
/*     */     //   154: aload_2
/*     */     //   155: bipush 13
/*     */     //   157: aload_0
/*     */     //   158: getfield 45	com/habboproject/server/game/players/data/PlayerData:id	I
/*     */     //   161: invokeinterface 197 3 0
/*     */     //   166: aload_2
/*     */     //   167: invokeinterface 201 1 0
/*     */     //   172: pop
/*     */     //   173: goto +32 -> 205
/*     */     //   176: astore_3
/*     */     //   177: aload_3
/*     */     //   178: invokestatic 205	com/habboproject/server/storage/SqlHelper:handleSqlException	(Ljava/sql/SQLException;)V
/*     */     //   181: aload_2
/*     */     //   182: invokestatic 209	com/habboproject/server/storage/SqlHelper:closeSilently	(Ljava/sql/PreparedStatement;)V
/*     */     //   185: aload_1
/*     */     //   186: invokestatic 213	com/habboproject/server/storage/SqlHelper:closeSilently	(Ljava/sql/Connection;)V
/*     */     //   189: goto +24 -> 213
/*     */     //   192: astore 4
/*     */     //   194: aload_2
/*     */     //   195: invokestatic 209	com/habboproject/server/storage/SqlHelper:closeSilently	(Ljava/sql/PreparedStatement;)V
/*     */     //   198: aload_1
/*     */     //   199: invokestatic 213	com/habboproject/server/storage/SqlHelper:closeSilently	(Ljava/sql/Connection;)V
/*     */     //   202: aload 4
/*     */     //   204: athrow
/*     */     //   205: aload_2
/*     */     //   206: invokestatic 209	com/habboproject/server/storage/SqlHelper:closeSilently	(Ljava/sql/PreparedStatement;)V
/*     */     //   209: aload_1
/*     */     //   210: invokestatic 213	com/habboproject/server/storage/SqlHelper:closeSilently	(Ljava/sql/Connection;)V
/*     */     //   213: return
/*     */     // Line number table:
/*     */     //   Java source line #111	-> byte code offset #0
/*     */     //   Java source line #112	-> byte code offset #2
/*     */     //   Java source line #114	-> byte code offset #4
/*     */     //   Java source line #116	-> byte code offset #8
/*     */     //   Java source line #122	-> byte code offset #10
/*     */     //   Java source line #116	-> byte code offset #11
/*     */     //   Java source line #124	-> byte code offset #15
/*     */     //   Java source line #125	-> byte code offset #26
/*     */     //   Java source line #126	-> byte code offset #37
/*     */     //   Java source line #127	-> byte code offset #48
/*     */     //   Java source line #128	-> byte code offset #59
/*     */     //   Java source line #129	-> byte code offset #70
/*     */     //   Java source line #130	-> byte code offset #82
/*     */     //   Java source line #131	-> byte code offset #94
/*     */     //   Java source line #132	-> byte code offset #106
/*     */     //   Java source line #133	-> byte code offset #118
/*     */     //   Java source line #134	-> byte code offset #130
/*     */     //   Java source line #135	-> byte code offset #142
/*     */     //   Java source line #136	-> byte code offset #154
/*     */     //   Java source line #138	-> byte code offset #166
/*     */     //   Java source line #140	-> byte code offset #173
/*     */     //   Java source line #141	-> byte code offset #177
/*     */     //   Java source line #143	-> byte code offset #181
/*     */     //   Java source line #144	-> byte code offset #185
/*     */     //   Java source line #142	-> byte code offset #192
/*     */     //   Java source line #143	-> byte code offset #194
/*     */     //   Java source line #144	-> byte code offset #198
/*     */     //   Java source line #145	-> byte code offset #202
/*     */     //   Java source line #143	-> byte code offset #205
/*     */     //   Java source line #144	-> byte code offset #209
/*     */     //   Java source line #146	-> byte code offset #213
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	214	0	this	PlayerData
/*     */     //   1	209	1	sqlConnection	java.sql.Connection
/*     */     //   3	203	2	preparedStatement	java.sql.PreparedStatement
/*     */     //   176	2	3	e	SQLException
/*     */     //   192	11	4	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	173	176	java/sql/SQLException
/*     */     //   4	181	192	finally
/*     */   }
/*     */   
/*     */   public void decreaseCredits(int amount)
/*     */   {
/* 149 */     this.credits -= amount;
/*     */   }
/*     */   
/*     */   public void increaseCredits(int amount) {
/* 153 */     this.credits += amount;
/*     */   }
/*     */   
/*     */   public void decreasePoints(int points) {
/* 157 */     this.vipPoints -= points;
/*     */   }
/*     */   
/*     */   public void increasePoints(int points) {
/* 161 */     this.vipPoints += points;
/*     */   }
/*     */   
/*     */   public void increaseActivityPoints(int points) {
/* 165 */     this.activityPoints += points;
/*     */   }
/*     */   
/*     */   public void decreaseActivityPoints(int points) {
/* 169 */     this.activityPoints -= points;
/*     */   }
/*     */   
/*     */   public void increaseAchievementPoints(int points) {
/* 173 */     this.achievementPoints += points;
/*     */   }
/*     */   
/*     */   public void setPoints(int points) {
/* 177 */     this.vipPoints = points;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 181 */     return this.id;
/*     */   }
/*     */   
/*     */   public int getRank() {
/* 185 */     return this.rank;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 189 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 193 */     this.username = username;
/*     */   }
/*     */   
/*     */   public int getAchievementPoints() {
/* 197 */     return this.achievementPoints;
/*     */   }
/*     */   
/*     */   public String getMotto() {
/* 201 */     return this.motto;
/*     */   }
/*     */   
/*     */   public void setMotto(String motto) {
/* 205 */     this.motto = motto;
/*     */   }
/*     */   
/*     */   public String getFigure() {
/* 209 */     return this.figure;
/*     */   }
/*     */   
/*     */   public String getGender() {
/* 213 */     return this.gender;
/*     */   }
/*     */   
/*     */   public int getCredits() {
/* 217 */     return this.credits;
/*     */   }
/*     */   
/*     */   public void setCredits(int credits) {
/* 221 */     this.credits = credits;
/*     */   }
/*     */   
/*     */   public int getVipPoints() {
/* 225 */     return this.vipPoints;
/*     */   }
/*     */   
/*     */   public int getLastVisit() {
/* 229 */     return this.lastVisit;
/*     */   }
/*     */   
/*     */   public String getRegDate() {
/* 233 */     return this.regDate;
/*     */   }
/*     */   
/*     */   public boolean isVip() {
/* 237 */     return this.vip;
/*     */   }
/*     */   
/*     */   public void setVip(boolean vip) {
/* 241 */     this.vip = vip;
/*     */   }
/*     */   
/*     */   public void setLastVisit(long time) {
/* 245 */     this.lastVisit = ((int)time);
/*     */   }
/*     */   
/*     */   public void setFigure(String figure) {
/* 249 */     this.figure = figure;
/*     */   }
/*     */   
/*     */   public void setGender(String gender) {
/* 253 */     this.gender = gender;
/*     */   }
/*     */   
/*     */   public int getRegTimestamp() {
/* 257 */     return this.regTimestamp;
/*     */   }
/*     */   
/*     */   public void setRegTimestamp(int regTimestamp) {
/* 261 */     this.regTimestamp = regTimestamp;
/*     */   }
/*     */   
/*     */   public String getEmail() {
/* 265 */     return this.email;
/*     */   }
/*     */   
/*     */   public void setEmail(String email) {
/* 269 */     this.email = email;
/*     */   }
/*     */   
/*     */   public int getFavouriteGroup() {
/* 273 */     return this.favouriteGroup;
/*     */   }
/*     */   
/*     */   public void setFavouriteGroup(int favouriteGroup) {
/* 277 */     this.favouriteGroup = favouriteGroup;
/*     */   }
/*     */   
/*     */   public String getIpAddress() {
/* 281 */     return this.ipAddress;
/*     */   }
/*     */   
/*     */   public void setIpAddress(String ipAddress) {
/* 285 */     this.ipAddress = ipAddress;
/*     */   }
/*     */   
/*     */   public int getActivityPoints() {
/* 289 */     return this.activityPoints;
/*     */   }
/*     */   
/*     */   public void setActivityPoints(int activityPoints) {
/* 293 */     this.activityPoints = activityPoints;
/*     */   }
/*     */   
/*     */   public void setVipPoints(int vipPoints) {
/* 297 */     this.vipPoints = vipPoints;
/*     */   }
/*     */   
/*     */   public void setRank(int rank) {
/* 301 */     this.rank = rank;
/*     */   }
/*     */   
/*     */   public String getTemporaryFigure() {
/* 305 */     return this.temporaryFigure;
/*     */   }
/*     */   
/*     */   public void setTemporaryFigure(String temporaryFigure) {
/* 309 */     this.temporaryFigure = temporaryFigure;
/*     */   }
/*     */   
/*     */   public int getQuestId() {
/* 313 */     return this.questId;
/*     */   }
/*     */   
/*     */   public void setQuestId(int questId) {
/* 317 */     this.questId = questId;
/*     */   }
/*     */   
/*     */   public void setAchievementPoints(int achievementPoints) {
/* 321 */     this.achievementPoints = achievementPoints;
/*     */   }
/*     */   
/*     */   public int getForumPosts()
/*     */   {
/* 326 */     return this.forumPosts;
/*     */   }
/*     */   
/*     */   public void increaseForumPosts() {
/* 330 */     this.forumPosts += 1;
/*     */   }
/*     */   
/*     */   public String getNewbieStep() {
/* 334 */     return this.newbieStep;
/*     */   }
/*     */   
/*     */   public void setNewbieStep(String newbieStep) {
/* 338 */     this.newbieStep = newbieStep;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\data\PlayerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */