package com.habboproject.server.game.players.data;

public abstract interface PlayerAvatar
{
  public static final byte USERNAME_FIGURE = 0;
  public static final byte USERNAME_FIGURE_MOTTO = 1;
  
  public abstract int getId();
  
  public abstract String getUsername();
  
  public abstract void setUsername(String paramString);
  
  public abstract String getFigure();
  
  public abstract void setFigure(String paramString);
  
  public abstract String getMotto();
  
  public abstract void setMotto(String paramString);
  
  public abstract int getForumPosts();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\data\PlayerAvatar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */