/*    */ package com.habboproject.server.game.players.data;
/*    */ 
/*    */ import com.habboproject.server.game.utilities.validator.PlayerFigureValidator;
/*    */ 
/*    */ public class PlayerAvatarData implements PlayerAvatar {
/*    */   private int id;
/*    */   private String username;
/*    */   private String figure;
/*    */   private String motto;
/*    */   private int forumPosts;
/*    */   
/*    */   public PlayerAvatarData(int id, String username, String figure, String motto, int forumPosts) {
/* 13 */     this.id = id;
/* 14 */     this.username = username;
/* 15 */     this.figure = figure;
/* 16 */     this.motto = motto;
/* 17 */     this.forumPosts = forumPosts;
/*    */     
/* 19 */     if (figure == null) { return;
/*    */     }
/* 21 */     if (!PlayerFigureValidator.isValidFigureCode(this.figure, "m")) {
/* 22 */       this.figure = "hr-100-61.hd-180-2.sh-290-91.ch-210-66.lg-270-82";
/*    */     }
/*    */   }
/*    */   
/*    */   public PlayerAvatarData(int id, String username, String figure, int forumPosts) {
/* 27 */     this(id, username, figure, null, forumPosts);
/*    */   }
/*    */   
/*    */   public int getId()
/*    */   {
/* 32 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(int id) {
/* 36 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getUsername()
/*    */   {
/* 41 */     return this.username;
/*    */   }
/*    */   
/*    */   public void setUsername(String username)
/*    */   {
/* 46 */     this.username = username;
/*    */   }
/*    */   
/*    */   public String getFigure()
/*    */   {
/* 51 */     return this.figure;
/*    */   }
/*    */   
/*    */   public void setFigure(String figure)
/*    */   {
/* 56 */     this.figure = figure;
/*    */   }
/*    */   
/*    */   public String getMotto()
/*    */   {
/* 61 */     return this.motto;
/*    */   }
/*    */   
/*    */   public void setMotto(String motto)
/*    */   {
/* 66 */     this.motto = motto;
/*    */   }
/*    */   
/*    */   public int getForumPosts()
/*    */   {
/* 71 */     return this.forumPosts;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\data\PlayerAvatarData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */