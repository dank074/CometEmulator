/*    */ package com.habboproject.server.game.players.login.queue;
/*    */ 
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ 
/*    */ public class PlayerLoginQueueEntry
/*    */ {
/*    */   private Session connectingClient;
/*    */   private int playerId;
/*    */   private String ssoTicket;
/*    */   
/*    */   public PlayerLoginQueueEntry(Session client, int id, String sso)
/*    */   {
/* 13 */     this.connectingClient = client;
/*    */     
/* 15 */     this.playerId = id;
/* 16 */     this.ssoTicket = sso;
/*    */   }
/*    */   
/*    */   public Session getClient() {
/* 20 */     return this.connectingClient;
/*    */   }
/*    */   
/*    */   public int getPlayerId() {
/* 24 */     return this.playerId;
/*    */   }
/*    */   
/*    */   public String getSsoTicket() {
/* 28 */     return this.ssoTicket;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\login\queue\PlayerLoginQueueEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */