/*    */ package com.habboproject.server.game.players.login.queue;
/*    */ 
/*    */ import com.habboproject.server.threads.ThreadManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticPlayerQueue
/*    */ {
/*    */   private static PlayerLoginQueueManager mgr;
/*    */   
/*    */   public static void init(ThreadManager threadManagement)
/*    */   {
/* 14 */     mgr = new PlayerLoginQueueManager(true, threadManagement);
/*    */   }
/*    */   
/*    */   public static PlayerLoginQueueManager getQueueManager() {
/* 18 */     return mgr;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\login\queue\StaticPlayerQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */