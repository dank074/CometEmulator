/*    */ package com.habboproject.server.game.players.login.queue;
/*    */ 
/*    */ import com.habboproject.server.threads.CometThread;
/*    */ import java.util.ArrayDeque;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class PlayerLoginQueue
/*    */   implements CometThread
/*    */ {
/* 10 */   private final int MAX_QUEUE_SIZE = 1000;
/* 11 */   private final ArrayDeque<PlayerLoginQueueEntry> queue = new ArrayDeque();
/*    */   
/* 13 */   private Logger log = Logger.getLogger(PlayerLoginQueue.class.getName());
/*    */   
/*    */   public void run()
/*    */   {
/* 17 */     if (this.queue.isEmpty()) {
/* 18 */       return;
/*    */     }
/* 20 */     PlayerLoginQueueEntry entry = (PlayerLoginQueueEntry)this.queue.pop();
/* 21 */     processQueueItem(entry);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void processQueueItem(PlayerLoginQueueEntry entry) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean queue(PlayerLoginQueueEntry entry)
/*    */   {
/* 76 */     if (this.queue.size() >= 1000) {
/* 77 */       this.log.warn("PlayerLoginQueue size reached max size of 1000");
/* 78 */       return false;
/*    */     }
/*    */     
/* 81 */     return this.queue.add(entry);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\login\queue\PlayerLoginQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */