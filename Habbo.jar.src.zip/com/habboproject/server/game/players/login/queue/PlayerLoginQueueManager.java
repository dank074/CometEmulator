/*    */ package com.habboproject.server.game.players.login.queue;
/*    */ 
/*    */ import com.habboproject.server.threads.ThreadManager;
/*    */ import java.util.concurrent.ScheduledFuture;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ 
/*    */ public class PlayerLoginQueueManager
/*    */ {
/*    */   private static final int WAIT_TIME = 100;
/*    */   private final PlayerLoginQueue loginQueue;
/*    */   private ScheduledFuture future;
/*    */   
/*    */   public PlayerLoginQueueManager(boolean autoStart, ThreadManager threadMgr)
/*    */   {
/* 16 */     this.loginQueue = new PlayerLoginQueue();
/* 17 */     if (autoStart) {
/* 18 */       start(threadMgr);
/*    */     }
/*    */   }
/*    */   
/*    */   private void start(ThreadManager threadMgr) {
/* 23 */     if (this.future != null) {
/* 24 */       return;
/*    */     }
/* 26 */     this.future = threadMgr.executePeriodic(this.loginQueue, 100L, 100L, TimeUnit.MILLISECONDS);
/*    */   }
/*    */   
/*    */   public boolean queue(PlayerLoginQueueEntry entry) {
/* 30 */     return this.loginQueue.queue(entry);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\login\queue\PlayerLoginQueueManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */