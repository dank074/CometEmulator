package com.habboproject.server.game.players.login.exceptions;

public class InvalidUniqueIDException
  extends PlayerLoginException
{}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\login\exceptions\InvalidUniqueIDException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */