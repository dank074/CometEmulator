package com.habboproject.server.game.players.login.exceptions;

public abstract class PlayerLoginException
  extends Exception
{}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\login\exceptions\PlayerLoginException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */