/*     */ package com.habboproject.server.game.players.components;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.config.Configuration;
/*     */ import com.habboproject.server.game.players.PlayerManager;
/*     */ import com.habboproject.server.game.players.components.types.messenger.MessengerFriend;
/*     */ import com.habboproject.server.game.players.components.types.messenger.MessengerSearchResult;
/*     */ import com.habboproject.server.game.players.data.PlayerAvatar;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.players.types.PlayerComponent;
/*     */ import com.habboproject.server.game.players.types.PlayerSettings;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.messages.composers.MessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.messenger.MessengerSearchResultsMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.messenger.UpdateFriendStateMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.notification.NotificationMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.network.sessions.SessionManager;
/*     */ import com.habboproject.server.storage.queries.player.messenger.MessengerDao;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MessengerComponent implements PlayerComponent
/*     */ {
/*     */   private Player player;
/*     */   private Map<Integer, MessengerFriend> friends;
/*     */   private List<Integer> requests;
/*     */   
/*     */   public MessengerComponent(Player player)
/*     */   {
/*  34 */     this.player = player;
/*     */     try
/*     */     {
/*  37 */       this.friends = MessengerDao.getFriendsByPlayerId(player.getId());
/*     */     } catch (Exception e) {
/*  39 */       Logger.getLogger(MessengerComponent.class.getName()).error("Error while loading messenger friends", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void dispose() {
/*  44 */     sendStatus(false);
/*  45 */     sendStatus(false, false);
/*     */     
/*  47 */     this.requests.clear();
/*  48 */     this.friends.clear();
/*  49 */     this.requests = null;
/*  50 */     this.friends = null;
/*  51 */     this.player = null;
/*     */   }
/*     */   
/*     */   public MessageComposer search(String query) {
/*  55 */     List<MessengerSearchResult> currentFriends = Lists.newArrayList();
/*  56 */     List<MessengerSearchResult> otherPeople = Lists.newArrayList();
/*     */     try
/*     */     {
/*  59 */       for (MessengerSearchResult searchResult : com.habboproject.server.storage.queries.player.messenger.MessengerSearchDao.performSearch(query)) {
/*  60 */         if (getFriendById(searchResult.getId()) != null) {
/*  61 */           currentFriends.add(searchResult);
/*     */         } else {
/*  63 */           otherPeople.add(searchResult);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/*  67 */       this.player.getSession().getLogger().error("Error while searching for players", e);
/*     */     }
/*     */     
/*  70 */     return new MessengerSearchResultsMessageComposer(currentFriends, otherPeople);
/*     */   }
/*     */   
/*     */   public void addRequest(int playerId) {
/*  74 */     getRequests().add(Integer.valueOf(playerId));
/*     */   }
/*     */   
/*     */   public void addFriend(MessengerFriend friend) {
/*  78 */     getFriends().put(Integer.valueOf(friend.getUserId()), friend);
/*     */     
/*  80 */     getPlayer().getAchievements().progressAchievement(com.habboproject.server.game.achievements.types.AchievementType.FRIENDS_LIST, 1);
/*     */   }
/*     */   
/*     */   public void removeFriend(int userId) {
/*  84 */     if (!this.friends.containsKey(Integer.valueOf(userId))) {
/*  85 */       return;
/*     */     }
/*     */     
/*  88 */     this.friends.remove(Integer.valueOf(userId));
/*     */     
/*  90 */     MessengerDao.deleteFriendship(this.player.getId(), userId);
/*  91 */     this.player.getSession().send(new UpdateFriendStateMessageComposer(-1, userId));
/*     */   }
/*     */   
/*     */   public Integer getRequestBySender(int sender) {
/*  95 */     for (Integer request : this.requests) {
/*  96 */       if (request.intValue() == sender) {
/*  97 */         return request;
/*     */       }
/*     */     }
/*     */     
/* 101 */     return null;
/*     */   }
/*     */   
/*     */   public void broadcast(MessageComposer msg) {
/* 105 */     for (MessengerFriend friend : getFriends().values())
/* 106 */       if ((friend.isOnline()) && (friend.getUserId() != getPlayer().getId()))
/*     */       {
/*     */ 
/*     */ 
/* 110 */         Session session = NetworkManager.getInstance().getSessions().getByPlayerId(friend.getUserId());
/*     */         
/* 112 */         if (session != null)
/* 113 */           session.send(msg);
/*     */       }
/*     */   }
/*     */   
/*     */   public void broadcast(List<Integer> friends, MessageComposer msg) {
/* 118 */     for (Iterator localIterator = friends.iterator(); localIterator.hasNext();) { int friendId = ((Integer)localIterator.next()).intValue();
/* 119 */       if ((friendId != this.player.getId()) && (this.friends.containsKey(Integer.valueOf(friendId))) && (((MessengerFriend)this.friends.get(Integer.valueOf(friendId))).isOnline()))
/*     */       {
/*     */ 
/*     */ 
/* 123 */         MessengerFriend friend = (MessengerFriend)this.friends.get(Integer.valueOf(friendId));
/*     */         
/* 125 */         if ((friend.isOnline()) && (friend.getUserId() != getPlayer().getId()))
/*     */         {
/*     */ 
/*     */ 
/* 129 */           Session session = NetworkManager.getInstance().getSessions().getByPlayerId(friend.getUserId());
/*     */           
/* 131 */           if ((session != null) && (session.getPlayer() != null))
/* 132 */             session.send(msg);
/*     */         }
/*     */       }
/*     */     } }
/*     */   
/* 137 */   public boolean hasRequestFrom(int playerId) { if (this.requests == null) { return false;
/*     */     }
/* 139 */     for (Integer messengerRequest : this.requests) {
/* 140 */       if (messengerRequest.intValue() == playerId) {
/* 141 */         return true;
/*     */       }
/*     */     }
/* 144 */     return false;
/*     */   }
/*     */   
/*     */   public List<PlayerAvatar> getRequestAvatars() {
/* 148 */     List<PlayerAvatar> avatars = Lists.newArrayList();
/*     */     
/* 150 */     if (this.requests == null) {
/* 151 */       this.requests = MessengerDao.getRequestsByPlayerId(this.player.getId());
/*     */     }
/*     */     
/* 154 */     for (Iterator localIterator = this.requests.iterator(); localIterator.hasNext();) { int playerId = ((Integer)localIterator.next()).intValue();
/* 155 */       PlayerAvatar playerAvatar = PlayerManager.getInstance().getAvatarByPlayerId(playerId, (byte)0);
/*     */       
/* 157 */       if (playerAvatar != null) {
/* 158 */         avatars.add(playerAvatar);
/*     */       }
/*     */     }
/*     */     
/* 162 */     return avatars;
/*     */   }
/*     */   
/*     */   public void clearRequests() {
/* 166 */     this.requests.clear();
/*     */   }
/*     */   
/*     */   public void sendOffline(int friend, boolean online, boolean inRoom) {
/* 170 */     getPlayer().getSession().send(new UpdateFriendStateMessageComposer(PlayerManager.getInstance().getAvatarByPlayerId(friend, (byte)1), online, inRoom));
/*     */   }
/*     */   
/*     */   public void sendStatus(boolean online) {
/* 174 */     String image = com.habboproject.server.boot.Comet.getServer().getConfig().get("comet.notification.avatar.prefix");
/*     */     
/* 176 */     if ((getPlayer() == null) || (getPlayer().getSettings() == null)) {
/* 177 */       return;
/*     */     }
/*     */     
/* 180 */     if (getPlayer().getSettings().getHideOnline()) {
/* 181 */       return;
/*     */     }
/*     */     
/* 184 */     broadcast(new NotificationMessageComposer(image.replace("{0}", getPlayer().getData().getUsername()), 
/* 185 */       "Seu amigo " + getPlayer().getData().getUsername() + " ficou " + (online ? "online" : "offline")));
/*     */   }
/*     */   
/*     */   public void sendStatus(boolean online, boolean inRoom) {
/* 189 */     if ((getPlayer() == null) || (getPlayer().getSettings() == null)) {
/* 190 */       return;
/*     */     }
/*     */     
/* 193 */     if (getPlayer().getSettings().getHideOnline()) {
/* 194 */       return;
/*     */     }
/*     */     
/* 197 */     broadcast(new UpdateFriendStateMessageComposer(getPlayer().getData(), online, inRoom));
/*     */   }
/*     */   
/*     */   public MessengerFriend getFriendById(int id) {
/* 201 */     return (MessengerFriend)getFriends().get(Integer.valueOf(id));
/*     */   }
/*     */   
/*     */   public Map<Integer, MessengerFriend> getFriends() {
/* 205 */     return this.friends;
/*     */   }
/*     */   
/*     */   public List<Integer> getRequests() {
/* 209 */     return this.requests;
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/* 213 */     return this.player;
/*     */   }
/*     */   
/*     */   public void removeRequest(Integer request) {
/* 217 */     this.requests.remove(request);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\MessengerComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */