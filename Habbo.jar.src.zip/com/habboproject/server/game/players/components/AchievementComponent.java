/*     */ package com.habboproject.server.game.players.components;
/*     */ 
/*     */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*     */ import com.habboproject.server.game.achievements.AchievementGroup;
/*     */ import com.habboproject.server.game.achievements.AchievementManager;
/*     */ import com.habboproject.server.game.achievements.types.Achievement;
/*     */ import com.habboproject.server.game.achievements.types.AchievementType;
/*     */ import com.habboproject.server.game.players.components.types.achievements.AchievementProgress;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.network.messages.outgoing.user.achievements.AchievementProgressMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.storage.queries.achievements.PlayerAchievementDao;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class AchievementComponent implements com.habboproject.server.game.players.types.PlayerComponent
/*     */ {
/*     */   private final Player player;
/*     */   private Map<AchievementType, AchievementProgress> progression;
/*     */   
/*     */   public AchievementComponent(Player player)
/*     */   {
/*  23 */     this.player = player;
/*     */     
/*  25 */     loadAchievements();
/*     */   }
/*     */   
/*     */   public void loadAchievements() {
/*  29 */     if (this.progression != null) {
/*  30 */       this.progression.clear();
/*     */     }
/*     */     
/*  33 */     this.progression = PlayerAchievementDao.getAchievementProgress(this.player.getId());
/*     */   }
/*     */   
/*     */   public void progressAchievement(AchievementType type, int data) {
/*  37 */     AchievementGroup achievementGroup = AchievementManager.getInstance().getAchievementGroup(type);
/*     */     
/*  39 */     if (achievementGroup == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     AchievementProgress progress;
/*     */     AchievementProgress progress;
/*  45 */     if (this.progression.containsKey(type)) {
/*  46 */       progress = (AchievementProgress)this.progression.get(type);
/*     */     } else {
/*  48 */       progress = new AchievementProgress(1, 0);
/*  49 */       this.progression.put(type, progress);
/*     */     }
/*     */     
/*  52 */     if (achievementGroup.getAchievement(progress.getLevel()) == null) {
/*  53 */       return;
/*     */     }
/*  55 */     if (achievementGroup.getAchievements() == null) {
/*  56 */       return;
/*     */     }
/*  58 */     if ((achievementGroup.getAchievements().size() <= progress.getLevel()) && (achievementGroup.getAchievement(progress.getLevel()).getProgressNeeded() <= progress.getProgress())) {
/*  59 */       return;
/*     */     }
/*     */     
/*  62 */     int targetLevel = progress.getLevel() + 1;
/*  63 */     Achievement currentAchievement = achievementGroup.getAchievement(progress.getLevel());
/*  64 */     Achievement targetAchievement = achievementGroup.getAchievement(targetLevel);
/*     */     
/*  66 */     if ((targetAchievement == null) && (achievementGroup.getLevelCount() != 1))
/*     */     {
/*  68 */       progress.setProgress(currentAchievement.getProgressNeeded());
/*  69 */       PlayerAchievementDao.saveProgress(this.player.getId(), type, progress);
/*     */       
/*  71 */       this.player.getData().save();
/*  72 */       this.player.getInventory().achievementBadge(type.getGroupName(), currentAchievement.getLevel());
/*  73 */       return;
/*     */     }
/*     */     
/*  76 */     int progressToGive = currentAchievement.getProgressNeeded() <= data ? currentAchievement.getProgressNeeded() : data;
/*  77 */     int remainingProgress = progressToGive >= data ? 0 : data - progressToGive;
/*     */     
/*  79 */     progress.increaseProgress(progressToGive);
/*     */     
/*  81 */     if (progress.getProgress() > currentAchievement.getProgressNeeded())
/*     */     {
/*  83 */       int difference = progress.getProgress() - currentAchievement.getProgressNeeded();
/*     */       
/*  85 */       progress.decreaseProgress(difference);
/*  86 */       remainingProgress += difference;
/*     */     }
/*     */     
/*  89 */     if (currentAchievement.getProgressNeeded() <= progress.getProgress()) {
/*  90 */       this.player.getData().increaseAchievementPoints(currentAchievement.getRewardAchievement());
/*  91 */       this.player.getData().increaseActivityPoints(currentAchievement.getRewardActivityPoints());
/*     */       
/*  93 */       this.player.poof();
/*     */       
/*  95 */       getPlayer().getSession().send(getPlayer().composeCurrenciesBalance());
/*  96 */       getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.user.purse.UpdateActivityPointsMessageComposer(getPlayer().getData().getActivityPoints(), currentAchievement.getRewardAchievement()));
/*     */       
/*  98 */       if (achievementGroup.getAchievement(targetLevel) != null) {
/*  99 */         progress.increaseLevel();
/*     */       }
/*     */       
/*     */ 
/* 103 */       this.player.getSession().send(new com.habboproject.server.network.messages.outgoing.user.achievements.AchievementPointsMessageComposer(getPlayer().getData().getAchievementPoints()));
/* 104 */       this.player.getSession().send(new AchievementProgressMessageComposer(progress, achievementGroup));
/* 105 */       this.player.getSession().send(new com.habboproject.server.network.messages.outgoing.user.achievements.AchievementUnlockedMessageComposer(achievementGroup.getCategory().toString(), achievementGroup.getGroupName(), achievementGroup.getId(), targetAchievement));
/*     */       
/* 107 */       this.player.getInventory().achievementBadge(type.getGroupName(), currentAchievement.getLevel());
/*     */     } else {
/* 109 */       this.player.getSession().send(new AchievementProgressMessageComposer(progress, achievementGroup));
/*     */     }
/*     */     
/* 112 */     boolean hasFinishedGroup = false;
/*     */     
/* 114 */     if ((progress.getLevel() >= achievementGroup.getLevelCount()) && (progress.getProgress() >= achievementGroup.getAchievement(achievementGroup.getLevelCount()).getProgressNeeded())) {
/* 115 */       hasFinishedGroup = true;
/*     */     }
/*     */     
/* 118 */     if ((remainingProgress != 0) && (!hasFinishedGroup)) {
/* 119 */       progressAchievement(type, remainingProgress);
/* 120 */       return;
/*     */     }
/*     */     
/* 123 */     this.player.getData().save();
/* 124 */     PlayerAchievementDao.saveProgress(this.player.getId(), type, progress);
/*     */   }
/*     */   
/*     */   public boolean hasStartedAchievement(AchievementType achievementType) {
/* 128 */     return this.progression.containsKey(achievementType);
/*     */   }
/*     */   
/*     */   public AchievementProgress getProgress(AchievementType achievementType) {
/* 132 */     return (AchievementProgress)this.progression.get(achievementType);
/*     */   }
/*     */   
/*     */   public Player getPlayer()
/*     */   {
/* 137 */     return this.player;
/*     */   }
/*     */   
/*     */   public void dispose()
/*     */   {
/* 142 */     this.progression.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\AchievementComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */