/*    */ package com.habboproject.server.game.players.components;
/*    */ 
/*    */ import com.habboproject.server.boot.Comet;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.players.types.PlayerComponent;
/*    */ 
/*    */ public class SubscriptionComponent implements PlayerComponent
/*    */ {
/*    */   private Player player;
/*    */   private boolean hasSub;
/*    */   private int expire;
/*    */   
/*    */   public SubscriptionComponent(Player player)
/*    */   {
/* 15 */     this.player = player;
/*    */     
/* 17 */     load();
/*    */   }
/*    */   
/*    */   public void load() {
/* 21 */     this.hasSub = true;
/* 22 */     this.expire = ((int)Comet.getTime() + 315569260);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void add(int days) {}
/*    */   
/*    */ 
/*    */   public void delete()
/*    */   {
/* 32 */     this.hasSub = false;
/* 33 */     this.expire = 0;
/*    */   }
/*    */   
/*    */ 
/*    */   public void dispose() {}
/*    */   
/*    */ 
/*    */   public boolean isValid()
/*    */   {
/* 42 */     if (getExpire() <= Comet.getTime()) {
/* 43 */       return false;
/*    */     }
/*    */     
/* 46 */     return true;
/*    */   }
/*    */   
/*    */   public boolean exists() {
/* 50 */     return this.hasSub;
/*    */   }
/*    */   
/*    */   public int getExpire() {
/* 54 */     return this.expire;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 58 */     return this.player;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\SubscriptionComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */