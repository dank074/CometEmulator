/*    */ package com.habboproject.server.game.players.components;
/*    */ 
/*    */ import com.habboproject.server.api.game.players.data.components.PlayerBots;
/*    */ import com.habboproject.server.api.game.players.data.components.bots.PlayerBot;
/*    */ import com.habboproject.server.game.players.components.types.inventory.InventoryBot;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.players.types.PlayerComponent;
/*    */ import com.habboproject.server.storage.queries.bots.PlayerBotDao;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class InventoryBotComponent implements PlayerComponent, PlayerBots
/*    */ {
/*    */   private Player player;
/*    */   private Map<Integer, PlayerBot> bots;
/*    */   
/*    */   public InventoryBotComponent(Player player)
/*    */   {
/* 18 */     this.player = player;
/*    */     
/* 20 */     this.bots = PlayerBotDao.getBotsByPlayerId(player.getId());
/*    */   }
/*    */   
/*    */   public void addBot(InventoryBot bot) {
/* 24 */     this.bots.put(Integer.valueOf(bot.getId()), bot);
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 28 */     this.bots.clear();
/* 29 */     this.bots = null;
/* 30 */     this.player = null;
/*    */   }
/*    */   
/*    */   public PlayerBot getBot(int id) {
/* 34 */     if (this.bots.containsKey(Integer.valueOf(id))) {
/* 35 */       return (PlayerBot)this.bots.get(Integer.valueOf(id));
/*    */     }
/*    */     
/* 38 */     return null;
/*    */   }
/*    */   
/*    */   public void remove(int id) {
/* 42 */     this.bots.remove(Integer.valueOf(id));
/*    */   }
/*    */   
/*    */   public boolean isBot(int id) {
/* 46 */     return this.bots.containsKey(Integer.valueOf(id));
/*    */   }
/*    */   
/*    */   public Map<Integer, PlayerBot> getBots() {
/* 50 */     return this.bots;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 54 */     return this.player;
/*    */   }
/*    */   
/*    */   public void clearBots() {
/* 58 */     this.bots.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\InventoryBotComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */