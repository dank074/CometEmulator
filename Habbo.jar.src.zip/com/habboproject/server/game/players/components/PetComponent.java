/*    */ package com.habboproject.server.game.players.components;
/*    */ 
/*    */ import com.habboproject.server.game.pets.data.PetData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.players.types.PlayerComponent;
/*    */ import com.habboproject.server.storage.queries.pets.PetDao;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PetComponent implements PlayerComponent
/*    */ {
/*    */   private Player player;
/*    */   private Map<Integer, PetData> pets;
/*    */   
/*    */   public PetComponent(Player player)
/*    */   {
/* 16 */     this.player = player;
/*    */     
/* 18 */     this.pets = PetDao.getPetsByPlayerId(player.getId());
/*    */   }
/*    */   
/*    */   public PetData getPet(int id) {
/* 22 */     if (getPets().containsKey(Integer.valueOf(id))) {
/* 23 */       return (PetData)getPets().get(Integer.valueOf(id));
/*    */     }
/*    */     
/* 26 */     return null;
/*    */   }
/*    */   
/*    */   public void clearPets() {
/* 30 */     this.pets.clear();
/*    */   }
/*    */   
/*    */   public void addPet(PetData petData) {
/* 34 */     this.pets.put(Integer.valueOf(petData.getId()), petData);
/*    */   }
/*    */   
/*    */   public void removePet(int id) {
/* 38 */     this.pets.remove(Integer.valueOf(id));
/*    */   }
/*    */   
/*    */   public Player getPlayer()
/*    */   {
/* 43 */     return this.player;
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 47 */     this.pets.clear();
/* 48 */     this.pets = null;
/* 49 */     this.player = null;
/*    */   }
/*    */   
/*    */   public Map<Integer, PetData> getPets() {
/* 53 */     return this.pets;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\PetComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */