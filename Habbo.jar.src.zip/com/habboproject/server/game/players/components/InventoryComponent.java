/*     */ package com.habboproject.server.game.players.components;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.api.game.furniture.types.FurnitureDefinition;
/*     */ import com.habboproject.server.api.game.furniture.types.GiftItemData;
/*     */ import com.habboproject.server.api.game.furniture.types.LimitedEditionItem;
/*     */ import com.habboproject.server.api.game.furniture.types.SongItem;
/*     */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*     */ import com.habboproject.server.api.game.players.data.components.inventory.PlayerItem;
/*     */ import com.habboproject.server.config.Locale;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.music.SongItemData;
/*     */ import com.habboproject.server.game.players.components.types.inventory.InventoryItem;
/*     */ import com.habboproject.server.game.players.components.types.inventory.InventoryItemSnapshot;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.network.messages.outgoing.catalog.UnseenItemsMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.items.wired.WiredRewardMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.user.inventory.BadgeInventoryMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.user.inventory.RemoveObjectFromInventoryMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.storage.queries.achievements.PlayerAchievementDao;
/*     */ import com.habboproject.server.storage.queries.player.inventory.InventoryDao;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class InventoryComponent implements PlayerInventory
/*     */ {
/*     */   private Player player;
/*     */   private Map<Long, PlayerItem> floorItems;
/*     */   private Map<Long, PlayerItem> wallItems;
/*     */   private Map<String, Integer> badges;
/*  36 */   private boolean itemsLoaded = false;
/*     */   
/*  38 */   private Logger log = Logger.getLogger(InventoryComponent.class.getName());
/*     */   
/*     */   public InventoryComponent(Player player) {
/*  41 */     this.player = player;
/*     */     
/*  43 */     this.floorItems = new ConcurrentHashMap();
/*  44 */     this.wallItems = new ConcurrentHashMap();
/*  45 */     this.badges = new ConcurrentHashMap();
/*     */     
/*  47 */     loadBadges();
/*     */   }
/*     */   
/*     */   public void loadItems()
/*     */   {
/*  52 */     this.itemsLoaded = true;
/*     */     
/*  54 */     if (getWallItems().size() >= 1) {
/*  55 */       getWallItems().clear();
/*     */     }
/*  57 */     if (getFloorItems().size() >= 1) {
/*  58 */       getFloorItems().clear();
/*     */     }
/*     */     try
/*     */     {
/*  62 */       Map<Long, PlayerItem> inventoryItems = InventoryDao.getInventoryByPlayerId(this.player.getId());
/*     */       
/*  64 */       for (Map.Entry<Long, PlayerItem> item : inventoryItems.entrySet()) {
/*  65 */         if (((PlayerItem)item.getValue()).getDefinition().getType().equals("s")) {
/*  66 */           getFloorItems().put((Long)item.getKey(), (PlayerItem)item.getValue());
/*     */         }
/*     */         
/*  69 */         if (((PlayerItem)item.getValue()).getDefinition().getType().equals("i")) {
/*  70 */           getWallItems().put((Long)item.getKey(), (PlayerItem)item.getValue());
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/*  74 */       this.log.error("Error while loading user inventory", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadBadges()
/*     */   {
/*     */     try
/*     */     {
/*  82 */       this.badges = InventoryDao.getBadgesByPlayerId(this.player.getId());
/*     */     } catch (Exception e) {
/*  84 */       this.log.error("Error while loading user badges");
/*     */     }
/*     */   }
/*     */   
/*     */   public void addBadge(String code, boolean insert)
/*     */   {
/*  90 */     addBadge(code, insert, true);
/*     */   }
/*     */   
/*     */   public void addBadge(String code, boolean insert, boolean sendAlert)
/*     */   {
/*  95 */     if (!this.badges.containsKey(code)) {
/*  96 */       if (insert) {
/*  97 */         InventoryDao.addBadge(code, this.player.getId());
/*     */       }
/*     */       
/* 100 */       this.badges.put(code, Integer.valueOf(0));
/*     */       
/* 102 */       this.player.getSession()
/* 103 */         .send(new BadgeInventoryMessageComposer(getBadges()))
/* 104 */         .send(new UnseenItemsMessageComposer(new HashMap() {}));
/*     */       
/*     */ 
/*     */ 
/* 108 */       if (sendAlert) {
/* 109 */         this.player.getSession().send(new WiredRewardMessageComposer(7));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasBadge(String code)
/*     */   {
/* 116 */     return this.badges.containsKey(code);
/*     */   }
/*     */   
/*     */   public void removeBadge(String code, boolean delete)
/*     */   {
/* 121 */     removeBadge(code, delete, true, true);
/*     */   }
/*     */   
/*     */   public void removebadge(String code, boolean delete, boolean sendAlert)
/*     */   {
/* 126 */     removeBadge(code, delete, sendAlert, true);
/*     */   }
/*     */   
/*     */   public void removeBadge(String code, boolean delete, boolean sendAlert, boolean sendUpdate)
/*     */   {
/* 131 */     if (this.badges.containsKey(code)) {
/* 132 */       if (delete) {
/* 133 */         InventoryDao.removeBadge(code, this.player.getId());
/*     */       }
/*     */       
/* 136 */       this.badges.remove(code);
/*     */       
/* 138 */       if (sendAlert) {
/* 139 */         this.player.getSession().send(new com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer(Locale.get("badge.deleted")));
/*     */       }
/*     */       
/* 142 */       this.player.getSession().send(new BadgeInventoryMessageComposer(this.badges));
/*     */     }
/*     */   }
/*     */   
/*     */   public void achievementBadge(String achievement, int level)
/*     */   {
/* 148 */     String oldBadge = achievement + (level - 1);
/* 149 */     String newBadge = achievement + level;
/*     */     
/* 151 */     boolean isUpdated = false;
/*     */     
/* 153 */     if (this.badges.containsKey(oldBadge)) {
/* 154 */       removeBadge(oldBadge, false, false, false);
/*     */       
/* 156 */       PlayerAchievementDao.updateBadge(oldBadge, newBadge, this.player.getId());
/* 157 */       isUpdated = true;
/*     */     }
/*     */     
/* 160 */     addBadge(newBadge, !isUpdated, false);
/*     */   }
/*     */   
/*     */   public void resetBadgeSlots()
/*     */   {
/* 165 */     for (Map.Entry<String, Integer> badge : this.badges.entrySet()) {
/* 166 */       if (((Integer)badge.getValue()).intValue() != 0) {
/* 167 */         this.badges.replace((String)badge.getKey(), Integer.valueOf(0));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Map<String, Integer> equippedBadges()
/*     */   {
/* 174 */     Map<String, Integer> badges = new ConcurrentHashMap();
/*     */     
/* 176 */     for (Map.Entry<String, Integer> badge : getBadges().entrySet()) {
/* 177 */       if (((Integer)badge.getValue()).intValue() > 0) {
/* 178 */         badges.put((String)badge.getKey(), (Integer)badge.getValue());
/*     */       }
/*     */     }
/* 181 */     return badges;
/*     */   }
/*     */   
/*     */   public PlayerItem add(long id, int itemId, int groupId, String extraData, GiftItemData giftData, LimitedEditionItem limitedEditionItem)
/*     */   {
/* 186 */     PlayerItem item = new InventoryItem(id, itemId, groupId, extraData, giftData, limitedEditionItem);
/*     */     
/* 188 */     if (item.getDefinition().getType().equals("s")) {
/* 189 */       getFloorItems().put(Long.valueOf(id), (InventoryItem)item);
/*     */     }
/*     */     
/* 192 */     if (item.getDefinition().getType().equals("i")) {
/* 193 */       getWallItems().put(Long.valueOf(id), (InventoryItem)item);
/*     */     }
/*     */     
/* 196 */     return item;
/*     */   }
/*     */   
/*     */   public List<SongItem> getSongs()
/*     */   {
/* 201 */     List<SongItem> songItems = Lists.newArrayList();
/*     */     
/* 203 */     for (PlayerItem inventoryItem : this.floorItems.values()) {
/* 204 */       if (inventoryItem.getDefinition().isSong()) {
/* 205 */         songItems.add(new SongItemData((InventoryItemSnapshot)inventoryItem.createSnapshot(), inventoryItem.getDefinition().getSongId()));
/*     */       }
/*     */     }
/*     */     
/* 209 */     return songItems;
/*     */   }
/*     */   
/*     */   public void add(long id, int itemId, int groupId, String extraData, LimitedEditionItem limitedEditionItem)
/*     */   {
/* 214 */     add(id, itemId, groupId, extraData, null, limitedEditionItem);
/*     */   }
/*     */   
/*     */   public void addItem(PlayerItem item)
/*     */   {
/* 219 */     if (this.floorItems.size() + this.wallItems.size() >= 5000) {
/* 220 */       getPlayer().sendNotif("Notice", Locale.getOrDefault("game.inventory.limitExceeded", "You have over 5,000 items in your inventory. The next time you login, you will only see the first 5000 items."));
/*     */     }
/*     */     
/* 223 */     if (item.getDefinition().getType().equals("s")) {
/* 224 */       this.floorItems.put(Long.valueOf(item.getId()), (InventoryItem)item);
/* 225 */     } else if (item.getDefinition().getType().equals("i")) {
/* 226 */       this.wallItems.put(Long.valueOf(item.getId()), (InventoryItem)item);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeItem(PlayerItem item) {
/* 231 */     if (item.getDefinition().getType().equals("s")) {
/* 232 */       this.floorItems.remove(Long.valueOf(item.getId()));
/* 233 */     } else if (item.getDefinition().getType().equals("i")) {
/* 234 */       this.wallItems.remove(Long.valueOf(item.getId()));
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeFloorItem(long itemId) {
/* 239 */     if (getFloorItems() == null) {
/* 240 */       return;
/*     */     }
/*     */     
/* 243 */     getFloorItems().remove(Long.valueOf(itemId));
/* 244 */     getPlayer().getSession().send(new RemoveObjectFromInventoryMessageComposer(ItemManager.getInstance().getItemVirtualId(itemId)));
/*     */   }
/*     */   
/*     */   public void removeWallItem(long itemId)
/*     */   {
/* 249 */     getWallItems().remove(Long.valueOf(itemId));
/* 250 */     getPlayer().getSession().send(new RemoveObjectFromInventoryMessageComposer(ItemManager.getInstance().getItemVirtualId(itemId)));
/*     */   }
/*     */   
/*     */   public boolean hasFloorItem(long id)
/*     */   {
/* 255 */     return getFloorItems().containsKey(Long.valueOf(id));
/*     */   }
/*     */   
/*     */   public PlayerItem getFloorItem(long id)
/*     */   {
/* 260 */     if (!hasFloorItem(id)) {
/* 261 */       return null;
/*     */     }
/* 263 */     return (PlayerItem)getFloorItems().get(Long.valueOf(id));
/*     */   }
/*     */   
/*     */   public boolean hasWallItem(long id)
/*     */   {
/* 268 */     return getWallItems().containsKey(Long.valueOf(id));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public PlayerItem getWallItem(int id)
/*     */   {
/* 274 */     return getWallItem(ItemManager.getInstance().getItemIdByVirtualId(id).longValue());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public PlayerItem getFloorItem(int id)
/*     */   {
/* 280 */     return getFloorItem(ItemManager.getInstance().getItemIdByVirtualId(id).longValue());
/*     */   }
/*     */   
/*     */   public PlayerItem getWallItem(long id)
/*     */   {
/* 285 */     if (!hasWallItem(id)) {
/* 286 */       return null;
/*     */     }
/* 288 */     return (PlayerItem)getWallItems().get(Long.valueOf(id));
/*     */   }
/*     */   
/*     */   public PlayerItem getItem(long id)
/*     */   {
/* 293 */     PlayerItem item = getFloorItem(id);
/*     */     
/* 295 */     if (item != null) {
/* 296 */       return item;
/*     */     }
/*     */     
/* 299 */     return getWallItem(id);
/*     */   }
/*     */   
/*     */   public void dispose()
/*     */   {
/* 304 */     for (PlayerItem floorItem : this.floorItems.values()) {
/* 305 */       ItemManager.getInstance().disposeItemVirtualId(floorItem.getId());
/*     */     }
/*     */     
/* 308 */     for (PlayerItem wallItem : this.wallItems.values()) {
/* 309 */       ItemManager.getInstance().disposeItemVirtualId(wallItem.getId());
/*     */     }
/*     */     
/* 312 */     this.floorItems.clear();
/* 313 */     this.floorItems = null;
/*     */     
/* 315 */     this.wallItems.clear();
/* 316 */     this.wallItems = null;
/*     */     
/* 318 */     this.badges.clear();
/* 319 */     this.badges = null;
/*     */   }
/*     */   
/*     */   public int getTotalSize()
/*     */   {
/* 324 */     return getWallItems().size() + getFloorItems().size();
/*     */   }
/*     */   
/*     */   public Map<Long, PlayerItem> getWallItems()
/*     */   {
/* 329 */     return this.wallItems;
/*     */   }
/*     */   
/*     */   public Map<Long, PlayerItem> getFloorItems()
/*     */   {
/* 334 */     return this.floorItems;
/*     */   }
/*     */   
/*     */   public Map<String, Integer> getBadges()
/*     */   {
/* 339 */     return this.badges;
/*     */   }
/*     */   
/*     */   public Player getPlayer()
/*     */   {
/* 344 */     return this.player;
/*     */   }
/*     */   
/*     */   public boolean itemsLoaded()
/*     */   {
/* 349 */     return this.itemsLoaded;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\InventoryComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */