/*    */ package com.habboproject.server.game.players.components;
/*    */ 
/*    */ import com.habboproject.server.game.permissions.PermissionsManager;
/*    */ import com.habboproject.server.game.permissions.types.CommandPermission;
/*    */ import com.habboproject.server.game.players.data.PlayerData;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PermissionComponent implements com.habboproject.server.api.game.players.data.components.PlayerPermissions
/*    */ {
/*    */   private Player player;
/*    */   
/*    */   public PermissionComponent(Player player)
/*    */   {
/* 15 */     this.player = player;
/*    */   }
/*    */   
/*    */   public com.habboproject.server.game.permissions.types.Rank getRank()
/*    */   {
/* 20 */     return PermissionsManager.getInstance().getRank(this.player.getData().getRank());
/*    */   }
/*    */   
/*    */   public boolean hasCommand(String key)
/*    */   {
/* 25 */     if (this.player.getData().getRank() == 255) {
/* 26 */       return true;
/*    */     }
/*    */     
/* 29 */     if (PermissionsManager.getInstance().getCommands().containsKey(key)) {
/* 30 */       CommandPermission permission = (CommandPermission)PermissionsManager.getInstance().getCommands().get(key);
/*    */       
/* 32 */       if ((permission.getMinimumRank() <= getPlayer().getData().getRank()) && (
/* 33 */         ((permission.isVipOnly()) && (this.player.getData().isVip())) || (!permission.isVipOnly())))
/* 34 */         return true;
/*    */     } else {
/* 36 */       if ((key.equals("debug")) && (com.habboproject.server.boot.Comet.isDebugging))
/* 37 */         return true;
/* 38 */       if (key.equals("dev")) {
/* 39 */         return true;
/*    */       }
/*    */     }
/* 42 */     return false;
/*    */   }
/*    */   
/*    */   public Player getPlayer()
/*    */   {
/* 47 */     return this.player;
/*    */   }
/*    */   
/*    */   public void dispose() {}
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\PermissionComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */