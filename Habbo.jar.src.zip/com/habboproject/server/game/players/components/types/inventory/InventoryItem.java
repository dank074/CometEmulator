/*     */ package com.habboproject.server.game.players.components.types.inventory;
/*     */ 
/*     */ import com.habboproject.server.api.game.furniture.types.GiftItemData;
/*     */ import com.habboproject.server.api.game.furniture.types.LimitedEditionItem;
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.catalog.types.gifts.GiftData;
/*     */ import com.habboproject.server.game.groups.GroupManager;
/*     */ import com.habboproject.server.game.groups.items.GroupItemManager;
/*     */ import com.habboproject.server.game.groups.items.types.GroupBackgroundColour;
/*     */ import com.habboproject.server.game.groups.items.types.GroupSymbolColour;
/*     */ import com.habboproject.server.game.groups.types.GroupData;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class InventoryItem implements com.habboproject.server.api.game.players.data.components.inventory.PlayerItem
/*     */ {
/*     */   private long id;
/*     */   private int baseId;
/*     */   private int groupId;
/*     */   private String extraData;
/*     */   private GiftData giftData;
/*     */   private LimitedEditionItem limitedEditionItem;
/*     */   
/*     */   public InventoryItem(ResultSet data) throws SQLException
/*     */   {
/*  30 */     this.id = data.getLong("id");
/*  31 */     this.baseId = data.getInt("base_item");
/*  32 */     this.groupId = data.getInt("group_id");
/*  33 */     this.extraData = data.getString("extra_data");
/*     */     try
/*     */     {
/*  36 */       if (getDefinition().getInteraction().equals("gift")) {
/*  37 */         this.giftData = ((GiftData)com.habboproject.server.utilities.JsonFactory.getInstance().fromJson(this.extraData.split("GIFT::##")[1], GiftData.class));
/*     */       }
/*     */     } catch (Exception e) {
/*  40 */       this.giftData = null;
/*     */     }
/*     */     
/*  43 */     if (data.getInt("limited_id") != 0) {
/*  44 */       this.limitedEditionItem = new com.habboproject.server.game.items.rares.LimitedEditionItemData(this.id, data.getInt("limited_id"), data.getInt("limited_total"));
/*     */     }
/*     */   }
/*     */   
/*     */   public InventoryItem(long id, int baseId, int groupId, String extraData, GiftItemData giftData, LimitedEditionItem limitEditionItem) {
/*  49 */     init(id, baseId, groupId, extraData, (GiftData)giftData);
/*     */     
/*  51 */     this.limitedEditionItem = limitEditionItem;
/*     */   }
/*     */   
/*     */   public InventoryItem(long id, int baseId, int groupId, String extraData) {
/*  55 */     init(id, baseId, groupId, extraData, null);
/*     */   }
/*     */   
/*     */   private void init(long id, int baseId, int groupId, String extraData, GiftData giftData) {
/*  59 */     this.id = id;
/*  60 */     this.baseId = baseId;
/*  61 */     this.groupId = groupId;
/*  62 */     this.extraData = extraData;
/*  63 */     this.giftData = giftData;
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg) {
/*  67 */     boolean isGift = getGiftData() != null;
/*  68 */     boolean isGroupItem = (getDefinition().getInteraction().equals("group_item")) || (getDefinition().getInteraction().equals("group_gate"));
/*  69 */     boolean isLimited = getLimitedEditionItem() != null;
/*  70 */     boolean isWired = (getDefinition().getInteraction().startsWith("wf_act")) || (getDefinition().getInteraction().startsWith("wf_cnd")) || (getDefinition().getInteraction().startsWith("wf_trg"));
/*     */     
/*  72 */     msg.writeInt(ItemManager.getInstance().getItemVirtualId(getId()));
/*  73 */     msg.writeString(getDefinition().getType().toUpperCase());
/*  74 */     msg.writeInt(ItemManager.getInstance().getItemVirtualId(getId()));
/*  75 */     msg.writeInt(isGift ? getGiftData().getSpriteId() : getDefinition().getSpriteId());
/*     */     
/*  77 */     if (!isGroupItem) {
/*  78 */       msg.writeInt(1);
/*     */     }
/*  80 */     if (isGroupItem)
/*     */     {
/*  82 */       int groupId = 0;
/*     */       
/*  84 */       msg.writeInt(17);
/*     */       
/*  86 */       if (StringUtils.isNumeric(getExtraData())) {
/*  87 */         groupId = Integer.parseInt(getExtraData());
/*     */       }
/*     */       
/*  90 */       GroupData groupData = groupId == 0 ? null : GroupManager.getInstance().getData(groupId);
/*     */       
/*  92 */       if (groupData == null) {
/*  93 */         msg.writeInt(2);
/*  94 */         msg.writeInt(0);
/*     */       } else {
/*  96 */         msg.writeInt(2);
/*  97 */         msg.writeInt(5);
/*  98 */         msg.writeString("0");
/*  99 */         msg.writeString(Integer.valueOf(groupId));
/* 100 */         msg.writeString(groupData.getBadge());
/*     */         
/* 102 */         String colourA = GroupManager.getInstance().getGroupItems().getSymbolColours().get(Integer.valueOf(groupData.getColourA())) != null ? ((GroupSymbolColour)GroupManager.getInstance().getGroupItems().getSymbolColours().get(Integer.valueOf(groupData.getColourA()))).getColour() : "ffffff";
/* 103 */         String colourB = GroupManager.getInstance().getGroupItems().getBackgroundColours().get(Integer.valueOf(groupData.getColourB())) != null ? ((GroupBackgroundColour)GroupManager.getInstance().getGroupItems().getBackgroundColours().get(Integer.valueOf(groupData.getColourB()))).getColour() : "ffffff";
/*     */         
/* 105 */         msg.writeString(colourA);
/* 106 */         msg.writeString(colourB);
/*     */       }
/* 108 */     } else if ((isLimited) && (!isGift)) {
/* 109 */       msg.writeString("");
/* 110 */       msg.writeBoolean(Boolean.valueOf(true));
/* 111 */       msg.writeBoolean(Boolean.valueOf(false));
/* 112 */     } else if ((getDefinition().getInteraction().equals("badge_display")) && (!isGift)) {
/* 113 */       msg.writeInt(2);
/*     */     } else {
/* 115 */       msg.writeInt(0);
/*     */     }
/*     */     
/* 118 */     if ((getDefinition().getInteraction().equals("badge_display")) && (!isGift)) {
/* 119 */       msg.writeInt(4);
/*     */       
/*     */ 
/* 122 */       String name = "";
/* 123 */       String date = "";
/*     */       String badge;
/* 125 */       if (getExtraData().contains("~")) {
/* 126 */         String[] data = getExtraData().split("~");
/*     */         
/* 128 */         String badge = data[0];
/* 129 */         name = data[1];
/* 130 */         date = data[2];
/*     */       } else {
/* 132 */         badge = getExtraData();
/*     */       }
/*     */       
/* 135 */       msg.writeString("0");
/* 136 */       msg.writeString(badge);
/* 137 */       msg.writeString(name);
/* 138 */       msg.writeString(date);
/* 139 */     } else if (!isGroupItem) {
/* 140 */       msg.writeString((!isGift) && (!isWired) ? getExtraData() : "");
/*     */     }
/*     */     
/* 143 */     if ((isLimited) && (!isGift)) {
/* 144 */       LimitedEditionItem limitedEditionItem = getLimitedEditionItem();
/*     */       
/* 146 */       msg.writeInt(limitedEditionItem.getLimitedRare());
/* 147 */       msg.writeInt(limitedEditionItem.getLimitedRareTotal());
/*     */     }
/*     */     
/* 150 */     msg.writeBoolean(Boolean.valueOf(getDefinition().canRecycle()));
/* 151 */     msg.writeBoolean(Boolean.valueOf((!isGift) && (getDefinition().canTrade())));
/* 152 */     msg.writeBoolean(Boolean.valueOf((!isLimited) && (!isGift) && (getDefinition().canInventoryStack())));
/* 153 */     msg.writeBoolean(Boolean.valueOf((!isGift) && (getDefinition().canMarket())));
/*     */     
/* 155 */     msg.writeInt(-1);
/* 156 */     msg.writeBoolean(Boolean.valueOf(true));
/* 157 */     msg.writeInt(-1);
/* 158 */     msg.writeString("");
/* 159 */     msg.writeInt(isGift ? getGiftData().getWrappingPaper() * 1000 + getGiftData().getDecorationType() : 0);
/*     */   }
/*     */   
/*     */   public void serializeTrade(IComposer msg) {
/* 163 */     boolean isGift = getGiftData() != null;
/* 164 */     boolean isGroupItem = (getDefinition().getInteraction().equals("group_item")) || (getDefinition().getInteraction().equals("group_gate"));
/* 165 */     boolean isLimited = getLimitedEditionItem() != null;
/* 166 */     boolean isWired = (getDefinition().getInteraction().startsWith("wf_act")) || (getDefinition().getInteraction().startsWith("wf_cnd")) || (getDefinition().getInteraction().startsWith("wf_trg"));
/*     */     
/* 168 */     msg.writeInt(ItemManager.getInstance().getItemVirtualId(this.id));
/* 169 */     msg.writeString(getDefinition().getType().toLowerCase());
/* 170 */     msg.writeInt(ItemManager.getInstance().getItemVirtualId(this.id));
/* 171 */     msg.writeInt(getDefinition().getSpriteId());
/* 172 */     msg.writeInt(0);
/* 173 */     msg.writeBoolean(Boolean.valueOf(true));
/*     */     
/* 175 */     if (isGroupItem)
/*     */     {
/* 177 */       int groupId = 0;
/*     */       
/*     */ 
/*     */ 
/* 181 */       if (StringUtils.isNumeric(getExtraData())) {
/* 182 */         groupId = Integer.parseInt(getExtraData());
/*     */       }
/*     */       
/* 185 */       GroupData groupData = groupId == 0 ? null : GroupManager.getInstance().getData(groupId);
/*     */       
/* 187 */       if (groupData == null) {
/* 188 */         msg.writeInt(0);
/*     */       } else {
/* 190 */         msg.writeInt(2);
/* 191 */         msg.writeInt(5);
/* 192 */         msg.writeString("0");
/* 193 */         msg.writeString(Integer.valueOf(groupId));
/* 194 */         msg.writeString(groupData.getBadge());
/*     */         
/* 196 */         String colourA = GroupManager.getInstance().getGroupItems().getSymbolColours().get(Integer.valueOf(groupData.getColourA())) != null ? ((GroupSymbolColour)GroupManager.getInstance().getGroupItems().getSymbolColours().get(Integer.valueOf(groupData.getColourA()))).getColour() : "ffffff";
/* 197 */         String colourB = GroupManager.getInstance().getGroupItems().getBackgroundColours().get(Integer.valueOf(groupData.getColourB())) != null ? ((GroupBackgroundColour)GroupManager.getInstance().getGroupItems().getBackgroundColours().get(Integer.valueOf(groupData.getColourB()))).getColour() : "ffffff";
/*     */         
/* 199 */         msg.writeString(colourA);
/* 200 */         msg.writeString(colourB);
/*     */       }
/* 202 */     } else if (isLimited) {
/* 203 */       msg.writeString("");
/* 204 */       msg.writeBoolean(Boolean.valueOf(true));
/* 205 */       msg.writeBoolean(Boolean.valueOf(false));
/* 206 */     } else if ((getDefinition().getInteraction().equals("badge_display")) && (!isGift)) {
/* 207 */       msg.writeInt(2);
/*     */     } else {
/* 209 */       msg.writeInt(0);
/*     */     }
/*     */     
/* 212 */     if ((getDefinition().getInteraction().equals("badge_display")) && (!isGift)) {
/* 213 */       msg.writeInt(4);
/*     */       
/* 215 */       msg.writeString("0");
/* 216 */       msg.writeString(getExtraData());
/* 217 */       msg.writeString("");
/* 218 */       msg.writeString("");
/* 219 */     } else if (!isGroupItem) {
/* 220 */       msg.writeString((!isGift) && (!isWired) ? getExtraData() : "");
/*     */     }
/*     */     
/* 223 */     if ((isLimited) && (!isGift)) {
/* 224 */       LimitedEditionItem limitedEditionItem = getLimitedEditionItem();
/*     */       
/* 226 */       msg.writeInt(limitedEditionItem.getLimitedRare());
/* 227 */       msg.writeInt(limitedEditionItem.getLimitedRareTotal());
/*     */     }
/*     */     
/* 230 */     msg.writeInt(0);
/* 231 */     msg.writeInt(0);
/* 232 */     msg.writeInt(0);
/*     */     
/* 234 */     if (getDefinition().getType().equals("s")) {
/* 235 */       msg.writeInt(0);
/*     */     }
/*     */   }
/*     */   
/*     */   public long getId()
/*     */   {
/* 241 */     return this.id;
/*     */   }
/*     */   
/*     */   public ItemDefinition getDefinition()
/*     */   {
/* 246 */     return ItemManager.getInstance().getDefinition(getBaseId());
/*     */   }
/*     */   
/*     */   public int getBaseId()
/*     */   {
/* 251 */     return this.baseId;
/*     */   }
/*     */   
/*     */   public String getExtraData()
/*     */   {
/* 256 */     return this.extraData;
/*     */   }
/*     */   
/*     */   public GiftData getGiftData() {
/* 260 */     return this.giftData;
/*     */   }
/*     */   
/*     */   public LimitedEditionItem getLimitedEditionItem()
/*     */   {
/* 265 */     return this.limitedEditionItem;
/*     */   }
/*     */   
/*     */   public InventoryItemSnapshot createSnapshot() {
/* 269 */     return new InventoryItemSnapshot(this.id, this.baseId, this.extraData);
/*     */   }
/*     */   
/*     */   public int getVirtualId()
/*     */   {
/* 274 */     return ItemManager.getInstance().getItemVirtualId(getId());
/*     */   }
/*     */   
/*     */   public int getGroupId()
/*     */   {
/* 279 */     return this.groupId;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\inventory\InventoryItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */