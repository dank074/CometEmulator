/*    */ package com.habboproject.server.game.players.components.types.inventory;
/*    */ 
/*    */ import com.habboproject.server.api.game.players.data.components.inventory.PlayerItemSnapshot;
/*    */ 
/*    */ public class InventoryItemSnapshot implements PlayerItemSnapshot {
/*    */   private long id;
/*    */   private int baseItemId;
/*    */   private String extraData;
/*    */   
/*    */   public InventoryItemSnapshot(long id, int baseItemId, String extraData) {
/* 11 */     this.id = id;
/* 12 */     this.baseItemId = baseItemId;
/* 13 */     this.extraData = extraData;
/*    */   }
/*    */   
/*    */   public long getId() {
/* 17 */     return this.id;
/*    */   }
/*    */   
/*    */   public int getBaseItemId() {
/* 21 */     return this.baseItemId;
/*    */   }
/*    */   
/*    */   public String getExtraData() {
/* 25 */     return this.extraData;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\inventory\InventoryItemSnapshot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */