/*    */ package com.habboproject.server.game.players.components.types.achievements;
/*    */ 
/*    */ public class AchievementProgress {
/*    */   private int level;
/*    */   private int progress;
/*    */   
/*    */   public AchievementProgress(int level, int progress) {
/*  8 */     this.level = level;
/*  9 */     this.progress = progress;
/*    */   }
/*    */   
/*    */   public void increaseProgress(int amount) {
/* 13 */     this.progress += amount;
/*    */   }
/*    */   
/*    */   public void decreaseProgress(int difference) {
/* 17 */     this.progress -= difference;
/*    */   }
/*    */   
/*    */   public void increaseLevel() {
/* 21 */     this.level += 1;
/*    */   }
/*    */   
/*    */   public int getLevel() {
/* 25 */     return this.level;
/*    */   }
/*    */   
/*    */   public int getProgress() {
/* 29 */     return this.progress;
/*    */   }
/*    */   
/*    */   public void setProgress(int progress) {
/* 33 */     this.progress = progress;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\achievements\AchievementProgress.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */