/*    */ package com.habboproject.server.game.players.components.types.messenger;
/*    */ 
/*    */ import com.habboproject.server.game.players.PlayerManager;
/*    */ import com.habboproject.server.game.players.data.PlayerAvatar;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import java.sql.ResultSet;
/*    */ 
/*    */ public class MessengerFriend
/*    */ {
/*    */   private int userId;
/*    */   private PlayerAvatar playerAvatar;
/*    */   
/*    */   public MessengerFriend(ResultSet data) throws java.sql.SQLException
/*    */   {
/* 18 */     this.userId = data.getInt("user_two_id");
/* 19 */     this.playerAvatar = new com.habboproject.server.game.players.data.PlayerAvatarData(this.userId, data.getString("username"), 
/* 20 */       data.getString("figure"), data.getString("motto"), 
/* 21 */       com.habboproject.server.storage.queries.player.PlayerDao.getForumPostsByPlayerId(this.userId));
/*    */   }
/*    */   
/*    */   public MessengerFriend(int userId) {
/* 25 */     this.userId = userId;
/*    */   }
/*    */   
/*    */   public boolean isInRoom() {
/* 29 */     if (!isOnline()) {
/* 30 */       return false;
/*    */     }
/*    */     
/* 33 */     Session client = NetworkManager.getInstance().getSessions().getByPlayerId(this.userId);
/*    */     
/*    */ 
/* 36 */     if ((client == null) || (client.getPlayer() == null) || (client.getPlayer().getEntity() == null)) {
/* 37 */       return false;
/*    */     }
/*    */     
/* 40 */     if (!client.getPlayer().getEntity().isVisible()) {
/* 41 */       return false;
/*    */     }
/* 43 */     return true;
/*    */   }
/*    */   
/*    */   public PlayerAvatar getAvatar() {
/* 47 */     if ((getSession() != null) && (getSession().getPlayer() != null)) {
/* 48 */       return getSession().getPlayer().getData();
/*    */     }
/*    */     
/* 51 */     return this.playerAvatar;
/*    */   }
/*    */   
/*    */   public int getUserId() {
/* 55 */     return this.userId;
/*    */   }
/*    */   
/*    */   public boolean isOnline() {
/* 59 */     return PlayerManager.getInstance().isOnline(this.userId);
/*    */   }
/*    */   
/*    */   public Session getSession() {
/* 63 */     return NetworkManager.getInstance().getSessions().getByPlayerId(this.userId);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\messenger\MessengerFriend.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */