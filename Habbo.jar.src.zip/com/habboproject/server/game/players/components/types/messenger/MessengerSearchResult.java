/*    */ package com.habboproject.server.game.players.components.types.messenger;
/*    */ 
/*    */ import com.habboproject.server.api.networking.messages.IComposer;
/*    */ 
/*    */ public class MessengerSearchResult
/*    */ {
/*    */   private int id;
/*    */   private String username;
/*    */   private String figure;
/*    */   private String motto;
/*    */   private String lastOnline;
/*    */   
/*    */   public MessengerSearchResult(int id, String username, String figure, String motto, String lastOnline)
/*    */   {
/* 15 */     this.id = id;
/* 16 */     this.username = username;
/* 17 */     this.figure = figure;
/* 18 */     this.motto = motto;
/* 19 */     this.lastOnline = lastOnline;
/*    */   }
/*    */   
/*    */   public void compose(IComposer msg) {
/* 23 */     msg.writeInt(this.id);
/* 24 */     msg.writeString(this.username);
/* 25 */     msg.writeString(this.motto);
/* 26 */     msg.writeBoolean(Boolean.valueOf(com.habboproject.server.game.players.PlayerManager.getInstance().isOnline(this.id)));
/* 27 */     msg.writeBoolean(Boolean.valueOf(false));
/* 28 */     msg.writeString("");
/* 29 */     msg.writeInt(0);
/* 30 */     msg.writeString(this.figure);
/* 31 */     msg.writeString(this.lastOnline);
/*    */   }
/*    */   
/*    */   public int getId() {
/* 35 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 39 */     return this.username;
/*    */   }
/*    */   
/*    */   public String getFigure() {
/* 43 */     return this.figure;
/*    */   }
/*    */   
/*    */   public String getMotto() {
/* 47 */     return this.motto;
/*    */   }
/*    */   
/*    */   public String getLastOnline() {
/* 51 */     return this.lastOnline;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\messenger\MessengerSearchResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */