/*    */ package com.habboproject.server.game.players.components.types.inventory;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ 
/*    */ public class InventoryBot implements com.habboproject.server.api.game.players.data.components.bots.PlayerBot
/*    */ {
/*    */   private int id;
/*    */   private int ownerId;
/*    */   private String name;
/*    */   private String figure;
/*    */   private String gender;
/*    */   
/*    */   public InventoryBot(ResultSet data) throws java.sql.SQLException {
/* 14 */     this.id = data.getInt("id");
/* 15 */     this.ownerId = data.getInt("owner_id");
/*    */     
/* 17 */     this.name = data.getString("name");
/* 18 */     this.figure = data.getString("figure");
/* 19 */     this.gender = data.getString("gender");
/* 20 */     this.motto = data.getString("motto");
/* 21 */     this.ownerName = data.getString("owner");
/* 22 */     this.mode = data.getString("mode");
/* 23 */     this.type = data.getString("type");
/* 24 */     this.data = data.getString("data"); }
/*    */   
/*    */   private String motto;
/*    */   
/* 28 */   public InventoryBot(int id, int ownerId, String ownerName, String name, String figure, String gender, String motto, String type) { this.id = id;
/* 29 */     this.ownerId = ownerId;
/*    */     
/* 31 */     this.name = name;
/* 32 */     this.figure = figure;
/* 33 */     this.gender = gender;
/* 34 */     this.motto = motto;
/* 35 */     this.ownerName = ownerName;
/* 36 */     this.mode = "default";
/* 37 */     this.type = type;
/* 38 */     this.data = null; }
/*    */   
/*    */   private String ownerName;
/*    */   
/* 42 */   public int getId() { return this.id; }
/*    */   
/*    */   private String mode;
/*    */   
/* 46 */   public int getOwnerId() { return this.ownerId; }
/*    */   
/*    */   private String type;
/*    */   private String data;
/* 50 */   public String getName() { return this.name; }
/*    */   
/*    */   public String getFigure()
/*    */   {
/* 54 */     return this.figure;
/*    */   }
/*    */   
/*    */   public String getGender() {
/* 58 */     return this.gender;
/*    */   }
/*    */   
/*    */   public String getMotto() {
/* 62 */     return this.motto;
/*    */   }
/*    */   
/*    */   public String getOwnerName() {
/* 66 */     return this.ownerName;
/*    */   }
/*    */   
/*    */   public String getMode() {
/* 70 */     return this.mode;
/*    */   }
/*    */   
/*    */   public String getType() {
/* 74 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getData() {
/* 78 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\inventory\InventoryBot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */