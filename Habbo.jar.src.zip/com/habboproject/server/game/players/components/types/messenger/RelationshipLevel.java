/*    */ package com.habboproject.server.game.players.components.types.messenger;
/*    */ 
/*    */ public enum RelationshipLevel {
/*  4 */   BOBBA(3), 
/*  5 */   SMILE(2), 
/*  6 */   HEART(1);
/*    */   
/*    */   private int levelId;
/*    */   
/*    */   private RelationshipLevel(int id) {
/* 11 */     this.levelId = id;
/*    */   }
/*    */   
/*    */   public int getLevelId() {
/* 15 */     return this.levelId;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\messenger\RelationshipLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */