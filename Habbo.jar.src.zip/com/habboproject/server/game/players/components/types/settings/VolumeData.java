/*    */ package com.habboproject.server.game.players.components.types.settings;
/*    */ 
/*    */ import com.habboproject.server.utilities.JsonData;
/*    */ 
/*    */ public class VolumeData implements JsonData, com.habboproject.server.api.game.players.data.types.IVolumeData
/*    */ {
/*    */   private int systemVolume;
/*    */   private int furniVolume;
/*    */   private int traxVolume;
/*    */   
/*    */   public VolumeData(int systemVolume, int furniVolume, int traxVolume) {
/* 12 */     this.systemVolume = systemVolume;
/* 13 */     this.furniVolume = furniVolume;
/* 14 */     this.traxVolume = traxVolume;
/*    */   }
/*    */   
/*    */   public int getSystemVolume() {
/* 18 */     return this.systemVolume;
/*    */   }
/*    */   
/*    */   public void setSystemVolume(int systemVolume) {
/* 22 */     this.systemVolume = systemVolume;
/*    */   }
/*    */   
/*    */   public int getFurniVolume() {
/* 26 */     return this.furniVolume;
/*    */   }
/*    */   
/*    */   public void setFurniVolume(int furniVolume) {
/* 30 */     this.furniVolume = furniVolume;
/*    */   }
/*    */   
/*    */   public int getTraxVolume() {
/* 34 */     return this.traxVolume;
/*    */   }
/*    */   
/*    */   public void setTraxVolume(int traxVolume) {
/* 38 */     this.traxVolume = traxVolume;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\settings\VolumeData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */