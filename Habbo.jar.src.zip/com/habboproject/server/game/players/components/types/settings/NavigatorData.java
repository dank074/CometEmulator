/*    */ package com.habboproject.server.game.players.components.types.settings;
/*    */ 
/*    */ import com.habboproject.server.utilities.JsonData;
/*    */ 
/*    */ public class NavigatorData
/*    */   implements JsonData
/*    */ {
/*    */   private int x;
/*    */   private int y;
/*    */   private int width;
/*    */   private int height;
/*    */   private boolean showSavedSearches;
/*    */   
/*    */   public NavigatorData(int x, int y, int width, int height, boolean showSavedSearches)
/*    */   {
/* 16 */     this.x = x;
/* 17 */     this.y = y;
/* 18 */     this.width = width;
/* 19 */     this.height = height;
/* 20 */     this.showSavedSearches = showSavedSearches;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 24 */     return this.x;
/*    */   }
/*    */   
/*    */   public void setX(int x) {
/* 28 */     this.x = x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 32 */     return this.y;
/*    */   }
/*    */   
/*    */   public void setY(int y) {
/* 36 */     this.y = y;
/*    */   }
/*    */   
/*    */   public int getWidth() {
/* 40 */     return this.width;
/*    */   }
/*    */   
/*    */   public void setWidth(int width) {
/* 44 */     this.width = width;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 48 */     return this.height;
/*    */   }
/*    */   
/*    */   public void setHeight(int height) {
/* 52 */     this.height = height;
/*    */   }
/*    */   
/*    */   public boolean showSavedSearches() {
/* 56 */     return this.showSavedSearches;
/*    */   }
/*    */   
/*    */   public void setShowSavedSearches(boolean showSavedSearches) {
/* 60 */     this.showSavedSearches = showSavedSearches;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\settings\NavigatorData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */