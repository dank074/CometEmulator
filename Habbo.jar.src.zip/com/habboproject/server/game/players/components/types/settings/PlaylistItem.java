/*    */ package com.habboproject.server.game.players.components.types.settings;
/*    */ 
/*    */ import com.habboproject.server.utilities.JsonData;
/*    */ 
/*    */ public class PlaylistItem implements JsonData, com.habboproject.server.api.game.players.data.types.IPlaylistItem
/*    */ {
/*    */   private String videoId;
/*    */   private String title;
/*    */   private String description;
/*    */   private int duration;
/*    */   
/*    */   public PlaylistItem(String videoId, String title, String description, int duration) {
/* 13 */     this.videoId = videoId;
/* 14 */     this.title = title;
/* 15 */     this.description = description;
/* 16 */     this.duration = duration;
/*    */   }
/*    */   
/*    */   public String getVideoId() {
/* 20 */     return this.videoId;
/*    */   }
/*    */   
/*    */   public void setVideoId(String videoId) {
/* 24 */     this.videoId = videoId;
/*    */   }
/*    */   
/*    */   public String getTitle() {
/* 28 */     return this.title;
/*    */   }
/*    */   
/*    */   public void setTitle(String title) {
/* 32 */     this.title = title;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 36 */     return this.description;
/*    */   }
/*    */   
/*    */   public void setDescription(String description) {
/* 40 */     this.description = description;
/*    */   }
/*    */   
/*    */   public int getDuration() {
/* 44 */     return this.duration;
/*    */   }
/*    */   
/*    */   public void setDuration(int duration) {
/* 48 */     this.duration = duration;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\settings\PlaylistItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */