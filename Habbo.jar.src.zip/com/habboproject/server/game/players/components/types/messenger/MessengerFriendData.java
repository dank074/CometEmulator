/*    */ package com.habboproject.server.game.players.components.types.messenger;
/*    */ 
/*    */ public class MessengerFriendData {
/*    */   private String username;
/*    */   private String figure;
/*    */   private String motto;
/*    */   
/*    */   public MessengerFriendData(String username, String figure, String motto) {
/*  9 */     this.username = username;
/* 10 */     this.figure = figure;
/* 11 */     this.motto = motto;
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 15 */     return this.username;
/*    */   }
/*    */   
/*    */   public void setUsername(String username) {
/* 19 */     this.username = username;
/*    */   }
/*    */   
/*    */   public String getFigure() {
/* 23 */     return this.figure;
/*    */   }
/*    */   
/*    */   public void setFigure(String figure) {
/* 27 */     this.figure = figure;
/*    */   }
/*    */   
/*    */   public String getMotto() {
/* 31 */     return this.motto;
/*    */   }
/*    */   
/*    */   public void setMotto(String motto) {
/* 35 */     this.motto = motto;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\messenger\MessengerFriendData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */