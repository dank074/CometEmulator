/*    */ package com.habboproject.server.game.players.components.types.settings;
/*    */ 
/*    */ import com.habboproject.server.utilities.JsonData;
/*    */ 
/*    */ public class WardrobeItem implements JsonData, com.habboproject.server.api.game.players.data.types.IWardrobeItem
/*    */ {
/*    */   private int slot;
/*    */   private String gender;
/*    */   private String figure;
/*    */   
/*    */   public WardrobeItem(int slot, String gender, String figure) {
/* 12 */     this.slot = slot;
/* 13 */     this.gender = gender;
/* 14 */     this.figure = figure;
/*    */   }
/*    */   
/*    */   public int getSlot() {
/* 18 */     return this.slot;
/*    */   }
/*    */   
/*    */   public void setSlot(int slot) {
/* 22 */     this.slot = slot;
/*    */   }
/*    */   
/*    */   public String getGender() {
/* 26 */     return this.gender;
/*    */   }
/*    */   
/*    */   public void setGender(String gender) {
/* 30 */     this.gender = gender;
/*    */   }
/*    */   
/*    */   public String getFigure() {
/* 34 */     return this.figure;
/*    */   }
/*    */   
/*    */   public void setFigure(String figure) {
/* 38 */     this.figure = figure;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\settings\WardrobeItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */