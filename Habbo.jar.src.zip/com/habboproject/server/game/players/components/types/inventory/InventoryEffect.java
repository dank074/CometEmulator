/*    */ package com.habboproject.server.game.players.components.types.inventory;
/*    */ 
/*    */ 
/*    */ public class InventoryEffect
/*    */ {
/*    */   private final int id;
/*    */   private final int effectId;
/*    */   private final double duration;
/*    */   private final boolean isTotem;
/*    */   private boolean activated;
/*    */   private double timestampActivated;
/*    */   private int quantity;
/*    */   
/*    */   public InventoryEffect(int id, int effectId, double duration, boolean isTotem, boolean activated, double timestampActivated, int quantity)
/*    */   {
/* 16 */     this.id = id;
/* 17 */     this.effectId = effectId;
/* 18 */     this.duration = duration;
/* 19 */     this.isTotem = isTotem;
/* 20 */     this.activated = activated;
/* 21 */     this.timestampActivated = timestampActivated;
/* 22 */     this.quantity = quantity;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 26 */     return this.id;
/*    */   }
/*    */   
/*    */   public int getEffectId() {
/* 30 */     return this.effectId;
/*    */   }
/*    */   
/*    */   public double getDuration() {
/* 34 */     return this.duration;
/*    */   }
/*    */   
/*    */   public boolean isTotem() {
/* 38 */     return this.isTotem;
/*    */   }
/*    */   
/*    */   public boolean isActivated() {
/* 42 */     return this.activated;
/*    */   }
/*    */   
/*    */   public void setActivated(boolean activated) {
/* 46 */     this.activated = activated;
/*    */   }
/*    */   
/*    */   public double getTimestampActivated() {
/* 50 */     return this.timestampActivated;
/*    */   }
/*    */   
/*    */   public void setTimestampActivated(double timestampActivated) {
/* 54 */     this.timestampActivated = timestampActivated;
/*    */   }
/*    */   
/*    */   public int getQuantity() {
/* 58 */     return this.quantity;
/*    */   }
/*    */   
/*    */   public void setQuantity(int quantity) {
/* 62 */     this.quantity = quantity;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\types\inventory\InventoryEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */