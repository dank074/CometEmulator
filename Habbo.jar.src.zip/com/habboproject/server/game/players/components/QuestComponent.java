/*     */ package com.habboproject.server.game.players.components;
/*     */ 
/*     */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.players.types.PlayerComponent;
/*     */ import com.habboproject.server.game.quests.QuestManager;
/*     */ import com.habboproject.server.game.quests.types.Quest;
/*     */ import com.habboproject.server.game.quests.types.QuestType;
/*     */ import com.habboproject.server.network.messages.outgoing.quests.QuestCompletedMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.quests.QuestListMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.storage.queries.quests.PlayerQuestsDao;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class QuestComponent implements PlayerComponent
/*     */ {
/*  19 */   private static final Logger log = Logger.getLogger(QuestComponent.class.getName());
/*     */   private Player player;
/*     */   private Map<Integer, Integer> questProgression;
/*     */   
/*     */   public QuestComponent(Player player)
/*     */   {
/*  25 */     this.player = player;
/*     */     
/*  27 */     loadQuestProgression();
/*     */   }
/*     */   
/*     */   private void loadQuestProgression() {
/*  31 */     this.questProgression = PlayerQuestsDao.getQuestProgression(getPlayer().getId());
/*     */   }
/*     */   
/*     */   public boolean hasStartedQuest(int questId) {
/*  35 */     return this.questProgression.containsKey(Integer.valueOf(questId));
/*     */   }
/*     */   
/*     */   public boolean hasCompletedQuest(int questId) {
/*  39 */     Quest quest = QuestManager.getInstance().getById(questId);
/*     */     
/*  41 */     if (quest == null) { return false;
/*     */     }
/*  43 */     if ((this.questProgression.containsKey(Integer.valueOf(questId))) && 
/*  44 */       (((Integer)this.questProgression.get(Integer.valueOf(questId))).intValue() >= quest.getGoalData())) {
/*  45 */       return true;
/*     */     }
/*     */     
/*     */ 
/*  49 */     return false;
/*     */   }
/*     */   
/*     */   public void startQuest(Quest quest) {
/*  53 */     if (this.questProgression.containsKey(Integer.valueOf(quest.getId())))
/*     */     {
/*  55 */       return;
/*     */     }
/*     */     
/*  58 */     this.questProgression.put(Integer.valueOf(quest.getId()), Integer.valueOf(0));
/*  59 */     PlayerQuestsDao.saveProgression(true, this.player.getId(), quest.getId(), 0);
/*     */     
/*  61 */     getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.quests.QuestStartedMessageComposer(quest, getPlayer()));
/*  62 */     getPlayer().getSession().send(new QuestListMessageComposer(QuestManager.getInstance().getQuests(), getPlayer(), false));
/*     */     
/*  64 */     getPlayer().getData().setQuestId(quest.getId());
/*  65 */     getPlayer().getData().save();
/*     */   }
/*     */   
/*     */   public void cancelQuest(int questId) {
/*  69 */     PlayerQuestsDao.cancelQuest(questId, this.player.getId());
/*  70 */     this.questProgression.remove(Integer.valueOf(questId));
/*     */   }
/*     */   
/*     */   public void progressQuest(QuestType type) {
/*  74 */     progressQuest(type, 0);
/*     */   }
/*     */   
/*     */   public void progressQuest(QuestType type, int data) {
/*  78 */     int questId = getPlayer().getData().getQuestId();
/*     */     
/*  80 */     if ((questId == 0) || (!hasStartedQuest(questId))) {
/*  81 */       return;
/*     */     }
/*     */     
/*  84 */     Quest quest = QuestManager.getInstance().getById(questId);
/*     */     
/*  86 */     if (quest == null) {
/*  87 */       return;
/*     */     }
/*     */     
/*  90 */     if (quest.getType() != type) {
/*  91 */       return;
/*     */     }
/*     */     
/*  94 */     if (hasCompletedQuest(questId)) {
/*  95 */       return;
/*     */     }
/*     */     
/*  98 */     int newProgressValue = getProgress(questId);
/*     */     
/* 100 */     switch (quest.getType()) {
/*     */     default: 
/* 102 */       newProgressValue++;
/* 103 */       break;
/*     */     
/*     */     case SOCIAL_WAVE: 
/* 106 */       if (quest.getGoalData() != data) {
/* 107 */         return;
/*     */       }
/*     */       
/* 110 */       newProgressValue = quest.getGoalData();
/*     */     }
/*     */     
/*     */     
/* 114 */     if (newProgressValue >= quest.getGoalData()) {
/* 115 */       boolean refreshCreditBalance = false;
/* 116 */       boolean refreshCurrenciesBalance = false;
/*     */       try
/*     */       {
/* 119 */         switch (quest.getRewardType()) {
/*     */         case CREDITS: 
/* 121 */           getPlayer().getData().increaseActivityPoints(quest.getReward());
/* 122 */           refreshCurrenciesBalance = true;
/* 123 */           break;
/*     */         
/*     */         case ACHIEVEMENT_POINTS: 
/* 126 */           getPlayer().getData().increaseAchievementPoints(quest.getReward());
/* 127 */           getPlayer().sendNotif("Alert", com.habboproject.server.config.Locale.get("game.received.achievementPoints").replace("%points%", quest.getReward()));
/* 128 */           getPlayer().poof();
/* 129 */           break;
/*     */         
/*     */         case ACTIVITY_POINTS: 
/* 132 */           this.player.getData().increasePoints(quest.getReward());
/* 133 */           refreshCurrenciesBalance = true;
/* 134 */           break;
/*     */         
/*     */         case VIP_POINTS: 
/* 137 */           getPlayer().getData().increaseCredits(quest.getReward());
/* 138 */           refreshCreditBalance = true;
/*     */         }
/*     */         
/*     */         
/* 142 */         if (!quest.getBadgeId().isEmpty())
/*     */         {
/* 144 */           this.player.getInventory().addBadge(quest.getBadgeId(), true);
/*     */         }
/*     */       } catch (Exception e) {
/* 147 */         log.error("Failed to deliver reward to player: " + getPlayer().getData().getUsername());
/*     */       }
/*     */       
/* 150 */       if (refreshCreditBalance) {
/* 151 */         getPlayer().getSession().send(getPlayer().composeCreditBalance());
/* 152 */       } else if (refreshCurrenciesBalance) {
/* 153 */         getPlayer().getSession().send(getPlayer().composeCurrenciesBalance());
/* 154 */         getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.user.purse.UpdateActivityPointsMessageComposer(getPlayer().getData().getActivityPoints(), quest.getReward()));
/*     */       }
/*     */       
/* 157 */       getPlayer().getData().save();
/*     */     }
/*     */     
/* 160 */     if (this.questProgression.containsKey(Integer.valueOf(questId))) {
/* 161 */       this.questProgression.replace(Integer.valueOf(questId), Integer.valueOf(newProgressValue));
/*     */     }
/*     */     
/* 164 */     PlayerQuestsDao.saveProgression(false, this.player.getId(), questId, newProgressValue);
/*     */     
/* 166 */     getPlayer().getSession().send(new QuestCompletedMessageComposer(quest, this.player));
/* 167 */     getPlayer().getSession().send(new QuestListMessageComposer(QuestManager.getInstance().getQuests(), this.player, false));
/*     */   }
/*     */   
/*     */   public int getProgress(int quest) {
/* 171 */     if (this.questProgression.containsKey(Integer.valueOf(quest))) {
/* 172 */       return ((Integer)this.questProgression.get(Integer.valueOf(quest))).intValue();
/*     */     }
/*     */     
/* 175 */     return 0;
/*     */   }
/*     */   
/*     */   public void dispose()
/*     */   {
/* 180 */     this.questProgression.clear();
/* 181 */     this.questProgression = null;
/*     */     
/* 183 */     this.player = null;
/*     */   }
/*     */   
/*     */   public Player getPlayer()
/*     */   {
/* 188 */     return this.player;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\QuestComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */