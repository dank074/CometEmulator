/*    */ package com.habboproject.server.game.players.components;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import com.habboproject.server.game.players.components.types.inventory.InventoryEffect;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.network.messages.outgoing.user.inventory.EffectAddedMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.storage.queries.effects.EffectDao;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EffectComponent
/*    */ {
/*    */   private Player player;
/*    */   private Map<Integer, InventoryEffect> effects;
/* 18 */   private Logger logger = Logger.getLogger(EffectComponent.class.getName());
/*    */   
/*    */   public EffectComponent(Player player) {
/* 21 */     this.player = player;
/* 22 */     this.effects = Maps.newConcurrentMap();
/* 23 */     loadEffects();
/*    */   }
/*    */   
/*    */   public Map<Integer, InventoryEffect> getEffects() {
/* 27 */     return this.effects;
/*    */   }
/*    */   
/*    */   public void loadEffects() {
/* 31 */     if ((this.effects != null) && (this.effects.size() >= 1)) {
/* 32 */       this.effects.clear();
/*    */     }
/*    */     try
/*    */     {
/* 36 */       this.effects = EffectDao.getEffectsByPlayerId(this.player.getId());
/*    */     }
/*    */     catch (Exception e) {
/* 39 */       this.logger.error("Error while loading user effects", e);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean hasEffect(int effectId) {
/* 44 */     if (effectId == 0) {
/* 45 */       return true;
/*    */     }
/*    */     
/* 48 */     for (InventoryEffect effect : this.effects.values()) {
/* 49 */       if (effect.getEffectId() == effectId) {
/* 50 */         return true;
/*    */       }
/*    */     }
/* 53 */     return false;
/*    */   }
/*    */   
/*    */   public void addEffect(int effectId, int duration, boolean isTotem) {
/* 57 */     if (hasEffect(effectId)) {
/* 58 */       return;
/*    */     }
/* 60 */     int effect = EffectDao.addEffect(this.player.getId(), effectId, duration, isTotem);
/*    */     
/* 62 */     this.effects.put(Integer.valueOf(effect), new InventoryEffect(effect, effectId, duration, isTotem, false, 0.0D, 1));
/* 63 */     this.player.getSession().send(new EffectAddedMessageComposer(effectId, duration, isTotem));
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 67 */     this.effects.clear();
/* 68 */     this.effects = null;
/* 69 */     this.player = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\EffectComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */