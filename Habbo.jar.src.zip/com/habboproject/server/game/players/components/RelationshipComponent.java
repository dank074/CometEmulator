/*    */ package com.habboproject.server.game.players.components;
/*    */ 
/*    */ import com.habboproject.server.game.players.components.types.messenger.RelationshipLevel;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.players.types.PlayerComponent;
/*    */ import com.habboproject.server.storage.queries.player.relationships.RelationshipDao;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class RelationshipComponent implements PlayerComponent
/*    */ {
/*    */   private Player player;
/*    */   private Map<Integer, RelationshipLevel> relationships;
/*    */   
/*    */   public RelationshipComponent(Player player)
/*    */   {
/* 16 */     this.player = player;
/*    */     
/* 18 */     this.relationships = RelationshipDao.getRelationshipsByPlayerId(player.getId());
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 22 */     this.relationships.clear();
/* 23 */     this.relationships = null;
/* 24 */     this.player = null;
/*    */   }
/*    */   
/*    */   public RelationshipLevel get(int playerId) {
/* 28 */     return (RelationshipLevel)this.relationships.get(Integer.valueOf(playerId));
/*    */   }
/*    */   
/*    */   public void remove(int playerId) {
/* 32 */     getRelationships().remove(Integer.valueOf(playerId));
/*    */   }
/*    */   
/*    */   public int count() {
/* 36 */     return this.relationships.size();
/*    */   }
/*    */   
/*    */   public Map<Integer, RelationshipLevel> getRelationships() {
/* 40 */     return this.relationships;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 44 */     return this.player;
/*    */   }
/*    */   
/*    */   public static int countByLevel(RelationshipLevel level, Map<Integer, RelationshipLevel> relationships) {
/* 48 */     int levelCount = 0;
/*    */     
/* 50 */     for (RelationshipLevel relationship : relationships.values()) {
/* 51 */       if (relationship == level) { levelCount++;
/*    */       }
/*    */     }
/* 54 */     return levelCount;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\players\components\RelationshipComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */