/*    */ package com.habboproject.server.game.landing;
/*    */ 
/*    */ import com.habboproject.server.game.landing.types.PromoArticle;
/*    */ import com.habboproject.server.storage.queries.landing.LandingDao;
/*    */ import com.habboproject.server.utilities.Initializable;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class LandingManager
/*    */   implements Initializable
/*    */ {
/*    */   private static LandingManager landingManagerInstance;
/* 13 */   private static final Logger log = Logger.getLogger(LandingManager.class.getName());
/*    */   
/*    */ 
/*    */   private Map<Integer, PromoArticle> articles;
/*    */   
/*    */ 
/*    */ 
/*    */   public void initialize()
/*    */   {
/* 22 */     loadArticles();
/*    */     
/* 24 */     log.info("LandingManager initialized");
/*    */   }
/*    */   
/*    */   public static LandingManager getInstance() {
/* 28 */     if (landingManagerInstance == null) {
/* 29 */       landingManagerInstance = new LandingManager();
/*    */     }
/*    */     
/* 32 */     return landingManagerInstance;
/*    */   }
/*    */   
/*    */   public void loadArticles() {
/* 36 */     if (this.articles != null) {
/* 37 */       this.articles.clear();
/*    */     }
/*    */     
/* 40 */     this.articles = LandingDao.getArticles();
/*    */   }
/*    */   
/*    */   public Map<Integer, PromoArticle> getArticles() {
/* 44 */     return this.articles;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\landing\LandingManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */