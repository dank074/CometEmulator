/*    */ package com.habboproject.server.game.landing.types;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ 
/*    */ public class PromoArticle
/*    */ {
/*    */   private int id;
/*    */   private String title;
/*    */   private String message;
/*    */   private String buttonText;
/*    */   private String buttonLink;
/*    */   private String imagePath;
/*    */   
/*    */   public PromoArticle(ResultSet data) throws java.sql.SQLException
/*    */   {
/* 16 */     this.id = data.getInt("id");
/* 17 */     this.title = data.getString("title");
/* 18 */     this.message = data.getString("message");
/* 19 */     this.buttonText = data.getString("button_text");
/* 20 */     this.buttonLink = data.getString("button_link");
/* 21 */     this.imagePath = data.getString("image_path");
/*    */   }
/*    */   
/*    */   public int getId() {
/* 25 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getTitle() {
/* 29 */     return this.title;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 33 */     return this.message;
/*    */   }
/*    */   
/*    */   public String getButtonText() {
/* 37 */     return this.buttonText;
/*    */   }
/*    */   
/*    */   public String getButtonLink() {
/* 41 */     return this.buttonLink;
/*    */   }
/*    */   
/*    */   public String getImagePath() {
/* 45 */     return this.imagePath;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\landing\types\PromoArticle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */