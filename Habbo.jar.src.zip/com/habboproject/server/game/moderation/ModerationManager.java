/*     */ package com.habboproject.server.game.moderation;
/*     */ 
/*     */ import com.habboproject.server.game.moderation.types.actions.ActionCategory;
/*     */ import com.habboproject.server.game.moderation.types.tickets.HelpTicket;
/*     */ import com.habboproject.server.game.moderation.types.tickets.HelpTicketState;
/*     */ import com.habboproject.server.game.rooms.types.components.types.ChatMessage;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.messages.outgoing.moderation.tickets.HelpTicketMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.network.sessions.SessionManager;
/*     */ import com.habboproject.server.storage.queries.moderation.PresetDao;
/*     */ import com.habboproject.server.storage.queries.moderation.TicketDao;
/*     */ import com.habboproject.server.utilities.Initializable;
/*     */ import com.habboproject.server.utilities.collections.ConcurrentHashSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModerationManager
/*     */   implements Initializable
/*     */ {
/*     */   private static ModerationManager moderationManagerInstance;
/*     */   private List<String> userPresets;
/*     */   private List<String> roomPresets;
/*     */   private List<ActionCategory> actionCategories;
/*     */   private Map<Integer, HelpTicket> tickets;
/*     */   private ConcurrentHashSet<Session> moderators;
/*  33 */   private Logger log = Logger.getLogger(ModerationManager.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  41 */     this.moderators = new ConcurrentHashSet();
/*     */     
/*  43 */     loadPresets();
/*  44 */     loadActiveTickets();
/*     */     
/*  46 */     this.log.info("ModerationManager initialized");
/*     */   }
/*     */   
/*     */   public static ModerationManager getInstance() {
/*  50 */     if (moderationManagerInstance == null) {
/*  51 */       moderationManagerInstance = new ModerationManager();
/*     */     }
/*  53 */     return moderationManagerInstance;
/*     */   }
/*     */   
/*     */   public void loadPresets() {
/*  57 */     if (this.userPresets == null) {
/*  58 */       this.userPresets = new ArrayList();
/*     */     } else {
/*  60 */       this.userPresets.clear();
/*     */     }
/*     */     
/*  63 */     if (this.roomPresets == null) {
/*  64 */       this.roomPresets = new ArrayList();
/*     */     } else {
/*  66 */       this.roomPresets.clear();
/*     */     }
/*     */     
/*  69 */     if (this.actionCategories == null) {
/*  70 */       this.actionCategories = new ArrayList();
/*     */     } else {
/*  72 */       for (ActionCategory actionCategory : this.actionCategories) {
/*  73 */         actionCategory.dispose();
/*     */       }
/*     */       
/*  76 */       this.actionCategories.clear();
/*     */     }
/*     */     try
/*     */     {
/*  80 */       PresetDao.getPresets(this.userPresets, this.roomPresets);
/*  81 */       PresetDao.getPresetActions(this.actionCategories);
/*     */       
/*  83 */       this.log.info("Loaded " + (getRoomPresets().size() + getUserPresets().size() + getActionCategories().size()) + " moderation presets");
/*     */     } catch (Exception e) {
/*  85 */       this.log.error("Error while loading moderation presets", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addModerator(Session session) {
/*  90 */     this.moderators.add(session);
/*     */   }
/*     */   
/*     */   public void removeModerator(Session session) {
/*  94 */     this.moderators.remove(session);
/*     */   }
/*     */   
/*     */   public void loadActiveTickets() {
/*  98 */     if (this.tickets == null) {
/*  99 */       this.tickets = new HashMap();
/*     */     } else {
/* 101 */       this.tickets.clear();
/*     */     }
/*     */     try
/*     */     {
/* 105 */       this.tickets = TicketDao.getOpenTickets();
/* 106 */       this.log.info("Loaded " + this.tickets.size() + " active help tickets");
/*     */     } catch (Exception e) {
/* 108 */       this.log.error("Error while loading active tickets", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addTicket(HelpTicket ticket) {
/* 113 */     this.tickets.put(Integer.valueOf(ticket.getId()), ticket);
/* 114 */     broadcastTicket(ticket);
/*     */   }
/*     */   
/*     */   public void broadcastTicket(HelpTicket ticket) {
/* 118 */     NetworkManager.getInstance().getSessions().broadcastToModerators(new HelpTicketMessageComposer(ticket));
/*     */   }
/*     */   
/*     */   public void createTicket(int submitterId, String message, int category, int reportedId, int timestamp, int roomId, List<ChatMessage> chatMessages) {
/* 122 */     int ticketId = TicketDao.createTicket(submitterId, message, category, reportedId, timestamp, roomId, chatMessages);
/*     */     
/* 124 */     HelpTicket ticket = new HelpTicket(ticketId, category, timestamp, 0, submitterId, reportedId, 0, message, HelpTicketState.OPEN, chatMessages, roomId);
/* 125 */     addTicket(ticket);
/*     */   }
/*     */   
/*     */   public HelpTicket getTicket(int id) {
/* 129 */     return (HelpTicket)this.tickets.get(Integer.valueOf(id));
/*     */   }
/*     */   
/*     */   public HelpTicket getTicketByUserId(int id) {
/* 133 */     for (HelpTicket ticket : this.tickets.values()) {
/* 134 */       if (ticket.getSubmitterId() == id) {
/* 135 */         return ticket;
/*     */       }
/*     */     }
/* 138 */     return null;
/*     */   }
/*     */   
/*     */   public List<String> getUserPresets() {
/* 142 */     return this.userPresets;
/*     */   }
/*     */   
/*     */   public List<String> getRoomPresets() {
/* 146 */     return this.roomPresets;
/*     */   }
/*     */   
/*     */   public List<ActionCategory> getActionCategories() {
/* 150 */     return this.actionCategories;
/*     */   }
/*     */   
/*     */   public HelpTicket getActiveTicketByPlayerId(int playerId) {
/* 154 */     HelpTicket ticket = getTicketByUserId(playerId);
/*     */     
/* 156 */     if ((ticket != null) && 
/* 157 */       (ticket.getState() != HelpTicketState.CLOSED)) {
/* 158 */       return ticket;
/*     */     }
/*     */     
/*     */ 
/* 162 */     return null;
/*     */   }
/*     */   
/*     */   public Map<Integer, HelpTicket> getTickets() {
/* 166 */     return this.tickets;
/*     */   }
/*     */   
/*     */   public ConcurrentHashSet<Session> getModerators()
/*     */   {
/* 171 */     return this.moderators;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\moderation\ModerationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */