/*    */ package com.habboproject.server.game.moderation.types;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ 
/*    */ public class Ban
/*    */ {
/*    */   private int id;
/*    */   private String data;
/*    */   private long expire;
/*    */   private BanType type;
/*    */   private String reason;
/*    */   
/*    */   public Ban(ResultSet data) throws java.sql.SQLException
/*    */   {
/* 15 */     this.id = data.getInt("id");
/* 16 */     this.data = data.getString("data");
/* 17 */     this.expire = data.getInt("expire");
/* 18 */     this.type = BanType.getType(data.getString("type"));
/* 19 */     this.reason = data.getString("reason");
/*    */   }
/*    */   
/*    */   public Ban(int id, String data, long expire, BanType type, String reason) {
/* 23 */     this.id = id;
/* 24 */     this.data = data;
/* 25 */     this.expire = expire;
/* 26 */     this.type = type;
/* 27 */     this.reason = reason;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 31 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getData() {
/* 35 */     return this.data;
/*    */   }
/*    */   
/*    */   public long getExpire() {
/* 39 */     return this.expire;
/*    */   }
/*    */   
/*    */   public BanType getType() {
/* 43 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getReason() {
/* 47 */     return this.reason;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\moderation\types\Ban.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */