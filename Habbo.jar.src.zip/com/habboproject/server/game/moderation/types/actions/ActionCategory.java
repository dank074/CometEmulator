/*    */ package com.habboproject.server.game.moderation.types.actions;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.habboproject.server.storage.queries.moderation.PresetDao;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionCategory
/*    */ {
/*    */   private int categoryId;
/*    */   private String categoryName;
/* 15 */   private List<ActionPreset> presets = Lists.newArrayList();
/*    */   
/*    */   public ActionCategory(ResultSet resultSet) throws SQLException {
/* 18 */     this.categoryId = resultSet.getInt("id");
/* 19 */     this.categoryName = resultSet.getString("name");
/*    */     
/* 21 */     PresetDao.getActionPresetsForCategory(this.categoryId, this.presets);
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 25 */     this.presets.clear();
/*    */   }
/*    */   
/*    */   public int getCategoryId() {
/* 29 */     return this.categoryId;
/*    */   }
/*    */   
/*    */   public String getCategoryName() {
/* 33 */     return this.categoryName;
/*    */   }
/*    */   
/*    */   public List<ActionPreset> getPresets() {
/* 37 */     return this.presets;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\moderation\types\actions\ActionCategory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */