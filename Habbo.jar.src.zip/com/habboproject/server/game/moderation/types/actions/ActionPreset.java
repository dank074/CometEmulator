/*    */ package com.habboproject.server.game.moderation.types.actions;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class ActionPreset
/*    */ {
/*    */   private int id;
/*    */   private int categoryId;
/*    */   private String name;
/*    */   private String message;
/*    */   private String description;
/*    */   private int banLength;
/*    */   private int avatarBanLength;
/*    */   private int muteLength;
/*    */   private int tradeLockLength;
/*    */   
/*    */   public ActionPreset(ResultSet resultSet) throws SQLException
/*    */   {
/* 20 */     this.id = resultSet.getInt("id");
/* 21 */     this.categoryId = resultSet.getInt("category_id");
/* 22 */     this.name = resultSet.getString("name");
/* 23 */     this.message = resultSet.getString("message");
/* 24 */     this.description = resultSet.getString("description");
/*    */     
/* 26 */     this.banLength = resultSet.getInt("ban_hours");
/* 27 */     this.avatarBanLength = resultSet.getInt("avatar_ban_hours");
/* 28 */     this.muteLength = resultSet.getInt("mute_hours");
/* 29 */     this.tradeLockLength = resultSet.getInt("trade_lock_hours");
/*    */   }
/*    */   
/*    */   public int getId() {
/* 33 */     return this.id;
/*    */   }
/*    */   
/*    */   public int getCategoryId() {
/* 37 */     return this.categoryId;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 41 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 45 */     return this.message;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 49 */     return this.description;
/*    */   }
/*    */   
/*    */   public int getBanLength() {
/* 53 */     return this.banLength;
/*    */   }
/*    */   
/*    */   public int getAvatarBanLength() {
/* 57 */     return this.avatarBanLength;
/*    */   }
/*    */   
/*    */   public int getMuteLength() {
/* 61 */     return this.muteLength;
/*    */   }
/*    */   
/*    */   public int getTradeLockLength() {
/* 65 */     return this.tradeLockLength;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\moderation\types\actions\ActionPreset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */