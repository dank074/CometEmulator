/*    */ package com.habboproject.server.game.moderation.types.tickets;
/*    */ 
/*    */ public enum HelpTicketState {
/*  4 */   OPEN(1), 
/*  5 */   IN_PROGRESS(2), 
/*  6 */   CLOSED(0), 
/*  7 */   INVALID(0), 
/*  8 */   RESOLVED(0), 
/*  9 */   ABUSIVE(0);
/*    */   
/*    */   private int tabId;
/*    */   
/*    */   private HelpTicketState(int tabId) {
/* 14 */     this.tabId = tabId;
/*    */   }
/*    */   
/*    */   public int getTabId() {
/* 18 */     return this.tabId;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\moderation\types\tickets\HelpTicketState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */