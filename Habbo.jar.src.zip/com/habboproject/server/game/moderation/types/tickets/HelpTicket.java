/*     */ package com.habboproject.server.game.moderation.types.tickets;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.game.rooms.types.components.types.ChatMessage;
/*     */ import com.habboproject.server.storage.queries.moderation.TicketDao;
/*     */ import com.habboproject.server.storage.queries.player.PlayerDao;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HelpTicket
/*     */ {
/*     */   private int id;
/*     */   private int categoryId;
/*     */   private int roomId;
/*     */   private int dateSubmitted;
/*     */   private int dateClosed;
/*     */   private int submitterId;
/*     */   private int reportedId;
/*     */   private int moderatorId;
/*     */   private String message;
/*     */   private String submitterUsername;
/*     */   private String reportedUsername;
/*     */   private String moderatorUsername;
/*     */   private HelpTicketState state;
/*     */   private List<ChatMessage> chatMessages;
/*     */   
/*     */   public HelpTicket(int id, int categoryId, int dateSubmitted, int dateClosed, int submitterId, int reportedId, int moderatorId, String message, HelpTicketState state, List<ChatMessage> chatMessages, int roomId)
/*     */   {
/*  35 */     this.id = id;
/*  36 */     this.categoryId = categoryId;
/*  37 */     this.dateSubmitted = dateSubmitted;
/*  38 */     this.dateClosed = dateClosed;
/*  39 */     this.submitterId = submitterId;
/*  40 */     this.reportedId = reportedId;
/*  41 */     this.moderatorId = moderatorId;
/*  42 */     this.message = message;
/*  43 */     this.state = state;
/*  44 */     this.chatMessages = chatMessages;
/*  45 */     this.roomId = roomId;
/*     */   }
/*     */   
/*     */ 
/*     */   public void save()
/*     */   {
/*  51 */     TicketDao.saveTicket(this);
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg) {
/*  55 */     msg.writeInt(getId());
/*  56 */     msg.writeInt(getState().getTabId());
/*  57 */     msg.writeInt(3);
/*  58 */     msg.writeInt(getCategoryId());
/*  59 */     msg.writeInt((int)(Comet.getTime() - getDateSubmitted()) * 1000);
/*  60 */     msg.writeInt(1);
/*  61 */     msg.writeInt(0);
/*  62 */     msg.writeInt(getSubmitterId());
/*  63 */     msg.writeString(getSubmitterUsername());
/*  64 */     msg.writeInt(getReportedId());
/*  65 */     msg.writeString(getReportedUsername());
/*  66 */     msg.writeInt(getModeratorId());
/*  67 */     msg.writeString(getModeratorId() != 0 ? getModeratorUsername() : "");
/*  68 */     msg.writeString(getMessage());
/*  69 */     msg.writeInt(0);
/*  70 */     msg.writeInt(getChatMessages().size());
/*     */     
/*  72 */     for (ChatMessage chatMessage : getChatMessages()) {
/*  73 */       msg.writeString(chatMessage.getMessage());
/*  74 */       msg.writeInt(-1);
/*  75 */       msg.writeInt(-1);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getId() {
/*  80 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/*  84 */     this.id = id;
/*     */   }
/*     */   
/*     */   public int getDateSubmitted() {
/*  88 */     return this.dateSubmitted;
/*     */   }
/*     */   
/*     */   public void setDateSubmitted(int dateSubmitted) {
/*  92 */     this.dateSubmitted = dateSubmitted;
/*     */   }
/*     */   
/*     */   public int getDateClosed() {
/*  96 */     return this.dateClosed;
/*     */   }
/*     */   
/*     */   public void setDateClosed(int dateClosed) {
/* 100 */     this.dateClosed = dateClosed;
/*     */   }
/*     */   
/*     */   public int getSubmitterId() {
/* 104 */     return this.submitterId;
/*     */   }
/*     */   
/*     */   public void setSubmitterId(int submitterId) {
/* 108 */     this.submitterId = submitterId;
/*     */   }
/*     */   
/*     */   public int getReportedId() {
/* 112 */     return this.reportedId;
/*     */   }
/*     */   
/*     */   public void setReportedId(int reportedId) {
/* 116 */     this.reportedId = reportedId;
/*     */   }
/*     */   
/*     */   public int getModeratorId() {
/* 120 */     return this.moderatorId;
/*     */   }
/*     */   
/*     */   public void setModeratorId(int moderatorId) {
/* 124 */     this.moderatorId = moderatorId;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/* 128 */     return this.message;
/*     */   }
/*     */   
/*     */   public void setMessage(String message) {
/* 132 */     this.message = message;
/*     */   }
/*     */   
/*     */   public HelpTicketState getState() {
/* 136 */     return this.state;
/*     */   }
/*     */   
/*     */   public void setState(HelpTicketState state) {
/* 140 */     this.state = state;
/*     */   }
/*     */   
/*     */   public List<ChatMessage> getChatMessages() {
/* 144 */     return this.chatMessages;
/*     */   }
/*     */   
/*     */   public void setChatMessages(List<ChatMessage> chatMessages) {
/* 148 */     this.chatMessages = chatMessages;
/*     */   }
/*     */   
/*     */   public int getCategoryId() {
/* 152 */     return this.categoryId;
/*     */   }
/*     */   
/*     */   public void setCategoryId(int categoryId) {
/* 156 */     this.categoryId = categoryId;
/*     */   }
/*     */   
/*     */   public int getRoomId() {
/* 160 */     return this.roomId;
/*     */   }
/*     */   
/*     */   public void setRoomId(int roomId) {
/* 164 */     this.roomId = roomId;
/*     */   }
/*     */   
/*     */   public String getSubmitterUsername() {
/* 168 */     if (this.submitterUsername == null) {
/* 169 */       this.submitterUsername = PlayerDao.getUsernameByPlayerId(getSubmitterId());
/*     */     }
/*     */     
/* 172 */     return this.submitterUsername;
/*     */   }
/*     */   
/*     */   public String getReportedUsername() {
/* 176 */     if (this.reportedUsername == null) {
/* 177 */       this.reportedUsername = PlayerDao.getUsernameByPlayerId(getReportedId());
/*     */     }
/*     */     
/* 180 */     return this.reportedUsername;
/*     */   }
/*     */   
/*     */   public String getModeratorUsername() {
/* 184 */     if (this.moderatorUsername == null) {
/* 185 */       this.moderatorUsername = PlayerDao.getUsernameByPlayerId(getModeratorId());
/*     */     }
/*     */     
/* 188 */     return this.moderatorUsername;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\moderation\types\tickets\HelpTicket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */