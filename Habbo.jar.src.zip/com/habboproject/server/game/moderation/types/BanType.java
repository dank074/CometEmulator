/*   */ package com.habboproject.server.game.moderation.types;
/*   */ 
/*   */ public enum BanType {
/* 4 */   IP, 
/* 5 */   USER, 
/* 6 */   MACHINE;
/*   */   
/*   */   public static BanType getType(String type) {
/* 9 */     return type.equals("user") ? USER : type.equals("ip") ? IP : MACHINE;
/*   */   }
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\moderation\types\BanType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */