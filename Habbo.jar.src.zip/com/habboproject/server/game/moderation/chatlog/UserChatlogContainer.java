/*    */ package com.habboproject.server.game.moderation.chatlog;
/*    */ 
/*    */ import com.habboproject.server.logging.entries.RoomChatLogEntry;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class UserChatlogContainer
/*    */ {
/*    */   private List<LogSet> logs;
/*    */   
/*    */   public UserChatlogContainer()
/*    */   {
/* 14 */     this.logs = new ArrayList();
/*    */   }
/*    */   
/*    */   public void addAll(int roomId, List<RoomChatLogEntry> chatlogs) {
/* 18 */     if (chatlogs.size() < 1) {
/* 19 */       return;
/*    */     }
/* 21 */     this.logs.add(new LogSet(roomId, chatlogs));
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 25 */     for (LogSet logSet : this.logs) {
/* 26 */       logSet.getLogs().clear();
/*    */     }
/*    */     
/* 29 */     this.logs.clear();
/*    */   }
/*    */   
/*    */   public int size() {
/* 33 */     return this.logs.size();
/*    */   }
/*    */   
/*    */   public List<LogSet> getLogs() {
/* 37 */     return this.logs;
/*    */   }
/*    */   
/*    */   public class LogSet
/*    */   {
/*    */     private int roomId;
/*    */     private List<RoomChatLogEntry> logs;
/*    */     
/*    */     public LogSet(List<RoomChatLogEntry> roomId) {
/* 46 */       this.roomId = roomId;
/* 47 */       this.logs = logs;
/*    */     }
/*    */     
/*    */     public int getRoomId() {
/* 51 */       return this.roomId;
/*    */     }
/*    */     
/*    */     public List<RoomChatLogEntry> getLogs() {
/* 55 */       return this.logs;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\moderation\chatlog\UserChatlogContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */