/*     */ package com.habboproject.server.game.moderation;
/*     */ 
/*     */ import com.corundumstudio.socketio.misc.ConcurrentHashSet;
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.game.moderation.types.Ban;
/*     */ import com.habboproject.server.game.moderation.types.BanType;
/*     */ import com.habboproject.server.storage.queries.moderation.BanDao;
/*     */ import com.habboproject.server.utilities.Initializable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BanManager
/*     */   implements Initializable
/*     */ {
/*     */   public static BanManager banManagerInstance;
/*     */   private Map<String, Ban> bans;
/*     */   private Set<Integer> mutedPlayers;
/*  23 */   Logger log = Logger.getLogger(BanManager.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  31 */     this.mutedPlayers = new ConcurrentHashSet();
/*     */     
/*  33 */     loadBans();
/*  34 */     this.log.info("BanManager initialized");
/*     */   }
/*     */   
/*     */   public static BanManager getInstance() {
/*  38 */     if (banManagerInstance == null) {
/*  39 */       banManagerInstance = new BanManager();
/*     */     }
/*  41 */     return banManagerInstance;
/*     */   }
/*     */   
/*     */   public void loadBans() {
/*  45 */     if (this.bans != null) {
/*  46 */       this.bans.clear();
/*     */     }
/*     */     try {
/*  49 */       this.bans = BanDao.getActiveBans();
/*  50 */       this.log.info("Loaded " + this.bans.size() + " bans");
/*     */     } catch (Exception e) {
/*  52 */       this.log.error("Error while loading bans", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void tick() {
/*  57 */     List<Ban> bansToRemove = Lists.newArrayList();
/*     */     
/*  59 */     for (Ban ban : this.bans.values()) {
/*  60 */       if ((ban.getExpire() != 0L) && (Comet.getTime() >= ban.getExpire())) {
/*  61 */         bansToRemove.add(ban);
/*     */       }
/*     */     }
/*     */     
/*  65 */     if (bansToRemove.size() != 0) {
/*  66 */       for (Ban ban : bansToRemove) {
/*  67 */         this.bans.remove(ban.getData());
/*     */       }
/*     */     }
/*     */     
/*  71 */     bansToRemove.clear();
/*     */   }
/*     */   
/*     */   public void banPlayer(BanType type, String data, int length, long expire, String reason, int bannerId) {
/*  75 */     int banId = BanDao.createBan(type, length, expire, data, bannerId, reason);
/*  76 */     add(new Ban(banId, data, length == 0 ? length : expire, type, reason));
/*     */   }
/*     */   
/*     */   private void add(Ban ban) {
/*  80 */     this.bans.put(ban.getData(), ban);
/*     */   }
/*     */   
/*     */   public boolean hasBan(String data, BanType type) {
/*  84 */     if (this.bans.containsKey(data)) {
/*  85 */       Ban ban = (Ban)this.bans.get(data);
/*     */       
/*  87 */       if ((ban != null) && (ban.getType() == type)) {
/*  88 */         if ((ban.getExpire() != 0L) && (Comet.getTime() >= ban.getExpire())) {
/*  89 */           return false;
/*     */         }
/*     */         
/*  92 */         return true;
/*     */       }
/*     */     }
/*     */     
/*  96 */     return false;
/*     */   }
/*     */   
/*     */   public Ban get(String data) {
/* 100 */     return (Ban)this.bans.get(data);
/*     */   }
/*     */   
/*     */   public boolean isMuted(int playerId) {
/* 104 */     return this.mutedPlayers.contains(Integer.valueOf(playerId));
/*     */   }
/*     */   
/*     */   public void mute(int playerId) {
/* 108 */     this.mutedPlayers.add(Integer.valueOf(playerId));
/*     */   }
/*     */   
/*     */   public void unmute(int playerId) {
/* 112 */     this.mutedPlayers.remove(Integer.valueOf(playerId));
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\moderation\BanManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */