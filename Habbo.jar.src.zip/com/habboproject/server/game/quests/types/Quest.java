/*     */ package com.habboproject.server.game.quests.types;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.players.components.QuestComponent;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.quests.QuestManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ public class Quest
/*     */ {
/*     */   private final int id;
/*     */   private final String name;
/*     */   private final String category;
/*     */   private final int seriesNumber;
/*     */   private final int goalType;
/*     */   private final int goalData;
/*     */   private final int reward;
/*     */   private final QuestReward rewardType;
/*     */   private final String dataBit;
/*     */   private final QuestType questType;
/*     */   private final String badgeId;
/*     */   
/*     */   public Quest(ResultSet data)
/*     */     throws SQLException
/*     */   {
/*  28 */     this.id = data.getInt("id");
/*  29 */     this.name = data.getString("name");
/*  30 */     this.category = data.getString("category");
/*  31 */     this.seriesNumber = data.getInt("series_number");
/*  32 */     this.goalType = data.getInt("goal_type");
/*  33 */     this.goalData = data.getInt("goal_data");
/*     */     
/*  35 */     this.reward = data.getInt("reward");
/*  36 */     this.rewardType = QuestReward.valueOf(data.getString("reward_type"));
/*  37 */     this.dataBit = data.getString("data_bit");
/*     */     
/*  39 */     this.questType = QuestType.getById(this.goalType);
/*  40 */     this.badgeId = data.getString("badge_id");
/*     */   }
/*     */   
/*     */   public void compose(Player player, IComposer msg) {
/*  44 */     boolean startedQuest = player.getData().getQuestId() == getId();
/*  45 */     int progress = player.getQuests().getProgress(getId());
/*     */     
/*  47 */     msg.writeString(getCategory());
/*  48 */     msg.writeInt(player.getQuests().hasCompletedQuest(getId()) ? getSeriesNumber() : getSeriesNumber() - 1);
/*  49 */     msg.writeInt(QuestManager.getInstance().getAmountOfQuestsInCategory(getCategory()));
/*  50 */     msg.writeInt(0);
/*  51 */     msg.writeInt(getId());
/*  52 */     msg.writeBoolean(Boolean.valueOf(startedQuest));
/*  53 */     msg.writeString(getType().getAction());
/*  54 */     msg.writeString(getDataBit());
/*  55 */     msg.writeInt(0);
/*  56 */     msg.writeString(getName());
/*  57 */     msg.writeInt(progress);
/*  58 */     msg.writeInt(getGoalData());
/*  59 */     msg.writeInt(0);
/*  60 */     msg.writeString("");
/*  61 */     msg.writeString("");
/*  62 */     msg.writeBoolean(Boolean.valueOf(true));
/*     */   }
/*     */   
/*     */   public QuestType getType() {
/*  66 */     return this.questType;
/*     */   }
/*     */   
/*     */   public int getId() {
/*  70 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  74 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getCategory() {
/*  78 */     return this.category;
/*     */   }
/*     */   
/*     */   public int getSeriesNumber() {
/*  82 */     return this.seriesNumber;
/*     */   }
/*     */   
/*     */   public int getGoalType() {
/*  86 */     return this.goalType;
/*     */   }
/*     */   
/*     */   public int getGoalData() {
/*  90 */     return this.goalData;
/*     */   }
/*     */   
/*     */   public int getReward() {
/*  94 */     return this.reward;
/*     */   }
/*     */   
/*     */   public QuestReward getRewardType() {
/*  98 */     return this.rewardType;
/*     */   }
/*     */   
/*     */   public String getDataBit() {
/* 102 */     return this.dataBit;
/*     */   }
/*     */   
/*     */   public String getBadgeId() {
/* 106 */     return this.badgeId;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\quests\types\Quest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */