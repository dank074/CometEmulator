package com.habboproject.server.game.quests.types;

public enum QuestCategory {}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\quests\types\QuestCategory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */