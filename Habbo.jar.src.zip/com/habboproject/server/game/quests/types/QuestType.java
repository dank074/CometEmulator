/*    */ package com.habboproject.server.game.quests.types;
/*    */ 
/*    */ public enum QuestType
/*    */ {
/*  5 */   FURNI_MOVE(0, "MOVE_ITEM"), 
/*  6 */   FURNI_ROTATE(1, "ROTATE_ITEM"), 
/*  7 */   FURNI_PLACE(2, "PLACE_ITEM"), 
/*  8 */   FURNI_PICK(3, "PICKUP_ITEM"), 
/*  9 */   FURNI_SWITCH(4, "SWITCH_ITEM_STATE"), 
/* 10 */   FURNI_STACK(5, "STACK_ITEM"), 
/* 11 */   FURNI_DECORATION_FLOOR(6, "PLACE_FLOOR"), 
/* 12 */   FURNI_DECORATION_WALL(7, "PLACE_WALLPAPER"), 
/* 13 */   SOCIAL_VISIT(8, "ENTER_OTHERS_ROOM"), 
/* 14 */   SOCIAL_CHAT(9, "CHAT_WITH_SOMEONE"), 
/* 15 */   SOCIAL_FRIEND(10, "REQUEST_FRIEND"), 
/* 16 */   SOCIAL_RESPECT(11, "GIVE_RESPECT"), 
/* 17 */   SOCIAL_DANCE(12, "DANCE"), 
/* 18 */   SOCIAL_WAVE(13, "WAVE"), 
/* 19 */   PROFILE_CHANGE_LOOK(14, "CHANGE_FIGURE"), 
/* 20 */   PROFILE_CHANGE_MOTTO(15, "CHANGE_MOTTO"), 
/* 21 */   PROFILE_BADGE(16, "WEAR_BADGE"), 
/* 22 */   EXPLORE_FIND_ITEM(17, "FIND_STUFF");
/*    */   
/*    */   private int questType;
/*    */   private String action;
/*    */   
/*    */   private QuestType(int type, String action) {
/* 28 */     this.questType = type;
/* 29 */     this.action = action;
/*    */   }
/*    */   
/*    */   public int getQuestType() {
/* 33 */     return this.questType;
/*    */   }
/*    */   
/*    */ 
/* 37 */   public String getAction() { return this.action; }
/*    */   
/*    */   public static QuestType getById(int id) {
/*    */     QuestType[] arrayOfQuestType;
/* 41 */     int j = (arrayOfQuestType = values()).length; for (int i = 0; i < j; i++) { QuestType type = arrayOfQuestType[i];
/* 42 */       if (type.getQuestType() == id) {
/* 43 */         return type;
/*    */       }
/*    */     }
/*    */     
/* 47 */     return EXPLORE_FIND_ITEM;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\quests\types\QuestType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */