package com.habboproject.server.game.quests.types;

public enum QuestReward
{
  ACHIEVEMENT_POINTS,  VIP_POINTS,  ACTIVITY_POINTS,  CREDITS;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\quests\types\QuestReward.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */