/*    */ package com.habboproject.server.game.quests;
/*    */ 
/*    */ import com.habboproject.server.game.quests.types.Quest;
/*    */ import com.habboproject.server.storage.queries.quests.QuestsDao;
/*    */ import com.habboproject.server.utilities.Initializable;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class QuestManager implements Initializable
/*    */ {
/* 11 */   private static final Logger log = Logger.getLogger(QuestManager.class.getName());
/*    */   
/*    */ 
/*    */   private static QuestManager questManagerInstance;
/*    */   
/*    */ 
/*    */   private Map<String, Quest> quests;
/*    */   
/*    */ 
/*    */ 
/*    */   public void initialize()
/*    */   {
/* 23 */     loadQuests();
/*    */   }
/*    */   
/*    */   public void loadQuests() {
/* 27 */     if (this.quests != null) {
/* 28 */       this.quests.clear();
/*    */     }
/*    */     
/* 31 */     this.quests = QuestsDao.getAllQuests();
/* 32 */     log.info("Loaded " + this.quests.size() + " quests");
/* 33 */     log.info("QuestManager initialized");
/*    */   }
/*    */   
/*    */   public static QuestManager getInstance() {
/* 37 */     if (questManagerInstance == null) {
/* 38 */       questManagerInstance = new QuestManager();
/*    */     }
/*    */     
/* 41 */     return questManagerInstance;
/*    */   }
/*    */   
/*    */   public Quest getById(int questId) {
/* 45 */     for (Quest quest : this.quests.values()) {
/* 46 */       if (quest.getId() == questId) {
/* 47 */         return quest;
/*    */       }
/*    */     }
/* 50 */     return null;
/*    */   }
/*    */   
/*    */   public int getAmountOfQuestsInCategory(String category) {
/* 54 */     int count = 0;
/*    */     
/* 56 */     for (Quest quest : this.quests.values()) {
/* 57 */       if (quest.getCategory().equals(category)) {
/* 58 */         count++;
/*    */       }
/*    */     }
/*    */     
/* 62 */     return count;
/*    */   }
/*    */   
/*    */   public Quest getNextQuestInSeries(Quest lastQuest) {
/* 66 */     for (Quest quest : this.quests.values()) {
/* 67 */       if ((quest.getCategory().equals(lastQuest.getCategory())) && 
/* 68 */         (quest.getSeriesNumber() == lastQuest.getSeriesNumber() + 1)) {
/* 69 */         return quest;
/*    */       }
/*    */     }
/*    */     
/* 73 */     return null;
/*    */   }
/*    */   
/*    */   public Map<String, Quest> getQuests() {
/* 77 */     return this.quests;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\quests\QuestManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */