/*     */ package com.habboproject.server.game.groups.types;
/*     */ 
/*     */ import com.habboproject.server.game.groups.GroupManager;
/*     */ import com.habboproject.server.game.groups.types.components.forum.ForumComponent;
/*     */ import com.habboproject.server.game.groups.types.components.forum.settings.ForumSettings;
/*     */ import com.habboproject.server.game.groups.types.components.membership.MembershipComponent;
/*     */ import com.habboproject.server.game.rooms.RoomManager;
/*     */ import com.habboproject.server.network.messages.composers.MessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.group.GroupInformationMessageComposer;
/*     */ import com.habboproject.server.storage.queries.groups.GroupForumDao;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Group
/*     */ {
/*     */   private int id;
/*     */   private MembershipComponent membershipComponent;
/*     */   private ForumComponent forumComponent;
/*     */   
/*     */   public Group(int id)
/*     */   {
/*  34 */     this.id = id;
/*     */     
/*  36 */     this.membershipComponent = new MembershipComponent(this);
/*     */     
/*  38 */     if (getData().hasForum()) {
/*  39 */       initializeForum();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageComposer composeInformation(boolean flag, int playerId)
/*     */   {
/*  51 */     return new GroupInformationMessageComposer(this, RoomManager.getInstance().getRoomData(getData().getRoomId()), flag, playerId == getData().getOwnerId(), getMembershipComponent().getAdministrators().contains(Integer.valueOf(playerId)), 
/*  52 */       getMembershipComponent().getMembershipRequests().contains(Integer.valueOf(playerId)) ? 2 : getMembershipComponent().getMembers().containsKey(Integer.valueOf(playerId)) ? 1 : 0);
/*     */   }
/*     */   
/*     */   public void initializeForum() {
/*  56 */     ForumSettings forumSettings = GroupForumDao.getSettings(this.id);
/*     */     
/*  58 */     if (forumSettings == null) {
/*  59 */       forumSettings = GroupForumDao.createSettings(this.id);
/*     */     }
/*     */     
/*  62 */     this.forumComponent = new ForumComponent(this, forumSettings);
/*     */   }
/*     */   
/*     */   public void dispose() {
/*  66 */     if (this.membershipComponent != null) {
/*  67 */       this.membershipComponent.dispose();
/*     */     }
/*     */     
/*  70 */     if (this.forumComponent != null) {
/*  71 */       this.forumComponent.dispose();
/*     */     }
/*     */     
/*  74 */     GroupManager.getInstance().getLogger().debug("Group with id #" + getId() + " was disposed");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getId()
/*     */   {
/*  83 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GroupData getData()
/*     */   {
/*  92 */     return GroupManager.getInstance().getData(this.id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MembershipComponent getMembershipComponent()
/*     */   {
/* 101 */     return this.membershipComponent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ForumComponent getForumComponent()
/*     */   {
/* 110 */     return this.forumComponent;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\Group.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */