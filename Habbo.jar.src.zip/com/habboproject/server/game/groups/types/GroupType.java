/*    */ package com.habboproject.server.game.groups.types;
/*    */ 
/*    */ public enum GroupType {
/*  4 */   REGULAR(0),  EXCLUSIVE(1),  PRIVATE(2);
/*    */   
/*    */   private int typeId;
/*    */   
/*    */   private GroupType(int type) {
/*  9 */     this.typeId = type;
/*    */   }
/*    */   
/*    */   public int getTypeId() {
/* 13 */     return this.typeId;
/*    */   }
/*    */   
/*    */   public static GroupType valueOf(int typeId) {
/* 17 */     if (typeId == 0)
/* 18 */       return REGULAR;
/* 19 */     if (typeId == 1) {
/* 20 */       return EXCLUSIVE;
/*    */     }
/* 22 */     return PRIVATE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\GroupType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */