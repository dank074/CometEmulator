/*     */ package com.habboproject.server.game.groups.types.components.forum.threads;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.game.players.PlayerManager;
/*     */ import com.habboproject.server.game.players.data.PlayerAvatar;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForumThread
/*     */ {
/*     */   private int id;
/*     */   private String title;
/*     */   private int authorId;
/*     */   private int authorTimestamp;
/*     */   private int state;
/*     */   private boolean isLocked;
/*     */   private boolean isPinned;
/*     */   private int deleterId;
/*     */   private int deleterTime;
/*     */   private List<ForumThreadReply> replies;
/*     */   
/*     */   public ForumThread(int id, String title, String message, int authorId, int authorTimestamp, int state, boolean isLocked, boolean isPinned, int deleterId, int deleterTime)
/*     */   {
/*  32 */     this.id = id;
/*  33 */     this.title = title;
/*     */     
/*  35 */     this.authorId = authorId;
/*  36 */     this.authorTimestamp = authorTimestamp;
/*     */     
/*  38 */     this.state = state;
/*     */     
/*  40 */     this.isLocked = isLocked;
/*  41 */     this.isPinned = isPinned;
/*     */     
/*  43 */     this.deleterId = deleterId;
/*  44 */     this.deleterTime = deleterTime;
/*     */     
/*  46 */     this.replies = new ArrayList();
/*     */     
/*  48 */     this.replies.add(new ForumThreadReply(id, 0, message, id, authorId, authorTimestamp, state, 
/*  49 */       deleterId, deleterTime));
/*     */   }
/*     */   
/*     */   public void compose(int unreadMessages, IComposer msg) {
/*  53 */     msg.writeInt(getId());
/*     */     
/*  55 */     PlayerAvatar threadAuthor = PlayerManager.getInstance().getAvatarByPlayerId(getAuthorId(), (byte)0);
/*     */     
/*  57 */     msg.writeInt(threadAuthor == null ? 0 : threadAuthor.getId());
/*  58 */     msg.writeString(threadAuthor == null ? "Unknown Player" : threadAuthor.getUsername());
/*     */     
/*  60 */     msg.writeString(getTitle());
/*     */     
/*  62 */     msg.writeBoolean(Boolean.valueOf(isPinned()));
/*  63 */     msg.writeBoolean(Boolean.valueOf(isLocked()));
/*     */     
/*  65 */     msg.writeInt((int)Comet.getTime() - getAuthorTimestamp());
/*     */     
/*  67 */     msg.writeInt(getReplies().size());
/*     */     
/*  69 */     msg.writeInt(unreadMessages);
/*     */     
/*  71 */     PlayerAvatar replyAuthor = PlayerManager.getInstance().getAvatarByPlayerId(getMostRecentPost().getAuthorId(), (byte)0);
/*     */     
/*  73 */     msg.writeInt(replyAuthor == null ? 0 : getMostRecentPost().getId());
/*  74 */     msg.writeInt(replyAuthor == null ? 0 : replyAuthor.getId());
/*  75 */     msg.writeString(replyAuthor == null ? "Unknown Player" : replyAuthor.getUsername());
/*  76 */     msg.writeInt(replyAuthor == null ? 0 : (int)Comet.getTime() - getMostRecentPost().getAuthorTimestamp());
/*     */     
/*  78 */     msg.writeByte(getState());
/*     */     
/*  80 */     PlayerAvatar threadDeleter = PlayerManager.getInstance().getAvatarByPlayerId(getDeleterId(), (byte)0);
/*     */     
/*  82 */     msg.writeInt(threadDeleter == null ? 0 : getDeleterId());
/*  83 */     msg.writeString(threadDeleter == null ? "" : threadDeleter.getUsername());
/*  84 */     msg.writeInt(threadDeleter == null ? 0 : (int)Comet.getTime() - getDeleterTime());
/*     */   }
/*     */   
/*     */   public List<ForumThreadReply> getReplies(int startIndex) {
/*  88 */     List<ForumThreadReply> replies = Lists.newArrayList();
/*     */     
/*  90 */     for (ForumThreadReply reply : getReplies()) {
/*  91 */       replies.add(reply);
/*     */     }
/*     */     
/*     */ 
/*  95 */     return (List)replies.stream().skip(startIndex).limit(20L).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public ForumThreadReply getReplyById(int id) {
/*  99 */     for (ForumThreadReply reply : this.replies) {
/* 100 */       if (reply.getId() == id) {
/* 101 */         return reply;
/*     */       }
/*     */     }
/*     */     
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   public ForumThreadReply getMostRecentPost() {
/* 109 */     return (ForumThreadReply)this.replies.get(this.replies.size() - 1);
/*     */   }
/*     */   
/*     */   public void addReply(ForumThreadReply reply) {
/* 113 */     this.replies.add(reply);
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 117 */     this.replies.clear();
/*     */   }
/*     */   
/*     */   public int getId() {
/* 121 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/* 125 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getTitle() {
/* 129 */     return this.title;
/*     */   }
/*     */   
/*     */   public void setTitle(String title) {
/* 133 */     this.title = title;
/*     */   }
/*     */   
/*     */   public List<ForumThreadReply> getReplies() {
/* 137 */     return this.replies;
/*     */   }
/*     */   
/*     */   public void setReplies(List<ForumThreadReply> replies) {
/* 141 */     this.replies = replies;
/*     */   }
/*     */   
/*     */   public int getAuthorId() {
/* 145 */     return this.authorId;
/*     */   }
/*     */   
/*     */   public int getAuthorTimestamp() {
/* 149 */     return this.authorTimestamp;
/*     */   }
/*     */   
/*     */   public boolean isLocked() {
/* 153 */     return this.isLocked;
/*     */   }
/*     */   
/*     */   public void setIsLocked(boolean isLocked) {
/* 157 */     this.isLocked = isLocked;
/*     */   }
/*     */   
/*     */   public int getState() {
/* 161 */     return this.state;
/*     */   }
/*     */   
/*     */   public void setState(int state) {
/* 165 */     this.state = state;
/*     */   }
/*     */   
/*     */   public boolean isPinned() {
/* 169 */     return this.isPinned;
/*     */   }
/*     */   
/*     */   public void setIsPinned(boolean isPinned) {
/* 173 */     this.isPinned = isPinned;
/*     */   }
/*     */   
/*     */   public int getDeleterId() {
/* 177 */     return this.deleterId;
/*     */   }
/*     */   
/*     */   public void setDeleterId(int deleterId) {
/* 181 */     this.deleterId = deleterId;
/*     */   }
/*     */   
/*     */   public int getDeleterTime() {
/* 185 */     return this.deleterTime;
/*     */   }
/*     */   
/*     */   public void setDeleterTime(int deleterTime) {
/* 189 */     this.deleterTime = deleterTime;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\components\forum\threads\ForumThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */