/*    */ package com.habboproject.server.game.groups.types.components.forum.settings;
/*    */ 
/*    */ import com.habboproject.server.storage.queries.groups.GroupForumDao;
/*    */ 
/*    */ public class ForumSettings
/*    */ {
/*    */   private int groupId;
/*    */   private ForumPermission readPermission;
/*    */   private ForumPermission postPermission;
/*    */   private ForumPermission startThreadsPermission;
/*    */   private ForumPermission moderatePermission;
/*    */   
/*    */   public ForumSettings(int groupId, ForumPermission readPermission, ForumPermission postPermission, ForumPermission startThreadsPermission, ForumPermission moderatePermission)
/*    */   {
/* 15 */     this.groupId = groupId;
/* 16 */     this.readPermission = readPermission;
/* 17 */     this.postPermission = postPermission;
/* 18 */     this.startThreadsPermission = startThreadsPermission;
/* 19 */     this.moderatePermission = moderatePermission;
/*    */   }
/*    */   
/*    */   public void save() {
/* 23 */     GroupForumDao.saveSettings(this);
/*    */   }
/*    */   
/*    */   public int getGroupId() {
/* 27 */     return this.groupId;
/*    */   }
/*    */   
/*    */   public void setGroupId(int groupId) {
/* 31 */     this.groupId = groupId;
/*    */   }
/*    */   
/*    */   public ForumPermission getReadPermission() {
/* 35 */     return this.readPermission;
/*    */   }
/*    */   
/*    */   public void setReadPermission(ForumPermission readPermission) {
/* 39 */     this.readPermission = readPermission;
/*    */   }
/*    */   
/*    */   public ForumPermission getPostPermission() {
/* 43 */     return this.postPermission;
/*    */   }
/*    */   
/*    */   public void setPostPermission(ForumPermission postPermission) {
/* 47 */     this.postPermission = postPermission;
/*    */   }
/*    */   
/*    */   public ForumPermission getStartThreadsPermission() {
/* 51 */     return this.startThreadsPermission;
/*    */   }
/*    */   
/*    */   public void setStartThreadsPermission(ForumPermission startThreadsPermission) {
/* 55 */     this.startThreadsPermission = startThreadsPermission;
/*    */   }
/*    */   
/*    */   public ForumPermission getModeratePermission() {
/* 59 */     return this.moderatePermission;
/*    */   }
/*    */   
/*    */   public void setModeratePermission(ForumPermission moderatePermission) {
/* 63 */     this.moderatePermission = moderatePermission;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\components\forum\settings\ForumSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */