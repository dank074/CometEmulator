/*    */ package com.habboproject.server.game.groups.types.components.forum.settings;
/*    */ 
/*    */ public enum ForumPermission {
/*  4 */   EVERYBODY(0), 
/*  5 */   MEMBERS(1), 
/*  6 */   ADMINISTRATORS(2), 
/*  7 */   OWNER(3);
/*    */   
/*    */   private int permissionId;
/*    */   
/*    */   private ForumPermission(int permissionId) {
/* 12 */     this.permissionId = permissionId;
/*    */   }
/*    */   
/*    */   public int getPermissionId() {
/* 16 */     return this.permissionId;
/*    */   }
/*    */   
/*    */   public static ForumPermission getById(int id) {
/* 20 */     switch (id) {
/* 21 */     case 0:  return EVERYBODY;
/* 22 */     case 1:  return MEMBERS;
/* 23 */     case 2:  return ADMINISTRATORS;
/* 24 */     case 3:  return OWNER;
/*    */     }
/*    */     
/* 27 */     return MEMBERS;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\components\forum\settings\ForumPermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */