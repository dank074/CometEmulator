/*     */ package com.habboproject.server.game.groups.types.components.forum.threads;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.game.players.PlayerManager;
/*     */ import com.habboproject.server.game.players.data.PlayerAvatar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForumThreadReply
/*     */ {
/*     */   private int id;
/*     */   private int index;
/*     */   private String message;
/*     */   private int threadId;
/*     */   private int authorId;
/*     */   private int authorTimestamp;
/*     */   private int deleterId;
/*     */   private int deleterTime;
/*     */   private int state;
/*     */   
/*     */   public ForumThreadReply(int id, int index, String message, int threadId, int authorId, int authorTimestamp, int state, int deleterId, int deleterTime)
/*     */   {
/*  26 */     this.id = id;
/*  27 */     this.index = index;
/*  28 */     this.message = message;
/*  29 */     this.threadId = threadId;
/*  30 */     this.authorId = authorId;
/*  31 */     this.authorTimestamp = authorTimestamp;
/*  32 */     this.state = state;
/*  33 */     this.deleterId = deleterId;
/*  34 */     this.deleterTime = deleterTime;
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg) {
/*  38 */     PlayerAvatar replyAuthor = PlayerManager.getInstance().getAvatarByPlayerId(getAuthorId(), 
/*  39 */       (byte)0);
/*     */     
/*  41 */     msg.writeInt(getId());
/*  42 */     msg.writeInt(this.index);
/*     */     
/*  44 */     msg.writeInt(getAuthorId());
/*  45 */     msg.writeString(replyAuthor.getUsername());
/*  46 */     msg.writeString(replyAuthor.getFigure());
/*     */     
/*  48 */     msg.writeInt((int)Comet.getTime() - getAuthorTimestamp());
/*     */     
/*  50 */     msg.writeString(getMessage());
/*     */     
/*  52 */     msg.writeByte(getState());
/*     */     
/*  54 */     PlayerAvatar deleterReply = PlayerManager.getInstance().getAvatarByPlayerId(getDeleterId(), 
/*  55 */       (byte)0);
/*     */     
/*  57 */     msg.writeInt(deleterReply == null ? 0 : getDeleterId());
/*  58 */     msg.writeString(deleterReply == null ? "" : deleterReply.getUsername());
/*  59 */     msg.writeInt(deleterReply == null ? 0 : (int)Comet.getTime() - getDeleterTime());
/*     */     
/*  61 */     msg.writeInt(replyAuthor.getForumPosts());
/*     */   }
/*     */   
/*     */   public int getId() {
/*  65 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/*  69 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/*  73 */     return this.message;
/*     */   }
/*     */   
/*     */   public void setMessage(String message) {
/*  77 */     this.message = message;
/*     */   }
/*     */   
/*     */   public int getAuthorId() {
/*  81 */     return this.authorId;
/*     */   }
/*     */   
/*     */   public void setAuthorId(int authorId) {
/*  85 */     this.authorId = authorId;
/*     */   }
/*     */   
/*     */   public int getAuthorTimestamp() {
/*  89 */     return this.authorTimestamp;
/*     */   }
/*     */   
/*     */   public void setAuthorTimestamp(int authorTimestamp) {
/*  93 */     this.authorTimestamp = authorTimestamp;
/*     */   }
/*     */   
/*     */   public int getThreadId() {
/*  97 */     return this.threadId;
/*     */   }
/*     */   
/*     */   public int getIndex() {
/* 101 */     return this.index;
/*     */   }
/*     */   
/*     */   public void setIndex(int index) {
/* 105 */     this.index = index;
/*     */   }
/*     */   
/*     */   public int getState() {
/* 109 */     return this.state;
/*     */   }
/*     */   
/*     */   public void setState(int state) {
/* 113 */     this.state = state;
/*     */   }
/*     */   
/*     */   public int getDeleterId() {
/* 117 */     return this.deleterId;
/*     */   }
/*     */   
/*     */   public void setDeleterId(int deleterId) {
/* 121 */     this.deleterId = deleterId;
/*     */   }
/*     */   
/*     */   public int getDeleterTime() {
/* 125 */     return this.deleterTime;
/*     */   }
/*     */   
/*     */   public void setDeleterTime(int deleterTime) {
/* 129 */     this.deleterTime = deleterTime;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\components\forum\threads\ForumThreadReply.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */