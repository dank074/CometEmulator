/*     */ package com.habboproject.server.game.groups.types.components.membership;
/*     */ 
/*     */ import com.habboproject.server.game.groups.types.Group;
/*     */ import com.habboproject.server.game.groups.types.GroupAccessLevel;
/*     */ import com.habboproject.server.game.groups.types.GroupMember;
/*     */ import com.habboproject.server.game.groups.types.components.GroupComponent;
/*     */ import com.habboproject.server.storage.queries.groups.GroupMemberDao;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.collections4.map.ListOrderedMap;
/*     */ import org.apache.commons.collections4.set.ListOrderedSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MembershipComponent
/*     */   implements GroupComponent
/*     */ {
/*     */   private Group group;
/*     */   private Map<Integer, GroupMember> groupMembers;
/*     */   private Set<Integer> groupAdministrators;
/*     */   private Set<Integer> groupMembershipRequests;
/*     */   
/*     */   public MembershipComponent(Group group)
/*     */   {
/*  43 */     this.group = group;
/*     */     
/*  45 */     this.groupMembers = new ListOrderedMap();
/*  46 */     this.groupAdministrators = new ListOrderedSet();
/*  47 */     this.groupMembershipRequests = new ListOrderedSet();
/*     */     
/*  49 */     loadMemberships();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void loadMemberships()
/*     */   {
/*  56 */     for (GroupMember groupMember : GroupMemberDao.getAllByGroupId(this.group.getId())) {
/*  57 */       createMembership(groupMember);
/*     */     }
/*     */     
/*  60 */     for (Integer playerId : GroupMemberDao.getAllRequestsByGroupId(this.group.getId())) {
/*  61 */       this.groupMembershipRequests.add(playerId);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createMembership(GroupMember groupMember)
/*     */   {
/*  71 */     if (groupMember.getMembershipId() == 0) {
/*  72 */       groupMember.setMembershipId(GroupMemberDao.create(groupMember));
/*     */     }
/*  74 */     if (this.groupMembers.containsKey(Integer.valueOf(groupMember.getPlayerId()))) {
/*  75 */       this.groupMembers.remove(Integer.valueOf(groupMember.getPlayerId()));
/*     */     }
/*  77 */     if (groupMember.getAccessLevel().isAdmin()) {
/*  78 */       this.groupAdministrators.add(Integer.valueOf(groupMember.getPlayerId()));
/*     */     }
/*  80 */     this.groupMembers.put(Integer.valueOf(groupMember.getPlayerId()), groupMember);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeMembership(int playerId)
/*     */   {
/*  89 */     if (!this.groupMembers.containsKey(Integer.valueOf(playerId))) {
/*  90 */       return;
/*     */     }
/*  92 */     int groupMembershipId = ((GroupMember)this.groupMembers.get(Integer.valueOf(playerId))).getMembershipId();
/*     */     
/*  94 */     GroupMemberDao.delete(groupMembershipId);
/*     */     
/*  96 */     this.groupMembers.remove(Integer.valueOf(playerId));
/*     */     
/*  98 */     if (this.groupAdministrators.contains(Integer.valueOf(playerId))) {
/*  99 */       this.groupAdministrators.remove(Integer.valueOf(playerId));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createRequest(int playerId)
/*     */   {
/* 108 */     if (this.groupMembers.containsKey(Integer.valueOf(playerId))) {
/* 109 */       return;
/*     */     }
/* 111 */     if (this.groupMembershipRequests.contains(Integer.valueOf(playerId))) {
/* 112 */       return;
/*     */     }
/* 114 */     this.groupMembershipRequests.add(Integer.valueOf(playerId));
/* 115 */     GroupMemberDao.createRequest(this.group.getId(), playerId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clearRequests()
/*     */   {
/* 122 */     if (this.groupMembershipRequests.size() == 0) {
/* 123 */       return;
/*     */     }
/* 125 */     this.groupMembershipRequests.clear();
/* 126 */     GroupMemberDao.clearRequests(this.group.getId());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removeRequest(int playerId)
/*     */   {
/* 133 */     if (!this.groupMembershipRequests.contains(Integer.valueOf(playerId))) {
/* 134 */       return;
/*     */     }
/* 136 */     this.groupMembershipRequests.remove(Integer.valueOf(playerId));
/*     */     
/* 138 */     GroupMemberDao.deleteRequest(this.group.getId(), playerId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 146 */     this.groupMembers.clear();
/* 147 */     this.groupAdministrators.clear();
/* 148 */     this.groupMembershipRequests.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Integer, GroupMember> getMembers()
/*     */   {
/* 157 */     return this.groupMembers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<GroupMember> getMembersAsList()
/*     */   {
/* 166 */     List<GroupMember> groupMembers = new ArrayList();
/*     */     
/* 168 */     for (GroupMember groupMember : getMembers().values()) {
/* 169 */       groupMembers.add(groupMember);
/*     */     }
/*     */     
/* 172 */     return groupMembers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Integer> getAdministrators()
/*     */   {
/* 181 */     return this.groupAdministrators;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Integer> getMembershipRequests()
/*     */   {
/* 190 */     return this.groupMembershipRequests;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Group getGroup()
/*     */   {
/* 200 */     return this.group;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\components\membership\MembershipComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */