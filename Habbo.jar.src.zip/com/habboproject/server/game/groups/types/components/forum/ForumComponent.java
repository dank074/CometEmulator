/*     */ package com.habboproject.server.game.groups.types.components.forum;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.groups.types.Group;
/*     */ import com.habboproject.server.game.groups.types.GroupData;
/*     */ import com.habboproject.server.game.groups.types.components.forum.settings.ForumSettings;
/*     */ import com.habboproject.server.game.groups.types.components.forum.threads.ForumThread;
/*     */ import com.habboproject.server.game.groups.types.components.forum.threads.ForumThreadReply;
/*     */ import com.habboproject.server.game.players.PlayerManager;
/*     */ import com.habboproject.server.game.players.data.PlayerAvatar;
/*     */ import com.habboproject.server.storage.queries.groups.GroupForumThreadDao;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ public class ForumComponent implements com.habboproject.server.game.groups.types.components.GroupComponent
/*     */ {
/*     */   public static final int MAX_MESSAGES_PER_PAGE = 20;
/*     */   private Group group;
/*     */   private ForumSettings forumSettings;
/*     */   private List<Integer> pinnedThreads;
/*     */   private Map<Integer, ForumThread> forumThreads;
/*     */   private Map<Integer, Map<Integer, Integer>> playerViews;
/*     */   
/*     */   public ForumComponent(Group group, ForumSettings forumSettings)
/*     */   {
/*  34 */     this.group = group;
/*  35 */     this.forumSettings = forumSettings;
/*  36 */     this.forumThreads = GroupForumThreadDao.getAllMessagesForGroup(this.group.getId());
/*  37 */     this.playerViews = GroupForumThreadDao.getAllPlayerViewsForGroup(this.group.getId());
/*  38 */     this.pinnedThreads = Lists.newArrayList();
/*     */     
/*  40 */     for (ForumThread forumThread : this.forumThreads.values()) {
/*  41 */       if (forumThread.isPinned()) {
/*  42 */         this.pinnedThreads.add(Integer.valueOf(forumThread.getId()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int playerViews() {
/*  48 */     return this.playerViews.size();
/*     */   }
/*     */   
/*     */   public int threadsSize() {
/*  52 */     return this.forumThreads.size();
/*     */   }
/*     */   
/*     */   public int repliesSize() {
/*  56 */     int replies = 0;
/*  57 */     for (ForumThread thread : this.forumThreads.values()) {
/*  58 */       replies += thread.getReplies().size();
/*     */     }
/*  60 */     return replies;
/*     */   }
/*     */   
/*     */   public double getScore() {
/*  64 */     double score = 0.0D;
/*  65 */     for (int i = 0; i < threadsSize(); i++) {
/*  66 */       score += 0.25D;
/*     */     }
/*     */     
/*  69 */     return score;
/*     */   }
/*     */   
/*     */   public void addView(int threadId, int playerId, int time) {
/*  73 */     if (!this.playerViews.containsKey(Integer.valueOf(threadId))) {
/*  74 */       this.playerViews.put(Integer.valueOf(threadId), Maps.newHashMap());
/*  75 */       ((Map)this.playerViews.get(Integer.valueOf(threadId))).put(Integer.valueOf(playerId), Integer.valueOf(time));
/*     */       
/*  77 */       GroupForumThreadDao.registerPlayerView(this.group.getId(), threadId, playerId, time);
/*     */       
/*  79 */       return;
/*     */     }
/*     */     
/*  82 */     if (!((Map)this.playerViews.get(Integer.valueOf(threadId))).containsKey(Integer.valueOf(playerId))) {
/*  83 */       ((Map)this.playerViews.get(Integer.valueOf(threadId))).put(Integer.valueOf(playerId), Integer.valueOf(time));
/*     */       
/*  85 */       GroupForumThreadDao.registerPlayerView(this.group.getId(), threadId, playerId, time);
/*     */       
/*  87 */       return;
/*     */     }
/*     */     
/*  90 */     ((Map)this.playerViews.get(Integer.valueOf(threadId))).remove(Integer.valueOf(playerId));
/*  91 */     ((Map)this.playerViews.get(Integer.valueOf(threadId))).put(Integer.valueOf(playerId), Integer.valueOf(time));
/*     */     
/*  93 */     GroupForumThreadDao.updatePlayerView(this.group.getId(), threadId, playerId, time);
/*     */   }
/*     */   
/*     */   public void markAsRead(int playerId, int time) {
/*  97 */     for (ForumThread thread : this.forumThreads.values())
/*  98 */       if (thread != null)
/*     */       {
/*     */ 
/* 101 */         if (!this.playerViews.containsKey(Integer.valueOf(thread.getId()))) {
/* 102 */           this.playerViews.put(Integer.valueOf(thread.getId()), Maps.newHashMap());
/* 103 */           ((Map)this.playerViews.get(Integer.valueOf(thread.getId()))).put(Integer.valueOf(playerId), Integer.valueOf(time));
/*     */           
/* 105 */           GroupForumThreadDao.registerPlayerView(this.group.getId(), thread.getId(), playerId, time);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 110 */         else if (!((Map)this.playerViews.get(Integer.valueOf(thread.getId()))).containsKey(Integer.valueOf(playerId))) {
/* 111 */           ((Map)this.playerViews.get(Integer.valueOf(thread.getId()))).put(Integer.valueOf(playerId), Integer.valueOf(time));
/*     */           
/* 113 */           GroupForumThreadDao.registerPlayerView(this.group.getId(), thread.getId(), playerId, time);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 118 */           ((Map)this.playerViews.get(Integer.valueOf(thread.getId()))).remove(Integer.valueOf(playerId));
/* 119 */           ((Map)this.playerViews.get(Integer.valueOf(thread.getId()))).put(Integer.valueOf(playerId), Integer.valueOf(time));
/*     */           
/* 121 */           GroupForumThreadDao.updatePlayerView(this.group.getId(), thread.getId(), playerId, time);
/*     */         } }
/*     */   }
/*     */   
/*     */   public int getUnreadThreads(int playerId) {
/* 126 */     int unreadThreads = 0;
/* 127 */     for (ForumThread thread : this.forumThreads.values()) {
/* 128 */       if ((!this.playerViews.containsKey(Integer.valueOf(thread.getId()))) || 
/* 129 */         (!((Map)this.playerViews.get(Integer.valueOf(thread.getId()))).containsKey(Integer.valueOf(playerId)))) {
/* 130 */         unreadThreads += thread.getReplies().size();
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 135 */         long lastView = ((Integer)((Map)this.playerViews.get(Integer.valueOf(thread.getId()))).get(Integer.valueOf(playerId))).intValue();
/*     */         
/* 137 */         for (ForumThreadReply reply : thread.getReplies()) {
/* 138 */           if (reply.getAuthorTimestamp() > lastView)
/*     */           {
/*     */ 
/* 141 */             unreadThreads++; }
/*     */         }
/*     */       }
/*     */     }
/* 145 */     return unreadThreads;
/*     */   }
/*     */   
/*     */   public int getUnreadThreadReplies(int playerId, int threadId) {
/* 149 */     int unreadReplies = 0;
/*     */     
/* 151 */     ForumThread thread = (ForumThread)this.forumThreads.get(Integer.valueOf(threadId));
/*     */     
/* 153 */     if (thread != null) {
/* 154 */       if ((!this.playerViews.containsKey(Integer.valueOf(threadId))) || (!((Map)this.playerViews.get(Integer.valueOf(threadId))).containsKey(Integer.valueOf(playerId)))) {
/* 155 */         return thread.getReplies().size();
/*     */       }
/*     */       
/* 158 */       long lastView = ((Integer)((Map)this.playerViews.get(Integer.valueOf(threadId))).get(Integer.valueOf(playerId))).intValue();
/*     */       
/* 160 */       for (ForumThreadReply reply : thread.getReplies()) {
/* 161 */         if (reply.getAuthorTimestamp() > lastView)
/*     */         {
/*     */ 
/* 164 */           unreadReplies++;
/*     */         }
/*     */       }
/*     */     }
/* 168 */     return unreadReplies;
/*     */   }
/*     */   
/*     */   public void composeData(int playerId, IComposer msg) {
/* 172 */     msg.writeInt(this.group.getId());
/*     */     
/* 174 */     msg.writeString(this.group.getData().getTitle());
/* 175 */     msg.writeString(this.group.getData().getDescription());
/* 176 */     msg.writeString(this.group.getData().getBadge());
/*     */     
/* 178 */     msg.writeInt(threadsSize());
/* 179 */     msg.writeInt((int)Math.abs(getScore()));
/* 180 */     msg.writeInt(repliesSize());
/*     */     
/* 182 */     msg.writeInt(getUnreadThreads(playerId));
/*     */     
/* 184 */     if (getMostRecentPost() == null) {
/* 185 */       msg.writeInt(-1);
/* 186 */       msg.writeInt(-1);
/* 187 */       msg.writeString("");
/* 188 */       msg.writeInt(0);
/* 189 */       return;
/*     */     }
/*     */     
/* 192 */     PlayerAvatar lastPlayer = PlayerManager.getInstance().getAvatarByPlayerId(getMostRecentPost().getAuthorId(), 
/* 193 */       (byte)0);
/*     */     
/* 195 */     msg.writeInt(getMostRecentPost().getId());
/*     */     
/* 197 */     msg.writeInt(lastPlayer == null ? 0 : lastPlayer.getId());
/* 198 */     msg.writeString(lastPlayer == null ? "Unknow Player" : lastPlayer.getUsername());
/* 199 */     msg.writeInt(lastPlayer == null ? 0 : (int)com.habboproject.server.boot.Comet.getTime() - getMostRecentPost().getAuthorTimestamp());
/*     */   }
/*     */   
/*     */   public List<ForumThread> getForumThreads(int startIndex) {
/* 203 */     ArrayList<ForumThread> threads = Lists.newArrayList();
/*     */     
/* 205 */     for (Integer threadId : getPinnedThreads()) {
/* 206 */       ForumThread forumThread = null;
/* 207 */       if ((forumThread = (ForumThread)getForumThreads().get(threadId)) != null) {
/* 208 */         threads.add(forumThread);
/*     */       }
/*     */     }
/*     */     
/* 212 */     for (ForumThread forumThread : this.group.getForumComponent().getForumThreads().values()) {
/* 213 */       if (!forumThread.isPinned()) {
/* 214 */         threads.add(forumThread);
/*     */       }
/*     */     }
/*     */     
/* 218 */     return (List)threads.stream().skip(startIndex).limit(20L).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public ForumThreadReply getMostRecentPost() {
/* 222 */     Iterator<Map.Entry<Integer, ForumThread>> threads = this.forumThreads.entrySet().iterator();
/*     */     
/* 224 */     ForumThread lastThread = null;
/* 225 */     while (threads.hasNext()) {
/* 226 */       lastThread = (ForumThread)((Map.Entry)threads.next()).getValue();
/*     */     }
/*     */     
/* 229 */     if (lastThread == null) {
/* 230 */       return null;
/*     */     }
/*     */     
/* 233 */     return lastThread.getMostRecentPost();
/*     */   }
/*     */   
/*     */   public void dispose()
/*     */   {
/* 238 */     for (ForumThread forumThread : this.forumThreads.values()) {
/* 239 */       forumThread.dispose();
/*     */     }
/*     */     
/* 242 */     this.forumThreads.clear();
/* 243 */     this.pinnedThreads.clear();
/* 244 */     this.playerViews.clear();
/*     */   }
/*     */   
/*     */   public Group getGroup()
/*     */   {
/* 249 */     return this.group;
/*     */   }
/*     */   
/*     */   public ForumSettings getForumSettings() {
/* 253 */     return this.forumSettings;
/*     */   }
/*     */   
/*     */   public Map<Integer, ForumThread> getForumThreads() {
/* 257 */     return this.forumThreads;
/*     */   }
/*     */   
/*     */   public List<Integer> getPinnedThreads() {
/* 261 */     return this.pinnedThreads;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\components\forum\ForumComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */