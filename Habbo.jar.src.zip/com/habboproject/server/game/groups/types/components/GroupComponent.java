package com.habboproject.server.game.groups.types.components;

import com.habboproject.server.game.groups.types.Group;

public abstract interface GroupComponent
{
  public abstract Group getGroup();
  
  public abstract void dispose();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\components\GroupComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */