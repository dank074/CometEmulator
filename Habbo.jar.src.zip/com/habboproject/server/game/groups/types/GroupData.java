/*     */ package com.habboproject.server.game.groups.types;
/*     */ 
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.storage.queries.groups.GroupDao;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupData
/*     */ {
/*     */   private int id;
/*     */   private String title;
/*     */   private String description;
/*     */   private String badge;
/*     */   private int ownerId;
/*     */   private int roomId;
/*     */   private int created;
/*     */   private GroupType type;
/*     */   private int colourA;
/*     */   private int colourB;
/*     */   private boolean canMembersDecorate;
/*     */   private boolean hasForum;
/*     */   
/*     */   public GroupData(ResultSet data)
/*     */     throws SQLException
/*     */   {
/*  80 */     this.id = data.getInt("id");
/*  81 */     this.title = data.getString("name");
/*  82 */     this.description = data.getString("description");
/*  83 */     this.badge = data.getString("badge");
/*  84 */     this.ownerId = data.getInt("owner_id");
/*  85 */     this.created = data.getInt("created");
/*  86 */     this.roomId = data.getInt("room_id");
/*  87 */     this.type = GroupType.valueOf(data.getString("type").toUpperCase());
/*  88 */     this.colourA = data.getInt("colour1");
/*  89 */     this.colourB = data.getInt("colour2");
/*  90 */     this.canMembersDecorate = data.getString("members_deco").equals("1");
/*  91 */     this.hasForum = data.getString("has_forum").equals("1");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GroupData(String title, String description, String badge, int ownerId, int roomId, int colourA, int colourB)
/*     */   {
/* 107 */     this.id = -1;
/* 108 */     this.title = title;
/* 109 */     this.description = description;
/* 110 */     this.badge = badge.replace("s00000", "");
/* 111 */     this.ownerId = ownerId;
/* 112 */     this.roomId = roomId;
/* 113 */     this.created = ((int)Comet.getTime());
/* 114 */     this.type = GroupType.REGULAR;
/* 115 */     this.colourA = colourA;
/* 116 */     this.colourB = colourB;
/* 117 */     this.canMembersDecorate = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save()
/*     */   {
/* 125 */     GroupDao.save(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getId()
/*     */   {
/* 134 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(int id)
/*     */   {
/* 143 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTitle()
/*     */   {
/* 152 */     return this.title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String title)
/*     */   {
/* 161 */     this.title = title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 170 */     return this.description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/* 179 */     this.description = description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOwnerId()
/*     */   {
/* 188 */     return this.ownerId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOwnerId(int id)
/*     */   {
/* 197 */     this.ownerId = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBadge()
/*     */   {
/* 206 */     return this.badge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBadge(String badge)
/*     */   {
/* 215 */     this.badge = badge.replace("s00000", "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRoomId()
/*     */   {
/* 224 */     return this.roomId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRoomId(int roomId)
/*     */   {
/* 233 */     this.roomId = roomId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCreatedTimestamp()
/*     */   {
/* 242 */     return this.created;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canMembersDecorate()
/*     */   {
/* 251 */     return this.canMembersDecorate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCanMembersDecorate(boolean canMembersDecorate)
/*     */   {
/* 260 */     this.canMembersDecorate = canMembersDecorate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GroupType getType()
/*     */   {
/* 269 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(GroupType type)
/*     */   {
/* 278 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColourA()
/*     */   {
/* 287 */     return this.colourA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColourA(int colourA)
/*     */   {
/* 296 */     this.colourA = colourA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColourB()
/*     */   {
/* 305 */     return this.colourB;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColourB(int colourB)
/*     */   {
/* 314 */     this.colourB = colourB;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasForum()
/*     */   {
/* 323 */     return this.hasForum;
/*     */   }
/*     */   
/*     */   public void setHasForum(boolean hasForum) {
/* 327 */     this.hasForum = hasForum;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\GroupData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */