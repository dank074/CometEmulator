/*   */ package com.habboproject.server.game.groups.types;
/*   */ 
/*   */ public enum GroupAccessLevel {
/* 4 */   MEMBER,  ADMIN,  OWNER;
/*   */   
/*   */   public boolean isAdmin() {
/* 7 */     return (equals(ADMIN)) || (equals(OWNER));
/*   */   }
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\GroupAccessLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */