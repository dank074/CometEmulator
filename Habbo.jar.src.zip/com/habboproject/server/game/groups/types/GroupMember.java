/*     */ package com.habboproject.server.game.groups.types;
/*     */ 
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.storage.queries.groups.GroupMemberDao;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupMember
/*     */ {
/*     */   private int membershipId;
/*     */   private int playerId;
/*     */   private int groupId;
/*     */   private GroupAccessLevel accessLevel;
/*     */   private int dateJoined;
/*     */   
/*     */   public GroupMember(ResultSet data)
/*     */     throws SQLException
/*     */   {
/*  43 */     this.membershipId = data.getInt("id");
/*  44 */     this.playerId = data.getInt("player_id");
/*  45 */     this.accessLevel = GroupAccessLevel.valueOf(data.getString("access_level").toUpperCase());
/*  46 */     this.groupId = data.getInt("group_id");
/*  47 */     this.dateJoined = data.getInt("date_joined");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GroupMember(int playerId, int groupId, GroupAccessLevel accessLevel)
/*     */   {
/*  58 */     this.membershipId = 0;
/*  59 */     this.playerId = playerId;
/*  60 */     this.groupId = groupId;
/*  61 */     this.accessLevel = accessLevel;
/*  62 */     this.dateJoined = ((int)Comet.getTime());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMembershipId()
/*     */   {
/*  71 */     return this.membershipId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMembershipId(int membershipId)
/*     */   {
/*  80 */     this.membershipId = membershipId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPlayerId()
/*     */   {
/*  89 */     return this.playerId;
/*     */   }
/*     */   
/*     */   public int getGroupId() {
/*  93 */     return this.groupId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GroupAccessLevel getAccessLevel()
/*     */   {
/* 102 */     return this.accessLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccessLevel(GroupAccessLevel accessLevel)
/*     */   {
/* 111 */     this.accessLevel = accessLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDateJoined()
/*     */   {
/* 120 */     return this.dateJoined;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void save()
/*     */   {
/* 127 */     GroupMemberDao.save(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\types\GroupMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */