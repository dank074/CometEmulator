/*    */ package com.habboproject.server.game.groups.items;
/*    */ 
/*    */ import com.habboproject.server.game.groups.items.types.GroupBackgroundColour;
/*    */ import com.habboproject.server.game.groups.items.types.GroupBaseColour;
/*    */ import com.habboproject.server.game.groups.items.types.GroupSymbol;
/*    */ import com.habboproject.server.game.groups.items.types.GroupSymbolColour;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class GroupItemManager
/*    */ {
/*    */   private List<com.habboproject.server.game.groups.items.types.GroupBase> bases;
/*    */   private List<GroupSymbol> symbols;
/*    */   private List<GroupBaseColour> baseColours;
/*    */   private Map<Integer, GroupSymbolColour> symbolColours;
/*    */   private Map<Integer, GroupBackgroundColour> backgroundColours;
/* 20 */   private static final Logger log = Logger.getLogger(GroupItemManager.class.getName());
/*    */   
/*    */   public GroupItemManager() {
/* 23 */     load();
/*    */   }
/*    */   
/*    */   public void load() {
/* 27 */     if (this.bases == null)
/*    */     {
/* 29 */       this.bases = new ArrayList();
/* 30 */       this.symbols = new ArrayList();
/* 31 */       this.baseColours = new ArrayList();
/* 32 */       this.symbolColours = new HashMap();
/* 33 */       this.backgroundColours = new HashMap();
/*    */     } else {
/* 35 */       this.bases.clear();
/* 36 */       this.symbols.clear();
/* 37 */       this.baseColours.clear();
/* 38 */       this.symbolColours.clear();
/* 39 */       this.backgroundColours.clear();
/*    */     }
/*    */     
/* 42 */     int itemCount = com.habboproject.server.storage.queries.groups.GroupItemDao.loadGroupItems(this.bases, this.symbols, this.baseColours, this.symbolColours, this.backgroundColours);
/*    */     
/* 44 */     log.info("Loaded " + itemCount + " group items");
/*    */   }
/*    */   
/*    */   public List<com.habboproject.server.game.groups.items.types.GroupBase> getBases() {
/* 48 */     return this.bases;
/*    */   }
/*    */   
/*    */   public List<GroupSymbol> getSymbols() {
/* 52 */     return this.symbols;
/*    */   }
/*    */   
/*    */   public List<GroupBaseColour> getBaseColours() {
/* 56 */     return this.baseColours;
/*    */   }
/*    */   
/*    */   public Map<Integer, GroupSymbolColour> getSymbolColours() {
/* 60 */     return this.symbolColours;
/*    */   }
/*    */   
/*    */   public Map<Integer, GroupBackgroundColour> getBackgroundColours() {
/* 64 */     return this.backgroundColours;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\items\GroupItemManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */