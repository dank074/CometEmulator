/*    */ package com.habboproject.server.game.groups.items.types;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ 
/*    */ public class GroupBaseColour
/*    */ {
/*    */   private int id;
/*    */   private String colour;
/*    */   
/*    */   public GroupBaseColour(ResultSet data) throws java.sql.SQLException
/*    */   {
/* 12 */     this.id = data.getInt("id");
/* 13 */     this.colour = data.getString("firstvalue");
/*    */   }
/*    */   
/*    */   public int getId() {
/* 17 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getColour() {
/* 21 */     return this.colour;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\items\types\GroupBaseColour.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */