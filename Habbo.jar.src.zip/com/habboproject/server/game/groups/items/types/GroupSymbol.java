/*    */ package com.habboproject.server.game.groups.items.types;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ 
/*    */ public class GroupSymbol
/*    */ {
/*    */   private int id;
/*    */   private String valueA;
/*    */   private String valueB;
/*    */   
/*    */   public GroupSymbol(ResultSet data) throws java.sql.SQLException
/*    */   {
/* 13 */     this.id = data.getInt("id");
/* 14 */     this.valueA = data.getString("firstvalue");
/* 15 */     this.valueB = data.getString("secondvalue");
/*    */   }
/*    */   
/*    */   public int getId() {
/* 19 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getValueA() {
/* 23 */     return this.valueA;
/*    */   }
/*    */   
/*    */   public String getValueB() {
/* 27 */     return this.valueB;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\items\types\GroupSymbol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */