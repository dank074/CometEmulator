/*     */ package com.habboproject.server.game.groups;
/*     */ 
/*     */ import com.google.common.collect.Maps;
/*     */ import com.habboproject.server.game.groups.items.GroupItemManager;
/*     */ import com.habboproject.server.game.groups.types.Group;
/*     */ import com.habboproject.server.game.groups.types.GroupData;
/*     */ import com.habboproject.server.game.groups.types.components.membership.MembershipComponent;
/*     */ import com.habboproject.server.storage.queries.groups.GroupDao;
/*     */ import com.habboproject.server.utilities.Initializable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupManager
/*     */   implements Initializable
/*     */ {
/*     */   private static GroupManager instance;
/*     */   private GroupItemManager groupItems;
/*     */   private Map<Integer, GroupData> groupDatas;
/*     */   private Map<Integer, Group> groupInstances;
/*     */   private Map<Integer, Group> groupForumIntances;
/*     */   private Map<Integer, Integer> roomIdToGroupId;
/*  26 */   private Logger log = Logger.getLogger(GroupManager.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  34 */     this.groupItems = new GroupItemManager();
/*     */     
/*  36 */     this.groupDatas = Maps.newConcurrentMap();
/*  37 */     this.groupInstances = Maps.newConcurrentMap();
/*  38 */     this.groupForumIntances = Maps.newConcurrentMap();
/*  39 */     this.roomIdToGroupId = Maps.newConcurrentMap();
/*     */     
/*  41 */     loadForums();
/*     */     
/*  43 */     this.log.info("GroupManager initialized");
/*     */   }
/*     */   
/*     */   private void loadForums() {
/*  47 */     if (this.groupForumIntances.size() > 0) {
/*  48 */       this.groupForumIntances.clear();
/*     */     }
/*     */     
/*  51 */     List<Integer> forums = GroupDao.loadForums();
/*  52 */     for (Integer groupId : forums) {
/*  53 */       this.groupForumIntances.put(groupId, get(groupId.intValue()));
/*     */     }
/*     */   }
/*     */   
/*     */   public static GroupManager getInstance() {
/*  58 */     if (instance == null) {
/*  59 */       instance = new GroupManager();
/*     */     }
/*     */     
/*  62 */     return instance;
/*     */   }
/*     */   
/*     */   public GroupData getData(int id) {
/*  66 */     if (this.groupDatas.get(Integer.valueOf(id)) != null) {
/*  67 */       return (GroupData)this.groupDatas.get(Integer.valueOf(id));
/*     */     }
/*  69 */     GroupData groupData = GroupDao.getDataById(id);
/*     */     
/*  71 */     if (groupData != null) {
/*  72 */       this.groupDatas.put(Integer.valueOf(id), groupData);
/*     */     }
/*  74 */     return groupData;
/*     */   }
/*     */   
/*     */   public Group get(int id) {
/*  78 */     if (id <= 0)
/*     */     {
/*  80 */       return null;
/*     */     }
/*     */     
/*  83 */     Group groupInstance = (Group)this.groupInstances.get(Integer.valueOf(id));
/*     */     
/*  85 */     if (groupInstance != null) {
/*  86 */       return groupInstance;
/*     */     }
/*  88 */     if (getData(id) == null) {
/*  89 */       return null;
/*     */     }
/*     */     
/*  92 */     groupInstance = load(id);
/*     */     
/*  94 */     this.groupInstances.put(Integer.valueOf(id), groupInstance);
/*     */     
/*  96 */     this.log.trace("Group with id #" + id + " was loaded");
/*     */     
/*  98 */     return groupInstance;
/*     */   }
/*     */   
/*     */   public Group createGroup(GroupData groupData) {
/* 102 */     int groupId = GroupDao.create(groupData);
/*     */     
/* 104 */     groupData.setId(groupId);
/* 105 */     this.groupDatas.put(Integer.valueOf(groupId), groupData);
/*     */     
/* 107 */     Group groupInstance = new Group(groupId);
/* 108 */     this.groupInstances.put(Integer.valueOf(groupId), groupInstance);
/*     */     
/* 110 */     return groupInstance;
/*     */   }
/*     */   
/*     */   public void addForum(Group group) {
/* 114 */     this.groupForumIntances.put(Integer.valueOf(group.getId()), group);
/*     */   }
/*     */   
/*     */   public Group getGroupByRoomId(int roomId)
/*     */   {
/* 119 */     if (this.roomIdToGroupId.containsKey(Integer.valueOf(roomId))) {
/* 120 */       return get(((Integer)this.roomIdToGroupId.get(Integer.valueOf(roomId))).intValue());
/*     */     }
/* 122 */     int groupId = GroupDao.getIdByRoomId(roomId);
/*     */     
/* 124 */     if (groupId != 0) {
/* 125 */       this.roomIdToGroupId.put(Integer.valueOf(roomId), Integer.valueOf(groupId));
/*     */     }
/* 127 */     return get(groupId);
/*     */   }
/*     */   
/*     */   public void removeGroup(int id) {
/* 131 */     Group group = get(id);
/*     */     
/* 133 */     if (group == null) {
/* 134 */       return;
/*     */     }
/* 136 */     if (this.roomIdToGroupId.containsKey(Integer.valueOf(group.getData().getRoomId()))) {
/* 137 */       this.roomIdToGroupId.remove(Integer.valueOf(group.getData().getRoomId()));
/*     */     }
/*     */     
/* 140 */     this.groupInstances.remove(Integer.valueOf(id));
/* 141 */     this.groupDatas.remove(Integer.valueOf(id));
/*     */     
/* 143 */     group.getMembershipComponent().dispose();
/*     */     
/* 145 */     GroupDao.deleteGroup(group.getId());
/*     */   }
/*     */   
/*     */   private Group load(int id) {
/* 149 */     return new Group(id);
/*     */   }
/*     */   
/*     */   public GroupItemManager getGroupItems() {
/* 153 */     return this.groupItems;
/*     */   }
/*     */   
/*     */   public Map<Integer, GroupData> getGroupDatas() {
/* 157 */     return this.groupDatas;
/*     */   }
/*     */   
/*     */   public Map<Integer, Group> getGroupInstances() {
/* 161 */     return this.groupInstances;
/*     */   }
/*     */   
/*     */   public Map<Integer, Group> getGroupForumIntances() {
/* 165 */     return this.groupForumIntances;
/*     */   }
/*     */   
/*     */   public Logger getLogger() {
/* 169 */     return this.log;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\groups\GroupManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */