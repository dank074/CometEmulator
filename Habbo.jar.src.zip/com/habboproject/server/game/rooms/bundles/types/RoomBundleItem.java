/*    */ package com.habboproject.server.game.rooms.bundles.types;
/*    */ 
/*    */ 
/*    */ public class RoomBundleItem
/*    */ {
/*    */   private int itemId;
/*    */   private int x;
/*    */   private int y;
/*    */   private double z;
/*    */   private int rotation;
/*    */   private String wallPosition;
/*    */   private String extraData;
/*    */   
/*    */   public RoomBundleItem(int itemId, int x, int y, double z, int rotation, String wallPosition, String extraData)
/*    */   {
/* 16 */     this.itemId = itemId;
/* 17 */     this.x = x;
/* 18 */     this.y = y;
/* 19 */     this.z = z;
/* 20 */     this.rotation = rotation;
/* 21 */     this.extraData = extraData;
/* 22 */     this.wallPosition = wallPosition;
/*    */   }
/*    */   
/*    */   public int getItemId() {
/* 26 */     return this.itemId;
/*    */   }
/*    */   
/*    */   public void setItemId(int itemId) {
/* 30 */     this.itemId = itemId;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 34 */     return this.x;
/*    */   }
/*    */   
/*    */   public void setX(int x) {
/* 38 */     this.x = x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 42 */     return this.y;
/*    */   }
/*    */   
/*    */   public void setY(int y) {
/* 46 */     this.y = y;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 50 */     return this.z;
/*    */   }
/*    */   
/*    */   public void setZ(int z) {
/* 54 */     this.z = z;
/*    */   }
/*    */   
/*    */   public String getExtraData() {
/* 58 */     return this.extraData;
/*    */   }
/*    */   
/*    */   public void setExtraData(String extraData) {
/* 62 */     this.extraData = extraData;
/*    */   }
/*    */   
/*    */   public String getWallPosition() {
/* 66 */     return this.wallPosition;
/*    */   }
/*    */   
/*    */   public int getRotation() {
/* 70 */     return this.rotation;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\bundles\types\RoomBundleItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */