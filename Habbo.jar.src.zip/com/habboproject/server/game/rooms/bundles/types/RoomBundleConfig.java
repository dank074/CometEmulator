/*    */ package com.habboproject.server.game.rooms.bundles.types;
/*    */ 
/*    */ public class RoomBundleConfig {
/*    */   private String roomName;
/*    */   private String decorations;
/*    */   private int thicknessWall;
/*    */   private int thicknessFloor;
/*    */   private boolean hideWalls;
/*    */   
/*    */   public RoomBundleConfig(String roomName, String decorations, int thicknessWall, int thicknessFloor, boolean hideWalls) {
/* 11 */     this.roomName = roomName;
/* 12 */     this.decorations = decorations;
/* 13 */     this.thicknessWall = thicknessWall;
/* 14 */     this.thicknessFloor = thicknessFloor;
/* 15 */     this.hideWalls = hideWalls;
/*    */   }
/*    */   
/*    */   public String getRoomName() {
/* 19 */     return this.roomName;
/*    */   }
/*    */   
/*    */   public void setRoomName(String roomName) {
/* 23 */     this.roomName = roomName;
/*    */   }
/*    */   
/*    */   public String getDecorations() {
/* 27 */     return this.decorations;
/*    */   }
/*    */   
/*    */   public void setDecorations(String decorations) {
/* 31 */     this.decorations = decorations;
/*    */   }
/*    */   
/*    */   public int getThicknessWall() {
/* 35 */     return this.thicknessWall;
/*    */   }
/*    */   
/*    */   public void setThicknessWall(int thicknessWall) {
/* 39 */     this.thicknessWall = thicknessWall;
/*    */   }
/*    */   
/*    */   public int getThicknessFloor() {
/* 43 */     return this.thicknessFloor;
/*    */   }
/*    */   
/*    */   public void setThicknessFloor(int thicknessFloor) {
/* 47 */     this.thicknessFloor = thicknessFloor;
/*    */   }
/*    */   
/*    */   public boolean isHideWalls() {
/* 51 */     return this.hideWalls;
/*    */   }
/*    */   
/*    */   public void setHideWalls(boolean hideWalls) {
/* 55 */     this.hideWalls = hideWalls;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\bundles\types\RoomBundleConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */