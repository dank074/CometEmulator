/*     */ package com.habboproject.server.game.rooms.bundles.types;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.models.CustomModel;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RoomBundle
/*     */ {
/*     */   private int id;
/*     */   private int roomId;
/*     */   private String alias;
/*     */   private CustomModel roomModelData;
/*     */   private List<RoomBundleItem> roomBundleData;
/*     */   private RoomBundleConfig config;
/*     */   private int costCredits;
/*     */   private int costSeasonal;
/*     */   private int costVip;
/*     */   
/*     */   public RoomBundle(int id, int roomId, String alias, CustomModel roomModel, List<RoomBundleItem> bundleData, int costCredits, int costSeasonal, int costVip, RoomBundleConfig config)
/*     */   {
/*  20 */     this.id = id;
/*  21 */     this.roomId = roomId;
/*  22 */     this.alias = alias;
/*  23 */     this.roomModelData = roomModel;
/*  24 */     this.roomBundleData = bundleData;
/*  25 */     this.costCredits = costCredits;
/*  26 */     this.costSeasonal = costSeasonal;
/*  27 */     this.costVip = costVip;
/*  28 */     this.config = config;
/*     */   }
/*     */   
/*     */   public int getId() {
/*  32 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/*  36 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getAlias() {
/*  40 */     return this.alias;
/*     */   }
/*     */   
/*     */   public void setAlias(String alias) {
/*  44 */     this.alias = alias;
/*     */   }
/*     */   
/*     */   public CustomModel getRoomModelData() {
/*  48 */     return this.roomModelData;
/*     */   }
/*     */   
/*     */   public void setRoomModelData(CustomModel roomModelData) {
/*  52 */     this.roomModelData = roomModelData;
/*     */   }
/*     */   
/*     */   public List<RoomBundleItem> getRoomBundleData() {
/*  56 */     return this.roomBundleData;
/*     */   }
/*     */   
/*     */   public void setRoomBundleData(List<RoomBundleItem> roomBundleData) {
/*  60 */     this.roomBundleData = roomBundleData;
/*     */   }
/*     */   
/*     */   public int getRoomId() {
/*  64 */     return this.roomId;
/*     */   }
/*     */   
/*     */   public void setRoomId(int roomId) {
/*  68 */     this.roomId = roomId;
/*     */   }
/*     */   
/*     */   public int getCostCredits() {
/*  72 */     return this.costCredits;
/*     */   }
/*     */   
/*     */   public void setCostCredits(int costCredits) {
/*  76 */     this.costCredits = costCredits;
/*     */   }
/*     */   
/*     */   public int getCostSeasonal() {
/*  80 */     return this.costSeasonal;
/*     */   }
/*     */   
/*     */   public void setCostSeasonal(int costSeasonal) {
/*  84 */     this.costSeasonal = costSeasonal;
/*     */   }
/*     */   
/*     */   public int getCostVip() {
/*  88 */     return this.costVip;
/*     */   }
/*     */   
/*     */   public void setCostVip(int costVip) {
/*  92 */     this.costVip = costVip;
/*     */   }
/*     */   
/*     */   public RoomBundleConfig getConfig() {
/*  96 */     return this.config;
/*     */   }
/*     */   
/*     */   public void setConfig(RoomBundleConfig config) {
/* 100 */     this.config = config;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\bundles\types\RoomBundle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */