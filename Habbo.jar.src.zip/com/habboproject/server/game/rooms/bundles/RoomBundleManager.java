/*    */ package com.habboproject.server.game.rooms.bundles;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.bundles.types.RoomBundle;
/*    */ import com.habboproject.server.storage.queries.rooms.BundleDao;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class RoomBundleManager
/*    */ {
/*    */   private static RoomBundleManager roomBundleManager;
/* 12 */   private static Logger log = Logger.getLogger(RoomBundleManager.class.getName());
/*    */   private Map<String, RoomBundle> bundles;
/*    */   
/*    */   public RoomBundleManager()
/*    */   {
/* 17 */     this.bundles = new ConcurrentHashMap();
/*    */   }
/*    */   
/*    */   public void initialize() {
/* 21 */     if (this.bundles.size() != 0) {
/* 22 */       this.bundles.clear();
/*    */     }
/*    */     
/* 25 */     BundleDao.loadActiveBundles(this.bundles);
/*    */     
/* 27 */     log.info("Loaded " + this.bundles.size() + " active room bundles");
/* 28 */     log.info("RoomBundleManager initialized");
/*    */   }
/*    */   
/*    */   public void addBundle(RoomBundle bundle) {
/* 32 */     if (this.bundles.containsKey(bundle.getAlias())) {
/* 33 */       this.bundles.replace(bundle.getAlias(), bundle);
/*    */     } else {
/* 35 */       this.bundles.put(bundle.getAlias(), bundle);
/*    */     }
/*    */   }
/*    */   
/*    */   public RoomBundle getBundle(String alias) {
/* 40 */     return (RoomBundle)this.bundles.get(alias);
/*    */   }
/*    */   
/*    */   public static RoomBundleManager getInstance() {
/* 44 */     if (roomBundleManager == null) {
/* 45 */       roomBundleManager = new RoomBundleManager();
/*    */     }
/*    */     
/* 48 */     return roomBundleManager;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\bundles\RoomBundleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */