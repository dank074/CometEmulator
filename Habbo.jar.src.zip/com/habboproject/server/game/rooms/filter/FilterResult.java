/*    */ package com.habboproject.server.game.rooms.filter;
/*    */ 
/*    */ public class FilterResult {
/*    */   private boolean isBlocked;
/*    */   private boolean wasModified;
/*    */   private String message;
/*    */   
/*    */   public FilterResult(String chatMessage) {
/*  9 */     this.isBlocked = false;
/* 10 */     this.wasModified = false;
/* 11 */     this.message = chatMessage;
/*    */   }
/*    */   
/*    */   public FilterResult(boolean isBlocked, String chatMessage) {
/* 15 */     this.isBlocked = isBlocked;
/* 16 */     this.wasModified = false;
/* 17 */     this.message = chatMessage;
/*    */   }
/*    */   
/*    */   public FilterResult(String chatMessage, boolean wasModified) {
/* 21 */     this.isBlocked = false;
/* 22 */     this.wasModified = wasModified;
/* 23 */     this.message = chatMessage;
/*    */   }
/*    */   
/*    */   public boolean isBlocked() {
/* 27 */     return this.isBlocked;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 31 */     return this.message;
/*    */   }
/*    */   
/*    */   public boolean wasModified() {
/* 35 */     return this.wasModified;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\filter\FilterResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */