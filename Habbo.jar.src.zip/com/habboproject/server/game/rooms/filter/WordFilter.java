/*    */ package com.habboproject.server.game.rooms.filter;
/*    */ 
/*    */ import com.habboproject.server.config.CometSettings;
/*    */ import com.habboproject.server.storage.queries.filter.FilterDao;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class WordFilter
/*    */ {
/*    */   private Map<String, String> wordfilter;
/*    */   
/*    */   public WordFilter()
/*    */   {
/* 15 */     loadFilter();
/*    */   }
/*    */   
/*    */   public void loadFilter() {
/* 19 */     if (this.wordfilter != null) {
/* 20 */       this.wordfilter.clear();
/*    */     }
/*    */     
/* 23 */     this.wordfilter = FilterDao.loadWordfilter();
/*    */     
/* 25 */     Logger.getLogger(WordFilter.class.getName()).info("Loaded " + this.wordfilter.size() + " filtered words");
/*    */   }
/*    */   
/*    */   public FilterResult filter(String message) {
/* 29 */     String filteredMessage = message;
/*    */     
/* 31 */     if (CometSettings.wordFilterMode == FilterMode.STRICT) {
/* 32 */       message = com.habboproject.server.utilities.FilterUtil.process(message.toLowerCase());
/*    */     }
/*    */     
/* 35 */     for (Map.Entry<String, String> word : this.wordfilter.entrySet()) {
/* 36 */       if (message.toLowerCase().contains((CharSequence)word.getKey())) {
/* 37 */         if (CometSettings.wordFilterMode == FilterMode.STRICT) {
/* 38 */           return new FilterResult(true, (String)word.getKey());
/*    */         }
/* 40 */         filteredMessage = filteredMessage.replace("(?i)" + (String)word.getKey(), (CharSequence)word.getValue());
/*    */       }
/*    */     }
/*    */     
/* 44 */     return new FilterResult(filteredMessage, !message.equals(filteredMessage));
/*    */   }
/*    */   
/*    */   public void save() {
/* 48 */     FilterDao.save(this.wordfilter);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\filter\WordFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */