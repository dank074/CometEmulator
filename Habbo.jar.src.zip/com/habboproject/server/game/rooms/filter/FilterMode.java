package com.habboproject.server.game.rooms.filter;

public enum FilterMode
{
  STRICT,  SMART,  DEFAULT;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\filter\FilterMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */