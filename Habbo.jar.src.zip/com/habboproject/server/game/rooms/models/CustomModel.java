/*    */ package com.habboproject.server.game.rooms.models;
/*    */ 
/*    */ public class CustomModel {
/*    */   private final int doorX;
/*    */   private final int doorY;
/*    */   private final int doorZ;
/*    */   private final int doorRotation;
/*    */   private final int wallHeight;
/*    */   private final String modelData;
/*    */   
/*    */   public CustomModel(int doorX, int doorY, int doorZ, int doorRotation, String modelData, int wallHeight) {
/* 12 */     this.doorX = doorX;
/* 13 */     this.doorY = doorY;
/* 14 */     this.doorZ = doorZ;
/* 15 */     this.doorRotation = doorRotation;
/* 16 */     this.modelData = modelData;
/* 17 */     this.wallHeight = wallHeight;
/*    */   }
/*    */   
/*    */   public int getDoorX() {
/* 21 */     return this.doorX;
/*    */   }
/*    */   
/*    */   public int getDoorY() {
/* 25 */     return this.doorY;
/*    */   }
/*    */   
/*    */   public int getDoorZ() {
/* 29 */     return this.doorZ;
/*    */   }
/*    */   
/*    */   public int getDoorRotation() {
/* 33 */     return this.doorRotation;
/*    */   }
/*    */   
/*    */   public String getModelData() {
/* 37 */     return this.modelData;
/*    */   }
/*    */   
/*    */   public int getWallHeight() {
/* 41 */     return this.wallHeight;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\models\CustomModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */