/*     */ package com.habboproject.server.game.rooms.models;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IMessageComposer;
/*     */ import com.habboproject.server.game.rooms.types.tiles.RoomTileState;
/*     */ import com.habboproject.server.game.utilities.ModelUtils;
/*     */ import com.habboproject.server.network.messages.outgoing.room.engine.RelativeHeightmapMessageComposer;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public abstract class RoomModel
/*     */ {
/*     */   private String name;
/*  12 */   private String map = "";
/*     */   
/*     */   private int doorX;
/*     */   
/*     */   private int doorY;
/*     */   
/*     */   private int doorZ;
/*     */   private int doorRotation;
/*     */   private int mapSizeX;
/*     */   private int mapSizeY;
/*     */   private double[][] squareHeight;
/*     */   private RoomTileState[][] squareState;
/*     */   private final IMessageComposer floorMapMessageComposer;
/*     */   private int wallHeight;
/*     */   
/*     */   public RoomModel(String name, String heightmap, int doorX, int doorY, int doorZ, int doorRotation, int wallHeight)
/*     */     throws RoomModel.InvalidModelException
/*     */   {
/*  30 */     this.name = name;
/*  31 */     this.doorX = doorX;
/*  32 */     this.doorY = doorY;
/*  33 */     this.doorZ = doorZ;
/*  34 */     this.doorRotation = doorRotation;
/*  35 */     this.wallHeight = wallHeight;
/*     */     
/*  37 */     String[] axes = heightmap.split("\r");
/*     */     
/*  39 */     if (axes.length == 0) { throw new InvalidModelException();
/*     */     }
/*  41 */     this.mapSizeX = axes[0].length();
/*  42 */     this.mapSizeY = axes.length;
/*  43 */     this.squareHeight = new double[this.mapSizeX][this.mapSizeY];
/*  44 */     this.squareState = new RoomTileState[this.mapSizeX][this.mapSizeY];
/*     */     
/*  46 */     int maxTileHeight = 0;
/*     */     try {
/*     */       char tile;
/*  49 */       for (int y = 0; y < this.mapSizeY; y++) {
/*  50 */         line = axes[y].replace("\r", "").replace("\n", "").toCharArray();
/*     */         
/*  52 */         x = 0;
/*  53 */         char[] arrayOfChar1; int j = (arrayOfChar1 = line).length; for (int i = 0; i < j; i++) { tile = arrayOfChar1[i];
/*  54 */           if (x >= this.mapSizeX) {
/*  55 */             throw new InvalidModelException();
/*     */           }
/*     */           
/*  58 */           String tileVal = String.valueOf(tile);
/*     */           
/*  60 */           if (tileVal.equals("x")) {
/*  61 */             this.squareState[x][y] = ((x == doorX) && (y == doorY) ? RoomTileState.VALID : RoomTileState.INVALID);
/*     */           } else {
/*  63 */             this.squareState[x][y] = RoomTileState.VALID;
/*  64 */             this.squareHeight[x][y] = ModelUtils.getHeight(tile);
/*     */             
/*  66 */             if (this.squareHeight[x][y] > maxTileHeight) {
/*  67 */               maxTileHeight = (int)Math.ceil(this.squareHeight[x][y]);
/*     */             }
/*     */           }
/*     */           
/*  71 */           x++;
/*     */         }
/*     */       }
/*     */       
/*  75 */       int x = (tile = heightmap.split("\r\n")).length; for (char[] line = 0; line < x; line++) { String mapLine = tile[line];
/*  76 */         if (!mapLine.isEmpty())
/*     */         {
/*     */ 
/*  79 */           this.map = (this.map + mapLine + '\r'); }
/*     */       }
/*     */     } catch (Exception e) {
/*  82 */       if ((e instanceof InvalidModelException)) {
/*  83 */         throw e;
/*     */       }
/*     */       
/*  86 */       Logger.getLogger(RoomModel.class.getName()).error("Failed to parse heightmap for model: " + this.name, e);
/*     */     }
/*     */     
/*  89 */     if (maxTileHeight >= 29) {
/*  90 */       this.wallHeight = 15;
/*     */     }
/*     */     
/*  93 */     this.floorMapMessageComposer = new RelativeHeightmapMessageComposer(this);
/*     */   }
/*     */   
/*     */   public String getId() {
/*  97 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getMap() {
/* 101 */     return this.map;
/*     */   }
/*     */   
/*     */   public int getDoorX() {
/* 105 */     return this.doorX;
/*     */   }
/*     */   
/*     */   public int getDoorY() {
/* 109 */     return this.doorY;
/*     */   }
/*     */   
/*     */   public int getDoorZ() {
/* 113 */     return this.doorZ;
/*     */   }
/*     */   
/*     */   public void setDoorZ(int doorZ) {
/* 117 */     this.doorZ = doorZ;
/*     */   }
/*     */   
/*     */   public int getDoorRotation() {
/* 121 */     return this.doorRotation;
/*     */   }
/*     */   
/*     */   public int getSizeX() {
/* 125 */     return this.mapSizeX;
/*     */   }
/*     */   
/*     */   public int getSizeY() {
/* 129 */     return this.mapSizeY;
/*     */   }
/*     */   
/*     */   public RoomTileState[][] getSquareState() {
/* 133 */     return this.squareState;
/*     */   }
/*     */   
/*     */   public double[][] getSquareHeight() {
/* 137 */     return this.squareHeight;
/*     */   }
/*     */   
/*     */   public IMessageComposer getRelativeHeightmapMessage() {
/* 141 */     return this.floorMapMessageComposer;
/*     */   }
/*     */   
/*     */   public int getWallHeight() {
/* 145 */     return this.wallHeight;
/*     */   }
/*     */   
/*     */   public class InvalidModelException
/*     */     extends Exception
/*     */   {
/*     */     public InvalidModelException() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\models\RoomModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */