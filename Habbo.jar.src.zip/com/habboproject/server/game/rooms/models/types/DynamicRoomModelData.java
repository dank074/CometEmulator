/*    */ package com.habboproject.server.game.rooms.models.types;
/*    */ 
/*    */ public class DynamicRoomModelData {
/*    */   private String name;
/*    */   private String heightmap;
/*    */   private int doorX;
/*    */   private int doorY;
/*    */   private int doorZ;
/*    */   private int doorRotation;
/*    */   private int wallHeight;
/*    */   
/*    */   public DynamicRoomModelData(String name, String heightmap, int doorX, int doorY, int doorZ, int doorRotation, int wallHeight) {
/* 13 */     this.name = name;
/* 14 */     this.heightmap = heightmap;
/* 15 */     this.doorX = doorX;
/* 16 */     this.doorY = doorY;
/* 17 */     this.doorZ = doorZ;
/* 18 */     this.doorRotation = doorRotation;
/* 19 */     this.wallHeight = wallHeight;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 23 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 27 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getHeightmap() {
/* 31 */     return this.heightmap;
/*    */   }
/*    */   
/*    */   public void setHeightmap(String heightmap) {
/* 35 */     this.heightmap = heightmap;
/*    */   }
/*    */   
/*    */   public int getDoorX() {
/* 39 */     return this.doorX;
/*    */   }
/*    */   
/*    */   public void setDoorX(int doorX) {
/* 43 */     this.doorX = doorX;
/*    */   }
/*    */   
/*    */   public int getDoorY() {
/* 47 */     return this.doorY;
/*    */   }
/*    */   
/*    */   public void setDoorY(int doorY) {
/* 51 */     this.doorY = doorY;
/*    */   }
/*    */   
/*    */   public int getDoorZ() {
/* 55 */     return this.doorZ;
/*    */   }
/*    */   
/*    */   public void setDoorZ(int doorZ) {
/* 59 */     this.doorZ = doorZ;
/*    */   }
/*    */   
/*    */   public int getDoorRotation() {
/* 63 */     return this.doorRotation;
/*    */   }
/*    */   
/*    */   public void setDoorRotation(int doorRotation) {
/* 67 */     this.doorRotation = doorRotation;
/*    */   }
/*    */   
/*    */   public int getWallHeight() {
/* 71 */     return this.wallHeight;
/*    */   }
/*    */   
/*    */   public void setWallHeight(int wallHeight) {
/* 75 */     this.wallHeight = wallHeight;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\models\types\DynamicRoomModelData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */