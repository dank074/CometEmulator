/*    */ package com.habboproject.server.game.rooms.models.types;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.models.RoomModel.InvalidModelException;
/*    */ 
/*    */ public class DynamicRoomModel extends com.habboproject.server.game.rooms.models.RoomModel
/*    */ {
/*    */   public DynamicRoomModel(String name, String heightmap, int doorX, int doorY, int doorZ, int doorRotation, int wallHeight) throws RoomModel.InvalidModelException {
/*  8 */     super(name, heightmap, doorX, doorY, doorZ, doorRotation, wallHeight);
/*    */   }
/*    */   
/*    */   public static DynamicRoomModel create(String name, String heightmap, int doorX, int doorY, int doorZ, int doorRotation, int wallHeight) {
/*    */     try {
/* 13 */       return new DynamicRoomModel(name, heightmap, doorX, doorY, doorZ, doorRotation, wallHeight);
/*    */     } catch (RoomModel.InvalidModelException e) {}
/* 15 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\models\types\DynamicRoomModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */