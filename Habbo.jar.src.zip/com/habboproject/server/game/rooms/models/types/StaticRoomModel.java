/*    */ package com.habboproject.server.game.rooms.models.types;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.models.RoomModel;
/*    */ import java.sql.ResultSet;
/*    */ 
/*    */ public class StaticRoomModel extends RoomModel
/*    */ {
/*    */   public StaticRoomModel(ResultSet data) throws Exception
/*    */   {
/* 10 */     super(data.getString("id"), data.getString("heightmap"), data.getInt("door_x"), data.getInt("door_y"), data.getInt("door_z"), data.getInt("door_dir"), -1);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\models\types\StaticRoomModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */