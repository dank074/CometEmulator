/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.others;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class AlertFloorItem extends RoomItemFloor
/*    */ {
/*    */   public AlertFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 11 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 16 */     if (this.ticksTimer > 0) {
/* 17 */       return false;
/*    */     }
/*    */     
/* 20 */     setExtraData("1");
/* 21 */     sendUpdate();
/*    */     
/* 23 */     setTicks(com.habboproject.server.game.rooms.objects.items.RoomItemFactory.getProcessTime(1.5D));
/* 24 */     return true;
/*    */   }
/*    */   
/*    */   public void onTickComplete()
/*    */   {
/* 29 */     setExtraData("0");
/* 30 */     sendUpdate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\others\AlertFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */