/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredActionBotTalkToAvatar extends WiredActionItem
/*    */ {
/*    */   public static final int PARAM_MESSAGE_TYPE = 0;
/*    */   
/*    */   public WiredActionBotTalkToAvatar(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 20 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 22 */     if (getWiredData().getParams().size() < 1) {
/* 23 */       getWiredData().getParams().clear();
/* 24 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(0));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 30 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 35 */     return 27;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 40 */     if ((event.entity == null) || (!(event.entity instanceof PlayerEntity))) {
/* 41 */       return;
/*    */     }
/*    */     
/* 44 */     if (!getWiredData().getText().contains("\t")) {
/* 45 */       return;
/*    */     }
/*    */     
/* 48 */     String[] talkData = getWiredData().getText().split("\t");
/* 49 */     if (talkData.length != 2) {
/* 50 */       return;
/*    */     }
/*    */     
/* 53 */     String botName = talkData[0];
/* 54 */     String message = talkData[1];
/*    */     
/* 56 */     if ((botName.isEmpty()) || (message.isEmpty())) {
/* 57 */       return;
/*    */     }
/*    */     
/* 60 */     message = message.replace("{username}", event.entity.getUsername()).replace("%username%", event.entity.getUsername()).replace("<", "").replace(">", "");
/*    */     
/* 62 */     BotEntity botEntity = getRoom().getBots().getBotByName(botName);
/* 63 */     if (botEntity != null) {
/* 64 */       boolean isShout = (getWiredData().getParams().size() == 1) && (((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue() == 1);
/*    */       
/* 66 */       if (isShout) {
/* 67 */         ((PlayerEntity)event.entity).getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer(botEntity.getId(), message, 2));
/*    */       } else {
/* 69 */         ((PlayerEntity)event.entity).getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.room.avatar.ShoutMessageComposer(botEntity.getId(), message, com.habboproject.server.game.rooms.types.misc.ChatEmotion.NONE, 2));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionBotTalkToAvatar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */