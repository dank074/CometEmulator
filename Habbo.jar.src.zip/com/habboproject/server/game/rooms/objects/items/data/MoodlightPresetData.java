/*    */ package com.habboproject.server.game.rooms.objects.items.data;
/*    */ 
/*    */ public class MoodlightPresetData {
/*    */   public boolean backgroundOnly;
/*    */   public String colour;
/*    */   public int intensity;
/*    */   
/*    */   public MoodlightPresetData(boolean backgroundOnly, String colour, int intensity) {
/*  9 */     this.backgroundOnly = backgroundOnly;
/* 10 */     this.colour = colour;
/* 11 */     this.intensity = intensity;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\data\MoodlightPresetData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */