/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.base;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredFloorItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.messages.composers.MessageComposer;
/*    */ import com.habboproject.server.network.messages.outgoing.room.items.wired.dialog.WiredConditionMessageComposer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WiredConditionItem
/*    */   extends WiredFloorItem
/*    */ {
/*    */   protected boolean isNegative;
/*    */   
/*    */   public WiredConditionItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 26 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/* 27 */     this.isNegative = getClass().getSimpleName().startsWith("WiredNegativeCondition");
/*    */   }
/*    */   
/*    */   public boolean isNegative() {
/* 31 */     return this.isNegative;
/*    */   }
/*    */   
/*    */   public MessageComposer getDialog()
/*    */   {
/* 36 */     return new WiredConditionMessageComposer(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\base\WiredConditionItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */