/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*     */ 
/*     */ import com.google.common.collect.Maps;
/*     */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*     */ import com.habboproject.server.api.game.players.data.components.inventory.PlayerItem;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.config.CometSettings;
/*     */ import com.habboproject.server.config.Locale;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import com.habboproject.server.game.players.PlayerManager;
/*     */ import com.habboproject.server.game.players.components.types.inventory.InventoryItem;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.network.messages.outgoing.notification.AlertMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.items.wired.WiredRewardMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.user.inventory.UpdateInventoryMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.storage.queries.rooms.RoomItemDao;
/*     */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class WiredActionGiveReward extends WiredActionItem
/*     */ {
/*  33 */   private static final Map<Long, Map<Integer, Long>> rewardTimings = ;
/*  34 */   private static final Random RANDOM = new Random();
/*     */   
/*     */   private static final int PARAM_HOW_OFTEN = 0;
/*     */   
/*     */   private static final int PARAM_UNIQUE = 1;
/*     */   
/*     */   private static final int PARAM_TOTAL_REWARD_LIMIT = 2;
/*     */   
/*     */   private static final int REWARD_LIMIT_ONCE = 0;
/*     */   
/*     */   private static final int REWARD_LIMIT_DAY = 1;
/*     */   
/*     */   private static final int REWARD_LIMIT_HOUR = 2;
/*     */   
/*     */   public static final String REWARD_DIAMONDS = "diamonds";
/*     */   public static final String REWARD_COINS = "coins";
/*     */   public static final String REWARD_DUCKETS = "duckets";
/*     */   private static final long ONE_DAY = 86400L;
/*     */   private static final long ONE_HOUR = 3600L;
/*  53 */   private int totalRewardCounter = 0;
/*     */   
/*     */   private List<Reward> rewards;
/*     */   private Map<Integer, Set<String>> givenRewards;
/*     */   private final int ownerRank;
/*     */   
/*     */   public WiredActionGiveReward(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  61 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     
/*  63 */     if (!rewardTimings.containsKey(Long.valueOf(getId()))) {
/*  64 */       rewardTimings.put(Long.valueOf(getId()), Maps.newConcurrentMap());
/*     */     }
/*     */     
/*  67 */     PlayerData playerData = PlayerManager.getInstance().getDataByPlayerId(this.ownerId);
/*     */     
/*  69 */     if (playerData != null) {
/*  70 */       this.ownerRank = playerData.getRank();
/*     */     } else {
/*  72 */       this.ownerRank = 1;
/*     */     }
/*     */     
/*  75 */     this.givenRewards = RoomItemDao.getGivenRewards(getId());
/*     */   }
/*     */   
/*     */   public boolean requiresPlayer()
/*     */   {
/*  80 */     return true;
/*     */   }
/*     */   
/*     */   public int getInterface()
/*     */   {
/*  85 */     return 17;
/*     */   }
/*     */   
/*     */   public void onEventComplete(WiredItemExecuteEvent event)
/*     */   {
/*  90 */     if ((getWiredData().getParams().size() != 4) || (!(event.entity instanceof PlayerEntity)) || (this.rewards.size() == 0)) {
/*  91 */       return;
/*     */     }
/*     */     
/*  94 */     if (CometSettings.roomWiredRewardMinimumRank > this.ownerRank) { return;
/*     */     }
/*  96 */     PlayerEntity playerEntity = (PlayerEntity)event.entity;
/*     */     
/*  98 */     int howOften = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*  99 */     boolean unique = ((Integer)getWiredData().getParams().get(Integer.valueOf(1))).intValue() == 1;
/* 100 */     int totalRewardLimit = ((Integer)getWiredData().getParams().get(Integer.valueOf(2))).intValue();
/*     */     
/* 102 */     int errorCode = -1;
/*     */     
/* 104 */     if ((totalRewardLimit != 0) && 
/* 105 */       (this.totalRewardCounter >= totalRewardLimit)) {
/* 106 */       errorCode = 0;
/*     */     }
/*     */     
/*     */ 
/* 110 */     if (errorCode != -1) {
/* 111 */       playerEntity.getPlayer().getSession().send(new WiredRewardMessageComposer(errorCode));
/* 112 */       return;
/*     */     }
/*     */     
/* 115 */     this.totalRewardCounter += 1;
/*     */     
/* 117 */     boolean receivedReward = false;
/*     */     
/* 119 */     errorCode = -1;
/*     */     label1093:
/* 121 */     for (Reward reward : this.rewards) {
/* 122 */       switch (howOften) {
/*     */       case 0: 
/* 124 */         if ((this.givenRewards.containsKey(Integer.valueOf(playerEntity.getPlayerId()))) && (((Set)this.givenRewards.get(Integer.valueOf(playerEntity.getPlayerId()))).contains(reward.productCode))) {
/* 125 */           errorCode = 1;
/*     */         } else {
/* 127 */           if (!this.givenRewards.containsKey(Integer.valueOf(playerEntity.getPlayerId()))) {
/* 128 */             this.givenRewards.put(Integer.valueOf(playerEntity.getPlayerId()), new java.util.HashSet());
/*     */           }
/*     */           
/* 131 */           ((Set)this.givenRewards.get(Integer.valueOf(playerEntity.getPlayerId()))).add(reward.productCode);
/*     */           
/* 133 */           RoomItemDao.saveReward(getId(), ((PlayerEntity)event.entity).getPlayerId(), reward.productCode);
/*     */         }
/*     */         
/* 136 */         if (((Map)rewardTimings.get(Long.valueOf(getId()))).containsKey(Integer.valueOf(playerEntity.getPlayerId()))) {
/* 137 */           errorCode = 1;
/*     */         }
/*     */         
/* 140 */         break;
/*     */       
/*     */       case 1: 
/* 143 */         if (((Map)rewardTimings.get(Long.valueOf(getId()))).containsKey(Integer.valueOf(playerEntity.getPlayerId()))) {
/* 144 */           long lastReward = ((Long)((Map)rewardTimings.get(Long.valueOf(getId()))).get(Integer.valueOf(playerEntity.getPlayerId()))).longValue();
/*     */           
/* 146 */           if (Comet.getTime() - lastReward < 86400L) {
/* 147 */             errorCode = 2;
/*     */           }
/*     */         }
/* 150 */         break;
/*     */       
/*     */       case 2: 
/* 153 */         if (((Map)rewardTimings.get(Long.valueOf(getId()))).containsKey(Integer.valueOf(playerEntity.getPlayerId()))) {
/* 154 */           long lastReward = ((Long)((Map)rewardTimings.get(Long.valueOf(getId()))).get(Integer.valueOf(playerEntity.getPlayerId()))).longValue();
/*     */           
/* 156 */           if (Comet.getTime() - lastReward < 3600L) {
/* 157 */             errorCode = 3;
/*     */           }
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/* 163 */       if ((totalRewardLimit != 0) && 
/* 164 */         (this.totalRewardCounter >= totalRewardLimit)) {
/* 165 */         errorCode = 0;
/*     */       }
/*     */       
/*     */ 
/* 169 */       if (errorCode == -1)
/*     */       {
/*     */ 
/*     */ 
/* 173 */         boolean giveReward = (unique) || (reward.probability / 100 <= RANDOM.nextDouble());
/*     */         
/* 175 */         if ((giveReward) && (!receivedReward)) {
/* 176 */           if (reward.isBadge) {
/* 177 */             if (!playerEntity.getPlayer().getInventory().hasBadge(reward.productCode)) {
/* 178 */               playerEntity.getPlayer().getInventory().addBadge(reward.productCode, true);
/*     */             }
/*     */           } else {
/* 181 */             String[] itemData = reward.productCode.contains("%") ? reward.productCode.split("%") : reward.productCode.split(":");
/*     */             
/* 183 */             if (isCurrencyReward(itemData[0]))
/*     */             {
/* 185 */               if (itemData.length != 2)
/*     */                 continue;
/* 187 */               if (!StringUtils.isNumeric(itemData[1])) {
/*     */                 continue;
/*     */               }
/*     */               
/* 191 */               int amount = Integer.parseInt(itemData[1]);
/*     */               String str1;
/* 193 */               switch ((str1 = itemData[0]).hashCode()) {case -232912481:  if (str1.equals("diamonds")) {} break; case 94839810:  if (str1.equals("coins")) break; break; case 2000382539:  if (!str1.equals("duckets")) {
/*     */                   break label1093;
/* 195 */                   playerEntity.getPlayer().getData().increaseCredits(amount);
/* 196 */                   playerEntity.getPlayer().getSession().send(new AlertMessageComposer(
/* 197 */                     Locale.getOrDefault("wired.reward.coins", "You received %s coin(s)!").replace("%s", amount)));
/*     */                   
/*     */                   break label1093;
/*     */                   
/* 201 */                   playerEntity.getPlayer().getData().increasePoints(amount);
/* 202 */                   playerEntity.getPlayer().getSession().send(new AlertMessageComposer(
/* 203 */                     Locale.getOrDefault("wired.reward.diamonds", "You received %s diamond(s)!").replace("%s", amount)));
/*     */                 }
/*     */                 else
/*     */                 {
/* 207 */                   playerEntity.getPlayer().getData().increaseActivityPoints(amount);
/* 208 */                   playerEntity.getPlayer().getSession().send(new AlertMessageComposer(
/* 209 */                     Locale.getOrDefault("wired.reward.duckets", "You received %s ducket(s)!").replace("%s", amount)));
/*     */                 }
/*     */                 break;
/*     */               }
/* 213 */               playerEntity.getPlayer().getData().save();
/* 214 */               playerEntity.getPlayer().sendBalance();
/*     */             } else {
/* 216 */               String extraData = "0";
/*     */               
/* 218 */               if (itemData.length == 2) {
/* 219 */                 extraData = itemData[1];
/*     */               }
/*     */               
/* 222 */               if (!StringUtils.isNumeric(itemData[0])) {
/*     */                 continue;
/*     */               }
/* 225 */               int itemId = Integer.parseInt(itemData[0]);
/*     */               
/* 227 */               ItemDefinition itemDefinition = ItemManager.getInstance().getDefinition(itemId);
/*     */               
/* 229 */               if (itemDefinition != null) {
/* 230 */                 long newItem = com.habboproject.server.storage.queries.items.ItemDao.createItem(playerEntity.getPlayerId(), itemId, extraData);
/*     */                 
/* 232 */                 PlayerItem playerItem = new InventoryItem(newItem, itemId, 0, extraData);
/*     */                 
/* 234 */                 playerEntity.getPlayer().getInventory().addItem(playerItem);
/*     */                 
/* 236 */                 playerEntity.getPlayer().getSession().send(new UpdateInventoryMessageComposer());
/* 237 */                 playerEntity.getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.catalog.UnseenItemsMessageComposer(com.google.common.collect.Sets.newHashSet(new PlayerItem[] { playerItem })));
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 242 */           receivedReward = true;
/*     */         }
/*     */       }
/*     */     }
/* 246 */     if (errorCode != -1) {
/* 247 */       playerEntity.getPlayer().getSession().send(new WiredRewardMessageComposer(errorCode));
/* 248 */       return;
/*     */     }
/*     */     
/* 251 */     if (!receivedReward) {
/* 252 */       playerEntity.getPlayer().getSession().send(new WiredRewardMessageComposer(4));
/*     */     } else {
/* 254 */       playerEntity.getPlayer().getSession().send(new WiredRewardMessageComposer(6));
/*     */     }
/*     */     
/* 257 */     if (((Map)rewardTimings.get(Long.valueOf(getId()))).containsKey(Integer.valueOf(playerEntity.getPlayerId()))) {
/* 258 */       ((Map)rewardTimings.get(Long.valueOf(getId()))).replace(Integer.valueOf(playerEntity.getPlayerId()), Long.valueOf(Comet.getTime()));
/*     */     } else {
/* 260 */       ((Map)rewardTimings.get(Long.valueOf(getId()))).put(Integer.valueOf(playerEntity.getPlayerId()), Long.valueOf(Comet.getTime()));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isCurrencyReward(String key) {
/* 265 */     return (key.equals("coins")) || (key.equals("diamonds")) || (key.equals("duckets"));
/*     */   }
/*     */   
/*     */   public void onDataRefresh()
/*     */   {
/* 270 */     if (this.rewards == null) {
/* 271 */       this.rewards = com.google.common.collect.Lists.newArrayList();
/*     */     } else {
/* 273 */       this.rewards.clear();
/*     */     }
/* 275 */     String[] data = getWiredData().getText().split(";");
/*     */     String[] arrayOfString1;
/* 277 */     int j = (arrayOfString1 = data).length; for (int i = 0; i < j; i++) { String reward = arrayOfString1[i];
/* 278 */       String[] rewardData = reward.split(",");
/* 279 */       if ((rewardData.length == 3) && (StringUtils.isNumeric(rewardData[2])))
/*     */       {
/* 281 */         this.rewards.add(new Reward(rewardData[0].equals("0"), rewardData[1], Integer.parseInt(rewardData[2])));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void onUnload() {
/* 287 */     this.givenRewards.clear();
/*     */   }
/*     */   
/*     */   public void onPickup()
/*     */   {
/* 292 */     super.onPickup();
/* 293 */     ((Map)rewardTimings.get(Long.valueOf(getId()))).clear();
/* 294 */     rewardTimings.remove(Long.valueOf(getId()));
/*     */   }
/*     */   
/*     */   public class Reward {
/*     */     private boolean isBadge;
/*     */     private String productCode;
/*     */     private int probability;
/*     */     
/*     */     public Reward(boolean isBadge, String productCode, int probability) {
/* 303 */       this.isBadge = isBadge;
/* 304 */       this.productCode = productCode;
/* 305 */       this.probability = probability;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionGiveReward.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */