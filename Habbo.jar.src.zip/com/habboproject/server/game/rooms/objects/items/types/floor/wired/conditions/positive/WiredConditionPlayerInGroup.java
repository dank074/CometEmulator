/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.groups.GroupManager;
/*    */ import com.habboproject.server.game.groups.types.Group;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionPlayerInGroup
/*    */   extends WiredConditionItem
/*    */ {
/*    */   public WiredConditionPlayerInGroup(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 28 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 33 */     return 10;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 38 */     if ((entity == null) || (!(entity instanceof PlayerEntity))) { return false;
/*    */     }
/* 40 */     PlayerEntity playerEntity = (PlayerEntity)entity;
/*    */     
/* 42 */     Group group = GroupManager.getInstance().getGroupByRoomId(getRoom().getId());
/*    */     
/* 44 */     if (group != null) {
/* 45 */       boolean isMember = playerEntity.getPlayer().getGroups().contains(Integer.valueOf(group.getId()));
/* 46 */       return this.isNegative ? true : isMember ? false : isMember;
/*    */     }
/*    */     
/* 49 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionPlayerInGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */