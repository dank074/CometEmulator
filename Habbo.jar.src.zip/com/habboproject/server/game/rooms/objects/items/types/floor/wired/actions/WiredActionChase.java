/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.AffectedTile;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.Square;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.types.ItemPathfinder;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerCollision;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomMapping;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomTile;
/*     */ import com.habboproject.server.network.messages.outgoing.room.items.SlideObjectBundleMessageComposer;
/*     */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class WiredActionChase extends WiredActionItem
/*     */ {
/*  25 */   private int targetId = -1;
/*     */   
/*     */   public WiredActionChase(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  28 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public boolean requiresPlayer()
/*     */   {
/*  33 */     return false;
/*     */   }
/*     */   
/*     */   public int getInterface()
/*     */   {
/*  38 */     return 8;
/*     */   }
/*     */   
/*     */   public void onEventComplete(WiredItemExecuteEvent event)
/*     */   {
/*  43 */     if (getWiredData().getSelectedIds().size() == 0) { return;
/*     */     }
/*  45 */     List<Long> toRemove = Lists.newArrayList();
/*  46 */     for (Iterator localIterator = getWiredData().getSelectedIds().iterator(); localIterator.hasNext();) {
/*  47 */       long itemId = ((Long)localIterator.next()).longValue();
/*  48 */       RoomItemFloor floorItem = getRoom().getItems().getFloorItem(itemId);
/*     */       
/*  50 */       if (floorItem == null) {
/*  51 */         toRemove.add(Long.valueOf(itemId));
/*     */       } else {
/*  53 */         boolean hasEntityOnTile = false;
/*  54 */         if ((hasEntityOnTile = floorItem.getEntitiesOnItem().size() > 0 ? 1 : 0) != 0) {
/*  55 */           for (Iterator iterator = floorItem.getEntitiesOnItem().iterator(); iterator.hasNext();) {
/*  56 */             RoomEntity onTile = (RoomEntity)iterator.next();
/*  57 */             if ((onTile instanceof PlayerEntity)) {
/*  58 */               PlayerEntity playerEntity = (PlayerEntity)onTile;
/*  59 */               if (floorItem.getCollision() != playerEntity) {
/*  60 */                 floorItem.setCollision(playerEntity);
/*  61 */                 WiredTriggerCollision.executeTriggers(playerEntity);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*  67 */         if (hasEntityOnTile) {
/*  68 */           floorItem.nullifyCollision();
/*     */         }
/*     */         else
/*     */         {
/*  72 */           PlayerEntity nearestEntity = floorItem.nearestPlayerEntity();
/*  73 */           Position positionFrom = floorItem.getPosition().copy();
/*     */           
/*  75 */           if (nearestEntity != null) {
/*  76 */             if (isCollided(nearestEntity, floorItem)) {
/*  77 */               if (floorItem.getCollision() != nearestEntity) {
/*  78 */                 floorItem.setCollision(nearestEntity);
/*     */                 
/*  80 */                 WiredTriggerCollision.executeTriggers(nearestEntity);
/*     */               }
/*     */               
/*     */             }
/*     */             else
/*     */             {
/*  86 */               this.targetId = nearestEntity.getId();
/*     */               
/*  88 */               List<Square> tilesToEntity = ItemPathfinder.getInstance().makePath(floorItem, nearestEntity.getPosition(), (byte)0, false);
/*     */               
/*  90 */               if ((tilesToEntity != null) && (tilesToEntity.size() != 0)) {
/*  91 */                 Position positionTo = new Position(((Square)tilesToEntity.get(0)).x, ((Square)tilesToEntity.get(0)).y);
/*     */                 
/*  93 */                 moveToTile(floorItem, positionFrom, positionTo);
/*  94 */                 tilesToEntity.clear();
/*     */               } else {
/*  96 */                 moveToTile(floorItem, positionFrom, null);
/*     */               }
/*     */             }
/*  99 */           } else { moveToTile(floorItem, positionFrom, null);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 104 */     if (toRemove.size() > 0) {
/* 105 */       for (Iterator localIterator1 = toRemove.iterator(); localIterator1.hasNext();) { long itemId = ((Long)localIterator1.next()).longValue();
/* 106 */         if (getWiredData().getSelectedIds().contains(Long.valueOf(itemId)))
/* 107 */           getWiredData().getSelectedIds().remove(Long.valueOf(itemId));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCollided(PlayerEntity entity, RoomItemFloor floorItem) {
/* 113 */     return ((AffectedTile.tilesAdjecent(entity.getPosition(), floorItem.getPosition())) && ((entity.getPosition().getX() == floorItem.getPosition().getX()) || (entity.getPosition().getY() == floorItem.getPosition().getY()))) || ((entity.getPosition().getX() == floorItem.getPosition().getX()) && (entity.getPosition().getY() == floorItem.getPosition().getY()));
/*     */   }
/*     */   
/*     */   private void moveToTile(RoomItemFloor floorItem, Position from, Position to) {
/* 117 */     if (to == null) {
/* 118 */       for (int i = 0; i < 16; i++) {
/* 119 */         if (to != null)
/*     */           break;
/* 121 */         to = random(floorItem, from);
/*     */       }
/*     */       
/* 124 */       if (to == null) { return;
/*     */       }
/*     */     }
/* 127 */     if (getRoom().getItems().moveFloorItem(floorItem.getId(), to, floorItem.getRotation(), true)) {
/* 128 */       to.setZ(floorItem.getPosition().getZ());
/*     */       
/* 130 */       getRoom().getEntities().broadcastMessage(new SlideObjectBundleMessageComposer(from, to, 0, 0, floorItem.getVirtualId()));
/*     */     }
/*     */     
/* 133 */     floorItem.nullifyCollision();
/*     */   }
/*     */   
/*     */   private Position random(RoomItemFloor floorItem, Position from) {
/* 137 */     int randomDirection = com.habboproject.server.utilities.RandomInteger.getRandom(0, 3) * 2;
/* 138 */     Position newPosition = from.squareInFront(randomDirection);
/* 139 */     RoomTile tile = floorItem.getRoom().getMapping().getTile(newPosition.getX(), newPosition.getY());
/*     */     
/* 141 */     if ((tile != null) && (tile.isReachable(floorItem))) {
/* 142 */       return newPosition;
/*     */     }
/*     */     
/* 145 */     return null;
/*     */   }
/*     */   
/*     */   public int getTargetId() {
/* 149 */     return this.targetId;
/*     */   }
/*     */   
/*     */   public void setTargetId(int targetId) {
/* 153 */     this.targetId = targetId;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionChase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */