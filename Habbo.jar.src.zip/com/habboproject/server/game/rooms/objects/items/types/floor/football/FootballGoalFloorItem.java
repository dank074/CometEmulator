/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.football;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*    */ 
/*    */ public class FootballGoalFloorItem extends RoomItemFloor
/*    */ {
/*    */   private GameTeam gameTeam;
/*    */   
/*    */   public FootballGoalFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 16 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     String str;
/* 18 */     switch ((str = getDefinition().getItemName()).hashCode()) {case 1468203088:  if (str.equals("fball_goal_b")) break; break; case 1468203093:  if (str.equals("fball_goal_g")) {} break; case 1468203104:  if (str.equals("fball_goal_r")) {} break; case 1468203111:  if (!str.equals("fball_goal_y"))
/*    */       {
/* 20 */         return;this.gameTeam = GameTeam.BLUE;
/* 21 */         return;
/*    */         
/*    */ 
/*    */ 
/* 25 */         this.gameTeam = GameTeam.GREEN;
/* 26 */         return;
/*    */         
/*    */ 
/*    */ 
/* 30 */         this.gameTeam = GameTeam.RED;
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/* 35 */         this.gameTeam = GameTeam.YELLOW; }
/* 36 */       break;
/*    */     }
/*    */     
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void onItemAddedToStack(RoomItemFloor floorItem)
/*    */   {
/* 45 */     if ((floorItem instanceof FootballFloorItem)) {
/* 46 */       getRoom().getGame().increaseTeamScore(this.gameTeam, 1);
/*    */       
/* 48 */       FootballFloorItem footballFloorItem = (FootballFloorItem)floorItem;
/* 49 */       if (footballFloorItem.getPusher() != null) {
/* 50 */         PlayerEntity entity = footballFloorItem.getPusher();
/*    */         
/* 52 */         if ((entity != null) && (entity.getPlayer() != null) && (entity.getPlayer().getSession() != null)) {
/* 53 */           entity.getPlayer().getAchievements().progressAchievement(com.habboproject.server.game.achievements.types.AchievementType.FOOTBALL_GOAL, 1);
/* 54 */           getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.ActionMessageComposer(entity.getId(), 1));
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isMovementCancelled(RoomEntity entity)
/*    */   {
/* 62 */     return true;
/*    */   }
/*    */   
/*    */   public GameTeam getGameTeam() {
/* 66 */     return this.gameTeam;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\football\FootballGoalFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */