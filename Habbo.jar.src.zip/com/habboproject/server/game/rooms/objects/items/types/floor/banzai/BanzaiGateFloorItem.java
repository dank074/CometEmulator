/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.banzai;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class BanzaiGateFloorItem extends com.habboproject.server.game.rooms.objects.items.types.DefaultFloorItem
/*     */ {
/*     */   private GameTeam gameTeam;
/*     */   
/*     */   public BanzaiGateFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     String str;
/*  20 */     switch ((str = getDefinition().getInteraction()).hashCode()) {case -2126818249:  if (str.equals("bb_yellow_gate")) {} break; case 217953361:  if (str.equals("bb_blue_gate")) {} break; case 1513745624:  if (str.equals("bb_red_gate")) break; break; case 1826243046:  if (!str.equals("bb_green_gate"))
/*     */       {
/*  22 */         return;this.gameTeam = GameTeam.RED;
/*  23 */         return;
/*     */         
/*  25 */         this.gameTeam = GameTeam.BLUE;
/*     */       }
/*     */       else {
/*  28 */         this.gameTeam = GameTeam.GREEN;
/*  29 */         return;
/*     */         
/*  31 */         this.gameTeam = GameTeam.YELLOW;
/*     */       }
/*     */       break;
/*     */     }
/*     */   }
/*     */   
/*     */   public void onEntityStepOn(RoomEntity entity) {
/*  38 */     PlayerEntity playerEntity = null;
/*  39 */     if ((!(entity instanceof PlayerEntity)) || ((playerEntity = (PlayerEntity)entity) == null) || (getTeam() == null) || (getTeam() == GameTeam.NONE)) {
/*  40 */       return;
/*     */     }
/*     */     
/*  43 */     if (playerEntity.getMountedEntity() != null) {
/*  44 */       return;
/*     */     }
/*     */     
/*  47 */     if ((playerEntity.getGameTeam() != null) && (playerEntity.getGameTeam() != GameTeam.NONE) && (playerEntity.getGameTeam() != getTeam())) {
/*  48 */       GameTeam oldTeam = playerEntity.getGameTeam();
/*     */       
/*  50 */       getRoom().getGame().removeFromTeam(oldTeam, Integer.valueOf(playerEntity.getPlayerId()));
/*     */       
/*  52 */       for (RoomItemFloor floorItem : getRoom().getItems().getByInteraction("bb_" + oldTeam.toString().toLowerCase() + "_gate")) {
/*  53 */         if (floorItem != null)
/*     */         {
/*     */ 
/*  56 */           floorItem.setExtraData(((List)getRoom().getGame().getTeams().get(oldTeam)).size());
/*  57 */           floorItem.sendUpdate();
/*     */         }
/*     */       }
/*     */     }
/*  61 */     if ((playerEntity.getGameTeam() != null) && (playerEntity.getGameTeam() == getTeam())) {
/*  62 */       getRoom().getGame().removeFromTeam(getTeam(), Integer.valueOf(playerEntity.getPlayerId()));
/*     */       
/*  64 */       playerEntity.setGameTeam(GameTeam.NONE);
/*  65 */       playerEntity.applyEffect(null);
/*     */     } else {
/*  67 */       ((List)getRoom().getGame().getTeams().get(getTeam())).add(new com.habboproject.server.game.rooms.types.components.games.GamePlayer(playerEntity.getPlayerId()));
/*     */       
/*  69 */       playerEntity.setGameTeam(getTeam());
/*  70 */       playerEntity.applyEffect(new com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect(getTeam().getBanzaiEffect(), 0));
/*     */     }
/*     */     
/*  73 */     updateTeamCount();
/*     */   }
/*     */   
/*     */   public void onEntityLeaveRoom(RoomEntity entity)
/*     */   {
/*     */     PlayerEntity playerEntity;
/*  79 */     if (((entity instanceof PlayerEntity)) && ((playerEntity = (PlayerEntity)entity).getGameTeam() == getTeam())) {
/*  80 */       getRoom().getGame().removeFromTeam(getTeam(), Integer.valueOf(playerEntity.getPlayerId()));
/*  81 */       updateTeamCount();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isMovementCancelled(RoomEntity entity)
/*     */   {
/*  87 */     if (Integer.parseInt(getExtraData()) >= 5) {
/*  88 */       return true;
/*     */     }
/*     */     
/*  91 */     if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof com.habboproject.server.game.rooms.types.components.games.banzai.BanzaiGame))) {
/*  92 */       return true;
/*     */     }
/*     */     
/*  95 */     return false;
/*     */   }
/*     */   
/*     */   private void updateTeamCount() {
/*  99 */     setExtraData(((List)getRoom().getGame().getTeams().get(getTeam())).size());
/* 100 */     sendUpdate();
/*     */   }
/*     */   
/*     */   public GameTeam getTeam() {
/* 104 */     return this.gameTeam;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\banzai\BanzaiGateFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */