/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.gates;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class OneWayGateFloorItem extends RoomItemFloor
/*    */ {
/* 11 */   private boolean isInUse = false;
/*    */   private RoomEntity interactingEntity;
/*    */   
/*    */   public OneWayGateFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 15 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 20 */     if (this.isInUse) {
/* 21 */       return false;
/*    */     }
/*    */     
/* 24 */     if ((getPosition().squareInFront(getRotation()).getX() != entity.getPosition().getX()) || (getPosition().squareInFront(getRotation()).getY() != entity.getPosition().getY())) {
/* 25 */       entity.moveTo(getPosition().squareInFront(getRotation()).getX(), getPosition().squareInFront(getRotation()).getY());
/* 26 */       return false;
/*    */     }
/*    */     
/* 29 */     Position squareBehind = getPosition().squareBehind(this.rotation);
/*    */     
/* 31 */     if (!getRoom().getMapping().isValidStep(getPosition(), squareBehind, true)) {
/* 32 */       return false;
/*    */     }
/*    */     
/* 35 */     this.isInUse = true;
/*    */     
/* 37 */     entity.setOverriden(true);
/* 38 */     entity.moveTo(squareBehind.getX(), squareBehind.getY());
/*    */     
/* 40 */     setExtraData("1");
/* 41 */     sendUpdate();
/*    */     
/* 43 */     this.interactingEntity = entity;
/* 44 */     setTicks(RoomItemFactory.getProcessTime(1.0D));
/*    */     
/* 46 */     return true;
/*    */   }
/*    */   
/*    */   public void onTickComplete()
/*    */   {
/* 51 */     if (this.isInUse) {
/* 52 */       this.interactingEntity.setOverriden(false);
/* 53 */       setTicks(RoomItemFactory.getProcessTime(1.0D));
/*    */     }
/*    */     
/* 56 */     setExtraData("0");
/* 57 */     sendUpdate();
/*    */     
/* 59 */     this.isInUse = false;
/* 60 */     this.interactingEntity = null;
/*    */   }
/*    */   
/*    */   public RoomEntity getInteractingEntity() {
/* 64 */     return this.interactingEntity;
/*    */   }
/*    */   
/*    */   public void setInteractingEntity(RoomEntity interactingEntity) {
/* 68 */     this.interactingEntity = interactingEntity;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\gates\OneWayGateFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */