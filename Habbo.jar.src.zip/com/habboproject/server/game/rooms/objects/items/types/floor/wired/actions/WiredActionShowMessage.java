/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ 
/*    */ public class WiredActionShowMessage
/*    */   extends WiredActionItem
/*    */ {
/* 15 */   protected boolean isWhisperBubble = false;
/*    */   
/*    */   public WiredActionShowMessage(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 23 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 28 */     return 7;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 33 */     if ((event.entity == null) || (!(event.entity instanceof PlayerEntity))) {
/* 34 */       return;
/*    */     }
/*    */     
/* 37 */     PlayerEntity playerEntity = (PlayerEntity)event.entity;
/*    */     
/* 39 */     if ((playerEntity.getPlayer() == null) || (playerEntity.getPlayer().getSession() == null)) {
/* 40 */       return;
/*    */     }
/*    */     
/* 43 */     if ((getWiredData() == null) || (getWiredData().getText() == null)) {
/* 44 */       return;
/*    */     }
/*    */     
/* 47 */     playerEntity.getPlayer().getSession().send(new WhisperMessageComposer(playerEntity.getId(), getWiredData().getText(), this.isWhisperBubble ? 0 : 34));
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionShowMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */