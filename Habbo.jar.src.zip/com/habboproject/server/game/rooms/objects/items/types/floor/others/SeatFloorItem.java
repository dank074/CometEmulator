/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.others;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntityStatus;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.adjustable.AdjustableHeightSeatFloorItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class SeatFloorItem extends RoomItemFloor
/*    */ {
/*    */   public SeatFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 19 */     if (!isWiredTrigger) {
/* 20 */       if (!(entity instanceof PlayerEntity)) {
/* 21 */         return false;
/*    */       }
/*    */       
/* 24 */       PlayerEntity pEntity = (PlayerEntity)entity;
/*    */       
/* 26 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && 
/* 27 */         (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 28 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 32 */     toggleInteract(true);
/* 33 */     sendUpdate();
/*    */     
/* 35 */     if ((this instanceof AdjustableHeightSeatFloorItem)) {
/* 36 */       for (RoomEntity sitter : getEntitiesOnItem()) {
/* 37 */         onEntityStepOn(sitter, true);
/*    */       }
/*    */     }
/*    */     
/* 41 */     saveData();
/* 42 */     return true;
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity, boolean instantUpdate) {
/* 46 */     double height = ((entity instanceof com.habboproject.server.game.rooms.objects.entities.types.PetEntity)) || (entity.hasAttribute("transformation")) ? getSitHeight() / 2.0D : getSitHeight();
/*    */     
/* 48 */     entity.addStatus(RoomEntityStatus.SIT, String.valueOf(height).replace(',', '.'));
/*    */     
/* 50 */     if (instantUpdate) {
/* 51 */       getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.AvatarUpdateMessageComposer(entity));
/*    */     } else {
/* 53 */       entity.markNeedsUpdate();
/*    */     }
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity) {
/* 58 */     onEntityStepOn(entity, false);
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 63 */     if (entity.hasStatus(RoomEntityStatus.SIT)) {
/* 64 */       entity.removeStatus(RoomEntityStatus.SIT);
/*    */     }
/*    */     
/* 67 */     entity.markNeedsUpdate();
/*    */   }
/*    */   
/*    */   public double getSitHeight() {
/* 71 */     return getDefinition().getHeight();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\others\SeatFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */