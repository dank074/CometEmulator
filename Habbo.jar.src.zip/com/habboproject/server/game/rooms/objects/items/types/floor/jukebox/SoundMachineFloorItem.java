/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.jukebox;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.music.MusicData;
/*     */ import com.habboproject.server.game.items.music.SongItemData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.network.messages.outgoing.music.PlayMusicMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.utilities.JsonFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SoundMachineFloorItem extends RoomItemFloor implements com.habboproject.server.utilities.attributes.Stateable
/*     */ {
/*     */   public static final int MAX_CAPACITY = 20;
/*  24 */   private boolean isPlaying = false;
/*  25 */   private int currentPlayingIndex = -1;
/*  26 */   private long startTimestamp = 0L;
/*     */   
/*     */   private List<SongItemData> songs;
/*     */   
/*  30 */   private boolean pendingPlay = false;
/*     */   
/*     */   public SoundMachineFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  33 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     
/*  35 */     if (data.startsWith("##jukeboxOn[")) {
/*  36 */       this.songs = ((List)JsonFactory.getInstance().fromJson(data.replace("##jukeboxOn", ""), new TypeToken() {}.getType()));
/*  39 */       this.pendingPlay = true;
/*  40 */       setTicks(RoomItemFactory.getProcessTime(1.5D));
/*  41 */     } else if (data.startsWith("##jukeboxOff[")) {
/*  42 */       this.songs = ((List)JsonFactory.getInstance().fromJson(data.replace("##jukeboxOff", ""), new TypeToken() {}.getType()));
/*     */     }
/*  44 */     else if (data.startsWith("[")) {
/*  45 */       this.songs = ((List)JsonFactory.getInstance().fromJson(data, new TypeToken() {}.getType()));
/*     */     }
/*     */     else {
/*  48 */       this.songs = new ArrayList();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onInteract(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity, int requestData, boolean isWiredTrigger)
/*     */   {
/*  54 */     if (((entity instanceof PlayerEntity)) && 
/*  55 */       (((PlayerEntity)entity).getPlayerId() != getRoom().getData().getOwnerId()) && (!((PlayerEntity)entity).getPlayer().getPermissions().getRank().roomFullControl())) {
/*  56 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  60 */     if (requestData == -1) { return false;
/*     */     }
/*  62 */     if (this.isPlaying) {
/*  63 */       stop();
/*     */     } else {
/*  65 */       play();
/*     */     }
/*     */     
/*  68 */     sendUpdate();
/*  69 */     return true;
/*     */   }
/*     */   
/*     */   public void onTickComplete()
/*     */   {
/*  74 */     if (this.pendingPlay) {
/*  75 */       play();
/*  76 */       this.pendingPlay = false;
/*  77 */       sendUpdate();
/*  78 */       return;
/*     */     }
/*     */     
/*  81 */     if (this.isPlaying) {
/*  82 */       if (this.currentPlayingIndex >= getSongs().size()) {
/*  83 */         stop();
/*  84 */         sendUpdate();
/*  85 */         return;
/*     */       }
/*     */       
/*  88 */       for (PlayerEntity entity : getRoom().getEntities().getPlayerEntities()) {
/*  89 */         if ((!entity.hasAttribute("traxSent")) && (System.currentTimeMillis() - entity.getJoinTime() >= 1100L)) {
/*  90 */           entity.getPlayer().getSession().send(getComposer());
/*  91 */           entity.setAttribute("traxSent", Boolean.valueOf(true));
/*     */         }
/*     */       }
/*     */       
/*  95 */       if (this.currentPlayingIndex != -1) {
/*  96 */         SongItemData songItemData = (SongItemData)getSongs().get(this.currentPlayingIndex);
/*     */         
/*  98 */         if (songItemData != null) {
/*  99 */           MusicData musicData = ItemManager.getInstance().getMusicData(songItemData.getSongId());
/*     */           
/* 101 */           if ((musicData != null) && 
/* 102 */             (timePlaying() >= musicData.getLengthSeconds() + 1.0D)) {
/* 103 */             playNextSong();
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 109 */       setTicks(RoomItemFactory.getProcessTime(1.0D));
/*     */     }
/*     */   }
/*     */   
/*     */   public void onPickup()
/*     */   {
/* 115 */     setExtraData(getDataObject());
/*     */   }
/*     */   
/*     */   public void onPlaced()
/*     */   {
/* 120 */     if (this.isPlaying) {
/* 121 */       broadcastSong();
/*     */     }
/*     */   }
/*     */   
/*     */   public void addSong(SongItemData songItemData) {
/* 126 */     this.songs.add(songItemData);
/*     */   }
/*     */   
/*     */   public SongItemData removeSong(int index) {
/* 130 */     if (index == this.currentPlayingIndex) {
/* 131 */       playNextSong();
/*     */     }
/*     */     
/* 134 */     SongItemData songItemData = (SongItemData)this.songs.get(index);
/* 135 */     this.songs.remove(index);
/*     */     
/* 137 */     return songItemData;
/*     */   }
/*     */   
/*     */   public void play() {
/* 141 */     if (this.songs.size() == 0) { return;
/*     */     }
/* 143 */     this.isPlaying = true;
/* 144 */     this.currentPlayingIndex = -1;
/*     */     
/* 146 */     playNextSong();
/* 147 */     setTicks(RoomItemFactory.getProcessTime(1.0D));
/*     */   }
/*     */   
/*     */   public void stop() {
/* 151 */     this.isPlaying = false;
/* 152 */     this.currentPlayingIndex = -1;
/*     */     
/* 154 */     broadcastSong();
/*     */   }
/*     */   
/*     */   public void playNextSong() {
/* 158 */     this.startTimestamp = Comet.getTime();
/* 159 */     this.currentPlayingIndex += 1;
/*     */     
/* 161 */     if (this.currentPlayingIndex >= getSongs().size()) {
/* 162 */       this.currentPlayingIndex = -1;
/*     */     }
/*     */     
/* 165 */     broadcastSong();
/*     */   }
/*     */   
/*     */   public void broadcastSong() {
/* 169 */     if ((!this.isPlaying) || (this.currentPlayingIndex >= this.songs.size())) {
/* 170 */       getRoom().getEntities().broadcastMessage(new PlayMusicMessageComposer());
/*     */       
/* 172 */       if (this.isPlaying)
/* 173 */         this.isPlaying = false;
/* 174 */       return;
/*     */     }
/*     */     
/* 177 */     for (PlayerEntity entity : getRoom().getEntities().getPlayerEntities()) {
/* 178 */       if (!entity.hasAttribute("traxSent")) {
/* 179 */         entity.setAttribute("traxSent", Boolean.valueOf(true));
/*     */       }
/*     */       
/* 182 */       if ((entity.getPlayer() != null) && (entity.getPlayer().getSession() != null))
/* 183 */         entity.getPlayer().getSession().send(getComposer());
/*     */     }
/*     */   }
/*     */   
/*     */   public com.habboproject.server.network.messages.composers.MessageComposer getComposer() {
/* 188 */     if (this.currentPlayingIndex == -1) { return null;
/*     */     }
/* 190 */     SongItemData songItemData = (SongItemData)this.songs.get(this.currentPlayingIndex);
/*     */     
/* 192 */     if (songItemData == null) {
/* 193 */       return null;
/*     */     }
/*     */     
/* 196 */     int songId = songItemData.getSongId();
/* 197 */     return new PlayMusicMessageComposer(songId, this.currentPlayingIndex, songTimeSync());
/*     */   }
/*     */   
/*     */   private int timePlaying() {
/* 201 */     return (int)(Comet.getTime() - this.startTimestamp);
/*     */   }
/*     */   
/*     */   public int songTimeSync() {
/* 205 */     if ((!this.isPlaying) || (this.currentPlayingIndex < 0) || (this.currentPlayingIndex >= getSongs().size())) {
/* 206 */       return 0;
/*     */     }
/*     */     
/* 209 */     SongItemData songItemData = (SongItemData)getSongs().get(this.currentPlayingIndex);
/*     */     
/* 211 */     if (songItemData != null) {
/* 212 */       MusicData musicData = ItemManager.getInstance().getMusicData(songItemData.getSongId());
/*     */       
/* 214 */       if ((musicData != null) && 
/* 215 */         (timePlaying() >= musicData.getLengthSeconds())) {
/* 216 */         return musicData.getLengthSeconds();
/*     */       }
/*     */     }
/*     */     
/* 220 */     return timePlaying() * 1000;
/*     */   }
/*     */   
/*     */   public String getDataObject()
/*     */   {
/* 225 */     return (this.isPlaying ? "##jukeboxOn" : "##jukeboxOff") + JsonFactory.getInstance().toJson(this.songs);
/*     */   }
/*     */   
/*     */   public void onUnload()
/*     */   {
/* 230 */     getSongs().clear();
/*     */   }
/*     */   
/*     */   public List<SongItemData> getSongs() {
/* 234 */     return this.songs;
/*     */   }
/*     */   
/*     */   public boolean getState()
/*     */   {
/* 239 */     return this.isPlaying;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\jukebox\SoundMachineFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */