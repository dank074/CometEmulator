/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredAddonPyramid extends RoomItemFloor
/*    */ {
/* 11 */   private boolean hasEntity = false;
/*    */   
/*    */   public WiredAddonPyramid(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 16 */     setTicks(com.habboproject.server.utilities.RandomInteger.getRandom(5, 8) * 2);
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 21 */     this.hasEntity = true;
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 26 */     this.hasEntity = false;
/*    */   }
/*    */   
/*    */   public void onTickComplete()
/*    */   {
/* 31 */     if (this.hasEntity) {
/* 32 */       setTicks(RoomItemFactory.getProcessTime(1.0D));
/* 33 */       return;
/*    */     }
/*    */     
/* 36 */     if (getExtraData().equals("1")) {
/* 37 */       setExtraData("0");
/*    */     } else {
/* 39 */       setExtraData("1");
/*    */     }
/*    */     
/* 42 */     sendUpdate();
/* 43 */     setTicks(RoomItemFactory.getProcessTime(com.habboproject.server.utilities.RandomInteger.getRandom(5, 8)));
/*    */     
/* 45 */     getRoom().getMapping().updateTile(getPosition().getX(), getPosition().getY());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\addons\WiredAddonPyramid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */