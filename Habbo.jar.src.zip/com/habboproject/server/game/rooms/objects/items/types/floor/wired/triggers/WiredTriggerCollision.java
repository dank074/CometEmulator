/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredTriggerCollision extends com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem
/*    */ {
/*    */   public WiredTriggerCollision(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 10 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 15 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 20 */     return 9;
/*    */   }
/*    */   
/*    */   public static boolean executeTriggers(RoomEntity entity) {
/* 24 */     boolean wasExecuted = false;
/*    */     
/* 26 */     for (com.habboproject.server.game.rooms.objects.items.RoomItemFloor floorItem : entity.getRoom().getItems().getByClass(WiredTriggerCollision.class)) {
/* 27 */       WiredTriggerCollision trigger = (WiredTriggerCollision)floorItem;
/*    */       
/* 29 */       wasExecuted = trigger.evaluate(entity, null);
/*    */     }
/*    */     
/* 32 */     return wasExecuted;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerCollision.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */