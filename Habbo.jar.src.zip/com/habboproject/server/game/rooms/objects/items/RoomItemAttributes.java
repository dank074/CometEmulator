package com.habboproject.server.game.rooms.objects.items;

public abstract interface RoomItemAttributes
{
  public abstract int getId();
  
  public abstract int getItemId();
  
  public abstract int getOwner();
  
  public abstract int getX();
  
  public abstract int getY();
  
  public abstract int getRotation();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\RoomItemAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */