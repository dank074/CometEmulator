/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.boutique;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class MannequinFloorItem extends RoomItemFloor
/*     */ {
/*  13 */   private String name = "New Mannequin";
/*  14 */   private String figure = "ch-210-62.lg-270-62";
/*  15 */   private String gender = "m";
/*     */   
/*     */   public MannequinFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     
/*  20 */     if (!getExtraData().isEmpty()) {
/*  21 */       String[] splitData = getExtraData().split(";#;");
/*  22 */       if (splitData.length != 3) { return;
/*     */       }
/*  24 */       this.name = splitData[0];
/*  25 */       this.figure = splitData[1];
/*  26 */       this.gender = splitData[2];
/*     */       
/*  28 */       String[] figureParts = this.figure.split("\\.");
/*  29 */       String finalFigure = "";
/*     */       String[] arrayOfString1;
/*  31 */       int j = (arrayOfString1 = figureParts).length; for (int i = 0; i < j; i++) { String figurePart = arrayOfString1[i];
/*  32 */         if ((!figurePart.contains("hr")) && (!figurePart.contains("hd")) && (!figurePart.contains("he")) && (!figurePart.contains("ha"))) {
/*  33 */           finalFigure = finalFigure + figurePart + ".";
/*     */         }
/*     */       }
/*     */       
/*  37 */       this.figure = finalFigure.substring(0, finalFigure.length() - 1);
/*     */     }
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg, boolean isNew)
/*     */   {
/*  43 */     msg.writeInt(0);
/*  44 */     msg.writeInt(1);
/*  45 */     msg.writeInt(3);
/*     */     
/*  47 */     msg.writeString("GENDER");
/*  48 */     msg.writeString(getGender());
/*  49 */     msg.writeString("FIGURE");
/*  50 */     msg.writeString(getFigure());
/*  51 */     msg.writeString("OUTFIT_NAME");
/*  52 */     msg.writeString(getName());
/*     */     
/*  54 */     msg.writeInt(0);
/*  55 */     msg.writeInt(0);
/*  56 */     msg.writeInt(this.ownerId);
/*     */     
/*  58 */     if (isNew) {
/*  59 */       msg.writeString(getRoom().getData().getOwner());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onInteract(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity, int requestData, boolean isWiredTrigger)
/*     */   {
/*  65 */     if ((isWiredTrigger) || (!(entity instanceof PlayerEntity))) {
/*  66 */       return isWiredTrigger;
/*     */     }
/*  68 */     PlayerEntity playerEntity = (PlayerEntity)entity;
/*     */     
/*  70 */     if ((this.name == null) || (this.gender == null) || (this.figure == null)) { return false;
/*     */     }
/*  72 */     if (!this.gender.equals(playerEntity.getGender())) { return false;
/*     */     }
/*  74 */     String newFigure = "";
/*     */     
/*  76 */     for (Object localObject = java.util.Arrays.asList(playerEntity.getFigure().split("\\.")).iterator(); ((Iterator)localObject).hasNext();) { String playerFigurePart = (String)((Iterator)localObject).next();
/*  77 */       if ((!playerFigurePart.startsWith("ch")) && (!playerFigurePart.startsWith("lg"))) {
/*  78 */         newFigure = newFigure + playerFigurePart + ".";
/*     */       }
/*     */     }
/*  81 */     String newFigureParts = "";
/*     */     
/*  83 */     switch ((localObject = playerEntity.getGender().toUpperCase()).hashCode()) {case 70:  if (((String)localObject).equals("F")) break;  case 77:  if ((goto 269) && (((String)localObject).equals("M")))
/*     */       {
/*  85 */         if (this.figure.equals("")) return false;
/*  86 */         newFigureParts = this.figure;
/*     */         
/*     */         break label269;
/*     */         
/*  90 */         if (this.figure.equals("")) return false;
/*  91 */         newFigureParts = this.figure;
/*     */       }
/*     */       break; }
/*     */     label269:
/*  95 */     for (String newFigurePart : java.util.Arrays.asList(newFigureParts.split("\\."))) {
/*  96 */       if (newFigurePart.startsWith("hd")) {
/*  97 */         newFigureParts = newFigureParts.replace(newFigurePart, "");
/*     */       }
/*     */     }
/* 100 */     if (newFigureParts.equals("")) { return false;
/*     */     }
/* 102 */     String figure = newFigure + newFigureParts;
/*     */     
/* 104 */     if (figure.length() > 512) {
/* 105 */       return false;
/*     */     }
/* 107 */     playerEntity.getPlayer().getData().setFigure(figure);
/* 108 */     playerEntity.getPlayer().getData().setGender(this.gender);
/*     */     
/* 110 */     playerEntity.getPlayer().getData().save();
/* 111 */     playerEntity.getPlayer().poof();
/*     */     
/* 113 */     return true;
/*     */   }
/*     */   
/*     */   public String getDataObject()
/*     */   {
/* 118 */     return this.name + ";#;" + this.figure + ";#;" + this.gender;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 122 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getFigure() {
/* 126 */     return this.figure;
/*     */   }
/*     */   
/*     */   public void setFigure(String figure) {
/* 130 */     this.figure = figure;
/*     */   }
/*     */   
/*     */   public String getGender() {
/* 134 */     return this.gender;
/*     */   }
/*     */   
/*     */   public void setGender(String gender) {
/* 138 */     this.gender = gender;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 142 */     this.name = name;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\boutique\MannequinFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */