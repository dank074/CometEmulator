/*    */ package com.habboproject.server.game.rooms.objects.items.types;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.executors.item.FloorItemExecuteEvent;
/*    */ import com.habboproject.server.utilities.collections.ConcurrentHashSet;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AdvancedFloorItem<T extends FloorItemExecuteEvent>
/*    */   extends RoomItemFloor
/*    */ {
/* 15 */   private final Set<T> itemEvents = new ConcurrentHashSet();
/*    */   
/*    */   public AdvancedFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void onTick()
/*    */   {
/* 23 */     Set<T> finishedEvents = new HashSet();
/*    */     
/* 25 */     for (T itemEvent : this.itemEvents) {
/* 26 */       itemEvent.incrementTicks();
/*    */       
/* 28 */       if (itemEvent.isFinished()) {
/* 29 */         finishedEvents.add(itemEvent);
/*    */       }
/*    */     }
/*    */     
/* 33 */     for (T finishedEvent : finishedEvents) {
/* 34 */       this.itemEvents.remove(finishedEvent);
/*    */       
/* 36 */       finishedEvent.onCompletion(this);
/*    */       
/* 38 */       if (finishedEvent.isInteractiveEvent()) {
/* 39 */         onEventComplete(finishedEvent);
/*    */       }
/*    */     }
/*    */     
/* 43 */     finishedEvents.clear();
/*    */   }
/*    */   
/*    */   public void queueEvent(T floorItemEvent) {
/* 47 */     if (getMaxEvents() <= this.itemEvents.size()) {
/* 48 */       return;
/*    */     }
/*    */     
/* 51 */     this.itemEvents.add(floorItemEvent);
/*    */   }
/*    */   
/*    */   protected abstract void onEventComplete(T paramT);
/*    */   
/*    */   public int getMaxEvents() {
/* 57 */     return 5000;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\AdvancedFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */