/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.bots.BotData;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.network.messages.outgoing.room.avatar.UpdateInfoMessageComposer;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ 
/*    */ public class WiredActionBotClothes extends WiredActionItem
/*    */ {
/*    */   public WiredActionBotClothes(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 16 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 21 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 26 */     return 26;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 31 */     if ((event.entity == null) || (!(event.entity instanceof com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity))) {
/* 32 */       return;
/*    */     }
/*    */     
/* 35 */     if (!getWiredData().getText().contains("\t")) {
/* 36 */       return;
/*    */     }
/*    */     
/* 39 */     String[] packetData = getWiredData().getText().split("\t");
/* 40 */     if (packetData.length != 2) {
/* 41 */       return;
/*    */     }
/*    */     
/* 44 */     String botName = packetData[0];
/* 45 */     String botLook = packetData[1];
/*    */     
/* 47 */     if ((botName.isEmpty()) || (botLook.isEmpty())) {
/* 48 */       return;
/*    */     }
/*    */     
/* 51 */     BotEntity botEntity = getRoom().getBots().getBotByName(botName);
/* 52 */     if (botEntity != null) {
/* 53 */       botEntity.getData().setFigure(botLook);
/* 54 */       botEntity.getData().setGender("M");
/*    */       
/* 56 */       getRoom().getEntities().broadcastMessage(new UpdateInfoMessageComposer(botEntity));
/*    */       
/* 58 */       botEntity.getData().save();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionBotClothes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */