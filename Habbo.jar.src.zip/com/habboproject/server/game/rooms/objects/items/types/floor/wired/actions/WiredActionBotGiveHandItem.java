/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredActionBotGiveHandItem extends com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem
/*    */ {
/*    */   private static final int PARAM_HANDITEM = 0;
/*    */   
/*    */   public WiredActionBotGiveHandItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 17 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 19 */     if (getWiredData().getParams().size() < 1) {
/* 20 */       getWiredData().getParams().clear();
/* 21 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(0));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 27 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 32 */     return 24;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 37 */     if (getWiredData().getParams().size() != 1) {
/* 38 */       return;
/*    */     }
/*    */     
/* 41 */     if (getWiredData().getText().isEmpty()) {
/* 42 */       return;
/*    */     }
/*    */     
/* 45 */     if ((event.entity == null) || (!(event.entity instanceof com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity))) {
/* 46 */       return;
/*    */     }
/*    */     
/* 49 */     int param = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */     
/* 51 */     String botName = getWiredData().getText();
/* 52 */     BotEntity botEntity = getRoom().getBots().getBotByName(botName);
/*    */     
/* 54 */     if (botEntity != null) {
/* 55 */       if (botEntity.isWalking()) {
/* 56 */         botEntity.cancelWalk();
/*    */       }
/*    */       
/* 59 */       if ((event.entity.getPosition().getX() != getRoom().getModel().getDoorX()) && (event.entity.getPosition().getY() != getRoom().getModel().getDoorY())) {
/* 60 */         double distance = event.entity.getPosition().distanceTo(event.entity.getPosition());
/*    */         
/* 62 */         if ((distance != 0.0D) && (distance <= 1.0D)) {
/* 63 */           botEntity.getData().setForcedUserTargetMovement(event.entity.getId());
/* 64 */           botEntity.getData().setCarryingItemToUser(true);
/* 65 */           botEntity.carryItem(param);
/* 66 */           botEntity.moveTo(event.entity.getPosition().getX(), event.entity.getPosition().getY());
/*    */         } else {
/* 68 */           getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer(botEntity.getId(), com.habboproject.server.config.Locale.get("bots.chat.giveItemMessage").replace("%username%", event.entity.getUsername()), com.habboproject.server.game.rooms.RoomManager.getInstance().getEmotions().getEmotion(":)"), 2));
/*    */           
/* 70 */           event.entity.carryItem(param);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionBotGiveHandItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */