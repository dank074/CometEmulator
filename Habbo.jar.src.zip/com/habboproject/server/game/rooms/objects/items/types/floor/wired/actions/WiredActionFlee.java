/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*     */ 
/*     */ import com.google.common.collect.Maps;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.AffectedTile;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.Square;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.types.ItemPathfinder;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerCollision;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomMapping;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomTile;
/*     */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class WiredActionFlee extends WiredActionItem
/*     */ {
/*     */   public WiredActionFlee(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  27 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public boolean requiresPlayer()
/*     */   {
/*  32 */     return false;
/*     */   }
/*     */   
/*     */   public int getInterface()
/*     */   {
/*  37 */     return 12;
/*     */   }
/*     */   
/*     */   public void onEventComplete(WiredItemExecuteEvent event)
/*     */   {
/*  42 */     if (getWiredData().getSelectedIds().size() == 0) {
/*  43 */       return;
/*     */     }
/*     */     
/*  46 */     List<Long> toRemove = com.google.common.collect.Lists.newArrayList();
/*  47 */     for (Iterator localIterator = getWiredData().getSelectedIds().iterator(); localIterator.hasNext();) {
/*  48 */       long itemId = ((Long)localIterator.next()).longValue();
/*     */       
/*  50 */       RoomItemFloor floorItem = getRoom().getItems().getFloorItem(itemId);
/*     */       
/*  52 */       if (floorItem == null) {
/*  53 */         toRemove.add(Long.valueOf(itemId));
/*     */       } else {
/*  55 */         PlayerEntity nearestEntity = floorItem.nearestPlayerEntity();
/*  56 */         Position positionFrom = floorItem.getPosition().copy();
/*     */         
/*  58 */         if ((nearestEntity != null) && (nearestEntity.getPosition() != null)) {
/*  59 */           Position newCoordinate = floorItem.getPosition().squareBehind(Position.calculateRotation(floorItem.getPosition().getX(), floorItem.getPosition().getY(), nearestEntity.getPosition().getX(), nearestEntity.getPosition().getY(), false));
/*     */           
/*  61 */           List<Square> tilesToEntity = ItemPathfinder.getInstance().makePath(floorItem, newCoordinate, (byte)0, false);
/*  62 */           if ((tilesToEntity != null) && (tilesToEntity.size() != 0)) {
/*  63 */             Position positionTo = new Position(((Square)tilesToEntity.get(0)).x, ((Square)tilesToEntity.get(0)).y);
/*  64 */             moveToTile(floorItem, positionFrom, positionTo);
/*  65 */             tilesToEntity.clear();
/*     */           } else {
/*  67 */             moveToTile(floorItem, positionFrom, null);
/*     */           }
/*     */         } else {
/*  70 */           moveToTile(floorItem, positionFrom, null);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  75 */     if (toRemove.size() > 0) {
/*  76 */       for (Iterator localIterator1 = toRemove.iterator(); localIterator1.hasNext();) { long itemId = ((Long)localIterator1.next()).longValue();
/*  77 */         if (getWiredData().getSelectedIds().contains(Long.valueOf(itemId)))
/*  78 */           getWiredData().getSelectedIds().remove(Long.valueOf(itemId));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCollided(PlayerEntity entity, RoomItemFloor floorItem) {
/*  84 */     return ((AffectedTile.tilesAdjecent(entity.getPosition(), floorItem.getPosition())) && ((entity.getPosition().getX() == floorItem.getPosition().getX()) || 
/*  85 */       (entity.getPosition().getY() == floorItem.getPosition().getY()))) || ((entity.getPosition().getX() == floorItem.getPosition().getX()) && (entity.getPosition().getY() == floorItem.getPosition().getY()));
/*     */   }
/*     */   
/*     */   private void moveToTile(RoomItemFloor floorItem, Position from, Position to) {
/*  89 */     if (from == null) {
/*  90 */       return;
/*     */     }
/*     */     
/*  93 */     if (to == null) {
/*  94 */       for (int i = 0; i < 16; i++) {
/*  95 */         if (to != null)
/*     */           break;
/*  97 */         to = random(floorItem, from);
/*     */       }
/*     */       
/* 100 */       if (to == null) {
/* 101 */         return;
/*     */       }
/*     */     }
/*     */     
/* 105 */     if (getRoom().getItems().moveFloorItem(floorItem.getId(), to, floorItem.getRotation(), true)) {
/* 106 */       Map<Integer, Double> items = Maps.newHashMap();
/*     */       
/* 108 */       items.put(Integer.valueOf(floorItem.getVirtualId()), Double.valueOf(floorItem.getPosition().getZ()));
/*     */       
/* 110 */       getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.items.SlideObjectBundleMessageComposer(from, to, 0, 0, items));
/*     */     }
/*     */     
/* 113 */     PlayerEntity nearestEntity = floorItem.nearestPlayerEntity();
/* 114 */     if ((nearestEntity != null) && (isCollided(nearestEntity, floorItem))) {
/* 115 */       floorItem.setCollision(nearestEntity);
/* 116 */       WiredTriggerCollision.executeTriggers(nearestEntity);
/*     */     }
/*     */     
/* 119 */     floorItem.nullifyCollision();
/*     */   }
/*     */   
/*     */   private Position random(RoomItemFloor floorItem, Position from) {
/* 123 */     int randomDirection = com.habboproject.server.utilities.RandomInteger.getRandom(0, 3) * 2;
/* 124 */     Position newPosition = from.squareBehind(randomDirection);
/* 125 */     RoomTile tile = floorItem.getRoom().getMapping().getTile(newPosition.getX(), newPosition.getY());
/*     */     
/* 127 */     if ((tile != null) && (tile.isReachable(floorItem))) {
/* 128 */       return newPosition;
/*     */     }
/*     */     
/* 131 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionFlee.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */