/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredActionGiveScore extends WiredActionItem
/*    */ {
/*    */   private static final int PARAM_SCORE = 0;
/*    */   private static final int PARAM_PER_GAME = 1;
/*    */   private final Map<Long, Integer> GAME_DATA;
/*    */   
/*    */   public WiredActionGiveScore(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 20 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 22 */     this.GAME_DATA = Maps.newHashMap();
/*    */     
/* 24 */     if (getWiredData().getParams().size() < 2) {
/* 25 */       getWiredData().getParams().clear();
/* 26 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(1));
/* 27 */       getWiredData().getParams().put(Integer.valueOf(1), Integer.valueOf(1));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 33 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 38 */     return 6;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 43 */     if (!(event.entity instanceof PlayerEntity)) {
/* 44 */       return;
/*    */     }
/*    */     
/* 47 */     if (!(event.entity instanceof PlayerEntity)) {
/* 48 */       return;
/*    */     }
/*    */     
/* 51 */     PlayerEntity playerEntity = (PlayerEntity)event.entity;
/* 52 */     if ((playerEntity.getGameTeam() == null) || (playerEntity.getGameTeam() == com.habboproject.server.game.rooms.types.components.games.GameTeam.NONE)) {
/* 53 */       return;
/*    */     }
/*    */     
/* 56 */     getRoom().getGame().increaseScoreToPlayer(getId(), playerEntity, playerEntity.getGameTeam(), getPerGame(), getScore());
/*    */   }
/*    */   
/*    */   public int getScore() {
/* 60 */     return ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */   }
/*    */   
/*    */   public int getPerGame() {
/* 64 */     return ((Integer)getWiredData().getParams().get(Integer.valueOf(1))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionGiveScore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */