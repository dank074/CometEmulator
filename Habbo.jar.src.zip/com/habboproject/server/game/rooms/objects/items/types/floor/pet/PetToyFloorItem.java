/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.pet;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntityStatus;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PetEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.DefaultFloorItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.ThreadManager;
/*    */ import com.habboproject.server.threads.executors.item.FloorItemUpdateStateEvent;
/*    */ 
/*    */ public class PetToyFloorItem extends DefaultFloorItem
/*    */ {
/*    */   public PetToyFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 15 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 20 */     if ((entity == null) || (!(entity instanceof PetEntity))) {
/* 21 */       return;
/*    */     }
/*    */     
/* 24 */     entity.setHeadRotation(getRotation());
/* 25 */     entity.setBodyRotation(getRotation());
/*    */     
/* 27 */     entity.addStatus(RoomEntityStatus.PLAY, "");
/* 28 */     entity.markNeedsUpdate();
/*    */     
/* 30 */     ThreadManager.getInstance().executeSchedule(new FloorItemUpdateStateEvent(this, "1"), 250L, java.util.concurrent.TimeUnit.MILLISECONDS);
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 35 */     if (!(entity instanceof PetEntity)) {
/* 36 */       return;
/*    */     }
/*    */     
/* 39 */     entity.removeStatus(RoomEntityStatus.PLAY);
/* 40 */     entity.markNeedsUpdate();
/*    */     
/* 42 */     setExtraData("0");
/* 43 */     sendUpdate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\pet\PetToyFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */