/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import com.habboproject.server.network.messages.outgoing.room.items.SlideObjectBundleMessageComposer;
/*    */ 
/*    */ public class WiredAddonPuzzleBoxFloorItem extends RoomItemFloor
/*    */ {
/*    */   public WiredAddonPuzzleBoxFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 15 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger) {
/* 19 */     if ((entity == null) || (!(entity instanceof com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity))) {
/* 20 */       return false;
/*    */     }
/*    */     
/* 23 */     if ((getPosition().distanceTo(entity.getPosition()) >= 0.0D) && (getPosition().distanceTo(entity.getPosition()) <= 1.0D)) {
/* 24 */       entity.setBodyRotation(Position.calculateRotation(entity.getPosition().getX(), entity.getPosition().getY(), getPosition().getX(), getPosition().getY(), false));
/* 25 */       entity.setHeadRotation(entity.getBodyRotation());
/*    */       
/* 27 */       if (entity.getBodyRotation() % 2 != 0) {
/* 28 */         entity.moveTo(getPosition().getX() + 1, getPosition().getY());
/* 29 */         return true;
/*    */       }
/*    */       
/* 32 */       Position oldPosition = getPosition().copy();
/* 33 */       Position newPosition = new Position(0, 0, getPosition().getZ());
/*    */       
/* 35 */       switch (entity.getBodyRotation()) {
/*    */       case 0: 
/* 37 */         newPosition = new Position(getPosition().getX(), getPosition().getY() - 1);
/* 38 */         break;
/*    */       
/*    */       case 2: 
/* 41 */         newPosition = new Position(getPosition().getX() + 1, getPosition().getY());
/* 42 */         break;
/*    */       
/*    */       case 4: 
/* 45 */         newPosition = new Position(getPosition().getX(), getPosition().getY() + 1);
/* 46 */         break;
/*    */       
/*    */       case 6: 
/* 49 */         newPosition = new Position(getPosition().getX() - 1, getPosition().getY());
/*    */       }
/*    */       
/*    */       
/* 53 */       if ((getRoom().getItems().moveFloorItem(getId(), newPosition, getRotation(), true)) && (oldPosition != null)) {
/* 54 */         getRoom().getEntities().broadcastMessage(new SlideObjectBundleMessageComposer(oldPosition, newPosition, 0, 0, getVirtualId()));
/* 55 */         entity.moveTo(oldPosition.getX(), oldPosition.getY());
/*    */       }
/*    */     } else {
/* 58 */       entity.moveTo(getPosition().getX() + 1, getPosition().getY());
/*    */     }
/*    */     
/* 61 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\addons\WiredAddonPuzzleBoxFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */