/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.adjustable;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.mapping.RoomTile;
/*    */ import java.text.DecimalFormat;
/*    */ 
/*    */ public class MagicStackFloorItem extends RoomItemFloor
/*    */ {
/* 11 */   private double magicHeight = 0.0D;
/*    */   
/*    */   public MagicStackFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 16 */     if (!data.isEmpty()) {
/* 17 */       this.magicHeight = Double.parseDouble(data);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getDataObject()
/*    */   {
/* 23 */     return this.magicHeight == 0.0D ? "" : new DecimalFormat("#.00").format(this.magicHeight).replace(",", ".");
/*    */   }
/*    */   
/*    */   public void onPlaced()
/*    */   {
/* 28 */     this.magicHeight = 0.0D;
/* 29 */     saveData();
/*    */   }
/*    */   
/*    */   public double getMagicHeight() {
/* 33 */     RoomTile tile = getRoom().getMapping().getTile(getPosition().copy());
/* 34 */     if (tile != null) {
/* 35 */       return tile.getTileHeight() + this.magicHeight;
/*    */     }
/*    */     
/* 38 */     return this.magicHeight;
/*    */   }
/*    */   
/*    */   public void setMagicHeight(double magicHeight) {
/* 42 */     setExtraData(new DecimalFormat("#.00").format(magicHeight).replace(",", "."));
/* 43 */     this.magicHeight = magicHeight;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\adjustable\MagicStackFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */