/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.base;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.game.permissions.types.Rank;
/*     */ import com.habboproject.server.game.players.components.PermissionComponent;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions.WiredActionKickUser;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons.WiredAddonRandomEffect;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons.WiredAddonUnseenEffect;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerEnterRoom;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.network.messages.composers.MessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.items.wired.dialog.WiredTriggerMessageComposer;
/*     */ import com.habboproject.server.utilities.RandomInteger;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ public abstract class WiredTriggerItem
/*     */   extends WiredFloorItem
/*     */ {
/*  26 */   private static Logger log = Logger.getLogger(WiredTriggerItem.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WiredTriggerItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  42 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public boolean evaluate(RoomEntity entity, Object data)
/*     */   {
/*     */     try
/*     */     {
/*  49 */       List<WiredActionItem> wiredActions = Lists.newArrayList();
/*     */       
/*     */ 
/*  52 */       List<WiredConditionItem> wiredConditions = Lists.newArrayList();
/*     */       
/*     */ 
/*  55 */       boolean useRandomEffect = false;
/*  56 */       WiredAddonUnseenEffect unseenEffectItem = null;
/*     */       
/*  58 */       boolean canExecute = true;
/*     */       
/*     */ 
/*  61 */       flash();
/*     */       
/*     */ 
/*  64 */       for (RoomItemFloor floorItem : getItemsOnStack()) {
/*  65 */         if ((floorItem instanceof WiredActionItem))
/*     */         {
/*     */ 
/*  68 */           wiredActions.add((WiredActionItem)floorItem);
/*  69 */         } else if ((floorItem instanceof WiredConditionItem))
/*     */         {
/*     */ 
/*  72 */           wiredConditions.add((WiredConditionItem)floorItem);
/*  73 */         } else if (((floorItem instanceof WiredAddonUnseenEffect)) && (unseenEffectItem == null))
/*     */         {
/*  75 */           unseenEffectItem = (WiredAddonUnseenEffect)floorItem;
/*  76 */         } else if ((floorItem instanceof WiredAddonRandomEffect)) {
/*  77 */           useRandomEffect = true;
/*     */         }
/*     */       }
/*     */       
/*  81 */       if ((unseenEffectItem != null) && (unseenEffectItem.getSeenEffects().size() >= wiredActions.size())) {
/*  82 */         unseenEffectItem.getSeenEffects().clear();
/*     */       }
/*     */       
/*     */ 
/*  86 */       for (WiredConditionItem conditionItem : wiredConditions) {
/*  87 */         conditionItem.flash();
/*     */         
/*  89 */         if (!conditionItem.evaluate(entity, data)) {
/*  90 */           canExecute = false;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  96 */       preActionTrigger(entity, data);
/*     */       
/*     */ 
/*  99 */       if ((canExecute) && (wiredActions.size() >= 1))
/*     */       {
/*     */ 
/* 102 */         boolean wasSuccess = false;
/*     */         WiredActionItem actionItem;
/* 104 */         if (useRandomEffect) {
/* 105 */           int itemIndex = RandomInteger.getRandom(0, wiredActions.size() - 1);
/*     */           
/* 107 */           actionItem = (WiredActionItem)wiredActions.get(itemIndex);
/*     */           
/* 109 */           if ((actionItem != null) && 
/* 110 */             (executeEffect(actionItem, entity, data))) {}
/* 111 */           return true;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 116 */         if (unseenEffectItem != null) {
/* 117 */           for (WiredActionItem actionItem : wiredActions) {
/* 118 */             if (!unseenEffectItem.getSeenEffects().contains(Long.valueOf(actionItem.getId()))) {
/* 119 */               unseenEffectItem.getSeenEffects().add(Long.valueOf(actionItem.getId()));
/*     */               
/* 121 */               if (!executeEffect(actionItem, entity, data)) break;
/* 122 */               wasSuccess = true;
/* 123 */               break;
/*     */             }
/*     */           }
/*     */           
/* 127 */           return wasSuccess;
/*     */         }
/* 129 */         for (WiredActionItem actionItem : wiredActions) {
/* 130 */           if (executeEffect(actionItem, entity, data)) {
/* 131 */             wasSuccess = true;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 136 */         return wasSuccess;
/*     */       }
/*     */     } catch (Exception e) {
/* 139 */       log.error("Error during WiredTrigger evaluation", e);
/*     */     }
/*     */     
/*     */ 
/* 143 */     return false;
/*     */   }
/*     */   
/*     */   private boolean executeEffect(WiredActionItem actionItem, RoomEntity entity, Object data) {
/* 147 */     if (((this instanceof WiredTriggerEnterRoom)) && ((actionItem instanceof WiredActionKickUser)) && 
/* 148 */       (entity != null) && 
/* 149 */       ((entity instanceof PlayerEntity)) && (((PlayerEntity)entity).getPlayer() != null) && 
/* 150 */       (!((PlayerEntity)entity).getPlayer().getPermissions().getRank().roomKickable())) {
/* 151 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 157 */     return actionItem.evaluate(entity, data);
/*     */   }
/*     */   
/*     */   public MessageComposer getDialog()
/*     */   {
/* 162 */     return new WiredTriggerMessageComposer(this);
/*     */   }
/*     */   
/*     */   public List<WiredActionItem> getIncompatibleActions()
/*     */   {
/* 167 */     List<WiredActionItem> incompatibleActions = Lists.newArrayList();
/*     */     
/*     */ 
/* 170 */     if (!suppliesPlayer())
/*     */     {
/* 172 */       for (RoomItemFloor floorItem : getItemsOnStack()) {
/* 173 */         if ((floorItem instanceof WiredActionItem))
/*     */         {
/* 175 */           if (((WiredActionItem)floorItem).requiresPlayer())
/*     */           {
/* 177 */             incompatibleActions.add((WiredActionItem)floorItem);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 183 */     return incompatibleActions;
/*     */   }
/*     */   
/*     */   public void preActionTrigger(RoomEntity entity, Object data) {}
/*     */   
/*     */   public abstract boolean suppliesPlayer();
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\base\WiredTriggerItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */