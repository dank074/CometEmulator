/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.others;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.DefaultFloorItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.messages.composers.MessageComposer;
/*    */ import java.util.List;
/*    */ 
/*    */ public class PrivateChatFloorItem extends DefaultFloorItem
/*    */ {
/* 14 */   private List<PlayerEntity> entities = Lists.newArrayList();
/*    */   
/*    */   public PrivateChatFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 17 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 22 */     if ((!(entity instanceof PlayerEntity)) || (this.entities.contains(entity))) { return;
/*    */     }
/* 24 */     entity.setPrivateChatItemId(getId());
/* 25 */     this.entities.add((PlayerEntity)entity);
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 30 */     if (!(entity instanceof PlayerEntity)) { return;
/*    */     }
/* 32 */     entity.setPrivateChatItemId(0L);
/* 33 */     this.entities.remove(entity);
/*    */   }
/*    */   
/*    */   public void broadcastMessage(MessageComposer msg) {
/* 37 */     for (PlayerEntity playerEntity : this.entities) {
/* 38 */       playerEntity.getPlayer().getSession().send(msg);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\others\PrivateChatFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */