/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionPlayerCountInRoom
/*    */   extends WiredConditionItem
/*    */ {
/*    */   private static final int PARAM_AT_LEAST = 0;
/*    */   private static final int PARAM_NO_MORE_THAN = 1;
/*    */   
/*    */   public WiredConditionPlayerCountInRoom(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 28 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 33 */     return 5;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 38 */     if (getWiredData().getParams().size() != 2) { return true;
/*    */     }
/* 40 */     int playerCount = getRoom().getEntities().getPlayerEntities().size();
/*    */     
/* 42 */     if ((playerCount >= ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue()) && (playerCount <= ((Integer)getWiredData().getParams().get(Integer.valueOf(1))).intValue()))
/*    */     {
/* 44 */       return !this.isNegative;
/*    */     }
/*    */     
/*    */ 
/* 48 */     return this.isNegative;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionPlayerCountInRoom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */