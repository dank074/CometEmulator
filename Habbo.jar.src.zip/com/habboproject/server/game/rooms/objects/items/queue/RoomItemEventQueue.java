/*    */ package com.habboproject.server.game.rooms.objects.items.queue;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemWall;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoomItemEventQueue
/*    */ {
/* 14 */   private final List<RoomItemEventQueueEntry> eventQueue = new LinkedList();
/* 15 */   private final Object lock = new Object();
/*    */   
/*    */   public void cycle() {
/* 18 */     if (this.eventQueue.size() == 0) {
/* 19 */       return;
/*    */     }
/*    */     
/* 22 */     List<RoomItemEventQueueEntry> eventQueueCopy = new LinkedList();
/*    */     RoomItemEventQueueEntry e;
/* 24 */     synchronized (this.lock) {
/* 25 */       for (Iterator localIterator = this.eventQueue.iterator(); localIterator.hasNext();) { e = (RoomItemEventQueueEntry)localIterator.next();
/* 26 */         eventQueueCopy.add(e);
/*    */       }
/*    */       
/* 29 */       this.eventQueue.clear();
/*    */     }
/*    */     
/* 32 */     for (RoomItemEventQueueEntry e : eventQueueCopy) {
/* 33 */       if ((e.getItem() instanceof RoomItemWall)) {
/* 34 */         RoomItemWall wall = (RoomItemWall)e.getItem();
/*    */         
/* 36 */         switch (e.getType()) {
/*    */         case StepOff: 
/* 38 */           wall.onPickup();
/* 39 */           break;
/*    */         
/*    */         case PreStepOn: 
/* 42 */           wall.onPlaced();
/* 43 */           return;
/*    */         
/*    */         case StepOn: 
/* 46 */           wall.onInteract(e.getEntity(), e.getRequestData(), e.isWiredTrigger());
/*    */         }
/*    */       }
/* 49 */       else if ((e.getItem() instanceof RoomItemFloor)) {
/* 50 */         RoomItemFloor floor = (RoomItemFloor)e.getItem();
/*    */         
/* 52 */         switch (e.getType()) {
/*    */         case StepOff: 
/* 54 */           floor.onPickup();
/* 55 */           break;
/*    */         
/*    */         case PreStepOn: 
/* 58 */           floor.onPlaced();
/* 59 */           return;
/*    */         
/*    */         case StepOn: 
/* 62 */           floor.onInteract(e.getEntity(), e.getRequestData(), e.isWiredTrigger());
/* 63 */           break;
/*    */         
/*    */         case Interact: 
/* 66 */           floor.onEntityPreStepOn(e.getEntity());
/* 67 */           break;
/*    */         
/*    */         case Pickup: 
/* 70 */           floor.onEntityStepOn(e.getEntity());
/* 71 */           break;
/*    */         
/*    */         case Placed: 
/* 74 */           floor.onEntityStepOff(e.getEntity());
/*    */         }
/*    */         
/*    */       }
/*    */     }
/*    */     
/* 80 */     eventQueueCopy.clear();
/*    */   }
/*    */   
/*    */   public void queue(RoomItemEventQueueEntry entry)
/*    */   {
/* 85 */     synchronized (this.lock) {
/* 86 */       this.eventQueue.add(entry);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\queue\RoomItemEventQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */