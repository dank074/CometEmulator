/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.entries;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class HighscoreEntry
/*    */ {
/*    */   private List<String> users;
/*    */   private int score;
/*    */   
/*    */   public HighscoreEntry(List<String> users, int score)
/*    */   {
/* 13 */     this.users = users;
/* 14 */     this.score = score;
/*    */   }
/*    */   
/*    */   public List<String> getUsers() {
/* 18 */     return this.users;
/*    */   }
/*    */   
/*    */   public void setUsers(List<String> users) {
/* 22 */     this.users = users;
/*    */   }
/*    */   
/*    */   public int getScore() {
/* 26 */     return this.score;
/*    */   }
/*    */   
/*    */   public void setScore(int score) {
/* 30 */     this.score = score;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\data\scoreboard\entries\HighscoreEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */