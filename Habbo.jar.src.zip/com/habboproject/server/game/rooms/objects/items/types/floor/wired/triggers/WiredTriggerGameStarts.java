/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredTriggerGameStarts extends WiredTriggerItem
/*    */ {
/*    */   public WiredTriggerGameStarts(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 10 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 15 */     return false;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 20 */     return 9;
/*    */   }
/*    */   
/*    */   public static boolean executeTriggers(Room room) {
/* 24 */     boolean wasExecuted = false;
/*    */     
/* 26 */     for (com.habboproject.server.game.rooms.objects.items.RoomItemFloor floorItem : room.getItems().getByClass(WiredTriggerGameStarts.class)) {
/* 27 */       WiredTriggerGameStarts trigger = (WiredTriggerGameStarts)floorItem;
/*    */       
/* 29 */       wasExecuted = trigger.evaluate(null, null);
/*    */     }
/*    */     
/* 32 */     return wasExecuted;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerGameStarts.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */