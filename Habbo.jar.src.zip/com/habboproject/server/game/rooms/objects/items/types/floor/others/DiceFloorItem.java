/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.others;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class DiceFloorItem extends RoomItemFloor
/*    */ {
/* 12 */   private boolean isInUse = false;
/* 13 */   private int rigNumber = -1;
/*    */   
/*    */   public DiceFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 16 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 21 */     if ((!isWiredTrigger) && 
/* 22 */       (!getPosition().touching(entity))) {
/* 23 */       entity.moveTo(getPosition().squareInFront(this.rotation).getX(), getPosition().squareBehind(this.rotation).getY());
/* 24 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 28 */     if (this.isInUse) {
/* 29 */       return false;
/*    */     }
/*    */     
/* 32 */     if (requestData >= 0) {
/* 33 */       if (!"-1".equals(getExtraData())) {
/* 34 */         setExtraData("-1");
/* 35 */         sendUpdate();
/*    */         
/* 37 */         this.isInUse = true;
/*    */         
/* 39 */         if ((entity != null) && 
/* 40 */           (entity.hasAttribute("diceRoll"))) {
/* 41 */           this.rigNumber = ((Integer)entity.getAttribute("diceRoll")).intValue();
/* 42 */           entity.removeAttribute("diceRoll");
/*    */         }
/*    */         
/*    */ 
/* 46 */         setTicks(RoomItemFactory.getProcessTime(2.5D));
/*    */       }
/*    */     } else {
/* 49 */       setExtraData("0");
/* 50 */       sendUpdate();
/*    */       
/* 52 */       saveData();
/*    */     }
/*    */     
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   public void onPlaced()
/*    */   {
/* 60 */     if (!"0".equals(getExtraData())) {
/* 61 */       setExtraData("0");
/*    */     }
/*    */   }
/*    */   
/*    */   public void onPickup()
/*    */   {
/* 67 */     cancelTicks();
/*    */   }
/*    */   
/*    */   public void onTickComplete()
/*    */   {
/* 72 */     int num = new Random().nextInt(6) + 1;
/*    */     
/* 74 */     setExtraData(Integer.toString(this.rigNumber == -1 ? num : this.rigNumber));
/* 75 */     sendUpdate();
/*    */     
/* 77 */     saveData();
/*    */     
/* 79 */     if (this.rigNumber != -1) { this.rigNumber = -1;
/*    */     }
/* 81 */     this.isInUse = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\others\DiceFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */