/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ 
/*    */ public class WiredActionTeleportPlayer extends com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem
/*    */ {
/*    */   public WiredActionTeleportPlayer(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 13 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 18 */     if (event.entity == null) { return;
/*    */     }
/* 20 */     if ((getWiredData() == null) || (getWiredData().getSelectedIds() == null) || (getWiredData().getSelectedIds().isEmpty())) {
/* 21 */       event.entity = null;
/* 22 */       return;
/*    */     }
/*    */     
/* 25 */     Long itemId = (Long)com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredUtil.getRandomElement(getWiredData().getSelectedIds());
/*    */     
/* 27 */     if (itemId == null) {
/* 28 */       event.entity = null;
/* 29 */       return;
/*    */     }
/*    */     
/* 32 */     RoomItemFloor item = getRoom().getItems().getFloorItem(itemId.longValue());
/*    */     
/* 34 */     if ((item == null) || (item.isAtDoor()) || (item.getPosition() == null) || (item.getTile() == null)) {
/* 35 */       event.entity = null;
/* 36 */       return;
/*    */     }
/*    */     
/* 39 */     Position position = new Position(item.getPosition().getX(), item.getPosition().getY(), item.getTile().getWalkHeight());
/*    */     
/* 41 */     event.entity.applyEffect(new com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect(4, 5));
/*    */     
/* 43 */     event.entity.cancelWalk();
/* 44 */     event.entity.warp(position);
/*    */     
/* 46 */     event.entity = null;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getInterface()
/*    */   {
/* 52 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 57 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionTeleportPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */