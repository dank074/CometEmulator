/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.game.rooms.types.misc.ChatEmotion;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredActionBotTalk extends com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem
/*    */ {
/*    */   public static final int PARAM_MESSAGE_TYPE = 0;
/*    */   
/*    */   public WiredActionBotTalk(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 17 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 19 */     if (getWiredData().getParams().size() < 1) {
/* 20 */       getWiredData().getParams().clear();
/* 21 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(0));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 27 */     return false;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 32 */     return 23;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 37 */     if (!getWiredData().getText().contains("\t")) {
/* 38 */       return;
/*    */     }
/*    */     
/* 41 */     String[] talkData = getWiredData().getText().split("\t");
/* 42 */     if (talkData.length != 2) {
/* 43 */       return;
/*    */     }
/*    */     
/* 46 */     String botName = talkData[0];
/* 47 */     String message = talkData[1];
/*    */     
/* 49 */     if ((botName.isEmpty()) || (message.isEmpty())) {
/* 50 */       return;
/*    */     }
/*    */     
/* 53 */     if ((event.entity instanceof com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity)) {
/* 54 */       message = message.replace("%username%", event.entity.getUsername());
/* 55 */       message = message.replace("{username}", event.entity.getUsername());
/*    */     }
/*    */     
/* 58 */     message = message.replace("<", "").replace(">", "");
/*    */     
/* 60 */     BotEntity botEntity = getRoom().getBots().getBotByName(botName);
/* 61 */     if (botEntity != null) {
/* 62 */       boolean isShout = (getWiredData().getParams().size() == 1) && (((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue() == 1);
/*    */       
/* 64 */       if (isShout) {
/* 65 */         getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.ShoutMessageComposer(botEntity.getId(), message, ChatEmotion.NONE, 2));
/*    */       } else {
/* 67 */         getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer(botEntity.getId(), message, ChatEmotion.NONE, 2));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionBotTalk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */