/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredTriggerAtGivenTime extends WiredTriggerItem
/*    */ {
/*    */   private static final int PARAM_TICK_LENGTH = 0;
/* 11 */   private boolean needsReset = false;
/*    */   
/*    */   public WiredTriggerAtGivenTime(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 16 */     if (getWiredData().getParams().get(Integer.valueOf(0)) == null) {
/* 17 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(2));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 23 */     return false;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 28 */     return 6;
/*    */   }
/*    */   
/*    */   public int getTime() {
/* 32 */     return ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */   }
/*    */   
/*    */   public static boolean executeTriggers(Room room, int timer) {
/* 36 */     boolean wasExecuted = false;
/*    */     
/* 38 */     for (com.habboproject.server.game.rooms.objects.items.RoomItemFloor wiredItem : room.getItems().getByClass(WiredTriggerAtGivenTime.class)) {
/* 39 */       WiredTriggerAtGivenTime trigger = (WiredTriggerAtGivenTime)wiredItem;
/*    */       
/* 41 */       if ((timer >= trigger.getTime()) && (!trigger.needsReset) && 
/* 42 */         (trigger.evaluate(null, null))) {
/* 43 */         wasExecuted = true;
/*    */         
/* 45 */         trigger.needsReset = true;
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 50 */     return wasExecuted;
/*    */   }
/*    */   
/*    */   public void setNeedsReset(boolean needsReset) {
/* 54 */     this.needsReset = needsReset;
/*    */   }
/*    */   
/*    */   public boolean needsReset() {
/* 58 */     return this.needsReset;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerAtGivenTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */