/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.banzai;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*    */ 
/*    */ public class BanzaiScoreboardFloorItem
/*    */   extends RoomItemFloor
/*    */ {
/*    */   private GameTeam gameTeam;
/*    */   
/*    */   public BanzaiScoreboardFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\banzai\BanzaiScoreboardFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */