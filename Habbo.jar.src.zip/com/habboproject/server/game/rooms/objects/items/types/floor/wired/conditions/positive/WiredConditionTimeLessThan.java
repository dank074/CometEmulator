/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionTimeLessThan
/*    */   extends WiredConditionItem
/*    */ {
/*    */   private static final int PARAM_TICKS = 0;
/*    */   
/*    */   public WiredConditionTimeLessThan(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 27 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 32 */     return 3;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 37 */     if ((getWiredData().getParams() == null) || (getWiredData().getParams().size() == 0) || (getWiredData().getParams().get(Integer.valueOf(0)) == null)) {
/* 38 */       return false;
/*    */     }
/* 40 */     int ticks = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/* 41 */     return getRoom().getWiredTimer() <= ticks;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionTimeLessThan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */