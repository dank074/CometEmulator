/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.snowboarding;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.network.messages.outgoing.room.avatar.ActionMessageComposer;
/*    */ 
/*    */ public class SnowboardJumpFloorItem extends com.habboproject.server.game.rooms.objects.items.RoomItemFloor
/*    */ {
/*    */   public SnowboardJumpFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 19 */     Position tileGoal = getPartnerTile();
/*    */     
/* 21 */     boolean increaseY = false;
/* 22 */     boolean decreaseY = false;
/* 23 */     boolean increaseX = false;
/* 24 */     boolean decreaseX = false;
/*    */     
/* 26 */     if (tileGoal != null) {
/* 27 */       switch (this.rotation) {
/*    */       case 4: 
/* 29 */         increaseY = true;
/* 30 */         break;
/*    */       
/*    */       case 0: 
/* 33 */         decreaseY = true;
/* 34 */         break;
/*    */       
/*    */       case 6: 
/* 37 */         decreaseX = true;
/* 38 */         break;
/*    */       
/*    */       case 2: 
/* 41 */         increaseX = true;
/*    */       }
/*    */       
/*    */       
/* 45 */       entity.moveTo(tileGoal.getX() + (decreaseX ? -1 : increaseX ? 1 : 0), tileGoal.getY() + (decreaseY ? -1 : increaseY ? 1 : 0));
/* 46 */       getRoom().getEntities().broadcastMessage(new ActionMessageComposer(entity.getId(), 8));
/*    */     }
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 52 */     if (!(entity instanceof PlayerEntity)) {
/* 53 */       return;
/*    */     }
/*    */     
/* 56 */     PlayerEntity playerEntity = (PlayerEntity)entity;
/*    */     
/*    */ 
/* 59 */     int actionId = com.habboproject.server.utilities.RandomInteger.getRandom(9, 10);
/* 60 */     getRoom().getEntities().broadcastMessage(new ActionMessageComposer(playerEntity.getId(), actionId));
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\snowboarding\SnowboardJumpFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */