/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionFurniHasPlayers
/*    */   extends WiredConditionItem
/*    */ {
/*    */   public WiredConditionFurniHasPlayers(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 29 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 34 */     return 8;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 39 */     int selectedItemsCount = 0;
/* 40 */     int itemsWithUserCount = 0;
/* 41 */     int itemsWithoutUsersCount = 0;
/*    */     
/* 43 */     for (Iterator localIterator = getWiredData().getSelectedIds().iterator(); localIterator.hasNext();) {
/* 44 */       long itemId = ((Long)localIterator.next()).longValue();
/*    */       
/* 46 */       RoomItemFloor floorItem = getRoom().getItems().getFloorItem(itemId);
/*    */       
/* 48 */       if (floorItem == null) {
/* 49 */         getWiredData().getSelectedIds().remove(Long.valueOf(itemId));
/*    */       } else {
/* 51 */         selectedItemsCount++;
/*    */         
/* 53 */         if (floorItem.getEntitiesOnItem().size() > 0) {
/* 54 */           itemsWithUserCount++;
/*    */         } else {
/* 56 */           itemsWithoutUsersCount++;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 61 */     if (this.isNegative) {
/* 62 */       if (itemsWithoutUsersCount == selectedItemsCount) {
/* 63 */         return true;
/*    */       }
/*    */       
/* 66 */       return false;
/*    */     }
/* 68 */     return itemsWithUserCount == selectedItemsCount;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionFurniHasPlayers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */