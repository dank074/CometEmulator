/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.RightsComponent;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredActionMuteTriggerer extends WiredActionItem
/*    */ {
/*    */   public static final int PARAM_MUTE_TIME = 0;
/*    */   
/*    */   public WiredActionMuteTriggerer(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 17 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 19 */     if (getWiredData().getParams().size() < 1) {
/* 20 */       getWiredData().getParams().clear();
/* 21 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(0));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 27 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 32 */     return 20;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 37 */     if ((event.entity == null) || (!(event.entity instanceof PlayerEntity))) {
/* 38 */       return;
/*    */     }
/*    */     
/* 41 */     int time = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */     
/* 43 */     String message = getWiredData().getText();
/*    */     
/* 45 */     if (time > 0) {
/* 46 */       ((PlayerEntity)event.entity).getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer(((PlayerEntity)event.entity).getPlayerId(), "Wired Mute: Silenciado por " + time + (time > 1 ? "minutos" : "minuto") + "! Message: " + ((message == null) || (message.isEmpty()) ? "Nenhuma mensagem" : message)));
/*    */       
/* 48 */       if (getRoom().getRights().hasMute(((PlayerEntity)event.entity).getPlayerId())) {
/* 49 */         getRoom().getRights().updateMute(((PlayerEntity)event.entity).getPlayerId(), time);
/*    */       } else {
/* 51 */         getRoom().getRights().addMute(((PlayerEntity)event.entity).getPlayerId(), time);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionMuteTriggerer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */