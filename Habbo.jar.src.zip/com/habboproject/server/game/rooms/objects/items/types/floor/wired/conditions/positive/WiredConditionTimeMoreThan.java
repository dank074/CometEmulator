/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionTimeMoreThan
/*    */   extends WiredConditionItem
/*    */ {
/*    */   private static final int PARAM_TICKS = 0;
/*    */   
/*    */   public WiredConditionTimeMoreThan(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 27 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 29 */     if (getWiredData().getParams().get(Integer.valueOf(0)) == null) {
/* 30 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(2));
/*    */     }
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 36 */     return 3;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 41 */     int ticks = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/* 42 */     return getRoom().getWiredTimer() >= ticks;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionTimeMoreThan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */