/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.boot.Comet;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredConditionDateRangeActive extends WiredConditionItem
/*    */ {
/* 12 */   private final int PARAM_INITIAL_DATE = 0;
/* 13 */   private final int PARAM_FINAL_DATE = 1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WiredConditionDateRangeActive(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 30 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 35 */     return 24;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 40 */     if ((getWiredData().getParams() == null) || (getWiredData().getParams().size() == 0)) {
/* 41 */       return false;
/*    */     }
/*    */     
/* 44 */     if (getWiredData().getParams().get(Integer.valueOf(0)) == null) {
/* 45 */       return false;
/*    */     }
/*    */     
/* 48 */     int currentDate = (int)Comet.getTime();
/*    */     
/* 50 */     if ((getWiredData().getParams().get(Integer.valueOf(1)) != null) && (((Integer)getWiredData().getParams().get(Integer.valueOf(1))).intValue() != 0)) {
/* 51 */       return (currentDate >= ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue()) && (currentDate < ((Integer)getWiredData().getParams().get(Integer.valueOf(1))).intValue());
/*    */     }
/*    */     
/* 54 */     return currentDate >= ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionDateRangeActive.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */