/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.entries.HighscoreEntry;
/*    */ import com.habboproject.server.utilities.comparators.HighscoreClassicComparator;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassicScoreboardData
/*    */ {
/* 13 */   private static final HighscoreClassicComparator comparator = new HighscoreClassicComparator();
/*    */   private int scoreType;
/*    */   private int clearType;
/*    */   private final List<HighscoreEntry> entries;
/*    */   
/*    */   public ClassicScoreboardData(int scoreType, int clearType, List<HighscoreEntry> entries)
/*    */   {
/* 20 */     this.scoreType = scoreType;
/* 21 */     this.clearType = clearType;
/* 22 */     this.entries = entries;
/*    */   }
/*    */   
/*    */   public List<HighscoreEntry> getEntries() {
/* 26 */     return this.entries;
/*    */   }
/*    */   
/*    */   public void addEntry(List<String> users, int score) {
/* 30 */     List<HighscoreEntry> list = this.entries;
/* 31 */     synchronized (list) {
/* 32 */       this.entries.add(new HighscoreEntry(users, score));
/* 33 */       Collections.sort(this.entries, comparator);
/*    */     }
/*    */   }
/*    */   
/*    */   public void removeAll() {
/* 38 */     List<HighscoreEntry> list = this.entries;
/* 39 */     synchronized (list) {
/* 40 */       this.entries.clear();
/*    */     }
/*    */   }
/*    */   
/*    */   public int getScoreType() {
/* 45 */     return this.scoreType;
/*    */   }
/*    */   
/*    */   public void setScoreType(int scoreType) {
/* 49 */     this.scoreType = scoreType;
/*    */   }
/*    */   
/*    */   public int getClearType() {
/* 53 */     return this.clearType;
/*    */   }
/*    */   
/*    */   public void setClearType(int clearType) {
/* 57 */     this.clearType = clearType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\data\scoreboard\ClassicScoreboardData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */