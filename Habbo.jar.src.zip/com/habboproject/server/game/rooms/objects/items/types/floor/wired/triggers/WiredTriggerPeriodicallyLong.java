/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredTriggerPeriodicallyLong extends WiredTriggerPeriodically
/*    */ {
/*    */   private static final int PARAM_TICK_LENGTH = 0;
/*    */   
/*    */   public WiredTriggerPeriodicallyLong(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 11 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 16 */     return true;
/*    */   }
/*    */   
/*    */   public int getTickCount()
/*    */   {
/* 21 */     return ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue() * 10;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 26 */     return 12;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerPeriodicallyLong.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */