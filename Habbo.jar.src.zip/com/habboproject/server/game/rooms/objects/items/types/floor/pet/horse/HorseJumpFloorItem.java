/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.pet.horse;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntityStatus;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PetEntity;
/*    */ 
/*    */ public class HorseJumpFloorItem extends com.habboproject.server.game.rooms.objects.items.types.DefaultFloorItem
/*    */ {
/*    */   public HorseJumpFloorItem(long id, int itemId, com.habboproject.server.game.rooms.types.Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 11 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 16 */     if (((entity instanceof PetEntity)) && (((PetEntity)entity).getData().getTypeId() == 15)) {
/* 17 */       entity.addStatus(RoomEntityStatus.JUMP, "0");
/*    */     }
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 23 */     if (((entity instanceof PetEntity)) && (((PetEntity)entity).getData().getTypeId() == 15)) {
/* 24 */       entity.removeStatus(RoomEntityStatus.JUMP);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isMovementCancelled(RoomEntity entity)
/*    */   {
/* 30 */     if (entity.getMountedEntity() == null) {
/* 31 */       return true;
/*    */     }
/*    */     
/* 34 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\pet\horse\HorseJumpFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */