/*    */ package com.habboproject.server.game.rooms.objects.items.types;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class DefaultFloorItem extends com.habboproject.server.game.rooms.objects.items.RoomItemFloor
/*    */ {
/*    */   public DefaultFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 12 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 17 */     if (!isWiredTrigger) {
/* 18 */       if (!(entity instanceof PlayerEntity)) {
/* 19 */         return false;
/*    */       }
/*    */       
/* 22 */       PlayerEntity pEntity = (PlayerEntity)entity;
/*    */       
/* 24 */       if ((getDefinition().requiresRights()) && 
/* 25 */         (!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && 
/* 26 */         (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 27 */         return false;
/*    */       }
/*    */       
/*    */ 
/* 31 */       if (pEntity.getPlayer().getId() == getRoom().getData().getOwnerId()) {
/* 32 */         pEntity.getPlayer().getQuests().progressQuest(com.habboproject.server.game.quests.types.QuestType.FURNI_SWITCH);
/*    */       }
/*    */     }
/*    */     
/* 36 */     toggleInteract(true);
/* 37 */     sendUpdate();
/*    */     
/* 39 */     saveData();
/* 40 */     return true;
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 45 */     if ((entity instanceof PlayerEntity)) {
/*    */       try {
/* 47 */         ((PlayerEntity)entity).getPlayer().getQuests().progressQuest(com.habboproject.server.game.quests.types.QuestType.EXPLORE_FIND_ITEM, getDefinition().getSpriteId());
/*    */       }
/*    */       catch (Exception localException) {}
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\DefaultFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */