/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredActionGiveScoreTeam extends WiredActionItem
/*    */ {
/*    */   private static final int PARAM_SCORE = 0;
/*    */   private static final int PARAM_PER_GAME = 1;
/*    */   private static final int PARAM_TEAM = 2;
/*    */   
/*    */   public WiredActionGiveScoreTeam(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 20 */     if (getWiredData().getParams().size() < 3) {
/* 21 */       getWiredData().getParams().clear();
/* 22 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(1));
/* 23 */       getWiredData().getParams().put(Integer.valueOf(1), Integer.valueOf(1));
/* 24 */       getWiredData().getParams().put(Integer.valueOf(2), Integer.valueOf(1));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 30 */     return false;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 35 */     return 14;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 40 */     if ((getTeamById() == null) || (getRoom().getGame() == null)) {
/* 41 */       return;
/*    */     }
/*    */     
/* 44 */     getRoom().getGame().increaseScoreToTeam(getItemId(), getTeamById(), getPerGame(), getScore());
/*    */   }
/*    */   
/*    */   public int getScore() {
/* 48 */     return ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */   }
/*    */   
/*    */   public int getPerGame() {
/* 52 */     return ((Integer)getWiredData().getParams().get(Integer.valueOf(1))).intValue();
/*    */   }
/*    */   
/*    */   public int getTeam() {
/* 56 */     return ((Integer)getWiredData().getParams().get(Integer.valueOf(2))).intValue();
/*    */   }
/*    */   
/*    */   public GameTeam getTeamById() {
/* 60 */     switch (getTeam()) {
/*    */     case 1: 
/* 62 */       return GameTeam.RED;
/*    */     
/*    */     case 2: 
/* 65 */       return GameTeam.GREEN;
/*    */     
/*    */     case 3: 
/* 68 */       return GameTeam.BLUE;
/*    */     
/*    */     case 4: 
/* 71 */       return GameTeam.YELLOW;
/*    */     }
/*    */     
/* 74 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionGiveScoreTeam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */