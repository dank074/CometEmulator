/*     */ package com.habboproject.server.game.rooms.objects.items;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.items.rares.LimitedEditionItemData;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import com.habboproject.server.game.items.types.LowPriorityItemProcessor;
/*     */ import com.habboproject.server.game.rooms.objects.BigRoomFloorObject;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.rollable.RollableFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.utilities.attributes.Attributable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RoomItem
/*     */   extends BigRoomFloorObject
/*     */   implements Attributable
/*     */ {
/*     */   protected int itemId;
/*     */   protected int ownerId;
/*     */   protected String ownerName;
/*     */   protected int groupId;
/*     */   protected int rotation;
/*     */   protected int ticksTimer;
/*     */   protected boolean needsUpdate;
/*     */   private LimitedEditionItemData limitedEditionItemData;
/*     */   private Map<String, Object> attributes;
/*     */   
/*     */   public RoomItem(long id, Position position, Room room)
/*     */   {
/*  35 */     super(id, position, room);
/*  36 */     this.ticksTimer = -1;
/*     */   }
/*     */   
/*     */   public void setLimitedEditionItemData(LimitedEditionItemData limitedEditionItemData) {
/*  40 */     this.limitedEditionItemData = limitedEditionItemData;
/*     */   }
/*     */   
/*     */   public int getItemId() {
/*  44 */     return this.itemId;
/*     */   }
/*     */   
/*     */   public int getOwner() {
/*  48 */     return this.ownerId;
/*     */   }
/*     */   
/*     */   public int getGroupId() {
/*  52 */     return this.groupId;
/*     */   }
/*     */   
/*     */   public int getRotation() {
/*  56 */     return this.rotation;
/*     */   }
/*     */   
/*     */   public boolean needsUpdate() {
/*  60 */     return this.needsUpdate;
/*     */   }
/*     */   
/*     */   public void needsUpdate(boolean needsUpdate) {
/*  64 */     this.needsUpdate = needsUpdate;
/*     */   }
/*     */   
/*     */   public final boolean requiresTick() {
/*  68 */     return (hasTicks()) || ((this instanceof WiredFloorItem));
/*     */   }
/*     */   
/*     */   protected final boolean hasTicks() {
/*  72 */     return this.ticksTimer > 0;
/*     */   }
/*     */   
/*     */   protected final void setTicks(int time) {
/*  76 */     this.ticksTimer = time;
/*     */     
/*  78 */     if ((this instanceof RollableFloorItem)) {
/*  79 */       LowPriorityItemProcessor.getInstance().submit((RoomItemFloor)this);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void cancelTicks() {
/*  84 */     this.ticksTimer = -1;
/*     */   }
/*     */   
/*     */   public final void tick() {
/*  88 */     onTick();
/*     */     
/*  90 */     if (this.ticksTimer > 0) {
/*  91 */       this.ticksTimer -= 1;
/*     */     }
/*     */     
/*  94 */     if (this.ticksTimer == 0) {
/*  95 */       cancelTicks();
/*  96 */       onTickComplete();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void onTick() {}
/*     */   
/*     */ 
/*     */ 
/*     */   protected void onTickComplete() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void onPlaced() {}
/*     */   
/*     */ 
/*     */   public void onPickup() {}
/*     */   
/*     */ 
/*     */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*     */   {
/* 118 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void onLoad() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void onUnload() {}
/*     */   
/*     */ 
/*     */   public void onEntityLeaveRoom(RoomEntity entity) {}
/*     */   
/*     */ 
/*     */   public void setAttribute(String attributeKey, Object attributeValue)
/*     */   {
/* 135 */     if (this.attributes == null) {
/* 136 */       this.attributes = new HashMap();
/*     */     }
/*     */     
/* 139 */     if (this.attributes.containsKey(attributeKey)) {
/* 140 */       this.attributes.replace(attributeKey, attributeValue);
/*     */     } else {
/* 142 */       this.attributes.put(attributeKey, attributeValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getAttribute(String attributeKey)
/*     */   {
/* 148 */     if (this.attributes == null) {
/* 149 */       this.attributes = new HashMap();
/*     */     }
/*     */     
/* 152 */     return this.attributes.get(attributeKey);
/*     */   }
/*     */   
/*     */   public boolean hasAttribute(String attributeKey)
/*     */   {
/* 157 */     if (this.attributes == null) {
/* 158 */       this.attributes = new HashMap();
/*     */     }
/*     */     
/* 161 */     return this.attributes.containsKey(attributeKey);
/*     */   }
/*     */   
/*     */   public void removeAttribute(String attributeKey)
/*     */   {
/* 166 */     if (this.attributes == null) {
/* 167 */       this.attributes = new HashMap();
/*     */     }
/*     */     
/* 170 */     this.attributes.remove(attributeKey);
/*     */   }
/*     */   
/*     */ 
/*     */   public abstract void serialize(IComposer paramIComposer);
/*     */   
/*     */   public abstract ItemDefinition getDefinition();
/*     */   
/*     */   public abstract boolean toggleInteract(boolean paramBoolean);
/*     */   
/*     */   public abstract void sendUpdate();
/*     */   
/*     */   public abstract void save();
/*     */   
/*     */   public abstract void saveData();
/*     */   
/*     */   public abstract String getExtraData();
/*     */   
/*     */   public abstract void setExtraData(String paramString);
/*     */   
/*     */   public void dispose() {}
/*     */   
/*     */   public LimitedEditionItemData getLimitedEditionItemData()
/*     */   {
/* 194 */     return this.limitedEditionItemData;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\RoomItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */