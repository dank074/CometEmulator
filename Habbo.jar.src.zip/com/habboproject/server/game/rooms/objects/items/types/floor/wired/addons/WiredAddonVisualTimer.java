/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons;
/*     */ 
/*     */ import com.habboproject.server.game.permissions.types.Rank;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerGameStarts;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class WiredAddonVisualTimer extends RoomItemFloor
/*     */ {
/*  14 */   private boolean isStarted = false;
/*     */   
/*     */   public WiredAddonVisualTimer(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  17 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTriggered)
/*     */   {
/*  23 */     if (!isWiredTriggered) {
/*  24 */       if (!(entity instanceof PlayerEntity)) {
/*  25 */         return false;
/*     */       }
/*     */       
/*  28 */       PlayerEntity pEntity = (PlayerEntity)entity;
/*     */       
/*  30 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && 
/*  31 */         (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/*  32 */         return false;
/*     */       }
/*     */     }
/*     */     
/*  36 */     if (requestData == 2) {
/*  37 */       int time = 0;
/*     */       
/*  39 */       if ((!getExtraData().isEmpty()) && (StringUtils.isNumeric(getExtraData()))) {
/*  40 */         time = Integer.parseInt(getExtraData());
/*     */       }
/*     */       
/*  43 */       if ((time == 0) || (time == 30) || (time == 60) || (time == 120) || (time == 180) || (time == 300) || (time == 600)) {}
/*  44 */       switch (time) {
/*     */       default: 
/*  46 */         time = 0;
/*  47 */         break;
/*     */       case 0: 
/*  49 */         time = 30;
/*  50 */         break;
/*     */       case 30: 
/*  52 */         time = 60;
/*  53 */         break;
/*     */       case 60: 
/*  55 */         time = 120;
/*  56 */         break;
/*     */       case 120: 
/*  58 */         time = 180;
/*  59 */         break;
/*     */       case 180: 
/*  61 */         time = 300;
/*  62 */         break;
/*     */       case 300: 
/*  64 */         time = 600;
/*     */         
/*     */ 
/*  67 */         break;
/*  68 */         time = 0;
/*     */       }
/*     */       
/*  71 */       setExtraData(time);
/*  72 */       sendUpdate();
/*     */     } else {
/*  74 */       if (this.isStarted) {
/*  75 */         this.isStarted = false;
/*     */         
/*     */ 
/*     */ 
/*  79 */         return true;
/*     */       }
/*     */       
/*     */ 
/*  83 */       this.isStarted = true;
/*     */       
/*  85 */       WiredTriggerGameStarts.executeTriggers(getRoom());
/*  86 */       setTicks(RoomItemFactory.getProcessTime(1.0D));
/*     */     }
/*     */     
/*  89 */     return true;
/*     */   }
/*     */   
/*     */   public void onTickComplete()
/*     */   {
/*  94 */     if (!this.isStarted) {
/*  95 */       return;
/*     */     }
/*     */     
/*  98 */     if ((getExtraData().isEmpty()) || (getExtraData().equals("0"))) {
/*  99 */       this.isStarted = false;
/* 100 */       return;
/*     */     }
/*     */     
/* 103 */     int timeLength = Integer.parseInt(getExtraData());
/*     */     
/* 105 */     if (timeLength - 1 >= 1) {
/* 106 */       setTicks(RoomItemFactory.getProcessTime(1.0D));
/*     */     } else {
/* 108 */       com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerGameEnds.executeTriggers(getRoom());
/* 109 */       this.isStarted = false;
/*     */     }
/*     */     
/* 112 */     setExtraData(timeLength - 1);
/* 113 */     sendUpdate();
/* 114 */     saveData();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\addons\WiredAddonVisualTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */