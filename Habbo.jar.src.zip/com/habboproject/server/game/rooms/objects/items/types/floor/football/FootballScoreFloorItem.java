/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.football;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*    */ 
/*    */ public class FootballScoreFloorItem extends com.habboproject.server.game.rooms.objects.items.RoomItemFloor
/*    */ {
/*    */   private GameTeam gameTeam;
/*    */   
/*    */   public FootballScoreFloorItem(long id, int itemId, com.habboproject.server.game.rooms.types.Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 11 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 13 */     setExtraData("0");
/*    */     String str;
/* 15 */     switch ((str = getDefinition().getItemName()).hashCode()) {case -670949:  if (str.equals("fball_score_b")) break; break; case -670944:  if (str.equals("fball_score_g")) {} break; case -670933:  if (str.equals("fball_score_r")) {} break; case -670926:  if (!str.equals("fball_score_y"))
/*    */       {
/* 17 */         return;this.gameTeam = GameTeam.BLUE;
/* 18 */         return;
/*    */         
/* 20 */         this.gameTeam = GameTeam.RED;
/*    */       }
/*    */       else {
/* 23 */         this.gameTeam = GameTeam.YELLOW;
/* 24 */         return;
/*    */         
/* 26 */         this.gameTeam = GameTeam.GREEN;
/*    */       }
/*    */       break; }
/*    */   }
/*    */   
/*    */   public void sendUpdate() {
/* 32 */     setExtraData(getRoom().getGame().getScore(this.gameTeam));
/*    */     
/* 34 */     super.sendUpdate();
/*    */   }
/*    */   
/*    */   public void reset() {
/* 38 */     setExtraData("0");
/* 39 */     sendUpdate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\football\FootballScoreFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */