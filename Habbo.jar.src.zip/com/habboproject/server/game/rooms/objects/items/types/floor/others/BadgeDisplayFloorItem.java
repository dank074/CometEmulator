/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.others;
/*    */ 
/*    */ import com.habboproject.server.api.networking.messages.IComposer;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class BadgeDisplayFloorItem
/*    */   extends RoomItemFloor
/*    */ {
/*    */   private String badge;
/*    */   private String name;
/*    */   private String date;
/*    */   
/*    */   public BadgeDisplayFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 16 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 18 */     configure();
/*    */   }
/*    */   
/*    */   public void compose(IComposer msg, boolean isNew)
/*    */   {
/* 23 */     if (this.badge.isEmpty()) {
/* 24 */       configure();
/*    */     }
/*    */     
/* 27 */     msg.writeInt(0);
/* 28 */     msg.writeInt(2);
/* 29 */     msg.writeInt(4);
/* 30 */     msg.writeString("0");
/* 31 */     msg.writeString(this.badge);
/* 32 */     msg.writeString(this.name);
/* 33 */     msg.writeString(this.date);
/*    */   }
/*    */   
/*    */   private void configure() {
/* 37 */     if (getExtraData().contains("~")) {
/* 38 */       String[] params = getExtraData().split("~");
/* 39 */       this.badge = params[0];
/* 40 */       this.name = params[1];
/* 41 */       this.date = params[2];
/*    */     } else {
/* 43 */       this.badge = getExtraData();
/* 44 */       this.name = "";
/* 45 */       this.date = "";
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\others\BadgeDisplayFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */