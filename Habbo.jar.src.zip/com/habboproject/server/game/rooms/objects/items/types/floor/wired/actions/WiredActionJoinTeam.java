/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.freeze.FreezeGateFloorItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*    */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredActionJoinTeam extends WiredActionItem
/*    */ {
/*    */   private static final int PARAM_TEAM_ID = 0;
/*    */   
/*    */   public WiredActionJoinTeam(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 21 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 23 */     if (getWiredData().getParams().size() != 1) {
/* 24 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(1));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 30 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 35 */     return 9;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 40 */     if ((event.entity == null) || (!(event.entity instanceof PlayerEntity))) {
/* 41 */       return;
/*    */     }
/*    */     
/* 44 */     PlayerEntity playerEntity = (PlayerEntity)event.entity;
/* 45 */     if ((playerEntity.getGameTeam() != GameTeam.NONE) && (playerEntity.getGameTeam() == getTeam())) {
/* 46 */       return;
/*    */     }
/*    */     
/* 49 */     playerEntity.setGameTeam(getTeam());
/* 50 */     ((List)getRoom().getGame().getTeams().get(getTeam())).add(new com.habboproject.server.game.rooms.types.components.games.GamePlayer(playerEntity.getPlayerId()));
/*    */     
/* 52 */     playerEntity.applyEffect(new com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect(getTeam().getFreezeEffect(), false));
/*    */     
/* 54 */     List<FreezeGateFloorItem> gameGates = getRoom().getItems().getByClass(FreezeGateFloorItem.class);
/* 55 */     if ((gameGates != null) && (gameGates.size() > 0)) {
/* 56 */       for (RoomItemFloor floorItem : gameGates)
/* 57 */         if (floorItem != null)
/*    */         {
/*    */ 
/*    */ 
/* 61 */           if (((com.habboproject.server.game.rooms.objects.items.types.floor.banzai.BanzaiGateFloorItem)floorItem).getTeam().equals(getTeam()))
/*    */           {
/*    */ 
/*    */ 
/* 65 */             floorItem.setExtraData(((List)getRoom().getGame().getTeams().get(getTeam())).size());
/* 66 */             floorItem.sendUpdate();
/*    */           } }
/*    */     }
/*    */   }
/*    */   
/*    */   private GameTeam getTeam() {
/* 72 */     switch (((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue()) {
/*    */     case 1: 
/* 74 */       return GameTeam.RED;
/*    */     
/*    */ 
/*    */     case 2: 
/* 78 */       return GameTeam.GREEN;
/*    */     
/*    */ 
/*    */     case 3: 
/* 82 */       return GameTeam.BLUE;
/*    */     
/*    */ 
/*    */     case 4: 
/* 86 */       return GameTeam.YELLOW;
/*    */     }
/*    */     
/*    */     
/* 90 */     return GameTeam.NONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionJoinTeam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */