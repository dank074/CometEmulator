/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.banzai.BanzaiGateFloorItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.freeze.FreezeGateFloorItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*    */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.List;
/*    */ 
/*    */ public class WiredActionLeaveTeam extends WiredActionItem
/*    */ {
/*    */   public WiredActionLeaveTeam(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 19 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 24 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 29 */     return 10;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 34 */     if ((event.entity == null) || (!(event.entity instanceof PlayerEntity))) {
/* 35 */       return;
/*    */     }
/*    */     
/* 38 */     PlayerEntity playerEntity = (PlayerEntity)event.entity;
/* 39 */     if (playerEntity.getGameTeam() == null) {
/* 40 */       return;
/*    */     }
/*    */     
/* 43 */     if (playerEntity.getCurrentEffect() == null) {
/* 44 */       return;
/*    */     }
/*    */     
/* 47 */     boolean isFreeze = playerEntity.getCurrentEffect().getEffectId() == playerEntity.getGameTeam().getFreezeEffect();
/*    */     
/* 49 */     if (isFreeze) {
/* 50 */       GameTeam oldTeam = playerEntity.getGameTeam();
/* 51 */       playerEntity.applyEffect(new PlayerEffect(0, 0));
/*    */       
/* 53 */       getRoom().getGame().removeFromTeam(playerEntity.getGameTeam(), Integer.valueOf(playerEntity.getPlayerId()));
/* 54 */       playerEntity.setGameTeam(null);
/*    */       
/* 56 */       List<FreezeGateFloorItem> gameGates = getRoom().getItems().getByClass(FreezeGateFloorItem.class);
/* 57 */       if ((gameGates != null) && (gameGates.size() > 0)) {
/* 58 */         for (RoomItemFloor floorItem : gameGates) {
/* 59 */           if (floorItem != null)
/*    */           {
/*    */ 
/*    */ 
/* 63 */             if (((BanzaiGateFloorItem)floorItem).getTeam().equals(oldTeam))
/*    */             {
/*    */ 
/*    */ 
/* 67 */               floorItem.setExtraData(((List)getRoom().getGame().getTeams().get(oldTeam)).size());
/* 68 */               floorItem.sendUpdate();
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionLeaveTeam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */