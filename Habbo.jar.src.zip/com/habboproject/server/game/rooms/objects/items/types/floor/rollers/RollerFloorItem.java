/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.rollers;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.models.RoomModel;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.AdvancedFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerWalksOffFurni;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerWalksOnFurni;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomMapping;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomTile;
/*     */ import com.habboproject.server.network.messages.outgoing.room.items.SlideObjectBundleMessageComposer;
/*     */ import com.habboproject.server.threads.executors.roller.RollerItemExecuteEvent;
/*     */ import com.habboproject.server.utilities.Direction;
/*     */ import com.habboproject.server.utilities.collections.ConcurrentHashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class RollerFloorItem extends AdvancedFloorItem<RollerItemExecuteEvent>
/*     */ {
/*  25 */   private boolean hasRollScheduled = false;
/*  26 */   private long lastTick = 0L;
/*     */   
/*  28 */   private boolean cycleCancelled = false;
/*     */   
/*  30 */   private Set<Integer> entitiesOnRoller = new ConcurrentHashSet();
/*  31 */   private Set<Integer> movedEntities = new ConcurrentHashSet();
/*     */   private final RollerItemExecuteEvent event;
/*     */   
/*     */   public RollerFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  36 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*  37 */     this.event = new RollerItemExecuteEvent(0);
/*     */   }
/*     */   
/*     */   public void onLoad()
/*     */   {
/*  42 */     this.event.setTotalTicks(getTickCount());
/*  43 */     queueEvent(this.event);
/*     */   }
/*     */   
/*     */   public void onPlaced()
/*     */   {
/*  48 */     this.event.setTotalTicks(getTickCount());
/*  49 */     queueEvent(this.event);
/*     */   }
/*     */   
/*     */   public void onEntityStepOn(RoomEntity entity)
/*     */   {
/*  54 */     this.entitiesOnRoller.add(Integer.valueOf(entity.getId()));
/*  55 */     this.event.setTotalTicks(getTickCount());
/*     */   }
/*     */   
/*     */   public void onEntityStepOff(RoomEntity entity)
/*     */   {
/*  60 */     if (!this.entitiesOnRoller.contains(Integer.valueOf(entity.getId()))) {
/*  61 */       return;
/*     */     }
/*     */     
/*  64 */     this.entitiesOnRoller.remove(Integer.valueOf(entity.getId()));
/*     */   }
/*     */   
/*     */   public void onItemAddedToStack(RoomItemFloor floorItem)
/*     */   {
/*  69 */     this.event.setTotalTicks(getTickCount());
/*     */   }
/*     */   
/*     */   protected void onEventComplete(RollerItemExecuteEvent event)
/*     */   {
/*  74 */     if (this.cycleCancelled) {
/*  75 */       this.cycleCancelled = false;
/*     */     }
/*     */     
/*  78 */     this.movedEntities.clear();
/*     */     
/*  80 */     handleEntities();
/*     */     
/*  82 */     if (!this.cycleCancelled) {
/*  83 */       handleItems();
/*     */     }
/*     */     
/*  86 */     event.setTotalTicks(getTickCount());
/*     */     
/*  88 */     queueEvent(event);
/*     */   }
/*     */   
/*     */   private void handleEntities() {
/*  92 */     Position sqInfront = getPosition().squareInFront(getRotation());
/*     */     
/*  94 */     if (!getRoom().getMapping().isValidPosition(sqInfront)) {
/*  95 */       return;
/*     */     }
/*     */     
/*  98 */     boolean retry = false;
/*     */     
/* 100 */     Direction direction = Direction.get(getRotation());
/*     */     
/* 102 */     List<RoomEntity> entities = getRoom().getEntities().getEntitiesAt(getPosition());
/*     */     
/* 104 */     for (RoomEntity entity : entities)
/* 105 */       if ((entity.getPosition().getX() == getPosition().getX()) || (entity.getPosition().getY() == getPosition().getY()))
/*     */       {
/*     */ 
/*     */ 
/* 109 */         if (entity.getPositionToSet() == null)
/*     */         {
/*     */ 
/*     */ 
/* 113 */           if (!getRoom().getMapping().isValidStep(entity, entity.getPosition(), sqInfront, true, false, false, true, false)) {
/* 114 */             retry = true;
/* 115 */             break;
/*     */           }
/*     */           
/* 118 */           if (getRoom().getEntities().positionHasEntity(sqInfront)) {
/* 119 */             retry = true;
/* 120 */             break;
/*     */           }
/*     */           
/* 123 */           if (!entity.isWalking())
/*     */           {
/*     */ 
/*     */ 
/* 127 */             if ((sqInfront.getX() == getRoom().getModel().getDoorX()) && (sqInfront.getY() == getRoom().getModel().getDoorY())) {
/* 128 */               entity.leaveRoom(false, false, true);
/*     */             }
/*     */             else
/*     */             {
/* 132 */               WiredTriggerWalksOffFurni.executeTriggers(entity, this);
/*     */               
/* 134 */               boolean hasRoller = false;
/* 135 */               boolean rollerIsFacing = false;
/* 136 */               boolean stopRoller = false;
/*     */               
/* 138 */               int itemsAtTile = 0;
/*     */               
/* 140 */               for (RoomItemFloor nextItem : getRoom().getItems().getItemsOnSquare(sqInfront.getX(), sqInfront.getY())) {
/* 141 */                 if ((nextItem instanceof com.habboproject.server.game.rooms.objects.items.types.floor.groups.GroupGateFloorItem))
/*     */                   break;
/* 143 */                 if (((nextItem instanceof com.habboproject.server.game.rooms.objects.items.types.floor.gates.GateFloorItem)) && 
/* 144 */                   (nextItem.getExtraData().equals("0"))) {
/* 145 */                   stopRoller = true;
/* 146 */                   break;
/*     */                 }
/*     */                 
/*     */ 
/* 150 */                 itemsAtTile++;
/*     */                 
/* 152 */                 if ((nextItem instanceof RollerFloorItem)) {
/* 153 */                   hasRoller = true;
/*     */                   
/* 155 */                   Direction rollerDirection = Direction.get(nextItem.getRotation());
/* 156 */                   Direction rollerInverted = rollerDirection.invert();
/*     */                   
/* 158 */                   if (rollerInverted == direction) {
/* 159 */                     rollerIsFacing = true;
/*     */                   }
/*     */                 }
/*     */                 
/* 163 */                 WiredTriggerWalksOnFurni.executeTriggers(entity, nextItem);
/*     */                 
/* 165 */                 nextItem.onEntityStepOn(entity);
/*     */               }
/*     */               
/* 168 */               if (stopRoller)
/*     */                 break;
/* 170 */               if ((hasRoller) && (rollerIsFacing) && 
/* 171 */                 (itemsAtTile > 1)) {
/* 172 */                 retry = true;
/* 173 */                 break;
/*     */               }
/*     */               
/*     */ 
/* 177 */               double toHeight = getRoom().getMapping().getTile(sqInfront.getX(), sqInfront.getY()).getWalkHeight();
/*     */               
/* 179 */               RoomTile oldTile = getRoom().getMapping().getTile(entity.getPosition().getX(), entity.getPosition().getY());
/* 180 */               RoomTile newTile = getRoom().getMapping().getTile(sqInfront.getX(), sqInfront.getY());
/*     */               
/* 182 */               if (oldTile != null) {
/* 183 */                 oldTile.getEntities().remove(entity);
/*     */               }
/*     */               
/* 186 */               if (newTile != null) {
/* 187 */                 newTile.getEntities().add(entity);
/*     */               }
/*     */               
/* 190 */               getRoom().getEntities().broadcastMessage(new SlideObjectBundleMessageComposer(entity.getPosition(), new Position(sqInfront.getX(), sqInfront.getY(), toHeight), getVirtualId(), entity.getId(), 0));
/* 191 */               entity.setPosition(new Position(sqInfront.getX(), sqInfront.getY(), toHeight));
/*     */               
/* 193 */               onEntityStepOff(entity);
/*     */               
/* 195 */               this.movedEntities.add(Integer.valueOf(entity.getId()));
/*     */             } }
/*     */         } }
/* 198 */     if (retry) {
/* 199 */       this.cycleCancelled = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleItems() {
/* 204 */     List<RoomItemFloor> floorItems = getRoom().getItems().getItemsOnSquare(getPosition().getX(), getPosition().getY());
/*     */     
/* 206 */     if (floorItems.size() < 2) {
/* 207 */       return;
/*     */     }
/*     */     
/*     */ 
/* 211 */     int rollerCount = 0;
/* 212 */     for (RoomItemFloor f : floorItems) {
/* 213 */       if ((f instanceof RollerFloorItem)) {
/* 214 */         rollerCount++;
/*     */       }
/*     */     }
/*     */     
/* 218 */     if (rollerCount > 1) {
/* 219 */       return;
/*     */     }
/*     */     
/* 222 */     Position sqInfront = getPosition().squareInFront(getRotation());
/* 223 */     Object itemsSq = getRoom().getItems().getItemsOnSquare(sqInfront.getX(), sqInfront.getY());
/*     */     
/* 225 */     boolean noItemsOnNext = false;
/*     */     
/* 227 */     for (RoomItemFloor floor : floorItems) {
/* 228 */       if ((floor.getPosition().getX() == getPosition().getX()) || (floor.getPosition().getY() == getPosition().getY()))
/*     */       {
/*     */ 
/*     */ 
/* 232 */         if ((!(floor instanceof RollerFloorItem)) && (floor.getPosition().getZ() > getPosition().getZ()))
/*     */         {
/*     */ 
/*     */ 
/* 236 */           if ((floor.getDefinition().canStack()) || ((floor instanceof com.habboproject.server.game.rooms.objects.items.types.floor.rollable.RollableFloorItem)) || 
/* 237 */             (floor.getTile().getTopItem() == floor.getId()))
/*     */           {
/*     */ 
/*     */ 
/* 241 */             double height = floor.getPosition().getZ();
/*     */             
/* 243 */             boolean hasRoller = false;
/*     */             
/* 245 */             for (RoomItemFloor iq : (List)itemsSq) {
/* 246 */               if ((iq instanceof RollerFloorItem)) {
/* 247 */                 hasRoller = true;
/*     */                 
/* 249 */                 if (iq.getPosition().getZ() != getPosition().getZ()) {
/* 250 */                   height -= getPosition().getZ();
/* 251 */                   height += iq.getPosition().getZ();
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/* 256 */             if ((!hasRoller) || (noItemsOnNext)) {
/* 257 */               height -= 0.5D;
/* 258 */               noItemsOnNext = true;
/*     */             }
/*     */             
/* 261 */             if ((hasRoller) && 
/* 262 */               (((List)itemsSq).size() > 1)) {
/* 263 */               return;
/*     */             }
/*     */             
/*     */ 
/* 267 */             if (!getRoom().getMapping().isValidStep(null, new Position(floor.getPosition().getX(), floor.getPosition().getY(), floor.getPosition().getZ()), sqInfront, true, false, false, true, true)) {
/* 268 */               return;
/*     */             }
/*     */             
/* 271 */             if (getRoom().getEntities().positionHasEntity(sqInfront, this.movedEntities)) {
/* 272 */               return;
/*     */             }
/*     */             
/* 275 */             getRoom().getEntities().broadcastMessage(new SlideObjectBundleMessageComposer(new Position(floor.getPosition().getX(), floor.getPosition().getY(), floor.getPosition().getZ()), new Position(sqInfront.getX(), sqInfront.getY(), height), getVirtualId(), 0, floor.getVirtualId()));
/*     */             
/* 277 */             floor.getPosition().setX(sqInfront.getX());
/* 278 */             floor.getPosition().setY(sqInfront.getY());
/* 279 */             floor.getPosition().setZ(height);
/*     */             
/* 281 */             com.habboproject.server.storage.queries.rooms.RoomItemDao.saveItemPosition(floor.getPosition().getX(), floor.getPosition().getY(), floor.getPosition().getZ(), floor.getRotation(), floor.getId());
/*     */           } } }
/*     */     }
/* 284 */     getRoom().getMapping().updateTile(getPosition().getX(), getPosition().getY());
/* 285 */     getRoom().getMapping().updateTile(sqInfront.getX(), sqInfront.getY());
/*     */     Iterator localIterator3;
/* 287 */     for (??? = getRoom().getItems().getItemsOnSquare(sqInfront.getX(), sqInfront.getY()).iterator(); ???.hasNext(); 
/* 288 */         localIterator3.hasNext())
/*     */     {
/* 287 */       RoomItemFloor nextItem = (RoomItemFloor)???.next();
/* 288 */       localIterator3 = floorItems.iterator(); continue;RoomItemFloor floor = (RoomItemFloor)localIterator3.next();
/* 289 */       nextItem.onItemAddedToStack(floor);
/*     */     }
/*     */   }
/*     */   
/*     */   private int getTickCount()
/*     */   {
/* 295 */     return com.habboproject.server.game.rooms.objects.items.RoomItemFactory.getProcessTime((getRoom().hasAttribute("customRollerSpeed") ? ((Integer)getRoom().getAttribute("customRollerSpeed")).intValue() : 4) / 2);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\rollers\RollerFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */