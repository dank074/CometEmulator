/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.freeze;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.players.types.PlayerFreeze;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.AffectedTile;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*    */ import com.habboproject.server.threads.ThreadManager;
/*    */ 
/*    */ public class FreezeTileFloorItem extends RoomItemFloor
/*    */ {
/*    */   public FreezeTileFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 23 */     if ((entity == null) || (!(entity instanceof PlayerEntity)) || (isWiredTrigger)) {
/* 24 */       return false;
/*    */     }
/*    */     
/* 27 */     if ((getRoom().getGame().getInstance() == null) || (!(getRoom().getGame().getInstance() instanceof com.habboproject.server.game.rooms.types.components.games.freeze.FreezeGame))) {
/* 28 */       return false;
/*    */     }
/*    */     
/* 31 */     if ((((PlayerEntity)entity).getGameTeam() == null) || (((PlayerEntity)entity).getGameTeam() == com.habboproject.server.game.rooms.types.components.games.GameTeam.NONE) || (!((PlayerEntity)entity).getPlayer().getFreeze().canThrowBall())) {
/* 32 */       return false;
/*    */     }
/*    */     
/* 35 */     if ((!getExtraData().equals("0")) && (!getExtraData().isEmpty())) {
/* 36 */       return false;
/*    */     }
/*    */     
/* 39 */     if (AffectedTile.tilesAdjecent(entity.getPosition().copy(), getPosition().copy())) {
/* 40 */       ThreadManager.getInstance().execute(new com.habboproject.server.threads.executors.freeze.FreezeTileThrowBallEvent(this, (PlayerEntity)entity));
/*    */     }
/*    */     
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\freeze\FreezeTileFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */