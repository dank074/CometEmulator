/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.freeze;
/*     */ 
/*     */ import com.habboproject.server.game.permissions.types.Rank;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.games.GameType;
/*     */ import com.habboproject.server.game.rooms.types.components.games.RoomGame;
/*     */ import com.habboproject.server.game.rooms.types.components.games.freeze.FreezeGame;
/*     */ 
/*     */ public class FreezeTimerFloorItem extends RoomItemFloor
/*     */ {
/*     */   private String lastTime;
/*  17 */   private boolean interrupted = false;
/*  18 */   private boolean running = false;
/*     */   
/*     */   public FreezeTimerFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  21 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*     */   {
/*  26 */     if (!isWiredTrigger) {
/*  27 */       if (!(entity instanceof PlayerEntity)) {
/*  28 */         return false;
/*     */       }
/*     */       
/*  31 */       PlayerEntity pEntity = (PlayerEntity)entity;
/*  32 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/*  33 */         return true;
/*     */       }
/*     */     }
/*     */     
/*  37 */     if ((getExtraData().isEmpty()) || (Integer.parseInt(getExtraData()) < 0)) {
/*  38 */       setExtraData("30");
/*     */     }
/*     */     
/*  41 */     if (isWiredTrigger) {
/*  42 */       return trigger(requestData);
/*     */     }
/*     */     
/*  45 */     if (requestData == 3) {
/*  46 */       if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof FreezeGame))) {
/*  47 */         this.running = false;
/*  48 */         getRoom().getGame().getInstance().onGameEnds();
/*  49 */         getRoom().getGame().stop();
/*     */       }
/*  51 */     } else if (requestData == 2) {
/*  52 */       if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof FreezeGame))) {
/*  53 */         this.running = false;
/*  54 */         getRoom().getGame().getInstance().onGameEnds();
/*  55 */         getRoom().getGame().stop();
/*     */       }
/*     */       
/*  58 */       int time = 0;
/*     */       
/*  60 */       if ((!getExtraData().isEmpty()) && (org.apache.commons.lang3.StringUtils.isNumeric(getExtraData()))) {
/*  61 */         time = Integer.parseInt(getExtraData());
/*     */       }
/*     */       
/*  64 */       switch (time) {
/*     */       case 0: 
/*  66 */         time = 30;
/*  67 */         break;
/*     */       
/*     */ 
/*     */       case 30: 
/*  71 */         time = 60;
/*  72 */         break;
/*     */       
/*     */ 
/*     */       case 60: 
/*  76 */         time = 120;
/*  77 */         break;
/*     */       
/*     */ 
/*     */       case 120: 
/*  81 */         time = 180;
/*  82 */         break;
/*     */       
/*     */ 
/*     */       case 180: 
/*  86 */         time = 300;
/*  87 */         break;
/*     */       
/*     */ 
/*     */       case 300: 
/*  91 */         time = 600;
/*  92 */         break;
/*     */       
/*     */ 
/*     */       default: 
/*  96 */         time = 30;
/*     */       }
/*     */       
/*     */       
/* 100 */       if (time < 0) {
/* 101 */         time = 0;
/*     */       }
/*     */       
/* 104 */       setExtraData(String.valueOf(time));
/* 105 */       sendUpdate();
/* 106 */       saveData();
/* 107 */     } else if (requestData == 1) {
/* 108 */       if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof FreezeGame))) {
/* 109 */         this.running = false;
/* 110 */         getRoom().getGame().getInstance().onGameEnds();
/* 111 */         getRoom().getGame().stop();
/*     */       }
/*     */       
/* 114 */       if ((getExtraData().equals("0")) && (this.lastTime != null) && (!this.lastTime.isEmpty()) && (Integer.parseInt(this.lastTime) > 0)) {
/* 115 */         setExtraData(this.lastTime);
/*     */       }
/*     */       
/* 118 */       int gameLength = Integer.parseInt(getExtraData());
/* 119 */       this.lastTime = getExtraData();
/*     */       
/* 121 */       if (gameLength == 0) {
/* 122 */         return true;
/*     */       }
/*     */       
/* 125 */       if (getRoom().getGame().getInstance() == null) {
/* 126 */         getRoom().getGame().createNew(GameType.FREEZE);
/* 127 */         getRoom().getGame().getInstance().startTimer(gameLength);
/* 128 */       } else if ((getRoom().getGame().getInstance() instanceof FreezeGame)) {
/* 129 */         this.running = false;
/* 130 */         getRoom().getGame().getInstance().onGameEnds();
/* 131 */         getRoom().getGame().stop();
/*     */       }
/*     */     }
/*     */     
/* 135 */     return true;
/*     */   }
/*     */   
/*     */   public boolean trigger(int requestData) {
/* 139 */     if (requestData == -1) {
/* 140 */       getRoom().getGame().getInstance().onGameEnds();
/* 141 */       getRoom().getGame().stop();
/* 142 */       this.running = false;
/* 143 */       return false;
/*     */     }
/* 145 */     if ((this.interrupted) && (requestData != -2)) {
/* 146 */       if (requestData == 0) {
/* 147 */         if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof FreezeGame))) {
/* 148 */           this.running = false;
/* 149 */           getRoom().getGame().getInstance().onGameEnds();
/* 150 */           getRoom().getGame().stop();
/*     */         }
/* 152 */         if ((getExtraData().equals("0")) && (this.lastTime != null) && (!this.lastTime.isEmpty()) && (Integer.parseInt(this.lastTime) > 0)) {
/* 153 */           setExtraData(this.lastTime);
/*     */         }
/* 155 */         int gameLength = Integer.parseInt(getExtraData());
/* 156 */         this.lastTime = getExtraData();
/* 157 */         if (gameLength == 0) {
/* 158 */           gameLength = 30;
/* 159 */           this.lastTime = "30";
/*     */         }
/* 161 */         if (getRoom().getGame().getInstance() == null) {
/* 162 */           getRoom().getGame().createNew(GameType.FREEZE);
/* 163 */           getRoom().getGame().getInstance().startTimer(gameLength);
/*     */         }
/* 165 */         return false;
/*     */       }
/* 167 */       if (getRoom().getGame().getInstance() == null) {
/* 168 */         getRoom().getGame().createNew(GameType.FREEZE);
/* 169 */         getRoom().getGame().getInstance().startTimer(requestData);
/*     */       }
/* 171 */       return false;
/*     */     }
/* 173 */     if (this.running) {
/* 174 */       if (getRoom().getGame().getInstance() == null) {
/* 175 */         this.running = false;
/* 176 */         return false;
/*     */       }
/* 178 */       this.running = false;
/* 179 */       getRoom().getGame().getInstance().onGameEnds();
/* 180 */       getRoom().getGame().stop();
/*     */     } else {
/* 182 */       if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof FreezeGame))) {
/* 183 */         this.running = false;
/* 184 */         getRoom().getGame().getInstance().onGameEnds();
/* 185 */         getRoom().getGame().stop();
/*     */       }
/* 187 */       if ((getExtraData().equals("0")) && (this.lastTime != null) && (!this.lastTime.isEmpty()) && (Integer.parseInt(this.lastTime) > 0)) {
/* 188 */         setExtraData(this.lastTime);
/*     */       }
/* 190 */       int gameLength = Integer.parseInt(getExtraData());
/* 191 */       this.lastTime = getExtraData();
/* 192 */       if (gameLength == 0) {
/* 193 */         gameLength = 30;
/* 194 */         this.lastTime = "30";
/*     */       }
/* 196 */       if (getRoom().getGame().getInstance() == null) {
/* 197 */         getRoom().getGame().createNew(GameType.FREEZE);
/* 198 */         getRoom().getGame().getInstance().startTimer((requestData == 0) || (requestData == -2) ? gameLength : requestData);
/*     */       }
/*     */     }
/* 201 */     return true;
/*     */   }
/*     */   
/*     */   public void onPlaced()
/*     */   {
/* 206 */     setExtraData("30");
/*     */   }
/*     */   
/*     */   public boolean isInterrupted() {
/* 210 */     return this.interrupted;
/*     */   }
/*     */   
/*     */   public void setInterrupted(boolean interrupted) {
/* 214 */     this.interrupted = interrupted;
/*     */   }
/*     */   
/*     */   public boolean isRunning() {
/* 218 */     return this.running;
/*     */   }
/*     */   
/*     */   public void setRunning(boolean running) {
/* 222 */     this.running = running;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\freeze\FreezeTimerFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */