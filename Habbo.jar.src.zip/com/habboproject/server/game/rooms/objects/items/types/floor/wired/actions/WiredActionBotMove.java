/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.models.RoomModel;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredUtil;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.List;
/*    */ 
/*    */ public class WiredActionBotMove extends WiredActionItem
/*    */ {
/*    */   public WiredActionBotMove(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 23 */     if ((getWiredData() == null) || (getWiredData().getSelectedIds() == null) || (getWiredData().getSelectedIds().isEmpty())) {
/* 24 */       return;
/*    */     }
/*    */     
/* 27 */     Long itemId = (Long)WiredUtil.getRandomElement(getWiredData().getSelectedIds());
/*    */     
/* 29 */     if (itemId == null) {
/* 30 */       return;
/*    */     }
/*    */     
/* 33 */     RoomItemFloor item = getRoom().getItems().getFloorItem(itemId.longValue());
/*    */     
/* 35 */     if ((item == null) || (item.isAtDoor()) || (item.getPosition() == null) || (item.getTile() == null)) {
/* 36 */       getWiredData().getSelectedIds().remove(itemId);
/* 37 */       return;
/*    */     }
/*    */     
/* 40 */     Position position = new Position(item.getPosition().getX(), item.getPosition().getY());
/*    */     
/* 42 */     String entityName = getWiredData().getText();
/*    */     
/* 44 */     BotEntity botEntity = getRoom().getBots().getBotByName(entityName);
/*    */     
/* 46 */     if (botEntity == null) {
/* 47 */       return;
/*    */     }
/*    */     
/* 50 */     if ((position.getX() != getRoom().getModel().getDoorX()) && (position.getY() != getRoom().getModel().getDoorY())) {
/* 51 */       botEntity.getData().setForcedFurniTargetMovement(itemId.longValue());
/* 52 */       botEntity.moveTo(position);
/*    */     }
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 58 */     return 22;
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 63 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionBotMove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */