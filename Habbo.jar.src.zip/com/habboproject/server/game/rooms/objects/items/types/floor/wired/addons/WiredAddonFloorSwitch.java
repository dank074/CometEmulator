/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ 
/*    */ public class WiredAddonFloorSwitch extends com.habboproject.server.game.rooms.objects.items.RoomItemFloor
/*    */ {
/*    */   public WiredAddonFloorSwitch(long id, int itemId, com.habboproject.server.game.rooms.types.Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 10 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 15 */     if ((entity != null) && 
/* 16 */       (!getPosition().touching(entity))) {
/* 17 */       entity.moveTo(getPosition().squareBehind(getRotation()).getX(), getPosition().squareBehind(getRotation()).getY());
/* 18 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 22 */     toggleInteract(true);
/*    */     
/* 24 */     sendUpdate();
/* 25 */     saveData();
/*    */     
/* 27 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\addons\WiredAddonFloorSwitch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */