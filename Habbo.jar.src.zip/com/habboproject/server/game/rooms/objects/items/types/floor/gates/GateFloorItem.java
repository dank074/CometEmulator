/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.gates;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.AffectedTile;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class GateFloorItem extends com.habboproject.server.game.rooms.objects.items.RoomItemFloor
/*    */ {
/*    */   public GateFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 12 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity0, int requestData, boolean isWiredTrigger)
/*    */   {
/* 17 */     if (!isWiredTrigger) {
/* 18 */       if (!(entity0 instanceof PlayerEntity)) {
/* 19 */         return false;
/*    */       }
/*    */       
/* 22 */       PlayerEntity pEntity = (PlayerEntity)entity0;
/*    */       
/* 24 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && 
/* 25 */         (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 26 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 30 */     for (AffectedTile tile : AffectedTile.getAffectedTilesAt(getDefinition().getLength(), getDefinition().getWidth(), getPosition().getX(), getPosition().getY(), getRotation())) {
/* 31 */       if (getRoom().getEntities().getEntitiesAt(new com.habboproject.server.game.rooms.objects.misc.Position(tile.x, tile.y)).size() > 0) {
/* 32 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 36 */     if (getRoom().getEntities().getEntitiesAt(getPosition()).size() > 0) {
/* 37 */       return false;
/*    */     }
/*    */     
/* 40 */     for (RoomEntity entity : getRoom().getEntities().getAllEntities().values()) {
/* 41 */       if ((getPosition().distanceTo(entity.getPosition()) <= 1.0D) && (entity.isWalking())) {
/* 42 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 46 */     toggleInteract(true);
/* 47 */     sendUpdate();
/*    */     
/* 49 */     saveData();
/*    */     
/* 51 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isMovementCancelled(RoomEntity entity)
/*    */   {
/* 56 */     if (getExtraData().equals("0")) {
/* 57 */       return true;
/*    */     }
/* 59 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\gates\GateFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */