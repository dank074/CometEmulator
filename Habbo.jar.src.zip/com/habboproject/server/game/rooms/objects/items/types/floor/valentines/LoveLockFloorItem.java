/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.valentines;
/*    */ 
/*    */ import com.habboproject.server.api.networking.messages.IComposer;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.mapping.RoomTile;
/*    */ import com.habboproject.server.network.messages.outgoing.room.items.lovelock.LoveLockWidgetMessageComposer;
/*    */ 
/*    */ public class LoveLockFloorItem extends com.habboproject.server.game.rooms.objects.items.RoomItemFloor
/*    */ {
/* 14 */   private int leftEntity = 0;
/* 15 */   private int rightEntity = 0;
/*    */   
/*    */   public LoveLockFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void compose(IComposer msg, boolean isNew)
/*    */   {
/* 23 */     String[] loveLockData = getExtraData().split(String.valueOf('\005'));
/*    */     
/* 25 */     msg.writeInt(0);
/* 26 */     msg.writeInt(2);
/*    */     
/* 28 */     msg.writeInt(loveLockData.length);
/*    */     
/* 30 */     for (int i = 0; i < loveLockData.length; i++) {
/* 31 */       msg.writeString(loveLockData[i]);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 37 */     if ((isWiredTrigger) || (entity == null)) {
/* 38 */       return false;
/*    */     }
/*    */     
/* 41 */     if (!(entity instanceof PlayerEntity)) {
/* 42 */       return false;
/*    */     }
/*    */     
/* 45 */     if (getExtraData().startsWith("1")) { return false;
/*    */     }
/* 47 */     Position leftPosition = null;
/* 48 */     Position rightPosition = null;
/*    */     
/* 50 */     switch (getRotation()) {
/*    */     case 2: 
/* 52 */       leftPosition = new Position(getPosition().getX(), getPosition().getY() - 1);
/* 53 */       rightPosition = new Position(getPosition().getX(), getPosition().getY() + 1);
/* 54 */       break;
/*    */     
/*    */     case 4: 
/* 57 */       leftPosition = new Position(getPosition().getX() + 1, getPosition().getY());
/* 58 */       rightPosition = new Position(getPosition().getX() - 1, getPosition().getY());
/*    */     }
/*    */     
/*    */     
/* 62 */     if (leftPosition == null) {
/* 63 */       return false;
/*    */     }
/*    */     
/* 66 */     RoomTile leftTile = getRoom().getMapping().getTile(leftPosition);
/* 67 */     RoomTile rightTile = getRoom().getMapping().getTile(rightPosition);
/*    */     
/* 69 */     if ((leftTile == null) || (rightTile == null) || (leftTile.getEntities().size() != 1) || (rightTile.getEntities().size() != 1)) {
/* 70 */       return false;
/*    */     }
/* 72 */     RoomEntity leftEntity = leftTile.getEntity();
/* 73 */     RoomEntity rightEntity = rightTile.getEntity();
/*    */     
/* 75 */     if ((leftEntity.getEntityType() != com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER) || (rightEntity.getEntityType() != com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER)) {
/* 76 */       return false;
/*    */     }
/*    */     try {
/* 79 */       ((PlayerEntity)leftEntity).getPlayer().getSession().send(new LoveLockWidgetMessageComposer(getVirtualId()));
/* 80 */       ((PlayerEntity)rightEntity).getPlayer().getSession().send(new LoveLockWidgetMessageComposer(getVirtualId()));
/*    */       
/* 82 */       this.leftEntity = ((PlayerEntity)leftEntity).getPlayerId();
/* 83 */       this.rightEntity = ((PlayerEntity)rightEntity).getPlayerId();
/*    */     } catch (Exception e) {
/* 85 */       return false;
/*    */     }
/*    */     
/* 88 */     return true;
/*    */   }
/*    */   
/*    */   public int getLeftEntity() {
/* 92 */     return this.leftEntity;
/*    */   }
/*    */   
/*    */   public int getRightEntity() {
/* 96 */     return this.rightEntity;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\valentines\LoveLockFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */