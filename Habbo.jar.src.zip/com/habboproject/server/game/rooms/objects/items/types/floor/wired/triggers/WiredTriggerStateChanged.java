/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredTriggerStateChanged extends com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem
/*    */ {
/*    */   public WiredTriggerStateChanged(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 11 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 16 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 21 */     return 1;
/*    */   }
/*    */   
/*    */   public static boolean executeTriggers(RoomEntity entity, RoomItemFloor floorItem) {
/* 25 */     boolean wasExecuted = false;
/*    */     
/* 27 */     for (RoomItemFloor wiredItem : entity.getRoom().getItems().getByClass(WiredTriggerStateChanged.class)) {
/* 28 */       WiredTriggerStateChanged trigger = (WiredTriggerStateChanged)wiredItem;
/*    */       
/* 30 */       if (trigger.getWiredData().getSelectedIds().contains(Long.valueOf(floorItem.getId()))) {
/* 31 */         wasExecuted = trigger.evaluate(entity, floorItem);
/*    */       }
/*    */     }
/* 34 */     return wasExecuted;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerStateChanged.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */