/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.base;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredFloorItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.network.messages.composers.MessageComposer;
/*    */ import com.habboproject.server.network.messages.outgoing.room.items.wired.dialog.WiredActionMessageComposer;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WiredActionItem
/*    */   extends WiredFloorItem
/*    */ {
/*    */   public WiredActionItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 31 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public MessageComposer getDialog()
/*    */   {
/* 36 */     return new WiredActionMessageComposer(this);
/*    */   }
/*    */   
/*    */   public final boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 41 */     if (hasTicks()) { return false;
/*    */     }
/* 43 */     WiredItemExecuteEvent itemEvent = new WiredItemExecuteEvent(entity, data);
/*    */     
/* 45 */     if (getWiredData().getDelay() >= 1) {
/* 46 */       itemEvent.setTotalTicks(RoomItemFactory.getProcessTime(getWiredData().getDelay() / 2));
/*    */       
/* 48 */       queueEvent(itemEvent);
/*    */     } else {
/* 50 */       itemEvent.onCompletion(this);
/* 51 */       onEventComplete(itemEvent);
/*    */     }
/*    */     
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   public WiredActionItemData getWiredData()
/*    */   {
/* 59 */     return (WiredActionItemData)super.getWiredData();
/*    */   }
/*    */   
/*    */   public List<WiredTriggerItem> getIncompatibleTriggers() {
/* 63 */     List<WiredTriggerItem> incompatibleTriggers = Lists.newArrayList();
/*    */     
/* 65 */     if (requiresPlayer()) {
/* 66 */       for (RoomItemFloor floorItem : getItemsOnStack()) {
/* 67 */         if (((floorItem instanceof WiredTriggerItem)) && 
/* 68 */           (!((WiredTriggerItem)floorItem).suppliesPlayer())) {
/* 69 */           incompatibleTriggers.add((WiredTriggerItem)floorItem);
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 75 */     return incompatibleTriggers;
/*    */   }
/*    */   
/*    */   public abstract boolean requiresPlayer();
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\base\WiredActionItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */