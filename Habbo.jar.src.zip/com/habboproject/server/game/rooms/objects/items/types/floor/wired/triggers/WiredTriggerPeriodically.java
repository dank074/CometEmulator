/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ 
/*    */ public class WiredTriggerPeriodically extends WiredTriggerItem
/*    */ {
/*    */   private static final int PARAM_TICK_LENGTH = 0;
/*    */   private final WiredItemExecuteEvent event;
/*    */   
/*    */   public WiredTriggerPeriodically(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 16 */     getWiredData().getParams().putIfAbsent(Integer.valueOf(0), Integer.valueOf(5));
/*    */     
/* 18 */     this.event = new WiredItemExecuteEvent(null, null);
/*    */     
/* 20 */     this.event.setTotalTicks(getTickCount());
/* 21 */     queueEvent(this.event);
/*    */   }
/*    */   
/*    */   public int getTickCount() {
/* 25 */     return ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 30 */     return true;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 35 */     evaluate(null, null);
/*    */     
/*    */ 
/* 38 */     this.event.setTotalTicks(getTickCount());
/* 39 */     queueEvent(this.event);
/*    */   }
/*    */   
/*    */   public void onDataChange()
/*    */   {
/* 44 */     this.event.setTotalTicks(getTickCount());
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 49 */     return 6;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerPeriodically.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */