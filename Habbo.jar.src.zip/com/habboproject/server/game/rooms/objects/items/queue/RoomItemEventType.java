package com.habboproject.server.game.rooms.objects.items.queue;

public enum RoomItemEventType
{
  PreStepOn,  StepOn,  StepOff,  Placed,  Pickup,  Interact;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\queue\RoomItemEventType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */