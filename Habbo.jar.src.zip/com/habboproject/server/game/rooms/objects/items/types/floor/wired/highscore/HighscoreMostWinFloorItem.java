/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.highscore;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import com.google.gson.Gson;
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.permissions.types.Rank;
/*     */ import com.habboproject.server.game.players.components.PermissionComponent;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.ResetItemData;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.TeamScoreboardData;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.entries.HighscoreTeamEntry;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.types.HighscorePlayer;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.RightsComponent;
/*     */ import com.habboproject.server.storage.queries.items.WiredHighscoreDao;
/*     */ import com.habboproject.server.utilities.JsonFactory;
/*     */ import com.habboproject.server.utilities.comparators.HighscoreTeamComparator;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.joda.time.DateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HighscoreMostWinFloorItem
/*     */   extends RoomItemFloor
/*     */ {
/*  35 */   private static final HighscoreTeamComparator comparator = new HighscoreTeamComparator();
/*     */   private boolean state;
/*     */   
/*     */   public HighscoreMostWinFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  39 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     String str1;
/*  41 */     if ((data.startsWith("1{")) || (data.startsWith("0{"))) {
/*  42 */       this.state = data.startsWith("1");
/*  43 */       this.itemData = ((TeamScoreboardData)JsonFactory.getInstance().fromJson(data.substring(1), TeamScoreboardData.class));
/*     */       
/*  45 */       int clearType = 0;
/*  46 */       switch ((str1 = getDefinition().getItemName().split("[_]")[1]).hashCode()) {case -1142765439:  if (str1.equals("mostwin*2")) break; break; case -1142765438:  if (str1.equals("mostwin*3")) {} break; case -1142765437:  if (!str1.equals("mostwin*4")) {
/*     */           break label189;
/*  48 */           clearType = 1;
/*     */           
/*     */ 
/*     */           break label189;
/*     */           
/*  53 */           clearType = 2;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*  58 */           clearType = 3; }
/*  59 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */       label189:
/*     */       
/*  66 */       if (this.itemData.getClearType() != clearType) {
/*  67 */         this.itemData.setClearType(clearType);
/*     */       }
/*     */       
/*  70 */       String resetData = WiredHighscoreDao.getData(id);
/*     */       
/*  72 */       if (!resetData.isEmpty()) {
/*  73 */         this.resetData = ((ResetItemData)JsonFactory.getInstance().fromJson(resetData, ResetItemData.class));
/*     */       }
/*     */       else {
/*  76 */         createResetData();
/*     */       }
/*     */       
/*  79 */       if (needsReset()) {
/*  80 */         updateResetData();
/*     */       }
/*     */     }
/*     */     else {
/*  84 */       int clearType = 0;
/*     */       
/*  86 */       switch ((str1 = getDefinition().getItemName().split("[_]")[1]).hashCode()) {case -1142765439:  if (str1.equals("mostwin*2")) break; break; case -1142765438:  if (str1.equals("mostwin*3")) {} break; case -1142765437:  if (!str1.equals("mostwin*4")) {
/*     */           break label377;
/*  88 */           clearType = 1;
/*     */           
/*     */ 
/*     */           break label377;
/*     */           
/*  93 */           clearType = 2;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*  98 */           clearType = 3; }
/*  99 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */       label377:
/*     */       
/* 106 */       this.state = false;
/*     */       
/* 108 */       this.itemData = new TeamScoreboardData(1, clearType, Maps.newHashMap());
/*     */       
/* 110 */       createResetData();
/*     */     } }
/*     */   
/*     */   private final TeamScoreboardData itemData;
/*     */   private ResetItemData resetData;
/* 115 */   public void createResetData() { DateTime date = new DateTime();
/* 116 */     this.resetData = new ResetItemData(date.getDayOfMonth(), date.getDayOfYear(), date.getMonthOfYear(), date.getDayOfWeek(), date.getWeekOfWeekyear());
/*     */     
/* 118 */     WiredHighscoreDao.save(JsonFactory.getInstance().toJson(this.resetData), getId());
/*     */   }
/*     */   
/*     */   public boolean needsReset() {
/* 122 */     DateTime date = new DateTime();
/* 123 */     if ((getScoreData().getClearType() == 1) && (getResetData().getLastDay() != date.getDayOfMonth())) {
/* 124 */       getResetData().setLastDay(date.getDayOfMonth());
/* 125 */       return true;
/*     */     }
/*     */     
/* 128 */     if ((getScoreData().getClearType() == 2) && (date.getWeekOfWeekyear() != getResetData().getLastWeekOfWeekyear())) {
/* 129 */       getResetData().setLastWeekOfWeekyear(date.getWeekOfWeekyear());
/* 130 */       return true;
/*     */     }
/*     */     
/* 133 */     if ((getScoreData().getClearType() == 3) && (getResetData().getLastMonth() != date.getMonthOfYear())) {
/* 134 */       getResetData().setLastMonth(date.getMonthOfYear());
/* 135 */       return true;
/*     */     }
/*     */     
/* 138 */     return false;
/*     */   }
/*     */   
/*     */   public void updateResetData() {
/* 142 */     DateTime date = new DateTime();
/*     */     
/* 144 */     this.resetData = new ResetItemData(date.getDayOfMonth(), date.getDayOfYear(), date.getMonthOfYear(), date.getDayOfWeek(), date.getWeekOfWeekyear());
/* 145 */     getScoreData().removeAll();
/*     */     
/* 147 */     WiredHighscoreDao.update(JsonFactory.getInstance().toJson(this.resetData), getId());
/*     */   }
/*     */   
/*     */   public void reset() {
/* 151 */     getScoreData().removeAll();
/* 152 */     WiredHighscoreDao.update(JsonFactory.getInstance().toJson(this.resetData), getId());
/*     */   }
/*     */   
/*     */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger) {
/* 156 */     if (isWiredTrigger) {
/* 157 */       if (!(entity instanceof PlayerEntity)) {
/* 158 */         return false;
/*     */       }
/*     */       
/* 161 */       PlayerEntity pEntity = (PlayerEntity)entity;
/* 162 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 163 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 167 */     this.state = (!this.state);
/*     */     
/* 169 */     sendUpdate();
/* 170 */     saveData();
/*     */     
/* 172 */     return true;
/*     */   }
/*     */   
/*     */   public String getDataObject() {
/* 176 */     return String.valueOf(this.state ? "1" : "0") + JsonFactory.getInstance().toJson(this.itemData);
/*     */   }
/*     */   
/*     */   public void addEntry(List<HighscorePlayer> users, int teamScore) {
/* 180 */     this.itemData.addEntry(users, teamScore);
/*     */     
/* 182 */     sendUpdate();
/* 183 */     saveData();
/*     */   }
/*     */   
/*     */   public void updateEntry(int id, List<HighscorePlayer> users, int teamScore) {
/* 187 */     this.itemData.updateEntry(id, users, teamScore);
/*     */     
/* 189 */     sendUpdate();
/* 190 */     saveData();
/*     */   }
/*     */   
/*     */   public Map<Integer, List<HighscoreTeamEntry>> getEntries() {
/* 194 */     return this.itemData.getEntries();
/*     */   }
/*     */   
/*     */   public TeamScoreboardData getScoreData() {
/* 198 */     return this.itemData;
/*     */   }
/*     */   
/*     */   public ResetItemData getResetData() {
/* 202 */     return this.resetData;
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg, boolean isNew) {
/* 206 */     msg.writeInt(0);
/* 207 */     msg.writeInt(6);
/*     */     
/* 209 */     msg.writeString(this.state ? "1" : "0");
/*     */     
/* 211 */     msg.writeInt(getScoreData().getScoreType());
/* 212 */     msg.writeInt(getScoreData().getClearType());
/*     */     
/* 214 */     msg.writeInt(getScoreData().getEntries().size() > 50 ? 50 : getScoreData().getEntries().size());
/*     */     
/* 216 */     List<HighscoreTeamEntry> entries = Lists.newArrayList();
/* 217 */     for (List<HighscoreTeamEntry> entry : getScoreData().getEntries().values()) {
/* 218 */       entries.addAll(entry);
/*     */     }
/*     */     
/* 221 */     Collections.sort(entries, comparator);
/*     */     
/* 223 */     int x = 0;
/* 224 */     Iterator localIterator3; for (Iterator localIterator2 = entries.iterator(); localIterator2.hasNext(); 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */         localIterator3.hasNext())
/*     */     {
/* 224 */       HighscoreTeamEntry entry = (HighscoreTeamEntry)localIterator2.next();
/* 225 */       x++; if (x > 50) {
/*     */         break;
/*     */       }
/*     */       
/* 229 */       msg.writeInt(entry.getTeamScore());
/*     */       
/* 231 */       msg.writeInt(entry.getUsers().size());
/* 232 */       localIterator3 = entry.getUsers().iterator(); continue;HighscorePlayer player = (HighscorePlayer)localIterator3.next();
/* 233 */       msg.writeString(player.getUsername());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\highscore\HighscoreMostWinFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */