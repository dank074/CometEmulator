/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.highscore;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.ClassicScoreboardData;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.ResetItemData;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.entries.HighscoreEntry;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.storage.queries.items.WiredHighscoreDao;
/*     */ import com.habboproject.server.utilities.JsonFactory;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.joda.time.DateTime;
/*     */ 
/*     */ public class HighscoreClassicFloorItem extends RoomItemFloor
/*     */ {
/*     */   private boolean state;
/*     */   private final ClassicScoreboardData itemData;
/*     */   private ResetItemData resetData;
/*     */   
/*     */   public HighscoreClassicFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  25 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     String str1;
/*  27 */     if ((data.startsWith("1{")) || (data.startsWith("0{"))) {
/*  28 */       this.state = data.startsWith("1");
/*  29 */       this.itemData = ((ClassicScoreboardData)JsonFactory.getInstance().fromJson(data.substring(1), ClassicScoreboardData.class));
/*     */       
/*  31 */       int clearType = 0;
/*     */       
/*  33 */       switch ((str1 = getDefinition().getItemName().split("[_]")[1]).hashCode()) {case -9084582:  if (str1.equals("classic*2")) break; break; case -9084581:  if (str1.equals("classic*3")) {} break; case -9084580:  if (!str1.equals("classic*4")) {
/*     */           break label189;
/*  35 */           clearType = 1;
/*     */           
/*     */           break label189;
/*     */           
/*  39 */           clearType = 2;
/*     */         }
/*     */         else
/*     */         {
/*  43 */           clearType = 3; }
/*  44 */         break;
/*     */       }
/*     */       
/*     */       
/*     */       label189:
/*     */       
/*  50 */       if (this.itemData.getClearType() != clearType) {
/*  51 */         this.itemData.setClearType(clearType);
/*     */       }
/*     */       
/*  54 */       if (this.itemData.getScoreType() != 2) {
/*  55 */         this.itemData.setScoreType(2);
/*     */       }
/*     */       
/*  58 */       String resetData = WiredHighscoreDao.getData(id);
/*  59 */       if (!resetData.isEmpty()) {
/*  60 */         this.resetData = ((ResetItemData)JsonFactory.getInstance().fromJson(resetData, ResetItemData.class));
/*     */       }
/*     */       else {
/*  63 */         createResetData();
/*     */       }
/*     */       
/*  66 */       if (needsReset()) {
/*  67 */         updateResetData();
/*     */       }
/*     */     }
/*     */     else {
/*  71 */       int clearType = 0;
/*  72 */       switch ((str1 = getDefinition().getItemName().split("[_]")[1]).hashCode()) {case -9084582:  if (str1.equals("classic*2")) break; break; case -9084581:  if (str1.equals("classic*3")) {} break; case -9084580:  if (!str1.equals("classic*4")) {
/*     */           break label397;
/*  74 */           clearType = 1;
/*     */           
/*     */           break label397;
/*     */           
/*  78 */           clearType = 2;
/*     */         }
/*     */         else
/*     */         {
/*  82 */           clearType = 3; }
/*  83 */         break;
/*     */       }
/*     */       
/*     */       
/*     */       label397:
/*     */       
/*  89 */       this.state = false;
/*     */       
/*  91 */       this.itemData = new ClassicScoreboardData(2, clearType, com.google.common.collect.Lists.newArrayList());
/*     */       
/*  93 */       createResetData();
/*     */     }
/*     */   }
/*     */   
/*     */   public void createResetData() {
/*  98 */     DateTime date = new DateTime();
/*  99 */     this.resetData = new ResetItemData(date.getDayOfMonth(), date.getDayOfYear(), date.getMonthOfYear(), date.getDayOfWeek(), date.getWeekOfWeekyear());
/*     */     
/* 101 */     WiredHighscoreDao.save(JsonFactory.getInstance().toJson(this.resetData), getId());
/*     */   }
/*     */   
/*     */   public boolean needsReset() {
/* 105 */     DateTime date = new DateTime();
/* 106 */     if ((getScoreData().getClearType() == 1) && (getResetData().getLastDay() != date.getDayOfMonth())) {
/* 107 */       getResetData().setLastDay(date.getDayOfMonth());
/* 108 */       return true;
/*     */     }
/*     */     
/* 111 */     if ((getScoreData().getClearType() == 2) && (date.getWeekOfWeekyear() != getResetData().getLastWeekOfWeekyear())) {
/* 112 */       getResetData().setLastWeekOfWeekyear(date.getWeekOfWeekyear());
/* 113 */       return true;
/*     */     }
/*     */     
/* 116 */     if ((getScoreData().getClearType() == 3) && (getResetData().getLastMonth() != date.getMonthOfYear())) {
/* 117 */       getResetData().setLastMonth(date.getMonthOfYear());
/* 118 */       return true;
/*     */     }
/*     */     
/* 121 */     return false;
/*     */   }
/*     */   
/*     */   public void updateResetData() {
/* 125 */     org.joda.time.DateTimeZone zone = org.joda.time.DateTimeZone.forID("America/Sao_Paulo");
/* 126 */     DateTime date = new DateTime();
/*     */     
/* 128 */     this.resetData = new ResetItemData(date.getDayOfMonth(), date.getDayOfYear(), date.getMonthOfYear(), date.getDayOfWeek(), date.getWeekOfWeekyear());
/* 129 */     getScoreData().removeAll();
/*     */     
/* 131 */     WiredHighscoreDao.update(JsonFactory.getInstance().toJson(this.resetData), getId());
/*     */   }
/*     */   
/*     */   public void reset() {
/* 135 */     getScoreData().removeAll();
/* 136 */     WiredHighscoreDao.update(JsonFactory.getInstance().toJson(this.resetData), getId());
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg, boolean isNew) {
/* 140 */     msg.writeInt(0);
/* 141 */     msg.writeInt(6);
/*     */     
/* 143 */     msg.writeString(this.state ? "1" : "0");
/*     */     
/* 145 */     msg.writeInt(getScoreData().getScoreType());
/* 146 */     msg.writeInt(getScoreData().getClearType());
/*     */     
/* 148 */     msg.writeInt(getScoreData().getEntries().size() > 50 ? 50 : getScoreData().getEntries().size());
/*     */     
/* 150 */     int x = 0;
/* 151 */     Iterator localIterator2; for (Iterator localIterator1 = getScoreData().getEntries().iterator(); localIterator1.hasNext(); 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */         localIterator2.hasNext())
/*     */     {
/* 151 */       HighscoreEntry entry = (HighscoreEntry)localIterator1.next();
/* 152 */       x++; if (x > 50) {
/*     */         break;
/*     */       }
/*     */       
/* 156 */       msg.writeInt(entry.getScore());
/* 157 */       msg.writeInt(entry.getUsers().size());
/* 158 */       localIterator2 = entry.getUsers().iterator(); continue;String name = (String)localIterator2.next();
/* 159 */       msg.writeString(name);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onInteract(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity, int requestData, boolean isWiredTrigger)
/*     */   {
/* 165 */     if (isWiredTrigger) {
/* 166 */       if (!(entity instanceof PlayerEntity)) {
/* 167 */         return false;
/*     */       }
/*     */       
/* 170 */       PlayerEntity pEntity = (PlayerEntity)entity;
/* 171 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 172 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 176 */     this.state = (!this.state);
/*     */     
/* 178 */     sendUpdate();
/* 179 */     saveData();
/*     */     
/* 181 */     return true;
/*     */   }
/*     */   
/*     */   public String getDataObject() {
/* 185 */     return String.valueOf(this.state ? "1" : "0") + JsonFactory.getInstance().toJson(this.itemData);
/*     */   }
/*     */   
/*     */   public void addEntry(List<String> users, int score) {
/* 189 */     this.itemData.addEntry(users, score);
/* 190 */     sendUpdate();
/* 191 */     saveData();
/*     */   }
/*     */   
/*     */   public ClassicScoreboardData getScoreData() {
/* 195 */     return this.itemData;
/*     */   }
/*     */   
/*     */   public ResetItemData getResetData() {
/* 199 */     return this.resetData;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\highscore\HighscoreClassicFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */