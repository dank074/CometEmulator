/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ 
/*    */ public class WiredActionKickUser extends WiredActionShowMessage
/*    */ {
/*    */   public WiredActionKickUser(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 16 */     this.isWhisperBubble = true;
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 21 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 26 */     return 7;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 31 */     if ((event.entity == null) || (!(event.entity instanceof PlayerEntity))) {
/* 32 */       return;
/*    */     }
/*    */     
/* 35 */     if (event.type == 1) {
/* 36 */       event.entity.leaveRoom(false, true, true);
/* 37 */       return;
/*    */     }
/*    */     
/* 40 */     PlayerEntity playerEntity = (PlayerEntity)event.entity;
/*    */     
/* 42 */     String kickException = "";
/*    */     
/* 44 */     if (getRoom().getData().getOwnerId() == playerEntity.getPlayerId()) {
/* 45 */       kickException = "Room owner";
/*    */     }
/*    */     
/* 48 */     if (kickException.isEmpty()) {
/* 49 */       super.onEventComplete(event);
/*    */       
/* 51 */       event.entity.applyEffect(new PlayerEffect(4, 5));
/* 52 */       event.type = 1;
/*    */       
/* 54 */       event.setTotalTicks(RoomItemFactory.getProcessTime(0.9D));
/* 55 */       queueEvent(event);
/*    */     } else {
/* 57 */       playerEntity.getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer(playerEntity.getId(), "Wired kick exception: " + kickException));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionKickUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */