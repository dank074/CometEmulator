/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.negative;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive.WiredConditionStuffIs;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredNegativeConditionStuffIs
/*    */   extends WiredConditionStuffIs
/*    */ {
/*    */   public WiredNegativeConditionStuffIs(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 11 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/* 12 */     this.isNegative = true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\negative\WiredNegativeConditionStuffIs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */