/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredItemSnapshot;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionMatchSnapshot
/*    */   extends WiredConditionItem
/*    */ {
/*    */   private static final int PARAM_MATCH_STATE = 0;
/*    */   private static final int PARAM_MATCH_ROTATION = 1;
/*    */   private static final int PARAM_MATCH_POSITION = 2;
/*    */   
/*    */   public WiredConditionMatchSnapshot(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 33 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 38 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 43 */     if (getWiredData().getParams().size() != 3) {
/* 44 */       return false;
/*    */     }
/*    */     
/* 47 */     boolean matchState = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue() == 1;
/* 48 */     boolean matchRotation = ((Integer)getWiredData().getParams().get(Integer.valueOf(1))).intValue() == 1;
/* 49 */     boolean matchPosition = ((Integer)getWiredData().getParams().get(Integer.valueOf(2))).intValue() == 1;
/*    */     
/* 51 */     for (Iterator localIterator = getWiredData().getSelectedIds().iterator(); localIterator.hasNext();) {
/* 52 */       long itemId = ((Long)localIterator.next()).longValue();
/*    */       
/* 54 */       RoomItemFloor floorItem = getRoom().getItems().getFloorItem(itemId);
/*    */       
/* 56 */       if (floorItem == null) {
/* 57 */         getWiredData().getSelectedIds().remove(Long.valueOf(itemId));
/*    */       } else {
/* 59 */         WiredItemSnapshot snapshot = (WiredItemSnapshot)getWiredData().getSnapshots().get(Long.valueOf(itemId));
/*    */         
/* 61 */         if (snapshot != null) {
/* 62 */           boolean matchesState = !this.isNegative;
/* 63 */           boolean matchesRotation = !this.isNegative;
/* 64 */           boolean matchesPosition = !this.isNegative;
/*    */           
/* 66 */           if (matchState) {
/* 67 */             if (!floorItem.getExtraData().equals(snapshot.getExtraData())) {
/* 68 */               matchesState = false;
/* 69 */             } else if (this.isNegative) {
/* 70 */               matchesState = true;
/*    */             }
/*    */           }
/*    */           
/* 74 */           if (matchRotation) {
/* 75 */             if (floorItem.getRotation() != snapshot.getRotation()) {
/* 76 */               matchesRotation = false;
/* 77 */             } else if (this.isNegative) {
/* 78 */               matchesRotation = true;
/*    */             }
/*    */           }
/*    */           
/* 82 */           if (matchPosition) {
/* 83 */             if ((floorItem.getPosition().getX() != snapshot.getX()) || (floorItem.getPosition().getY() != snapshot.getY())) {
/* 84 */               matchesPosition = false;
/* 85 */             } else if (this.isNegative) {
/* 86 */               matchesPosition = true;
/*    */             }
/*    */           }
/*    */           
/* 90 */           if ((this.isNegative) && ((matchesPosition) || (matchesRotation) || (matchesState)))
/* 91 */             return false;
/* 92 */           if ((!this.isNegative) && ((!matchesPosition) || (!matchesRotation) || (!matchesState))) {
/* 93 */             return false;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 99 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionMatchSnapshot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */