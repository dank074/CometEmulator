/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredConditionPlayerWearingEffect extends WiredConditionItem
/*    */ {
/* 11 */   public static int PARAM_EFFECT_ID = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WiredConditionPlayerWearingEffect(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 27 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 32 */     return 12;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 37 */     if (entity == null) { return false;
/*    */     }
/* 39 */     if (getWiredData().getParams().size() != 1) {
/* 40 */       return false;
/*    */     }
/*    */     
/* 43 */     int effectId = ((Integer)getWiredData().getParams().get(Integer.valueOf(PARAM_EFFECT_ID))).intValue();
/* 44 */     boolean isWearingEffect = false;
/*    */     
/* 46 */     if ((entity.getCurrentEffect() != null) && 
/* 47 */       (entity.getCurrentEffect().getEffectId() == effectId)) {
/* 48 */       isWearingEffect = true;
/*    */     }
/*    */     
/*    */ 
/* 52 */     if (isWearingEffect) {
/* 53 */       if (this.isNegative) {
/* 54 */         return false;
/*    */       }
/*    */     }
/* 57 */     else if (!this.isNegative) {
/* 58 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 62 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionPlayerWearingEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */