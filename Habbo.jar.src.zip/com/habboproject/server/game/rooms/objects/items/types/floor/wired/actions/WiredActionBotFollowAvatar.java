/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredActionBotFollowAvatar extends com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem
/*    */ {
/*    */   private static final int PARAM_STOPFOLLOWING = 0;
/*    */   private static final int PARAM_DELAY = 1;
/*    */   
/*    */   public WiredActionBotFollowAvatar(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 17 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 19 */     if (getWiredData().getParams().size() < 2) {
/* 20 */       getWiredData().getParams().clear();
/* 21 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(1));
/* 22 */       getWiredData().getParams().put(Integer.valueOf(1), Integer.valueOf(0));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 28 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 33 */     return 25;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 38 */     if (getWiredData().getText().isEmpty()) {
/* 39 */       return;
/*    */     }
/*    */     
/* 42 */     if ((getWiredData().getParams() == null) || (getWiredData().getParams().size() == 0)) {
/* 43 */       return;
/*    */     }
/*    */     
/* 46 */     String botName = getWiredData().getText();
/* 47 */     BotEntity botEntity = getRoom().getBots().getBotByName(botName);
/*    */     
/* 49 */     boolean stopFollowing = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue() == 0;
/* 50 */     boolean hasDelay = ((Integer)getWiredData().getParams().get(Integer.valueOf(1))).intValue() != 0;
/*    */     
/* 52 */     if (botEntity != null) {
/* 53 */       if (stopFollowing) {
/* 54 */         if (botEntity.isWalking()) {
/* 55 */           botEntity.cancelWalk();
/*    */         }
/*    */         
/* 58 */         botEntity.getData().setForcedUserTargetMovement(0);
/*    */       } else {
/* 60 */         if (botEntity.isWalking()) {
/* 61 */           botEntity.cancelWalk();
/*    */         }
/*    */         
/* 64 */         if ((event.entity.getPosition().getX() != getRoom().getModel().getDoorX()) && (event.entity.getPosition().getY() != getRoom().getModel().getDoorY())) {
/* 65 */           botEntity.getData().setForcedUserTargetMovement(event.entity.getId());
/* 66 */           botEntity.moveTo(event.entity.getPosition().getX(), event.entity.getPosition().getY());
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionBotFollowAvatar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */