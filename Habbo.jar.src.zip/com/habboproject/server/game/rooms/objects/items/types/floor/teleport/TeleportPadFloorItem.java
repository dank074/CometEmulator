/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.teleport;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.ThreadManager;
/*    */ import com.habboproject.server.threads.executors.teleport.TeleportEventOne;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ public class TeleportPadFloorItem
/*    */   extends TeleportDoorFloorItem
/*    */ {
/*    */   public TeleportPadFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 17 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 22 */     if ((getRoom() == null) || (entity == null) || (!(entity instanceof PlayerEntity)) || (isWiredTrigger)) {
/* 23 */       return false;
/*    */     }
/*    */     
/* 26 */     Position posInFront = getPosition().squareInFront(getRotation());
/* 27 */     if ((!canInteract(entity.getPosition().copy(), getPosition().copy(), entity.isOverriden())) && (!canInteract(entity.getPosition().copy(), posInFront, entity.isOverriden()))) {
/* 28 */       entity.moveTo(posInFront.getX(), posInFront.getY());
/* 29 */       return false;
/*    */     }
/*    */     
/* 32 */     entity.setOverriden(true);
/* 33 */     entity.getProcessingPath().clear();
/*    */     
/* 35 */     ThreadManager.getInstance().executeSchedule(new TeleportEventOne(this, (PlayerEntity)entity), 100L, TimeUnit.MILLISECONDS);
/*    */     
/* 37 */     return true;
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 42 */     if ((getRoom() == null) || (entity == null) || (!(entity instanceof PlayerEntity)) || (!getExtraData().equals("0"))) {
/* 43 */       return;
/*    */     }
/*    */     
/* 46 */     if (canInteract(entity)) {
/* 47 */       entity.setOverriden(true);
/* 48 */       entity.getProcessingPath().clear();
/*    */       
/* 50 */       ThreadManager.getInstance().executeSchedule(new TeleportEventOne(this, (PlayerEntity)entity), 100L, TimeUnit.MILLISECONDS);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteract(RoomEntity entity) {
/* 55 */     if (((PlayerEntity)entity).isTeleporting()) {
/* 56 */       return false;
/*    */     }
/*    */     
/* 59 */     if (!getExtraData().equals("0")) {
/* 60 */       return false;
/*    */     }
/*    */     
/* 63 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\teleport\TeleportPadFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */