/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.entries;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.types.HighscorePlayer;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HighscoreTeamEntry
/*    */ {
/*    */   private List<HighscorePlayer> users;
/*    */   private int teamScore;
/*    */   
/*    */   public HighscoreTeamEntry(List<HighscorePlayer> users, int teamScore)
/*    */   {
/* 15 */     this.users = users;
/* 16 */     this.teamScore = teamScore;
/*    */   }
/*    */   
/*    */   public List<HighscorePlayer> getUsers() {
/* 20 */     return this.users;
/*    */   }
/*    */   
/*    */   public void setUsers(List<HighscorePlayer> users) {
/* 24 */     this.users = users;
/*    */   }
/*    */   
/*    */   public int getTeamScore() {
/* 28 */     return this.teamScore;
/*    */   }
/*    */   
/*    */   public void setTeamScore(int teamScore) {
/* 32 */     this.teamScore = teamScore;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\data\scoreboard\entries\HighscoreTeamEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */