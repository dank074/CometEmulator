/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.adjustable;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.others.SeatFloorItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class AdjustableHeightSeatFloorItem extends SeatFloorItem
/*    */ {
/*    */   public AdjustableHeightSeatFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 10 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 12 */     if (getExtraData().isEmpty()) {
/* 13 */       setExtraData("0");
/*    */     }
/*    */   }
/*    */   
/*    */   public double getSitHeight()
/*    */   {
/*    */     double height;
/*    */     double height;
/* 21 */     if (!org.apache.commons.lang.StringUtils.isNumeric(getExtraData())) {
/* 22 */       height = 1.0D;
/*    */     } else {
/* 24 */       height = Double.parseDouble(getExtraData());
/*    */       
/* 26 */       if (height <= 1.0D) {
/* 27 */         height += 1.0D;
/*    */       } else {
/* 29 */         height += 0.5D;
/*    */       }
/*    */     }
/*    */     
/* 33 */     return height;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\adjustable\AdjustableHeightSeatFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */