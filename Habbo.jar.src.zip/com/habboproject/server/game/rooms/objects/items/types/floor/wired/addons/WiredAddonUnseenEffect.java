/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.List;
/*    */ 
/*    */ public class WiredAddonUnseenEffect extends RoomItemFloor
/*    */ {
/*    */   private List<Long> seenEffects;
/*    */   
/*    */   public WiredAddonUnseenEffect(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 16 */     this.seenEffects = Lists.newArrayList();
/*    */   }
/*    */   
/*    */   public List<Long> getSeenEffects() {
/* 20 */     return this.seenEffects;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\addons\WiredAddonUnseenEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */