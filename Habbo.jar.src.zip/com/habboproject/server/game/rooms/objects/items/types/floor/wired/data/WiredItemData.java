/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.data;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.google.common.collect.Maps;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredItemSnapshot;
/*    */ import com.habboproject.server.utilities.JsonData;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ public class WiredItemData
/*    */   implements JsonData
/*    */ {
/* 14 */   private int selectionType = 0;
/*    */   private List<Long> selectedIds;
/*    */   private String text;
/*    */   private Map<Integer, Integer> params;
/*    */   private Map<Long, WiredItemSnapshot> snapshots;
/*    */   
/*    */   public WiredItemData(int selectionType, List<Long> selectedIds, String text, Map<Integer, Integer> params, Map<Long, WiredItemSnapshot> snapshots) {
/* 21 */     this.selectionType = selectionType;
/* 22 */     this.selectedIds = selectedIds;
/* 23 */     this.text = text;
/* 24 */     this.params = params;
/* 25 */     this.snapshots = snapshots;
/*    */   }
/*    */   
/*    */   public WiredItemData() {
/* 29 */     this.selectionType = 0;
/* 30 */     this.selectedIds = Lists.newArrayList();
/* 31 */     this.text = "";
/* 32 */     this.params = Maps.newHashMap();
/* 33 */     this.snapshots = Maps.newHashMap();
/*    */   }
/*    */   
/*    */   public void selectItem(long itemId) {
/* 37 */     this.selectedIds.add(Long.valueOf(itemId));
/*    */   }
/*    */   
/*    */   public int getSelectionType() {
/* 41 */     return this.selectionType;
/*    */   }
/*    */   
/*    */   public void setSelectionType(int selectionType) {
/* 45 */     this.selectionType = selectionType;
/*    */   }
/*    */   
/*    */   public List<Long> getSelectedIds() {
/* 49 */     return this.selectedIds;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 53 */     return this.text;
/*    */   }
/*    */   
/*    */   public void setText(String text) {
/* 57 */     this.text = text;
/*    */   }
/*    */   
/*    */   public Map<Integer, Integer> getParams() {
/* 61 */     return this.params;
/*    */   }
/*    */   
/*    */   public void setParams(Map<Integer, Integer> params) {
/* 65 */     this.params = params;
/*    */   }
/*    */   
/*    */   public Map<Long, WiredItemSnapshot> getSnapshots() {
/* 69 */     return this.snapshots;
/*    */   }
/*    */   
/*    */   public void setSnapshots(Map<Long, WiredItemSnapshot> snapshots) {
/* 73 */     this.snapshots = snapshots;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\data\WiredItemData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */