/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.types;
/*    */ 
/*    */ 
/*    */ public class HighscorePlayer
/*    */ {
/*    */   private final String username;
/*    */   private int playerScore;
/*    */   
/*    */   public HighscorePlayer(String username, int playerScore)
/*    */   {
/* 11 */     this.username = username;
/* 12 */     this.playerScore = playerScore;
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 16 */     return this.username;
/*    */   }
/*    */   
/*    */   public int getPlayerScore() {
/* 20 */     return this.playerScore;
/*    */   }
/*    */   
/*    */   public void setPlayerScore(int playerScore) {
/* 24 */     this.playerScore = playerScore;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\data\scoreboard\types\HighscorePlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */