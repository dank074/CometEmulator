/*   */ package com.habboproject.server.game.rooms.objects.items.types.floor.banzai;
/*   */ 
/*   */ import com.habboproject.server.game.rooms.types.Room;
/*   */ 
/*   */ public class BanzaiPuckFloorItem extends com.habboproject.server.game.rooms.objects.items.types.floor.rollable.RollableFloorItem
/*   */ {
/*   */   public BanzaiPuckFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*   */   {
/* 9 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*   */   }
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\banzai\BanzaiPuckFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */