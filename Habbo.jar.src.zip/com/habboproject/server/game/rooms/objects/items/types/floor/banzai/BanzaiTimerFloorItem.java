/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.banzai;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.games.GameType;
/*     */ import com.habboproject.server.game.rooms.types.components.games.RoomGame;
/*     */ import com.habboproject.server.game.rooms.types.components.games.banzai.BanzaiGame;
/*     */ 
/*     */ public class BanzaiTimerFloorItem extends RoomItemFloor
/*     */ {
/*     */   private String lastTime;
/*  14 */   private boolean interrupted = false;
/*  15 */   private boolean running = false;
/*     */   
/*     */   public BanzaiTimerFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public boolean onInteract(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity, int requestData, boolean isWiredTriggered)
/*     */   {
/*  23 */     if (!isWiredTriggered) {
/*  24 */       if (!(entity instanceof PlayerEntity)) {
/*  25 */         return false;
/*     */       }
/*     */       
/*  28 */       PlayerEntity pEntity = (PlayerEntity)entity;
/*  29 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/*  30 */         return false;
/*     */       }
/*     */     }
/*     */     
/*  34 */     if ((getExtraData().isEmpty()) || (Integer.parseInt(getExtraData()) < 0)) {
/*  35 */       setExtraData("0");
/*     */     }
/*     */     
/*  38 */     if (isWiredTriggered) {
/*  39 */       return trigger(requestData);
/*     */     }
/*     */     
/*  42 */     if (requestData == 3) {
/*  43 */       if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof BanzaiGame))) {
/*  44 */         this.running = false;
/*  45 */         getRoom().getGame().getInstance().onGameEnds();
/*  46 */         getRoom().getGame().stop();
/*     */       }
/*  48 */     } else if (requestData == 2) {
/*  49 */       if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof BanzaiGame))) {
/*  50 */         this.running = false;
/*  51 */         getRoom().getGame().getInstance().onGameEnds();
/*  52 */         getRoom().getGame().stop();
/*     */       }
/*     */       
/*  55 */       int time = 0;
/*     */       
/*  57 */       if ((!getExtraData().isEmpty()) && (org.apache.commons.lang.StringUtils.isNumeric(getExtraData()))) {
/*  58 */         time = Integer.parseInt(getExtraData());
/*     */       }
/*     */       
/*  61 */       switch (time) {
/*     */       case 0: 
/*  63 */         time = 30;
/*  64 */         break;
/*     */       
/*     */ 
/*     */       case 30: 
/*  68 */         time = 60;
/*  69 */         break;
/*     */       
/*     */ 
/*     */       case 60: 
/*  73 */         time = 120;
/*  74 */         break;
/*     */       
/*     */ 
/*     */       case 120: 
/*  78 */         time = 180;
/*  79 */         break;
/*     */       
/*     */ 
/*     */       case 180: 
/*  83 */         time = 300;
/*  84 */         break;
/*     */       
/*     */ 
/*     */       case 300: 
/*  88 */         time = 600;
/*  89 */         break;
/*     */       
/*     */ 
/*     */       default: 
/*  93 */         time = 30;
/*     */       }
/*     */       
/*     */       
/*  97 */       if (time < 0) {
/*  98 */         time = 0;
/*     */       }
/*     */       
/* 101 */       setExtraData(String.valueOf(time));
/* 102 */       sendUpdate();
/*     */       
/* 104 */       saveData();
/* 105 */     } else if (requestData == 1) {
/* 106 */       if ((getExtraData().equals("0")) && (this.lastTime != null) && (!this.lastTime.isEmpty()) && (Integer.parseInt(this.lastTime) > 0)) {
/* 107 */         setExtraData(this.lastTime);
/*     */       }
/*     */       
/* 110 */       int gameLength = Integer.parseInt(getExtraData());
/*     */       
/* 112 */       this.lastTime = getExtraData();
/*     */       
/* 114 */       if (gameLength == 0) {
/* 115 */         return true;
/*     */       }
/*     */       
/* 118 */       if (getRoom().getGame().getInstance() == null) {
/* 119 */         getRoom().getGame().createNew(GameType.BANZAI);
/* 120 */         getRoom().getGame().getInstance().startTimer(gameLength);
/* 121 */       } else if ((getRoom().getGame().getInstance() instanceof BanzaiGame)) {
/* 122 */         this.running = false;
/* 123 */         getRoom().getGame().getInstance().onGameEnds();
/* 124 */         getRoom().getGame().stop();
/*     */       }
/*     */     }
/*     */     
/* 128 */     return true;
/*     */   }
/*     */   
/*     */   public void onPickup()
/*     */   {
/* 133 */     if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof BanzaiGame))) {
/* 134 */       getRoom().getGame().getInstance().onGameEnds();
/* 135 */       getRoom().getGame().stop();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean trigger(int requestData) {
/* 140 */     if (requestData == -1) {
/* 141 */       getRoom().getGame().getInstance().onGameEnds();
/* 142 */       getRoom().getGame().stop();
/*     */       
/* 144 */       this.running = false;
/*     */       
/* 146 */       return false;
/*     */     }
/*     */     
/* 149 */     if ((this.interrupted) && (requestData != -2)) {
/* 150 */       if (requestData == 0) {
/* 151 */         if ((getExtraData().equals("0")) && (this.lastTime != null) && (!this.lastTime.isEmpty()) && (Integer.parseInt(this.lastTime) > 0)) {
/* 152 */           setExtraData(this.lastTime);
/*     */         }
/*     */         
/* 155 */         int gameLength = Integer.parseInt(getExtraData());
/*     */         
/* 157 */         this.lastTime = getExtraData();
/*     */         
/* 159 */         if (gameLength == 0) {
/* 160 */           gameLength = 30;
/* 161 */           this.lastTime = "30";
/*     */         }
/*     */         
/* 164 */         if (getRoom().getGame().getInstance() == null) {
/* 165 */           getRoom().getGame().createNew(GameType.BANZAI);
/* 166 */           getRoom().getGame().getInstance().startTimer(gameLength);
/*     */         }
/*     */         
/* 169 */         return false;
/*     */       }
/*     */       
/* 172 */       if (getRoom().getGame().getInstance() == null) {
/* 173 */         getRoom().getGame().createNew(GameType.BANZAI);
/* 174 */         getRoom().getGame().getInstance().startTimer(requestData);
/*     */       }
/*     */       
/* 177 */       return false;
/*     */     }
/*     */     
/* 180 */     if (this.running) {
/* 181 */       if (getRoom().getGame().getInstance() == null) {
/* 182 */         this.running = false;
/* 183 */         return false;
/*     */       }
/*     */       
/* 186 */       this.running = false;
/*     */       
/* 188 */       getRoom().getGame().getInstance().onGameEnds();
/* 189 */       getRoom().getGame().stop();
/*     */     } else {
/* 191 */       if ((getExtraData().equals("0")) && (this.lastTime != null) && (!this.lastTime.isEmpty()) && (Integer.parseInt(this.lastTime) > 0)) {
/* 192 */         setExtraData(this.lastTime);
/*     */       }
/*     */       
/* 195 */       int gameLength = Integer.parseInt(getExtraData());
/*     */       
/* 197 */       this.lastTime = getExtraData();
/*     */       
/* 199 */       if (gameLength == 0) {
/* 200 */         gameLength = 30;
/* 201 */         this.lastTime = "30";
/*     */       }
/*     */       
/* 204 */       if (getRoom().getGame().getInstance() == null) {
/* 205 */         getRoom().getGame().createNew(GameType.BANZAI);
/* 206 */         getRoom().getGame().getInstance().startTimer((requestData == 0) || (requestData == -2) ? gameLength : requestData);
/*     */       }
/*     */     }
/*     */     
/* 210 */     return true;
/*     */   }
/*     */   
/*     */   public String getDataObject()
/*     */   {
/* 215 */     return (this.lastTime != null) && (!this.lastTime.isEmpty()) ? this.lastTime : getExtraData();
/*     */   }
/*     */   
/*     */   public boolean isRunning() {
/* 219 */     return this.running;
/*     */   }
/*     */   
/*     */   public void setRunning(boolean running) {
/* 223 */     this.running = running;
/*     */   }
/*     */   
/*     */   public boolean isInterrupted() {
/* 227 */     return this.interrupted;
/*     */   }
/*     */   
/*     */   public void setInterrupted(boolean interrupted) {
/* 231 */     this.interrupted = interrupted;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\banzai\BanzaiTimerFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */