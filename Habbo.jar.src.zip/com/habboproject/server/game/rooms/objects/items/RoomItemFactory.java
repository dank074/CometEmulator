/*     */ package com.habboproject.server.game.rooms.objects.items;
/*     */ 
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.rares.LimitedEditionItemData;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.adjustable.AdjustableHeightSeatFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.adjustable.MagicStackFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.banzai.BanzaiGateFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.banzai.BanzaiTeleportFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.banzai.BanzaiTileFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.football.FootballGateFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.football.FootballGoalFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.freeze.FreezeBlockFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.freeze.FreezeGateFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.freeze.FreezeTileFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.gates.GateFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.gates.OneWayGateFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.groups.GroupFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.others.BadgeDisplayFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.others.DiceFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.others.PressurePlateSeatFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.others.WaterFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.pet.PetBreedingBoxFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.rollers.RollerFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.snowboarding.SnowboardJumpFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.teleport.TeleportFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.teleport.TeleportPadFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.totem.TotemPlanetFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions.WiredActionBotClothes;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions.WiredActionBotMove;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions.WiredActionCallStacks;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions.WiredActionToggleState;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons.WiredAddonColourWheel;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons.WiredAddonFloorSwitch;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons.WiredAddonPressurePlate;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons.WiredAddonPuzzleBoxFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons.WiredAddonVisualTimer;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.negative.WiredNegativeConditionFurniHasPlayers;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.negative.WiredNegativeConditionPlayerWearingEffect;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.negative.WiredNegativeConditionTriggererOnFurni;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive.WiredConditionActorInTeam;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive.WiredConditionDateRangeActive;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive.WiredConditionPlayerCountInRoom;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive.WiredConditionTimeMoreThan;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive.WiredConditionTriggererOnFurni;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerAtGivenTime;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerAtGivenTimeLong;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerGameEnds;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerPlayerSaysKeyword;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.wall.MoodlightWallItem;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import java.util.HashMap;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class RoomItemFactory
/*     */ {
/*     */   private static final int processMs = 500;
/*     */   private static final String GIFT_DATA = "GIFT::##";
/*     */   public static final String STACK_TOOL = "tile_stackmagic";
/*     */   public static final String TELEPORT_PAD = "teleport_pad";
/*  61 */   private static final Logger log = Logger.getLogger(RoomItemFactory.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private static final HashMap<String, Class<? extends RoomItemFloor>> itemDefinitionMap = new HashMap() {};
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RoomItemFloor createFloor(long id, int baseId, Room room, int ownerId, int groupId, int x, int y, double height, int rot, String data, LimitedEditionItemData limitedEditionItemData)
/*     */   {
/* 211 */     ItemDefinition def = ItemManager.getInstance().getDefinition(baseId);
/* 212 */     RoomItemFloor floorItem = null;
/*     */     
/* 214 */     if (def == null) {
/* 215 */       return null;
/*     */     }
/*     */     
/* 218 */     if (def.canSit()) {
/* 219 */       floorItem = new com.habboproject.server.game.rooms.objects.items.types.floor.others.SeatFloorItem(id, baseId, room, ownerId, groupId, x, y, height, rot, data);
/*     */     }
/*     */     
/* 222 */     if (def.getItemName().startsWith("tile_stackmagic")) {
/* 223 */       floorItem = new MagicStackFloorItem(id, baseId, room, ownerId, groupId, x, y, height, rot, data);
/*     */     }
/*     */     
/* 226 */     if (data.startsWith("GIFT::##")) {
/*     */       try {
/* 228 */         floorItem = new com.habboproject.server.game.rooms.objects.items.types.floor.others.GiftFloorItem(id, baseId, room, ownerId, groupId, x, y, height, rot, data);
/*     */       } catch (Exception e) {
/* 230 */         return null;
/*     */       }
/*     */       
/* 233 */     } else if (itemDefinitionMap.containsKey(def.getInteraction())) {
/*     */       try {
/* 235 */         floorItem = 
/* 236 */           (RoomItemFloor)((Class)itemDefinitionMap.get(def.getInteraction())).getConstructor(new Class[] { Long.TYPE, Integer.TYPE, Room.class, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Double.TYPE, Integer.TYPE, String.class }).newInstance(new Object[] { Long.valueOf(id), Integer.valueOf(baseId), room, Integer.valueOf(ownerId), Integer.valueOf(groupId), Integer.valueOf(x), Integer.valueOf(y), Double.valueOf(height), Integer.valueOf(rot), data });
/*     */       } catch (Exception e) {
/* 238 */         log.warn("Failed to create instance for item: " + id + ", type: " + def.getInteraction(), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 243 */     if (floorItem == null) {
/* 244 */       floorItem = new com.habboproject.server.game.rooms.objects.items.types.DefaultFloorItem(id, baseId, room, ownerId, groupId, x, y, height, rot, data);
/*     */     }
/*     */     
/* 247 */     if (limitedEditionItemData != null) {
/* 248 */       floorItem.setLimitedEditionItemData(limitedEditionItemData);
/*     */     }
/*     */     
/* 251 */     return floorItem;
/*     */   }
/*     */   
/*     */   public static RoomItemWall createWall(long id, int baseId, Room room, int owner, String position, String data, LimitedEditionItemData limitedEditionItemData) {
/* 255 */     ItemDefinition def = ItemManager.getInstance().getDefinition(baseId);
/* 256 */     if (def == null) {
/* 257 */       return null;
/*     */     }
/*     */     
/*     */     String str;
/*     */     RoomItemWall wallItem;
/* 262 */     switch ((str = def.getInteraction()).hashCode()) {case -1331727278:  if (str.equals("dimmer")) break; break; case -982450741:  if (str.equals("postit")) {} case 876710021:  if ((goto 162) && (str.equals("habbowheel")))
/*     */       {
/* 264 */         RoomItemWall wallItem = new com.habboproject.server.game.rooms.objects.items.types.wall.WheelWallItem(id, baseId, room, owner, position, data);
/*     */         
/*     */         break label180;
/*     */         
/* 268 */         RoomItemWall wallItem = new MoodlightWallItem(id, baseId, room, owner, position, data);
/*     */         
/*     */         break label180;
/*     */         
/* 272 */         wallItem = new com.habboproject.server.game.rooms.objects.items.types.wall.PostItWallItem(id, baseId, room, owner, position, data); }
/* 273 */       break;
/*     */     }
/*     */     
/* 276 */     RoomItemWall wallItem = new com.habboproject.server.game.rooms.objects.items.types.DefaultWallItem(id, baseId, room, owner, position, data);
/*     */     
/*     */ 
/*     */     label180:
/*     */     
/* 281 */     if (limitedEditionItemData != null) {
/* 282 */       wallItem.setLimitedEditionItemData(limitedEditionItemData);
/*     */     }
/*     */     
/* 285 */     return wallItem;
/*     */   }
/*     */   
/*     */   public static int getProcessTime(double time) {
/* 289 */     long realTime = Math.round(time * 1000.0D / 500.0D);
/*     */     
/* 291 */     if (realTime < 1L) {
/* 292 */       realTime = 1L;
/*     */     }
/*     */     
/* 295 */     return (int)realTime;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\RoomItemFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */