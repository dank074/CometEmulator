/*    */ package com.habboproject.server.game.rooms.objects.items.types.wall;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemWall;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.RightsComponent;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class WheelWallItem extends RoomItemWall
/*    */ {
/* 13 */   private boolean isInUse = false;
/*    */   
/* 15 */   private final Random r = new Random();
/*    */   
/*    */   public WheelWallItem(long id, int itemId, Room room, int owner, String position, String data) {
/* 18 */     super(id, itemId, room, owner, position, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 23 */     if (this.isInUse) {
/* 24 */       return false;
/*    */     }
/*    */     
/* 27 */     if ((entity instanceof PlayerEntity)) {
/* 28 */       PlayerEntity pEntity = (PlayerEntity)entity;
/* 29 */       if (!getRoom().getRights().hasRights(pEntity.getPlayerId())) {
/* 30 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 34 */     this.isInUse = true;
/*    */     
/* 36 */     setExtraData("-1");
/* 37 */     sendUpdate();
/*    */     
/* 39 */     setTicks(RoomItemFactory.getProcessTime(4.0D));
/* 40 */     return true;
/*    */   }
/*    */   
/*    */   public void onTickComplete()
/*    */   {
/* 45 */     int wheelPos = this.r.nextInt(10) + 1;
/*    */     
/* 47 */     setExtraData(Integer.toString(wheelPos));
/* 48 */     sendUpdate();
/*    */     
/* 50 */     this.isInUse = false;
/*    */   }
/*    */   
/*    */   public void onPickup()
/*    */   {
/* 55 */     cancelTicks();
/*    */   }
/*    */   
/*    */   public void onPlaced()
/*    */   {
/* 60 */     if (!"0".equals(getExtraData())) {
/* 61 */       setExtraData("0");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\wall\WheelWallItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */