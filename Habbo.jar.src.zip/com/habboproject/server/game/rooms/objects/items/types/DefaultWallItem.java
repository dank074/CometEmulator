/*    */ package com.habboproject.server.game.rooms.objects.items.types;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public final class DefaultWallItem extends com.habboproject.server.game.rooms.objects.items.RoomItemWall
/*    */ {
/*    */   public DefaultWallItem(long id, int itemId, Room room, int owner, String position, String data)
/*    */   {
/* 11 */     super(id, itemId, room, owner, position, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 16 */     if (!isWiredTrigger) {
/* 17 */       if (!(entity instanceof PlayerEntity)) {
/* 18 */         return false;
/*    */       }
/* 20 */       if (!entity.getRoom().getRights().hasRights(((PlayerEntity)entity).getPlayerId())) {
/* 21 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 25 */     toggleInteract(true);
/* 26 */     sendUpdate();
/*    */     
/* 28 */     saveData();
/* 29 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\DefaultWallItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */