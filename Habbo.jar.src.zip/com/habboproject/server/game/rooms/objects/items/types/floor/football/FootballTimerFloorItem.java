/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.football;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.games.GameType;
/*     */ import com.habboproject.server.game.rooms.types.components.games.RoomGame;
/*     */ import com.habboproject.server.game.rooms.types.components.games.football.FootballGame;
/*     */ 
/*     */ public class FootballTimerFloorItem extends com.habboproject.server.game.rooms.objects.items.RoomItemFloor
/*     */ {
/*  12 */   private int time = 0;
/*     */   
/*  14 */   private boolean interrupted = false;
/*  15 */   private boolean running = false;
/*     */   
/*     */   public FootballTimerFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public boolean onInteract(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity, int requestData, boolean isWiredTriggered)
/*     */   {
/*  23 */     if (!isWiredTriggered) {
/*  24 */       if (!(entity instanceof PlayerEntity)) {
/*  25 */         return false;
/*     */       }
/*     */       
/*  28 */       PlayerEntity pEntity = (PlayerEntity)entity;
/*  29 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/*  30 */         return true;
/*     */       }
/*     */     }
/*     */     
/*  34 */     if (isWiredTriggered) {
/*  35 */       return trigger(requestData);
/*     */     }
/*     */     
/*  38 */     if (requestData == 1)
/*     */     {
/*  40 */       if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof FootballGame))) {
/*  41 */         this.running = false;
/*  42 */         getRoom().getGame().getInstance().onGameEnds();
/*  43 */         getRoom().getGame().stop();
/*     */       }
/*     */       int time;
/*  46 */       if (((time = Integer.parseInt(getExtraData())) == 0) || (time == 30) || (time == 60) || (time == 120) || (time == 180) || (time == 300) || (time == 600)) {}
/*  47 */       switch (time) {
/*     */       default: 
/*  49 */         time = 0;
/*  50 */         break;
/*     */       
/*     */ 
/*     */       case 0: 
/*  54 */         time = 30;
/*  55 */         break;
/*     */       
/*     */ 
/*     */       case 30: 
/*  59 */         time = 60;
/*  60 */         break;
/*     */       
/*     */ 
/*     */       case 60: 
/*  64 */         time = 120;
/*  65 */         break;
/*     */       
/*     */ 
/*     */       case 120: 
/*  69 */         time = 180;
/*  70 */         break;
/*     */       
/*     */ 
/*     */       case 180: 
/*  74 */         time = 300;
/*  75 */         break;
/*     */       
/*     */ 
/*     */       case 300: 
/*  79 */         time = 600;
/*     */         
/*     */ 
/*     */ 
/*  83 */         break;
/*  84 */         time = 0;
/*     */       }
/*     */       
/*  87 */       this.time = time;
/*     */       
/*  89 */       setExtraData(String.valueOf(this.time));
/*  90 */       sendUpdate();
/*  91 */     } else if (getRoom().getGame().getInstance() == null) {
/*  92 */       getRoom().getGame().createNew(GameType.FOOTBALL);
/*  93 */       getRoom().getGame().getInstance().startTimer(this.time);
/*  94 */     } else if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof FootballGame))) {
/*  95 */       this.running = false;
/*  96 */       getRoom().getGame().getInstance().onGameEnds();
/*  97 */       getRoom().getGame().stop();
/*     */     }
/*     */     
/* 100 */     return true;
/*     */   }
/*     */   
/*     */   public boolean trigger(int requestData) {
/* 104 */     if (requestData == -1) {
/* 105 */       getRoom().getGame().getInstance().onGameEnds();
/* 106 */       getRoom().getGame().stop();
/* 107 */       this.running = false;
/* 108 */       return false;
/*     */     }
/*     */     
/* 111 */     if ((this.interrupted) && (requestData != -2)) {
/* 112 */       if (requestData == 0)
/*     */       {
/* 114 */         if ((getExtraData().equals("0")) && (this.time > 0)) {
/* 115 */           setExtraData(String.valueOf(this.time));
/*     */         }
/*     */         int gameLength;
/* 118 */         if ((gameLength = Integer.parseInt(getExtraData())) == 0) {
/* 119 */           gameLength = 30;
/*     */         }
/*     */         
/* 122 */         this.time = gameLength;
/*     */         
/* 124 */         if (getRoom().getGame().getInstance() == null) {
/* 125 */           getRoom().getGame().createNew(GameType.FOOTBALL);
/* 126 */           getRoom().getGame().getInstance().startTimer(gameLength);
/*     */         }
/*     */         
/* 129 */         return false;
/*     */       }
/*     */       
/* 132 */       if (getRoom().getGame().getInstance() == null) {
/* 133 */         getRoom().getGame().createNew(GameType.FOOTBALL);
/* 134 */         getRoom().getGame().getInstance().startTimer(requestData);
/*     */       }
/*     */       
/* 137 */       return false;
/*     */     }
/*     */     
/* 140 */     if (this.running) {
/* 141 */       if (getRoom().getGame().getInstance() == null) {
/* 142 */         this.running = false;
/* 143 */         return false;
/*     */       }
/*     */       
/* 146 */       this.running = false;
/* 147 */       getRoom().getGame().getInstance().onGameEnds();
/* 148 */       getRoom().getGame().stop();
/*     */     }
/*     */     else
/*     */     {
/* 152 */       if ((getExtraData().equals("0")) && (this.time > 0)) {
/* 153 */         setExtraData(String.valueOf(this.time));
/*     */       }
/*     */       int gameLength;
/* 156 */       if ((gameLength = Integer.parseInt(getExtraData())) == 0) {
/* 157 */         gameLength = 30;
/*     */       }
/*     */       
/* 160 */       this.time = gameLength;
/*     */       
/* 162 */       if (getRoom().getGame().getInstance() == null) {
/* 163 */         getRoom().getGame().createNew(GameType.FOOTBALL);
/* 164 */         getRoom().getGame().getInstance().startTimer((requestData == 0) || (requestData == -2) ? gameLength : requestData);
/*     */       }
/*     */     }
/*     */     
/* 168 */     return true;
/*     */   }
/*     */   
/*     */   public void onPickup()
/*     */   {
/* 173 */     if ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof FootballGame))) {
/* 174 */       getRoom().getGame().getInstance().onGameEnds();
/* 175 */       getRoom().getGame().stop();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isInterrupted() {
/* 180 */     return this.interrupted;
/*     */   }
/*     */   
/*     */   public void setInterrupted(boolean interrupted) {
/* 184 */     this.interrupted = interrupted;
/*     */   }
/*     */   
/*     */   public boolean isRunning() {
/* 188 */     return this.running;
/*     */   }
/*     */   
/*     */   public void setRunning(boolean running) {
/* 192 */     this.running = running;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\football\FootballTimerFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */