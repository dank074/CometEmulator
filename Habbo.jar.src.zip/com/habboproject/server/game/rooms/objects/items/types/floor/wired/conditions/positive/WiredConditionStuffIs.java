/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.items.types.ItemDefinition;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionStuffIs
/*    */   extends WiredConditionItem
/*    */ {
/*    */   public WiredConditionStuffIs(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 31 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 36 */     return 8;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 41 */     RoomItemFloor item = null;
/* 42 */     if ((data == null) || (!(data instanceof RoomItemFloor))) {
/* 43 */       if ((entity != null) && ((entity instanceof PlayerEntity))) {
/* 44 */         List<RoomItemFloor> floorItems = getRoom().getItems().getItemsOnSquare(entity.getPosition().getX(), entity.getPosition().getY());
/* 45 */         if ((floorItems != null) && (floorItems.size() > 0)) {
/* 46 */           item = (RoomItemFloor)floorItems.get(0);
/*    */         }
/*    */       }
/*    */     } else {
/* 50 */       item = (RoomItemFloor)data;
/*    */     }
/*    */     
/* 53 */     if (item == null) {
/* 54 */       return false;
/*    */     }
/*    */     
/* 57 */     if ((getWiredData().getSelectedIds() == null) || (getWiredData().getSelectedIds().size() == 0)) {
/* 58 */       return false;
/*    */     }
/*    */     
/* 61 */     for (Iterator localIterator = getWiredData().getSelectedIds().iterator(); localIterator.hasNext();) {
/* 62 */       long itemId = ((Long)localIterator.next()).longValue();
/*    */       
/* 64 */       RoomItemFloor floorItem = getRoom().getItems().getFloorItem(itemId);
/*    */       
/* 66 */       if (floorItem == null) {
/* 67 */         getWiredData().getSelectedIds().remove(Long.valueOf(itemId));
/*    */       } else {
/* 69 */         if (((!this.isNegative) && (item.getDefinition().getItemName() == floorItem.getDefinition().getItemName())) || ((this.isNegative) && (item.getDefinition().getItemName() != floorItem.getDefinition().getItemName()))) {
/* 70 */           return true;
/*    */         }
/*    */         
/* 73 */         if (((!this.isNegative) && (item.getDefinition().getInteraction() != "default") && (item.getDefinition().getInteraction() == floorItem.getDefinition().getInteraction())) || (
/* 74 */           (this.isNegative) && (item.getDefinition().getInteraction() != "default") && (item.getDefinition().getInteraction() != floorItem.getDefinition().getInteraction()))) {
/* 75 */           return true;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 80 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionStuffIs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */