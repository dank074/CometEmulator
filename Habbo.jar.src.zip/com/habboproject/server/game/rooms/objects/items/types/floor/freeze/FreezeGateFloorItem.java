/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.freeze;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class FreezeGateFloorItem extends RoomItemFloor
/*     */ {
/*     */   private GameTeam gameTeam;
/*     */   
/*     */   public FreezeGateFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  19 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     String str;
/*  21 */     switch ((str = getDefinition().getInteraction()).hashCode()) {case -1638325784:  if (str.equals("freeze_blue_gate")) break; break; case -1317080991:  if (str.equals("freeze_red_gate")) {} break; case 116164399:  if (str.equals("freeze_green_gate")) {} break; case 695318542:  if (!str.equals("freeze_yellow_gate"))
/*     */       {
/*  23 */         return;this.gameTeam = GameTeam.BLUE;
/*  24 */         return;
/*     */         
/*     */ 
/*     */ 
/*  28 */         this.gameTeam = GameTeam.RED;
/*  29 */         return;
/*     */         
/*     */ 
/*     */ 
/*  33 */         this.gameTeam = GameTeam.GREEN;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*  38 */         this.gameTeam = GameTeam.YELLOW; }
/*  39 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void onPlaced()
/*     */   {
/*  48 */     setExtraData("0");
/*  49 */     sendUpdate();
/*  50 */     save();
/*     */   }
/*     */   
/*     */   public void onPickup() {
/*  54 */     setExtraData("0");
/*  55 */     save();
/*     */   }
/*     */   
/*     */   public void onEntityStepOn(RoomEntity entity) {
/*  59 */     PlayerEntity playerEntity = null;
/*  60 */     if ((!(entity instanceof PlayerEntity)) || ((playerEntity = (PlayerEntity)entity) == null) || (getTeam() == null) || (getTeam() == GameTeam.NONE)) {
/*  61 */       return;
/*     */     }
/*     */     
/*  64 */     if (playerEntity.getMountedEntity() != null) {
/*  65 */       return;
/*     */     }
/*     */     
/*  68 */     if ((playerEntity.getGameTeam() != null) && (playerEntity.getGameTeam() != GameTeam.NONE) && (playerEntity.getGameTeam() != getTeam())) {
/*  69 */       GameTeam oldTeam = playerEntity.getGameTeam();
/*     */       
/*  71 */       getRoom().getGame().removeFromTeam(oldTeam, Integer.valueOf(playerEntity.getPlayerId()));
/*     */       
/*  73 */       for (RoomItemFloor floorItem : getRoom().getItems().getByInteraction("freeze_" + oldTeam.toString().toLowerCase() + "_gate")) {
/*  74 */         if (floorItem != null)
/*     */         {
/*     */ 
/*     */ 
/*  78 */           floorItem.setExtraData(((List)getRoom().getGame().getTeams().get(oldTeam)).size());
/*  79 */           floorItem.sendUpdate();
/*     */         }
/*     */       }
/*     */     }
/*  83 */     if ((playerEntity.getGameTeam() != null) && (playerEntity.getGameTeam() == getTeam())) {
/*  84 */       getRoom().getGame().removeFromTeam(getTeam(), Integer.valueOf(playerEntity.getPlayerId()));
/*     */       
/*  86 */       playerEntity.setGameTeam(GameTeam.NONE);
/*  87 */       playerEntity.applyEffect(null);
/*     */     } else {
/*  89 */       ((List)getRoom().getGame().getTeams().get(getTeam())).add(new com.habboproject.server.game.rooms.types.components.games.GamePlayer(playerEntity.getPlayerId()));
/*     */       
/*  91 */       playerEntity.setGameTeam(getTeam());
/*  92 */       playerEntity.applyEffect(new PlayerEffect(getTeam().getFreezeEffect(), 0));
/*     */     }
/*     */     
/*  95 */     updateTeamCount();
/*     */   }
/*     */   
/*     */   public void onEntityLeaveRoom(RoomEntity entity) {
/*  99 */     if ((entity instanceof PlayerEntity)) {
/* 100 */       PlayerEntity playerEntity = (PlayerEntity)entity;
/* 101 */       if (playerEntity.getGameTeam() == getTeam()) {
/* 102 */         getRoom().getGame().removeFromTeam(getTeam(), Integer.valueOf(playerEntity.getPlayerId()));
/* 103 */         updateTeamCount();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isMovementCancelled(RoomEntity entity) {
/* 109 */     return (Integer.parseInt(getExtraData()) >= 5) || ((getRoom().getGame().getInstance() != null) && ((getRoom().getGame().getInstance() instanceof com.habboproject.server.game.rooms.types.components.games.freeze.FreezeGame)));
/*     */   }
/*     */   
/*     */   public void updateTeamCount() {
/* 113 */     setExtraData(((List)getRoom().getGame().getTeams().get(getTeam())).size());
/* 114 */     sendUpdate();
/*     */   }
/*     */   
/*     */   public GameTeam getTeam() {
/* 118 */     return this.gameTeam;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\freeze\FreezeGateFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */