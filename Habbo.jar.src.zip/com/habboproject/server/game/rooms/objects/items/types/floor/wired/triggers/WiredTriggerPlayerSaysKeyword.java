/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredTriggerPlayerSaysKeyword extends WiredTriggerItem
/*    */ {
/*    */   public static final int PARAM_OWNERONLY = 0;
/*    */   
/*    */   public WiredTriggerPlayerSaysKeyword(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 15 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 20 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 25 */     return 0;
/*    */   }
/*    */   
/*    */   public static boolean executeTriggers(PlayerEntity playerEntity, String message) {
/* 29 */     boolean wasExecuted = false;
/* 30 */     for (com.habboproject.server.game.rooms.objects.items.RoomItemFloor floorItem : playerEntity.getRoom().getItems().getByClass(WiredTriggerPlayerSaysKeyword.class)) {
/* 31 */       WiredTriggerPlayerSaysKeyword trigger = (WiredTriggerPlayerSaysKeyword)floorItem;
/*    */       
/* 33 */       boolean ownerOnly = (trigger.getWiredData().getParams().containsKey(Integer.valueOf(0))) && (((Integer)trigger.getWiredData().getParams().get(Integer.valueOf(0))).intValue() != 0);
/* 34 */       boolean isOwner = playerEntity.getPlayerId() == trigger.getRoom().getData().getOwnerId();
/*    */       
/* 36 */       if (((!ownerOnly) || (isOwner)) && (!trigger.getWiredData().getText().isEmpty()) && (org.apache.commons.lang3.StringUtils.containsIgnoreCase(message, trigger.getWiredData().getText())))
/*    */       {
/*    */ 
/* 39 */         wasExecuted = trigger.evaluate(playerEntity, message);
/*    */       }
/*    */     }
/* 42 */     if (wasExecuted) {
/* 43 */       playerEntity.getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.room.avatar.WhisperMessageComposer(playerEntity.getId(), message));
/*    */     }
/*    */     
/* 46 */     return wasExecuted;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerPlayerSaysKeyword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */