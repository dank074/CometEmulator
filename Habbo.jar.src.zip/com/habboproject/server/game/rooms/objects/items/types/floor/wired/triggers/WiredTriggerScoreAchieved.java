/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredTriggerScoreAchieved extends WiredTriggerItem
/*    */ {
/*    */   private static final int PARAM_SCORE_TO_ACHIEVE = 0;
/*    */   
/*    */   public WiredTriggerScoreAchieved(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 19 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 24 */     return 10;
/*    */   }
/*    */   
/*    */   public int scoreToAchieve() {
/* 28 */     if (getWiredData().getParams().size() == 1) {
/* 29 */       return ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */     }
/*    */     
/* 32 */     return 0;
/*    */   }
/*    */   
/*    */   public static boolean executeTriggers(int score, com.habboproject.server.game.rooms.types.components.games.GameTeam team, Room room, com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity playerEntity) {
/* 36 */     boolean wasExecuted = false;
/*    */     
/* 38 */     for (com.habboproject.server.game.rooms.objects.items.RoomItemFloor floorItem : room.getItems().getByClass(WiredTriggerScoreAchieved.class)) {
/* 39 */       WiredTriggerScoreAchieved trigger = (WiredTriggerScoreAchieved)floorItem;
/*    */       
/* 41 */       if (trigger.scoreToAchieve() >= score) {
/* 42 */         wasExecuted = trigger.evaluate(playerEntity, team);
/*    */       }
/*    */     }
/*    */     
/* 46 */     return wasExecuted;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerScoreAchieved.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */