/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.others;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntityStatus;
/*    */ 
/*    */ public class BedFloorItem extends com.habboproject.server.game.rooms.objects.items.types.DefaultFloorItem
/*    */ {
/*    */   public BedFloorItem(long id, int itemId, com.habboproject.server.game.rooms.types.Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 10 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 15 */     entity.addStatus(RoomEntityStatus.LAY, getDefinition().getHeight());
/* 16 */     entity.markNeedsUpdate();
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 21 */     entity.removeStatus(RoomEntityStatus.LAY);
/* 22 */     entity.markNeedsUpdate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\others\BedFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */