/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.football;
/*    */ 
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class FootballGateFloorItem extends RoomItemFloor
/*    */ {
/*    */   public FootballGateFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 13 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 15 */     if (getExtraData().equals("0")) {
/* 16 */       setExtraData("hr-828-31.ch-255-82.sh-3089-64.hd-180-10.lg-3058-64;hr-828-31.ch-255-82.sh-3089-64.hd-180-10.lg-3058-64");
/* 17 */       saveData();
/*    */     }
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity) {
/* 22 */     if (!(entity instanceof PlayerEntity)) {
/* 23 */       return;
/*    */     }
/*    */     
/* 26 */     PlayerEntity playerEntity = (PlayerEntity)entity;
/*    */     
/* 28 */     String newFigure = "";
/* 29 */     for (String playerFigurePart : Arrays.asList(playerEntity.getFigure().split("[.]"))) {
/* 30 */       if ((!playerFigurePart.startsWith("ch")) && (!playerFigurePart.startsWith("lg"))) {
/* 31 */         newFigure = String.valueOf(newFigure) + playerFigurePart + ".";
/*    */       }
/*    */     }
/*    */     
/* 35 */     String newFigureParts = getFigure(playerEntity.getGender());
/* 36 */     for (String newFigurePart : Arrays.asList(newFigureParts.split("[.]"))) {
/* 37 */       if (newFigurePart.startsWith("hd")) {
/* 38 */         newFigureParts = newFigureParts.replace(newFigurePart, "");
/*    */       }
/*    */     }
/*    */     
/* 42 */     if (newFigureParts.equals("")) {
/* 43 */       return;
/*    */     }
/*    */     
/* 46 */     playerEntity.getPlayer().getData().setFigure(String.valueOf(newFigure) + newFigureParts);
/* 47 */     playerEntity.getPlayer().poof();
/*    */     
/* 49 */     playerEntity.getPlayer().getData().save();
/*    */   }
/*    */   
/*    */   public void setFigure(String gender, String figure) { String str;
/* 53 */     switch ((str = gender.toUpperCase()).hashCode()) {case 70:  if (str.equals("F")) break; break; case 77:  if (!str.equals("M"))
/*    */       {
/* 55 */         return;setExtraData(String.valueOf(getFigure("M")) + ";" + figure);
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/* 60 */         setExtraData(String.valueOf(figure) + ";" + getFigure("F")); }
/* 61 */       break;
/*    */     }
/*    */     
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getFigure(String gender)
/*    */   {
/* 70 */     if (!getExtraData().contains(";")) {
/* 71 */       return "hr-828-31.ch-255-82.sh-3089-64.hd-180-10.lg-3058-64";
/*    */     }
/*    */     
/* 74 */     String[] figureData = getExtraData().split(";");
/*    */     String figure;
/*    */     String figure;
/* 77 */     if (gender.toUpperCase().equals("M")) {
/* 78 */       figure = figureData[0]; } else { String figure;
/* 79 */       if (figureData.length != 2) {
/* 80 */         figure = "";
/*    */       } else {
/* 82 */         figure = figureData[1];
/*    */       }
/*    */     }
/* 85 */     return figure.isEmpty() ? "hr-828-31.ch-255-82.sh-3089-64.hd-180-10.lg-3058-64" : figure;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\football\FootballGateFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */