/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionHasFurniOn
/*    */   extends WiredConditionItem
/*    */ {
/*    */   private static final int PARAM_MODE = 0;
/*    */   
/*    */   public WiredConditionHasFurniOn(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 32 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 37 */     return 7;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 42 */     int mode = 0;
/*    */     
/* 44 */     if ((getWiredData().getParams() != null) && (getWiredData().getParams().containsKey(Integer.valueOf(0)))) {
/* 45 */       mode = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */     }
/*    */     
/* 48 */     int selectedItemsCount = 0;
/* 49 */     int selectedItemsWithFurni = 0;
/*    */     
/* 51 */     List<Long> toRemove = Lists.newArrayList();
/* 52 */     long itemId; for (Iterator localIterator = getWiredData().getSelectedIds().iterator(); localIterator.hasNext();) {
/* 53 */       itemId = ((Long)localIterator.next()).longValue();
/*    */       
/* 55 */       RoomItemFloor floorItem = getRoom().getItems().getFloorItem(itemId);
/*    */       
/* 57 */       if (floorItem == null) {
/* 58 */         toRemove.add(Long.valueOf(itemId));
/*    */       } else {
/* 60 */         selectedItemsCount++;
/* 61 */         for (RoomItemFloor itemOnSq : floorItem.getItemsOnStack()) {
/* 62 */           if ((itemOnSq.getPosition().getZ() != 0.0D) && (itemOnSq.getPosition().getZ() > floorItem.getPosition().getZ()) && (itemOnSq.getId() != floorItem.getId())) {
/* 63 */             selectedItemsWithFurni++;
/* 64 */             break;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 70 */     if (toRemove.size() > 0) {
/* 71 */       for (Long itemId : toRemove) {
/* 72 */         getWiredData().getSelectedIds().remove(itemId);
/*    */       }
/*    */     }
/*    */     
/* 76 */     boolean result = false;
/*    */     
/* 78 */     if (mode == 0) {
/* 79 */       if (selectedItemsWithFurni >= 1) result = true;
/*    */     }
/* 81 */     else if (selectedItemsWithFurni == selectedItemsCount) { result = true;
/*    */     }
/*    */     
/* 84 */     return this.isNegative ? true : result ? false : result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionHasFurniOn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */