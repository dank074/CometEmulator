/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredTriggerAtGivenTimeLong extends WiredTriggerAtGivenTime
/*    */ {
/*    */   private static final int PARAM_TICK_LENGTH = 0;
/*    */   
/*    */   public WiredTriggerAtGivenTimeLong(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 10 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 12 */     if (getWiredData().getParams().get(Integer.valueOf(0)) == null) {
/* 13 */       getWiredData().getParams().put(Integer.valueOf(0), Integer.valueOf(2));
/*    */     }
/*    */   }
/*    */   
/*    */   public int getTime()
/*    */   {
/* 19 */     return ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue() * 10;
/*    */   }
/*    */   
/*    */   public static boolean executeTriggers(Room room, int timer) {
/* 23 */     boolean wasExecuted = false;
/*    */     
/* 25 */     for (com.habboproject.server.game.rooms.objects.items.RoomItemFloor wiredItem : room.getItems().getByClass(WiredTriggerAtGivenTime.class)) {
/* 26 */       WiredTriggerAtGivenTimeLong trigger = (WiredTriggerAtGivenTimeLong)wiredItem;
/*    */       
/* 28 */       if (timer >= trigger.getTime()) {
/* 29 */         wasExecuted = trigger.evaluate(null, null);
/*    */       }
/*    */     }
/*    */     
/* 33 */     return wasExecuted;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 38 */     return 12;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerAtGivenTimeLong.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */