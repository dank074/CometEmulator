/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.groups;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.groups.GroupManager;
/*     */ import com.habboproject.server.game.groups.items.GroupItemManager;
/*     */ import com.habboproject.server.game.groups.types.GroupData;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.AffectedTile;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.threads.ThreadManager;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class GroupGateFloorItem extends com.habboproject.server.game.rooms.objects.items.RoomItemFloor
/*     */ {
/*     */   public GroupGateFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  20 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg, boolean isNew)
/*     */   {
/*  25 */     GroupData groupData = GroupManager.getInstance().getData(getGroupId());
/*     */     
/*  27 */     if (groupData == null) {
/*  28 */       msg.writeInt(0);
/*  29 */       msg.writeInt(2);
/*  30 */       msg.writeInt(0);
/*     */     } else {
/*  32 */       msg.writeInt(0);
/*  33 */       msg.writeInt(2);
/*  34 */       msg.writeInt(5);
/*     */       
/*  36 */       msg.writeString(getExtraData());
/*  37 */       msg.writeString(Integer.valueOf(getGroupId()));
/*     */       
/*  39 */       msg.writeString(groupData.getBadge());
/*     */       
/*  41 */       String colourA = GroupManager.getInstance().getGroupItems().getSymbolColours().get(Integer.valueOf(groupData.getColourA())) != null ? ((com.habboproject.server.game.groups.items.types.GroupSymbolColour)GroupManager.getInstance().getGroupItems().getSymbolColours().get(Integer.valueOf(groupData.getColourA()))).getColour() : "ffffff";
/*  42 */       String colourB = GroupManager.getInstance().getGroupItems().getBackgroundColours().get(Integer.valueOf(groupData.getColourB())) != null ? ((com.habboproject.server.game.groups.items.types.GroupBackgroundColour)GroupManager.getInstance().getGroupItems().getBackgroundColours().get(Integer.valueOf(groupData.getColourB()))).getColour() : "ffffff";
/*     */       
/*  44 */       msg.writeString(colourA);
/*  45 */       msg.writeString(colourB);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*     */   {
/*  51 */     if (((entity instanceof PlayerEntity)) && ((((PlayerEntity)entity).getPlayer().getGroups().contains(Integer.valueOf(getGroupId()))) || (((PlayerEntity)entity).getPlayer().getPermissions().getRank().roomFullControl()))) {
/*  52 */       for (AffectedTile tile : AffectedTile.getAffectedTilesAt(getDefinition().getLength(), getDefinition().getWidth(), getPosition().getX(), getPosition().getY(), getRotation())) {
/*  53 */         if (getRoom().getEntities().getEntitiesAt(new Position(tile.x, tile.y)).size() > 0)
/*     */         {
/*     */ 
/*  56 */           return false;
/*     */         }
/*     */       }
/*  59 */       if (getRoom().getEntities().getEntitiesAt(getPosition()).size() > 0) {
/*  60 */         return false;
/*     */       }
/*     */       
/*  63 */       for (RoomEntity entity0 : getRoom().getEntities().getAllEntities().values()) {
/*  64 */         if ((getPosition().distanceTo(entity0.getPosition()) <= 1.0D) && (entity0.isWalking()))
/*     */         {
/*     */ 
/*  67 */           return false;
/*     */         }
/*     */       }
/*  70 */       if (getExtraData() == "0") {
/*  71 */         setExtraData("1");
/*     */       } else {
/*  73 */         setExtraData("0");
/*     */       }
/*     */       
/*  76 */       sendUpdate();
/*     */       
/*  78 */       return true;
/*     */     }
/*     */     
/*  81 */     return false;
/*     */   }
/*     */   
/*     */   public void onEntityPreStepOn(RoomEntity entity)
/*     */   {
/*  86 */     ThreadManager.getInstance().execute(new com.habboproject.server.threads.executors.gate.GateOpenEvent(this));
/*     */   }
/*     */   
/*     */   public void onEntityStepOff(RoomEntity entity)
/*     */   {
/*  91 */     ThreadManager.getInstance().executeSchedule(new com.habboproject.server.threads.executors.gate.GateCloseEvent(this), 500L, java.util.concurrent.TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */   public boolean isMovementCancelled(RoomEntity entity)
/*     */   {
/*  96 */     if (entity == null) {
/*  97 */       return true;
/*     */     }
/*  99 */     if (!(entity instanceof PlayerEntity)) {
/* 100 */       return true;
/*     */     }
/*     */     
/* 103 */     if (!((PlayerEntity)entity).getPlayer().getGroups().contains(Integer.valueOf(getGroupId()))) {
/* 104 */       return true;
/*     */     }
/*     */     
/* 107 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 111 */     return !getExtraData().equals("0");
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\groups\GroupGateFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */