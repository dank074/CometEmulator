/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.pet;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import com.habboproject.server.game.pets.data.PetData;
/*     */ import com.habboproject.server.game.pets.races.BreedingType;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PetEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.ai.pets.PetAI;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.messages.outgoing.notification.MotdNotificationMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.network.sessions.SessionManager;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PetBreedingBoxFloorItem
/*     */   extends RoomItemFloor
/*     */ {
/*  26 */   private List<PetEntity> entities = Lists.newArrayList();
/*     */   private BreedingType type;
/*     */   
/*     */   public PetBreedingBoxFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  24 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     
/*     */     String str;
/*     */     
/*  28 */     switch ((str = getDefinition().getInteraction()).hashCode()) {case -794265755:  if (str.equals("breeding_bear")) {} break; case 667116037:  if (str.equals("breeding_cat")) {} break; case 667117419:  if (str.equals("breeding_dog")) break; break; case 667128765:  if (str.equals("breeding_pig")) {} break; case 2109694836:  if (!str.equals("breeding_terrier"))
/*     */       {
/*  30 */         return;this.type = BreedingType.DOG;
/*  31 */         return;
/*     */         
/*     */ 
/*  34 */         this.type = BreedingType.CAT;
/*     */       }
/*     */       else
/*     */       {
/*  38 */         this.type = BreedingType.TERRIER;
/*  39 */         return;
/*     */         
/*     */ 
/*  42 */         this.type = BreedingType.BEAR;
/*  43 */         return;
/*     */         
/*     */ 
/*  46 */         this.type = BreedingType.PIG;
/*     */       }
/*     */       break;
/*     */     }
/*     */   }
/*     */   
/*     */   public void onEntityStepOn(RoomEntity entity) {
/*  53 */     if ((entity == null) || (!(entity instanceof PetEntity))) {
/*  54 */       return;
/*     */     }
/*     */     
/*  57 */     if (!getEntities().contains(entity)) {
/*  58 */       getEntities().add((PetEntity)entity);
/*     */       
/*  60 */       ((PetEntity)entity).getPetAI().possibleBreeding();
/*     */     }
/*     */     
/*  63 */     if (getEntities().size() == 2) {
/*  64 */       Session owner = NetworkManager.getInstance().getSessions().getByPlayerId(((PetEntity)entity).getData().getOwnerId());
/*  65 */       if (owner != null) {
/*  66 */         owner.send(new MotdNotificationMessageComposer("Okay!"));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void onEntityStepOff(RoomEntity entity)
/*     */   {
/*  73 */     if ((entity == null) || (!(entity instanceof PetEntity))) {
/*  74 */       return;
/*     */     }
/*     */     
/*  77 */     if (getEntities().contains(entity)) {
/*  78 */       getEntities().remove(entity);
/*     */     }
/*     */     
/*  81 */     entity.setOverriden(false);
/*     */   }
/*     */   
/*     */   public boolean isMovementCancelled(RoomEntity entity)
/*     */   {
/*  86 */     if (entity == null) {
/*  87 */       return true;
/*     */     }
/*  89 */     if (!(entity instanceof PetEntity)) {
/*  90 */       return true;
/*     */     }
/*  92 */     if ((getEntities().size() == 2) && (!getEntities().contains(entity))) {
/*  93 */       return true;
/*     */     }
/*  95 */     return false;
/*     */   }
/*     */   
/*     */   public List<PetEntity> getEntities() {
/*  99 */     return this.entities;
/*     */   }
/*     */   
/*     */   public BreedingType getType() {
/* 103 */     return this.type;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\pet\PetBreedingBoxFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */