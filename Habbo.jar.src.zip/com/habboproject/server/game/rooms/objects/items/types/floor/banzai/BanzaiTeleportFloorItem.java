/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.banzai;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomTile;
/*     */ import com.habboproject.server.network.messages.outgoing.room.items.UpdateFloorItemMessageComposer;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class BanzaiTeleportFloorItem extends RoomItemFloor
/*     */ {
/*  16 */   private int stage = 0;
/*     */   private Position teleportPosition;
/*     */   private RoomEntity entity;
/*     */   private RoomItemFloor floorItem;
/*     */   
/*     */   public BanzaiTeleportFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  23 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public void onItemAddedToStack(RoomItemFloor floorItem)
/*     */   {
/*  28 */     if (this.floorItem != null) { return;
/*     */     }
/*  30 */     if (!(floorItem instanceof com.habboproject.server.game.rooms.objects.items.types.floor.rollable.RollableFloorItem)) {
/*  31 */       return;
/*     */     }
/*     */     
/*  34 */     if (floorItem.hasAttribute("warp")) {
/*  35 */       this.stage = 2;
/*  36 */       setTicks(RoomItemFactory.getProcessTime(0.5D));
/*     */       
/*  38 */       floorItem.removeAttribute("warp");
/*  39 */       return;
/*     */     }
/*     */     
/*  42 */     Position teleportPosition = findPosition();
/*     */     
/*  44 */     if (teleportPosition == null) {
/*  45 */       return;
/*     */     }
/*     */     
/*  48 */     this.teleportPosition = teleportPosition;
/*     */     
/*  50 */     this.floorItem = floorItem;
/*  51 */     this.floorItem.setAttribute("warp", Boolean.valueOf(true));
/*     */     
/*  53 */     setTicks(RoomItemFactory.getProcessTime(0.5D));
/*     */   }
/*     */   
/*     */   public void onEntityStepOn(RoomEntity entity)
/*     */   {
/*  58 */     if (this.entity != null) { return;
/*     */     }
/*  60 */     if (entity.hasAttribute("warp")) {
/*  61 */       this.stage = 2;
/*  62 */       setTicks(RoomItemFactory.getProcessTime(0.5D));
/*     */       
/*  64 */       entity.removeAttribute("warp");
/*  65 */       return;
/*     */     }
/*     */     
/*     */ 
/*  69 */     Position teleportPosition = findPosition();
/*     */     
/*  71 */     if (teleportPosition == null) {
/*  72 */       return;
/*     */     }
/*     */     
/*  75 */     this.teleportPosition = teleportPosition;
/*     */     
/*  77 */     this.entity = entity;
/*  78 */     this.entity.setAttribute("warp", Boolean.valueOf(true));
/*     */     
/*  80 */     setExtraData("1");
/*  81 */     sendUpdate();
/*     */     
/*  83 */     this.stage = 1;
/*     */     
/*  85 */     entity.cancelWalk();
/*  86 */     setTicks(RoomItemFactory.getProcessTime(0.5D));
/*     */   }
/*     */   
/*     */   private Position findPosition() {
/*  90 */     Set<BanzaiTeleportFloorItem> teleporters = new java.util.HashSet();
/*     */     
/*  92 */     for (RoomItemFloor tele : getRoom().getItems().getFloorItems().values()) {
/*  93 */       if (((tele instanceof BanzaiTeleportFloorItem)) && 
/*  94 */         (tele.getId() != getId())) {
/*  95 */         teleporters.add((BanzaiTeleportFloorItem)tele);
/*     */       }
/*     */     }
/*     */     
/*  99 */     if (teleporters.size() < 1) {
/* 100 */       return null;
/*     */     }
/* 102 */     BanzaiTeleportFloorItem randomTeleporter = (BanzaiTeleportFloorItem)teleporters.toArray()[com.habboproject.server.utilities.RandomInteger.getRandom(0, teleporters.size() - 1)];
/* 103 */     teleporters.clear();
/*     */     
/* 105 */     return new Position(randomTeleporter.getPosition().getX(), randomTeleporter.getPosition().getY(), randomTeleporter.getTile().getWalkHeight());
/*     */   }
/*     */   
/*     */   public void onTickComplete()
/*     */   {
/* 110 */     if (this.stage == 1) {
/* 111 */       if (this.entity != null) {
/* 112 */         this.entity.warp(this.teleportPosition);
/* 113 */         this.entity = null;
/*     */       }
/*     */       
/* 116 */       if (this.floorItem != null) {
/* 117 */         this.floorItem.getPosition().setX(this.teleportPosition.getX());
/* 118 */         this.floorItem.getPosition().setY(this.teleportPosition.getY());
/*     */         
/* 120 */         for (RoomItemFloor floorItem : getRoom().getItems().getItemsOnSquare(this.teleportPosition.getX(), this.teleportPosition.getY())) {
/* 121 */           floorItem.onItemAddedToStack(this);
/*     */         }
/*     */         
/* 124 */         this.floorItem.getPosition().setZ(this.teleportPosition.getZ());
/* 125 */         getRoom().getEntities().broadcastMessage(new UpdateFloorItemMessageComposer(this.floorItem));
/*     */       }
/*     */       
/* 128 */       this.teleportPosition = null;
/*     */       
/* 130 */       setTicks(RoomItemFactory.getProcessTime(0.5D));
/* 131 */       this.stage = 0;
/* 132 */       return; }
/* 133 */     if (this.stage == 2) {
/* 134 */       setExtraData("1");
/* 135 */       sendUpdate();
/*     */       
/* 137 */       setTicks(RoomItemFactory.getProcessTime(0.5D));
/* 138 */       this.stage = 0;
/* 139 */       return;
/*     */     }
/*     */     
/* 142 */     setExtraData("0");
/* 143 */     sendUpdate();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\banzai\BanzaiTeleportFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */