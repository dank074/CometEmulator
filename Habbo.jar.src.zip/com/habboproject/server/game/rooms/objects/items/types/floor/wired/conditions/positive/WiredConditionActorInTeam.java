/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredConditionActorInTeam extends WiredConditionItem
/*    */ {
/* 13 */   private final int PARAM_SELECTED_TEAM = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WiredConditionActorInTeam(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 29 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 34 */     return 6;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 39 */     if ((entity == null) || (!(entity instanceof PlayerEntity))) {
/* 40 */       return false;
/*    */     }
/*    */     
/* 43 */     if ((getWiredData().getParams() == null) || (getWiredData().getParams().size() == 0) || (getWiredData().getParams().get(Integer.valueOf(0)) == null)) {
/* 44 */       return false;
/*    */     }
/*    */     
/* 47 */     int selectedTeam = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */     
/* 49 */     if ((selectedTeam <= 0) || (selectedTeam > 4)) {
/* 50 */       return false;
/*    */     }
/*    */     
/* 53 */     if ((selectedTeam == 1) && (((PlayerEntity)entity).getGameTeam() == GameTeam.RED)) {
/* 54 */       if (!this.isNegative) {
/* 55 */         return true;
/*    */       }
/* 57 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 61 */     if ((selectedTeam == 2) && (((PlayerEntity)entity).getGameTeam() == GameTeam.GREEN)) {
/* 62 */       if (!this.isNegative) {
/* 63 */         return true;
/*    */       }
/* 65 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 69 */     if ((selectedTeam == 3) && (((PlayerEntity)entity).getGameTeam() == GameTeam.BLUE)) {
/* 70 */       if (!this.isNegative) {
/* 71 */         return true;
/*    */       }
/* 73 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 77 */     if ((selectedTeam == 4) && (((PlayerEntity)entity).getGameTeam() == GameTeam.YELLOW)) {
/* 78 */       if (!this.isNegative) {
/* 79 */         return true;
/*    */       }
/* 81 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 85 */     return this.isNegative;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionActorInTeam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */