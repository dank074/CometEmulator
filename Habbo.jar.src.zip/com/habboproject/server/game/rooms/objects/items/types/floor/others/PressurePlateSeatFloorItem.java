/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.others;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ 
/*    */ public class PressurePlateSeatFloorItem extends SeatFloorItem
/*    */ {
/*    */   public PressurePlateSeatFloorItem(long id, int itemId, com.habboproject.server.game.rooms.types.Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  8 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 13 */     super.onEntityStepOn(entity);
/*    */     
/* 15 */     setExtraData("1");
/* 16 */     sendUpdate();
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 21 */     super.onEntityStepOff(entity);
/*    */     
/* 23 */     setExtraData("0");
/* 24 */     sendUpdate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\others\PressurePlateSeatFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */