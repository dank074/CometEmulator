/*    */ package com.habboproject.server.game.rooms.objects.items.data;
/*    */ 
/*    */ public class BackgroundTonerData {
/*    */   private int hue;
/*    */   private int saturation;
/*    */   private int lightness;
/*    */   
/*    */   public BackgroundTonerData(int hue, int saturation, int lightness) {
/*  9 */     this.hue = hue;
/* 10 */     this.saturation = saturation;
/* 11 */     this.lightness = lightness;
/*    */   }
/*    */   
/*    */   public int getHue() {
/* 15 */     return this.hue;
/*    */   }
/*    */   
/*    */   public void setHue(int hue) {
/* 19 */     this.hue = hue;
/*    */   }
/*    */   
/*    */   public int getSaturation() {
/* 23 */     return this.saturation;
/*    */   }
/*    */   
/*    */   public void setSaturation(int saturation) {
/* 27 */     this.saturation = saturation;
/*    */   }
/*    */   
/*    */   public int getLightness() {
/* 31 */     return this.lightness;
/*    */   }
/*    */   
/*    */   public void setLightness(int lightness) {
/* 35 */     this.lightness = lightness;
/*    */   }
/*    */   
/*    */   public static BackgroundTonerData get(String extradata) {
/* 39 */     if (!extradata.contains(";#;")) {
/* 40 */       return null;
/*    */     }
/*    */     
/* 43 */     String[] data = extradata.split(";#;");
/*    */     
/* 45 */     if (data.length < 3) {
/* 46 */       return null;
/*    */     }
/*    */     
/* 49 */     return new BackgroundTonerData(Integer.parseInt(data[0]), Integer.parseInt(data[1]), Integer.parseInt(data[2]));
/*    */   }
/*    */   
/*    */   public static String get(BackgroundTonerData data) {
/* 53 */     return data.getHue() + ";#;" + data.getSaturation() + ";#;" + data.getLightness();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\data\BackgroundTonerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */