/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ 
/*    */ public class WiredItemSnapshot
/*    */ {
/*    */   private long itemId;
/*    */   private int x;
/*    */   private int y;
/*    */   private double z;
/*    */   private int rotation;
/*    */   private String extraData;
/*    */   
/*    */   public WiredItemSnapshot(RoomItemFloor floorItem) {
/* 15 */     this.itemId = floorItem.getId();
/* 16 */     this.x = floorItem.getPosition().getX();
/* 17 */     this.y = floorItem.getPosition().getY();
/* 18 */     this.z = floorItem.getPosition().getZ();
/* 19 */     this.rotation = floorItem.getRotation();
/* 20 */     this.extraData = floorItem.getExtraData();
/*    */   }
/*    */   
/*    */   public long getItemId() {
/* 24 */     return this.itemId;
/*    */   }
/*    */   
/*    */   public void setItemId(int itemId) {
/* 28 */     this.itemId = itemId;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 32 */     return this.x;
/*    */   }
/*    */   
/*    */   public void setX(int x) {
/* 36 */     this.x = x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 40 */     return this.y;
/*    */   }
/*    */   
/*    */   public void setY(int y) {
/* 44 */     this.y = y;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 48 */     return this.z;
/*    */   }
/*    */   
/*    */   public void setZ(double z) {
/* 52 */     this.z = z;
/*    */   }
/*    */   
/*    */   public int getRotation() {
/* 56 */     return this.rotation;
/*    */   }
/*    */   
/*    */   public void setRotation(int rotation) {
/* 60 */     this.rotation = rotation;
/*    */   }
/*    */   
/*    */   public String getExtraData() {
/* 64 */     return this.extraData;
/*    */   }
/*    */   
/*    */   public void setExtraData(String extraData) {
/* 68 */     this.extraData = extraData;
/*    */   }
/*    */   
/*    */   public static abstract interface Refreshable
/*    */   {
/*    */     public abstract void refreshSnapshots();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\WiredItemSnapshot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */