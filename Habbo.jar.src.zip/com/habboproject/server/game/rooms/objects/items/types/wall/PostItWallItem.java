/*    */ package com.habboproject.server.game.rooms.objects.items.types.wall;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemWall;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Arrays;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class PostItWallItem extends RoomItemWall
/*    */ {
/*    */   private String colour;
/*    */   private String message;
/*    */   
/*    */   public PostItWallItem(long id, int itemId, Room room, int owner, String position, String data)
/*    */   {
/* 15 */     super(id, itemId, room, owner, position, data);
/*    */     
/* 17 */     if (isValidData(data)) {
/* 18 */       setExtraData(data);
/*    */     } else {
/* 20 */       setExtraData("FFFF33 ");
/*    */     }
/*    */   }
/*    */   
/*    */   public String getExtraData() {
/* 25 */     return this.colour;
/*    */   }
/*    */   
/*    */   public void setExtraData(String extraData)
/*    */   {
/* 30 */     String[] data = extraData.split(" ");
/* 31 */     String colour = data[0];
/*    */     
/* 33 */     if (!isValidColour(colour)) {
/* 34 */       return;
/*    */     }
/*    */     
/* 37 */     super.setExtraData(extraData);
/*    */     
/* 39 */     this.colour = colour;
/*    */     
/* 41 */     this.message = StringUtils.join(Arrays.copyOfRange(data, 1, data.length), " ");
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   private boolean isValidColour(String colour)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: dup
/*    */     //   2: astore_2
/*    */     //   3: invokevirtual 72	java/lang/String:hashCode	()I
/*    */     //   6: lookupswitch	default:+87->93, 1695802060:+42->48, 1695891988:+54->60, 2070451754:+66->72, 2070841312:+78->84
/*    */     //   48: aload_2
/*    */     //   49: ldc 76
/*    */     //   51: invokevirtual 78	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   54: ifne +41 -> 95
/*    */     //   57: goto +36 -> 93
/*    */     //   60: aload_2
/*    */     //   61: ldc 82
/*    */     //   63: invokevirtual 78	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   66: ifne +29 -> 95
/*    */     //   69: goto +24 -> 93
/*    */     //   72: aload_2
/*    */     //   73: ldc 84
/*    */     //   75: invokevirtual 78	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   78: ifne +17 -> 95
/*    */     //   81: goto +12 -> 93
/*    */     //   84: aload_2
/*    */     //   85: ldc 86
/*    */     //   87: invokevirtual 78	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   90: ifne +5 -> 95
/*    */     //   93: iconst_0
/*    */     //   94: ireturn
/*    */     //   95: iconst_1
/*    */     //   96: ireturn
/*    */     // Line number table:
/*    */     //   Java source line #45	-> byte code offset #0
/*    */     //   Java source line #47	-> byte code offset #93
/*    */     //   Java source line #53	-> byte code offset #95
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	97	0	this	PostItWallItem
/*    */     //   0	97	1	colour	String
/*    */     //   2	83	2	str	String
/*    */   }
/*    */   
/*    */   private boolean isValidData(String data)
/*    */   {
/* 58 */     return data.contains(" ");
/*    */   }
/*    */   
/*    */   public String getColour() {
/* 62 */     return this.colour;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 66 */     return this.message;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\wall\PostItWallItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */