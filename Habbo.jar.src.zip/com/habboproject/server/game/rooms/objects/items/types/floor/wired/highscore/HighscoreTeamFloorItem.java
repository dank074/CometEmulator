/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.highscore;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import com.google.gson.Gson;
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.permissions.types.Rank;
/*     */ import com.habboproject.server.game.players.components.PermissionComponent;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.ResetItemData;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.TeamScoreboardData;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.entries.HighscoreTeamEntry;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.types.HighscorePlayer;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.RightsComponent;
/*     */ import com.habboproject.server.storage.queries.items.WiredHighscoreDao;
/*     */ import com.habboproject.server.utilities.JsonFactory;
/*     */ import com.habboproject.server.utilities.comparators.HighscoreTeamComparator;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.joda.time.DateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HighscoreTeamFloorItem
/*     */   extends RoomItemFloor
/*     */ {
/*  35 */   private static final HighscoreTeamComparator comparator = new HighscoreTeamComparator();
/*     */   private boolean state;
/*     */   
/*     */   public HighscoreTeamFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  39 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     String str1;
/*  41 */     if ((data.startsWith("1{")) || (data.startsWith("0{"))) {
/*  42 */       this.state = data.startsWith("1");
/*  43 */       this.itemData = ((TeamScoreboardData)JsonFactory.getInstance().fromJson(data.substring(1), TeamScoreboardData.class));
/*     */       
/*  45 */       int clearType = 0;
/*  46 */       switch ((str1 = getDefinition().getItemName().split("[_]")[1]).hashCode()) {case 872205250:  if (str1.equals("perteam*2")) break; break; case 872205251:  if (str1.equals("perteam*3")) {} break; case 872205252:  if (!str1.equals("perteam*4")) {
/*     */           break label189;
/*  48 */           clearType = 1;
/*     */           
/*     */ 
/*     */           break label189;
/*     */           
/*  53 */           clearType = 2;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*  58 */           clearType = 3; }
/*  59 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */       label189:
/*     */       
/*  66 */       if (this.itemData.getClearType() != clearType) {
/*  67 */         this.itemData.setClearType(clearType);
/*     */       }
/*     */       
/*  70 */       String resetData = WiredHighscoreDao.getData(id);
/*  71 */       if (!resetData.isEmpty()) {
/*  72 */         this.resetData = ((ResetItemData)JsonFactory.getInstance().fromJson(resetData, ResetItemData.class));
/*     */       }
/*     */       else {
/*  75 */         createResetData();
/*     */       }
/*     */       
/*  78 */       if (needsReset()) {
/*  79 */         updateResetData();
/*     */       }
/*     */     }
/*     */     else {
/*  83 */       int clearType = 0;
/*  84 */       switch ((str1 = getDefinition().getItemName().split("[_]")[1]).hashCode()) {case 872205250:  if (str1.equals("perteam*2")) break; break; case 872205251:  if (str1.equals("perteam*3")) {} break; case 872205252:  if (!str1.equals("perteam*4")) {
/*     */           break label377;
/*  86 */           clearType = 1;
/*     */           
/*     */ 
/*     */           break label377;
/*     */           
/*  91 */           clearType = 2;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*  96 */           clearType = 3; }
/*  97 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */       label377:
/*     */       
/* 104 */       this.state = false;
/*     */       
/* 106 */       this.itemData = new TeamScoreboardData(0, clearType, Maps.newHashMap());
/*     */       
/* 108 */       createResetData();
/*     */     } }
/*     */   
/*     */   private final TeamScoreboardData itemData;
/*     */   private ResetItemData resetData;
/* 113 */   public void createResetData() { DateTime date = new DateTime();
/* 114 */     this.resetData = new ResetItemData(date.getDayOfMonth(), date.getDayOfYear(), date.getMonthOfYear(), date.getDayOfWeek(), date.getWeekOfWeekyear());
/*     */     
/* 116 */     WiredHighscoreDao.save(JsonFactory.getInstance().toJson(this.resetData), getId());
/*     */   }
/*     */   
/*     */   public boolean needsReset() {
/* 120 */     DateTime date = new DateTime();
/* 121 */     if ((getScoreData().getClearType() == 1) && (getResetData().getLastDay() != date.getDayOfMonth())) {
/* 122 */       getResetData().setLastDay(date.getDayOfMonth());
/* 123 */       return true;
/*     */     }
/*     */     
/* 126 */     if ((getScoreData().getClearType() == 2) && (date.getWeekOfWeekyear() != getResetData().getLastWeekOfWeekyear())) {
/* 127 */       getResetData().setLastWeekOfWeekyear(date.getWeekOfWeekyear());
/* 128 */       return true;
/*     */     }
/*     */     
/* 131 */     if ((getScoreData().getClearType() == 3) && (getResetData().getLastMonth() != date.getMonthOfYear())) {
/* 132 */       getResetData().setLastMonth(date.getMonthOfYear());
/* 133 */       return true;
/*     */     }
/*     */     
/* 136 */     return false;
/*     */   }
/*     */   
/*     */   public void updateResetData() {
/* 140 */     DateTime date = new DateTime();
/* 141 */     this.resetData = new ResetItemData(date.getDayOfMonth(), date.getDayOfYear(), date.getMonthOfYear(), date.getDayOfWeek(), date.getWeekOfWeekyear());
/* 142 */     getScoreData().removeAll();
/*     */     
/* 144 */     WiredHighscoreDao.update(JsonFactory.getInstance().toJson(this.resetData), getId());
/*     */   }
/*     */   
/*     */   public void reset() {
/* 148 */     getScoreData().removeAll();
/*     */     
/* 150 */     WiredHighscoreDao.update(JsonFactory.getInstance().toJson(this.resetData), getId());
/*     */   }
/*     */   
/*     */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger) {
/* 154 */     if (isWiredTrigger) {
/* 155 */       if (!(entity instanceof PlayerEntity)) {
/* 156 */         return false;
/*     */       }
/*     */       
/* 159 */       PlayerEntity pEntity = (PlayerEntity)entity;
/* 160 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 161 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 165 */     this.state = (!this.state);
/*     */     
/* 167 */     sendUpdate();
/* 168 */     saveData();
/*     */     
/* 170 */     return true;
/*     */   }
/*     */   
/*     */   public String getDataObject() {
/* 174 */     return String.valueOf(this.state ? "1" : "0") + JsonFactory.getInstance().toJson(this.itemData);
/*     */   }
/*     */   
/*     */   public void addEntry(List<HighscorePlayer> users, int teamScore) {
/* 178 */     this.itemData.addEntry(users, teamScore);
/* 179 */     sendUpdate();
/* 180 */     saveData();
/*     */   }
/*     */   
/*     */   public void updateEntry(int id, List<HighscorePlayer> users, int teamScore) {
/* 184 */     this.itemData.updateEntry(id, users, teamScore);
/* 185 */     sendUpdate();
/* 186 */     saveData();
/*     */   }
/*     */   
/*     */   public Map<Integer, List<HighscoreTeamEntry>> getEntries() {
/* 190 */     return this.itemData.getEntries();
/*     */   }
/*     */   
/*     */   public TeamScoreboardData getScoreData() {
/* 194 */     return this.itemData;
/*     */   }
/*     */   
/*     */   public ResetItemData getResetData() {
/* 198 */     return this.resetData;
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg, boolean isNew) {
/* 202 */     msg.writeInt(0);
/* 203 */     msg.writeInt(6);
/*     */     
/* 205 */     msg.writeString(this.state ? "1" : "0");
/*     */     
/* 207 */     msg.writeInt(getScoreData().getScoreType());
/* 208 */     msg.writeInt(getScoreData().getClearType());
/*     */     
/* 210 */     msg.writeInt(getScoreData().getEntries().size() > 50 ? 50 : getScoreData().getEntries().size());
/*     */     
/* 212 */     List<HighscoreTeamEntry> entries = Lists.newArrayList();
/* 213 */     for (List<HighscoreTeamEntry> entry : getScoreData().getEntries().values()) {
/* 214 */       entries.addAll(entry);
/*     */     }
/*     */     
/* 217 */     Collections.sort(entries, comparator);
/*     */     
/* 219 */     int x = 0;
/* 220 */     Iterator localIterator3; for (Iterator localIterator2 = entries.iterator(); localIterator2.hasNext(); 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */         localIterator3.hasNext())
/*     */     {
/* 220 */       HighscoreTeamEntry entry = (HighscoreTeamEntry)localIterator2.next();
/* 221 */       x++; if (x > 50) {
/*     */         break;
/*     */       }
/*     */       
/* 225 */       msg.writeInt(entry.getTeamScore());
/*     */       
/* 227 */       msg.writeInt(entry.getUsers().size());
/* 228 */       localIterator3 = entry.getUsers().iterator(); continue;HighscorePlayer player = (HighscorePlayer)localIterator3.next();
/* 229 */       msg.writeString(player.getUsername());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\highscore\HighscoreTeamFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */