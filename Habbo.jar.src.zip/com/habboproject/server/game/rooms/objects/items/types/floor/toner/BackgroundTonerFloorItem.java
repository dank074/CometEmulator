/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.toner;
/*    */ 
/*    */ import com.habboproject.server.api.networking.messages.IComposer;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.data.BackgroundTonerData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class BackgroundTonerFloorItem extends RoomItemFloor
/*    */ {
/*    */   public BackgroundTonerFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 13 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void compose(IComposer msg, boolean isNew)
/*    */   {
/* 18 */     BackgroundTonerData data = BackgroundTonerData.get(getExtraData());
/*    */     
/* 20 */     boolean enabled = data != null;
/*    */     
/* 22 */     msg.writeInt(0);
/* 23 */     msg.writeInt(5);
/* 24 */     msg.writeInt(4);
/* 25 */     msg.writeInt(enabled ? 1 : 0);
/*    */     
/* 27 */     if (enabled) {
/* 28 */       msg.writeInt(data.getHue());
/* 29 */       msg.writeInt(data.getSaturation());
/* 30 */       msg.writeInt(data.getLightness());
/*    */     } else {
/* 32 */       setExtraData("0;#;0;#;0");
/* 33 */       saveData();
/*    */       
/* 35 */       msg.writeInt(0);
/* 36 */       msg.writeInt(0);
/* 37 */       msg.writeInt(0);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 43 */     setExtraData("");
/* 44 */     saveData();
/*    */     
/* 46 */     getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.items.UpdateFloorItemMessageComposer(this));
/*    */     
/* 48 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\toner\BackgroundTonerFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */