/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredTriggerEnterRoom extends WiredTriggerItem
/*    */ {
/*    */   public WiredTriggerEnterRoom(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 11 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 16 */     return 7;
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 21 */     return true;
/*    */   }
/*    */   
/*    */   public static void executeTriggers(PlayerEntity playerEntity) {
/* 25 */     if ((playerEntity == null) || (playerEntity.getRoom() == null) || (playerEntity.getRoom().getItems() == null)) {
/* 26 */       return;
/*    */     }
/*    */     
/* 29 */     for (com.habboproject.server.game.rooms.objects.items.RoomItemFloor floorItem : playerEntity.getRoom().getItems().getByClass(WiredTriggerEnterRoom.class)) {
/* 30 */       if ((floorItem instanceof WiredTriggerEnterRoom))
/*    */       {
/* 32 */         WiredTriggerEnterRoom trigger = (WiredTriggerEnterRoom)floorItem;
/*    */         
/* 34 */         if ((trigger.getWiredData().getText().isEmpty()) || (trigger.getWiredData().getText().equals(playerEntity.getUsername()))) {
/* 35 */           trigger.evaluate(playerEntity, null);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerEnterRoom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */