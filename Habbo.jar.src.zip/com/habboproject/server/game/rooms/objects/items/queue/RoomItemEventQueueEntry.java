/*    */ package com.habboproject.server.game.rooms.objects.items.queue;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoomItemEventQueueEntry
/*    */ {
/*    */   private final RoomItem item;
/*    */   private final RoomEntity entity;
/*    */   private final RoomItemEventType type;
/*    */   private final int requestData;
/*    */   private final boolean isWiredTrigger;
/*    */   
/*    */   public RoomItemEventQueueEntry(RoomItem item, RoomItemEventType type)
/*    */   {
/* 18 */     this.item = item;
/* 19 */     this.entity = null;
/*    */     
/* 21 */     this.type = type;
/*    */     
/* 23 */     this.requestData = -1;
/* 24 */     this.isWiredTrigger = false;
/*    */   }
/*    */   
/*    */   public RoomItemEventQueueEntry(RoomItem item, RoomEntity entity, RoomItemEventType type) {
/* 28 */     this.item = item;
/* 29 */     this.entity = entity;
/*    */     
/* 31 */     this.type = type;
/*    */     
/* 33 */     this.requestData = -1;
/* 34 */     this.isWiredTrigger = false;
/*    */   }
/*    */   
/*    */   public RoomItemEventQueueEntry(RoomItem item, RoomEntity entity, RoomItemEventType type, int requestData, boolean isWiredTrigger) {
/* 38 */     this.item = item;
/* 39 */     this.entity = entity;
/*    */     
/* 41 */     this.type = type;
/*    */     
/* 43 */     this.requestData = requestData;
/* 44 */     this.isWiredTrigger = isWiredTrigger;
/*    */   }
/*    */   
/*    */   public RoomItem getItem() {
/* 48 */     return this.item;
/*    */   }
/*    */   
/*    */   public RoomEntity getEntity() {
/* 52 */     return this.entity;
/*    */   }
/*    */   
/*    */   public RoomItemEventType getType() {
/* 56 */     return this.type;
/*    */   }
/*    */   
/*    */   public int getRequestData() {
/* 60 */     return this.requestData;
/*    */   }
/*    */   
/*    */   public boolean isWiredTrigger() {
/* 64 */     return this.isWiredTrigger;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\queue\RoomItemEventQueueEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */