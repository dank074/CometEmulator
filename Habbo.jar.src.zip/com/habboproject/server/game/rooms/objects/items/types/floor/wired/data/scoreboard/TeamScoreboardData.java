/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.entries.HighscoreTeamEntry;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard.types.HighscorePlayer;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TeamScoreboardData
/*    */ {
/*    */   private int scoreType;
/*    */   private int clearType;
/*    */   private final Map<Integer, List<HighscoreTeamEntry>> entries;
/*    */   
/*    */   public TeamScoreboardData(int scoreType, int clearType, Map<Integer, List<HighscoreTeamEntry>> entries)
/*    */   {
/* 20 */     this.scoreType = scoreType;
/* 21 */     this.clearType = clearType;
/* 22 */     this.entries = entries;
/*    */   }
/*    */   
/*    */   public Map<Integer, List<HighscoreTeamEntry>> getEntries() {
/* 26 */     return this.entries;
/*    */   }
/*    */   
/*    */   public void addEntry(List<HighscorePlayer> users, int teamScore) {
/* 30 */     Map<Integer, List<HighscoreTeamEntry>> map = this.entries;
/*    */     
/* 32 */     synchronized (map) {
/* 33 */       int index = this.entries.size();
/* 34 */       this.entries.put(Integer.valueOf(index), Lists.newArrayList());
/* 35 */       ((List)this.entries.get(Integer.valueOf(index))).add(new HighscoreTeamEntry(users, teamScore));
/*    */     }
/*    */   }
/*    */   
/*    */   public void updateEntry(int index, List<HighscorePlayer> users, int teamScore) {
/* 40 */     Map<Integer, List<HighscoreTeamEntry>> map = this.entries;
/*    */     
/* 42 */     synchronized (map) {
/* 43 */       for (HighscoreTeamEntry entry : (List)this.entries.get(Integer.valueOf(index))) {
/* 44 */         entry.setTeamScore(entry.getTeamScore() + teamScore);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void removeAll() {
/* 50 */     Map<Integer, List<HighscoreTeamEntry>> map = this.entries;
/* 51 */     synchronized (map) {
/* 52 */       this.entries.clear();
/*    */     }
/*    */   }
/*    */   
/*    */   public int getScoreType() {
/* 57 */     return this.scoreType;
/*    */   }
/*    */   
/*    */   public void setScoreType(int scoreType) {
/* 61 */     this.scoreType = scoreType;
/*    */   }
/*    */   
/*    */   public int getClearType() {
/* 65 */     return this.clearType;
/*    */   }
/*    */   
/*    */   public void setClearType(int clearType) {
/* 69 */     this.clearType = clearType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\data\scoreboard\TeamScoreboardData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */