/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.addons;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredAddonColourWheel extends RoomItemFloor
/*    */ {
/*    */   private static final int TIMEOUT = 4;
/*    */   
/*    */   public WiredAddonColourWheel(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, "0");
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 19 */     if ((!isWiredTrigger) && (entity != null) && 
/* 20 */       (!getPosition().touching(entity))) {
/* 21 */       entity.moveTo(getPosition().squareBehind(getRotation()).getX(), getPosition().squareBehind(this.rotation).getY());
/* 22 */       return true;
/*    */     }
/*    */     
/*    */ 
/* 26 */     setExtraData("9");
/* 27 */     sendUpdate();
/*    */     
/* 29 */     setTicks(com.habboproject.server.game.rooms.objects.items.RoomItemFactory.getProcessTime(2.0D));
/* 30 */     return true;
/*    */   }
/*    */   
/*    */   public void onTickComplete()
/*    */   {
/* 35 */     int randomInteger = com.habboproject.server.utilities.RandomInteger.getRandom(1, 8);
/*    */     
/* 37 */     setExtraData(randomInteger);
/* 38 */     sendUpdate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\addons\WiredAddonColourWheel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */