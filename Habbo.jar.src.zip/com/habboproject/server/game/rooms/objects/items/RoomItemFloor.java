/*     */ package com.habboproject.server.game.rooms.objects.items;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.rares.LimitedEditionItemData;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.AffectedTile;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.DefaultFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.adjustable.AdjustableHeightFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.adjustable.MagicStackFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.boutique.MannequinFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.jukebox.SoundMachineFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.RoomData;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomTile;
/*     */ import com.habboproject.server.network.messages.outgoing.room.items.UpdateFloorItemMessageComposer;
/*     */ import com.habboproject.server.storage.queries.rooms.RoomItemDao;
/*     */ import com.habboproject.server.utilities.attributes.Collidable;
/*     */ import com.habboproject.server.utilities.comparators.PositionComporator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public abstract class RoomItemFloor extends RoomItem implements Collidable
/*     */ {
/*     */   private String extraData;
/*     */   private ItemDefinition itemDefinition;
/*     */   private RoomEntity collidedEntity;
/*     */   private boolean hasQueuedSave;
/*     */   private int lastDirection;
/*     */   
/*     */   public RoomItemFloor(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  41 */     super(id, new Position(x, y, z), room);
/*     */     
/*  43 */     this.itemId = itemId;
/*  44 */     this.ownerId = (getRoom().getGroup() == null ? getRoom().getData().getOwnerId() : owner);
/*  45 */     this.ownerName = (getRoom().getGroup() == null ? getRoom().getData().getOwner() : com.habboproject.server.storage.queries.player.PlayerDao.getUsernameByPlayerId(this.ownerId));
/*  46 */     this.groupId = groupId;
/*  47 */     this.rotation = rotation;
/*  48 */     this.extraData = data;
/*  49 */     this.lastDirection = 0;
/*  50 */     this.needsUpdate = false;
/*     */   }
/*     */   
/*     */   public void serialize(IComposer msg, boolean isNew) {
/*  54 */     msg.writeInt(getVirtualId());
/*  55 */     msg.writeInt(getDefinition().getSpriteId());
/*  56 */     msg.writeInt(getPosition().getX());
/*  57 */     msg.writeInt(getPosition().getY());
/*  58 */     msg.writeInt(getRotation());
/*     */     
/*  60 */     msg.writeString(Double.valueOf((this instanceof MagicStackFloorItem) ? ((MagicStackFloorItem)this).getMagicHeight() : getPosition().getZ()));
/*  61 */     msg.writeString(Double.valueOf((this instanceof AdjustableHeightFloorItem) ? ((AdjustableHeightFloorItem)this).getCurrentHeight() : getDefinition().getHeight()));
/*     */     
/*  63 */     compose(msg, isNew);
/*     */     
/*  65 */     if (!(this instanceof MannequinFloorItem)) {
/*  66 */       msg.writeInt(-1);
/*  67 */       msg.writeInt((!(this instanceof DefaultFloorItem)) && (!(this instanceof SoundMachineFloorItem)) ? 1 : 0);
/*  68 */       msg.writeInt(this.ownerId);
/*     */       
/*  70 */       if (isNew) {
/*  71 */         msg.writeString(this.ownerName);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void serialize(IComposer msg)
/*     */   {
/*  78 */     serialize(msg, false);
/*     */   }
/*     */   
/*     */   public ItemDefinition getDefinition() {
/*  82 */     if (this.itemDefinition == null) {
/*  83 */       this.itemDefinition = ItemManager.getInstance().getDefinition(getItemId());
/*     */     }
/*     */     
/*  86 */     return this.itemDefinition;
/*     */   }
/*     */   
/*     */   public double getTotalHeight() {
/*  90 */     double startHeight = getPosition().getZ();
/*     */     
/*  92 */     if ((this instanceof AdjustableHeightFloorItem)) {
/*  93 */       return startHeight + ((AdjustableHeightFloorItem)this).getCurrentHeight();
/*     */     }
/*     */     
/*  96 */     if ((this instanceof MagicStackFloorItem)) {
/*  97 */       return ((MagicStackFloorItem)this).getMagicHeight();
/*     */     }
/*     */     
/* 100 */     return startHeight + getDefinition().getHeight();
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg, boolean isNew) {
/* 104 */     if (getDefinition().isAdFurni()) {
/* 105 */       msg.writeInt(0);
/* 106 */       msg.writeInt(1);
/* 107 */       if ((!this.extraData.equals("")) && (this.extraData.contains(String.valueOf('\t')))) {
/* 108 */         String[] adsData = this.extraData.split(String.valueOf('\t'));
/* 109 */         int count = adsData.length;
/* 110 */         msg.writeInt(count / 2);
/* 111 */         int i = 0;
/* 112 */         while (i <= count - 1) {
/* 113 */           msg.writeString(adsData[i]);
/* 114 */           i++;
/*     */         }
/*     */       } else {
/* 117 */         msg.writeInt(0);
/*     */       }
/* 119 */     } else if (getDefinition().getItemName().contains("yttv")) {
/* 120 */       msg.writeInt(0);
/* 121 */       msg.writeInt(1);
/* 122 */       msg.writeInt(1);
/* 123 */       msg.writeString("THUMBNAIL_URL");
/* 124 */       msg.writeString("/deliver/" + (hasAttribute("video") ? getAttribute("video") : "pv-MvYijLjs"));
/* 125 */     } else if (getLimitedEditionItemData() != null) {
/* 126 */       msg.writeInt(0);
/* 127 */       msg.writeString("");
/* 128 */       msg.writeBoolean(Boolean.valueOf(true));
/* 129 */       msg.writeBoolean(Boolean.valueOf(false));
/* 130 */       msg.writeString(getExtraData());
/* 131 */       msg.writeInt(getLimitedEditionItemData().getLimitedRare());
/* 132 */       msg.writeInt(getLimitedEditionItemData().getLimitedRareTotal());
/*     */     } else {
/* 134 */       msg.writeInt(1);
/* 135 */       msg.writeInt(0);
/* 136 */       msg.writeString((this instanceof SoundMachineFloorItem) ? "0" : ((SoundMachineFloorItem)this).getState() ? "1" : (this instanceof WiredFloorItem) ? "0" : (this instanceof com.habboproject.server.game.rooms.objects.items.types.floor.football.FootballGateFloorItem) ? "" : getExtraData());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void onItemAddedToStack(RoomItemFloor floorItem) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void onEntityPreStepOn(RoomEntity entity) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void onEntityStepOn(RoomEntity entity) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void onEntityStepOff(RoomEntity entity) {}
/*     */   
/*     */ 
/*     */   public void onEntityPostStepOn(RoomEntity entity) {}
/*     */   
/*     */ 
/*     */   public void onPositionChanged(Position newPosition) {}
/*     */   
/*     */ 
/*     */   public boolean isMovementCancelled(RoomEntity entity)
/*     */   {
/* 165 */     return false;
/*     */   }
/*     */   
/*     */   public boolean toggleInteract(boolean state)
/*     */   {
/* 170 */     if (!state) {
/* 171 */       if (!(this instanceof WiredFloorItem)) {
/* 172 */         setExtraData("0");
/*     */       }
/* 174 */       return true;
/*     */     }
/*     */     
/* 177 */     if (!StringUtils.isNumeric(getExtraData())) {
/* 178 */       return true;
/*     */     }
/*     */     
/* 181 */     if (getDefinition().getInteractionCycleCount() > 1) {
/* 182 */       if ((getExtraData().isEmpty()) || (getExtraData().equals(" "))) {
/* 183 */         setExtraData("0");
/*     */       }
/*     */       
/* 186 */       int i = Integer.parseInt(getExtraData()) + 1;
/*     */       
/* 188 */       if (i > getDefinition().getInteractionCycleCount() - 1) {
/* 189 */         setExtraData("0");
/*     */       } else {
/* 191 */         setExtraData(i);
/*     */       }
/*     */       
/* 194 */       return true;
/*     */     }
/* 196 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void save()
/*     */   {
/* 202 */     RoomItemDao.saveItem(this);
/*     */   }
/*     */   
/*     */   public void saveData()
/*     */   {
/* 207 */     RoomItemDao.saveData(getId(), getDataObject());
/*     */   }
/*     */   
/*     */   public void sendUpdate()
/*     */   {
/* 212 */     Room r = getRoom();
/*     */     
/* 214 */     if (r != null) {
/* 215 */       r.getEntities().broadcastMessage(new UpdateFloorItemMessageComposer(this));
/*     */     }
/*     */   }
/*     */   
/*     */   public List<RoomItemFloor> getItemsOnStack() {
/* 220 */     List<RoomItemFloor> floorItems = Lists.newArrayList();
/*     */     
/* 222 */     List<AffectedTile> affectedTiles = AffectedTile.getAffectedTilesAt(
/* 223 */       getDefinition().getLength(), getDefinition().getWidth(), getPosition().getX(), getPosition().getY(), getRotation());
/*     */     
/* 225 */     floorItems.addAll(getRoom().getItems().getItemsOnSquare(getPosition().getX(), getPosition().getY()));
/*     */     Iterator localIterator2;
/* 227 */     for (Iterator localIterator1 = affectedTiles.iterator(); localIterator1.hasNext(); 
/* 228 */         localIterator2.hasNext())
/*     */     {
/* 227 */       AffectedTile tile = (AffectedTile)localIterator1.next();
/* 228 */       localIterator2 = getRoom().getItems().getItemsOnSquare(tile.x, tile.y).iterator(); continue;RoomItemFloor floorItem = (RoomItemFloor)localIterator2.next();
/* 229 */       if (!floorItems.contains(floorItem)) { floorItems.add(floorItem);
/*     */       }
/*     */     }
/*     */     
/* 233 */     return floorItems;
/*     */   }
/*     */   
/*     */   public List<RoomEntity> getEntitiesOnItem() {
/* 237 */     List<RoomEntity> entities = Lists.newArrayList();
/*     */     
/* 239 */     entities.addAll(getRoom().getEntities().getEntitiesAt(getPosition()));
/*     */     
/* 241 */     for (AffectedTile affectedTile : AffectedTile.getAffectedTilesAt(getDefinition().getLength(), getDefinition().getWidth(), getPosition().getX(), getPosition().getY(), getRotation())) {
/* 242 */       List<RoomEntity> entitiesOnTile = getRoom().getEntities().getEntitiesAt(new Position(affectedTile.x, affectedTile.y));
/*     */       
/* 244 */       entities.addAll(entitiesOnTile);
/*     */     }
/*     */     
/* 247 */     return entities;
/*     */   }
/*     */   
/*     */   public Position getPartnerTile() {
/* 251 */     if (getDefinition().getLength() != 2) { return null;
/*     */     }
/* 253 */     for (AffectedTile affTile : AffectedTile.getAffectedBothTilesAt(getDefinition().getLength(), getDefinition().getWidth(), getPosition().getX(), getPosition().getY(), getRotation())) {
/* 254 */       if ((affTile.x != getPosition().getX()) || (affTile.y != getPosition().getY()))
/*     */       {
/* 256 */         return new Position(affTile.x, affTile.y);
/*     */       }
/*     */     }
/* 259 */     return null;
/*     */   }
/*     */   
/*     */   public PlayerEntity nearestPlayerEntity() {
/* 263 */     PositionComporator positionComporator = new PositionComporator(this);
/*     */     
/* 265 */     List<PlayerEntity> nearestEntities = getRoom().getEntities().getPlayerEntities();
/*     */     
/* 267 */     java.util.Collections.sort(nearestEntities, positionComporator);
/*     */     
/* 269 */     for (PlayerEntity playerEntity : nearestEntities) {
/* 270 */       if (playerEntity.getTile().isReachable(this)) {
/* 271 */         return playerEntity;
/*     */       }
/*     */     }
/*     */     
/* 275 */     return null;
/*     */   }
/*     */   
/*     */   public RoomEntity getCollision() {
/* 279 */     return this.collidedEntity;
/*     */   }
/*     */   
/*     */   public void setCollision(RoomEntity entity) {
/* 283 */     this.collidedEntity = entity;
/*     */   }
/*     */   
/*     */   public void nullifyCollision() {
/* 287 */     this.collidedEntity = null;
/*     */   }
/*     */   
/*     */   public double getOverrideHeight() {
/* 291 */     return -1.0D;
/*     */   }
/*     */   
/*     */   public String getDataObject() {
/* 295 */     return this.extraData;
/*     */   }
/*     */   
/*     */   public String getExtraData() {
/* 299 */     return this.extraData;
/*     */   }
/*     */   
/*     */   public void setRotation(int rot) {
/* 303 */     this.rotation = rot;
/*     */   }
/*     */   
/*     */   public void setExtraData(String data) {
/* 307 */     this.extraData = data;
/*     */     
/* 309 */     if (!this.needsUpdate) {
/* 310 */       this.needsUpdate = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasQueuedSave() {
/* 315 */     return this.hasQueuedSave;
/*     */   }
/*     */   
/*     */   public void setHasQueuedSave(boolean hasQueuedSave) {
/* 319 */     this.hasQueuedSave = hasQueuedSave;
/*     */   }
/*     */   
/*     */   public int getLastDirection() {
/* 323 */     return this.lastDirection;
/*     */   }
/*     */   
/*     */   public void setLastDirection(int lastDirection) {
/* 327 */     this.lastDirection = lastDirection;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\RoomItemFloor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */