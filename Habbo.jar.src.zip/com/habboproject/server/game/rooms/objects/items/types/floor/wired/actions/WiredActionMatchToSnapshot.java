/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.others.DiceFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredItemSnapshot;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.highscore.HighscoreClassicFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.network.messages.outgoing.room.items.SlideObjectBundleMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.items.UpdateFloorItemMessageComposer;
/*     */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class WiredActionMatchToSnapshot extends WiredActionItem
/*     */ {
/*     */   private static final int PARAM_MATCH_STATE = 0;
/*     */   private static final int PARAM_MATCH_ROTATION = 1;
/*     */   private static final int PARAM_MATCH_POSITION = 2;
/*     */   
/*     */   public WiredActionMatchToSnapshot(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  29 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public boolean requiresPlayer()
/*     */   {
/*  34 */     return false;
/*     */   }
/*     */   
/*     */   public int getInterface()
/*     */   {
/*  39 */     return 3;
/*     */   }
/*     */   
/*     */   public void onEventComplete(WiredItemExecuteEvent event)
/*     */   {
/*  44 */     if (getWiredData().getSnapshots().size() == 0) {
/*  45 */       return;
/*     */     }
/*     */     
/*  48 */     boolean matchState = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue() == 1;
/*  49 */     boolean matchRotation = ((Integer)getWiredData().getParams().get(Integer.valueOf(1))).intValue() == 1;
/*  50 */     boolean matchPosition = ((Integer)getWiredData().getParams().get(Integer.valueOf(2))).intValue() == 1;
/*     */     
/*  52 */     List<Long> toRemove = Lists.newArrayList();
/*  53 */     for (Iterator iterator = getWiredData().getSelectedIds().iterator(); iterator.hasNext();) {
/*  54 */       long itemId = ((Long)iterator.next()).longValue();
/*     */       
/*  56 */       RoomItemFloor floorItem = getRoom().getItems().getFloorItem(itemId);
/*     */       
/*  58 */       if (floorItem == null) {
/*  59 */         toRemove.add(Long.valueOf(itemId));
/*     */       } else {
/*  61 */         boolean rotationChanged = false;
/*     */         
/*  63 */         WiredItemSnapshot itemSnapshot = (WiredItemSnapshot)getWiredData().getSnapshots().get(Long.valueOf(itemId));
/*  64 */         if (itemSnapshot != null)
/*     */         {
/*  66 */           if ((matchState) && (!(floorItem instanceof DiceFloorItem)) && (!(floorItem instanceof HighscoreClassicFloorItem))) {
/*  67 */             floorItem.setExtraData(itemSnapshot.getExtraData());
/*  68 */             floorItem.saveData();
/*     */           }
/*     */           
/*  71 */           if ((matchPosition) || (matchRotation)) {
/*  72 */             Position currentPosition = floorItem.getPosition().copy();
/*     */             
/*  74 */             Position newPosition = new Position(itemSnapshot.getX(), itemSnapshot.getY(), itemSnapshot.getZ());
/*     */             
/*  76 */             int currentRotation = floorItem.getRotation();
/*     */             
/*  78 */             if (getRoom().getItems().moveFloorItem(floorItem.getId(), !matchPosition ? currentPosition : newPosition, matchRotation ? itemSnapshot.getRotation() : floorItem.getRotation(), true, false)) {
/*  79 */               if (currentRotation != floorItem.getRotation()) {
/*  80 */                 rotationChanged = true;
/*     */               }
/*     */               
/*  83 */               if ((!matchRotation) || ((!rotationChanged) && (!matchState))) {
/*  84 */                 getRoom().getEntities().broadcastMessage(new SlideObjectBundleMessageComposer(currentPosition, newPosition, 0, getVirtualId(), floorItem.getVirtualId()));
/*     */               }
/*     */             }
/*     */           }
/*     */           
/*  89 */           if ((matchRotation) && (rotationChanged)) {
/*  90 */             getRoom().getEntities().broadcastMessage(new UpdateFloorItemMessageComposer(floorItem));
/*     */           }
/*  92 */           floorItem.save();
/*     */           
/*  94 */           if (matchState) {
/*  95 */             floorItem.sendUpdate();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 100 */     if (toRemove.size() > 0) {
/* 101 */       for (Iterator localIterator1 = toRemove.iterator(); localIterator1.hasNext();) { long itemId = ((Long)localIterator1.next()).longValue();
/* 102 */         getWiredData().getSelectedIds().remove(Long.valueOf(itemId));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionMatchToSnapshot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */