package com.habboproject.server.game.rooms.objects.items;

public enum RoomItemType
{
  FLOOR,  WALL;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\RoomItemType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */