/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionHasHandItem
/*    */   extends WiredConditionItem
/*    */ {
/*    */   private static final int PARAM_HANDITEM = 0;
/*    */   
/*    */   public WiredConditionHasHandItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 28 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 33 */     return 25;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 38 */     if ((entity == null) || (!(entity instanceof PlayerEntity))) { return false;
/*    */     }
/* 40 */     if (getWiredData().getParams().size() != 1) {
/* 41 */       return false;
/*    */     }
/*    */     
/* 44 */     int handItem = ((Integer)getWiredData().getParams().get(Integer.valueOf(0))).intValue();
/*    */     
/* 46 */     if (entity.getHandItem() == handItem) {
/* 47 */       if (this.isNegative) {
/* 48 */         return false;
/*    */       }
/*    */     }
/* 51 */     else if (!this.isNegative) {
/* 52 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 56 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionHasHandItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */