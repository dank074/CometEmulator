/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.others;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomMapping;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class WaterFloorItem
/*     */   extends RoomItemFloor
/*     */ {
/*  14 */   private boolean posA = false;
/*  15 */   private boolean posB = false;
/*  16 */   private boolean posC = false;
/*  17 */   private boolean posD = false;
/*  18 */   private boolean posE = false;
/*  19 */   private boolean posF = false;
/*  20 */   private boolean posG = false;
/*  21 */   private boolean posH = false;
/*  22 */   private boolean posI = false;
/*  23 */   private boolean posJ = false;
/*  24 */   private boolean posK = false;
/*  25 */   private boolean posL = false;
/*     */   
/*     */   public WaterFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  28 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */   }
/*     */   
/*     */   public void refresh() {
/*  32 */     for (RoomItemFloor floorItem : getRoom().getItems().getByClass(WaterFloorItem.class)) {
/*  33 */       ((WaterFloorItem)floorItem).calculateExtraData();
/*     */     }
/*     */   }
/*     */   
/*     */   public void calculateExtraData() {
/*  38 */     int extraData = 0;
/*     */     
/*  40 */     Map<Integer, List<Integer>> tiles = getRoom().getItems().getWaterTiles();
/*     */     
/*  42 */     if (checkPosition(tiles, -1, -1)) {
/*  43 */       extraData += getValue(1);
/*     */     }
/*     */     
/*  46 */     if (checkPosition(tiles, 0, -1)) {
/*  47 */       extraData += getValue(2);
/*     */     }
/*     */     
/*  50 */     if (checkPosition(tiles, 1, -1)) {
/*  51 */       extraData += getValue(3);
/*     */     }
/*     */     
/*  54 */     if (checkPosition(tiles, 2, -1)) {
/*  55 */       extraData += getValue(4);
/*     */     }
/*     */     
/*  58 */     if (checkPosition(tiles, -1, 0)) {
/*  59 */       extraData += getValue(5);
/*     */     }
/*     */     
/*  62 */     if (checkPosition(tiles, 2, 0)) {
/*  63 */       extraData += getValue(6);
/*     */     }
/*     */     
/*  66 */     if (checkPosition(tiles, -1, 1)) {
/*  67 */       extraData += getValue(7);
/*     */     }
/*     */     
/*  70 */     if (checkPosition(tiles, 2, 1)) {
/*  71 */       extraData += getValue(8);
/*     */     }
/*     */     
/*  74 */     if (checkPosition(tiles, -1, 2)) {
/*  75 */       extraData += getValue(9);
/*     */     }
/*     */     
/*  78 */     if (checkPosition(tiles, 0, 2)) {
/*  79 */       extraData += getValue(10);
/*     */     }
/*     */     
/*  82 */     if (checkPosition(tiles, 1, 2)) {
/*  83 */       extraData += getValue(11);
/*     */     }
/*     */     
/*  86 */     if (checkPosition(tiles, 2, 2)) {
/*  87 */       extraData += getValue(12);
/*     */     }
/*     */     
/*  90 */     if ((!this.posB) && (checkTileBlocked(0, -1))) {
/*  91 */       extraData += getValue(2);
/*     */     }
/*     */     
/*  94 */     if ((!this.posC) && (checkTileBlocked(1, -1))) {
/*  95 */       extraData += getValue(3);
/*     */     }
/*     */     
/*  98 */     if ((!this.posE) && (checkTileBlocked(-1, 0))) {
/*  99 */       extraData += getValue(5);
/*     */     }
/*     */     
/* 102 */     if ((!this.posF) && (checkTileBlocked(2, 0))) {
/* 103 */       extraData += getValue(6);
/*     */     }
/*     */     
/* 106 */     if ((!this.posG) && (checkTileBlocked(-1, 1))) {
/* 107 */       extraData += getValue(7);
/*     */     }
/*     */     
/* 110 */     if ((!this.posH) && (checkTileBlocked(2, 1))) {
/* 111 */       extraData += getValue(8);
/*     */     }
/*     */     
/* 114 */     if ((!this.posJ) && (checkTileBlocked(0, 2))) {
/* 115 */       extraData += getValue(10);
/*     */     }
/*     */     
/* 118 */     if ((!this.posK) && (checkTileBlocked(1, 2))) {
/* 119 */       extraData += getValue(11);
/*     */     }
/*     */     
/* 122 */     setExtraData(extraData);
/* 123 */     sendUpdate();
/*     */     
/* 125 */     save();
/*     */     
/* 127 */     reset();
/*     */   }
/*     */   
/*     */   private boolean checkPosition(Map<Integer, List<Integer>> tiles, int diffX, int diffY) {
/* 131 */     return (tiles.containsKey(Integer.valueOf(getPosition().getX() + diffX))) && (((List)tiles.get(Integer.valueOf(getPosition().getX() + diffX))).contains(Integer.valueOf(getPosition().getY() + diffY)));
/*     */   }
/*     */   
/*     */   private boolean checkTileBlocked(int diffX, int diffY) {
/* 135 */     return !getRoom().getMapping().isValidPosition(new Position(getPosition().getX() + diffX, getPosition().getY() + diffY));
/*     */   }
/*     */   
/*     */   private int getValue(int pos) {
/* 139 */     int value = 0;
/* 140 */     switch (pos) {
/*     */     case 1: 
/* 142 */       if (!this.posA) {
/* 143 */         value = 2048;
/* 144 */         this.posA = true;
/*     */       }
/* 146 */       break;
/*     */     
/*     */     case 2: 
/* 149 */       if (!this.posB) {
/* 150 */         value = 1024;
/* 151 */         this.posB = true;
/*     */       }
/* 153 */       break;
/*     */     
/*     */     case 3: 
/* 156 */       if (!this.posC) {
/* 157 */         value = 512;
/* 158 */         this.posC = true;
/*     */       }
/* 160 */       break;
/*     */     
/*     */     case 4: 
/* 163 */       if (!this.posD) {
/* 164 */         value = 256;
/* 165 */         this.posD = true;
/*     */       }
/* 167 */       break;
/*     */     
/*     */     case 5: 
/* 170 */       if (!this.posE) {
/* 171 */         value = 128;
/* 172 */         this.posE = true;
/*     */       }
/* 174 */       break;
/*     */     
/*     */     case 6: 
/* 177 */       if (!this.posF) {
/* 178 */         value = 64;
/* 179 */         this.posF = true;
/*     */       }
/* 181 */       break;
/*     */     
/*     */     case 7: 
/* 184 */       if (!this.posG) {
/* 185 */         value = 32;
/* 186 */         this.posG = true;
/*     */       }
/* 188 */       break;
/*     */     
/*     */     case 8: 
/* 191 */       if (!this.posH) {
/* 192 */         value = 16;
/* 193 */         this.posH = true;
/*     */       }
/* 195 */       break;
/*     */     
/*     */     case 9: 
/* 198 */       if (!this.posI) {
/* 199 */         value = 8;
/* 200 */         this.posI = true;
/*     */       }
/* 202 */       break;
/*     */     
/*     */     case 10: 
/* 205 */       if (!this.posJ) {
/* 206 */         value = 4;
/* 207 */         this.posJ = true;
/*     */       }
/* 209 */       break;
/*     */     
/*     */     case 11: 
/* 212 */       if (!this.posK) {
/* 213 */         value = 2;
/* 214 */         this.posK = true;
/*     */       }
/* 216 */       break;
/*     */     
/*     */     case 12: 
/* 219 */       if (!this.posL) {
/* 220 */         value = 1;
/* 221 */         this.posL = true;
/*     */       }
/* 223 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/* 229 */     return value;
/*     */   }
/*     */   
/*     */   private void reset() {
/* 233 */     this.posA = false;
/* 234 */     this.posB = false;
/* 235 */     this.posC = false;
/* 236 */     this.posD = false;
/* 237 */     this.posE = false;
/* 238 */     this.posF = false;
/* 239 */     this.posG = false;
/* 240 */     this.posH = false;
/* 241 */     this.posI = false;
/* 242 */     this.posJ = false;
/* 243 */     this.posK = false;
/* 244 */     this.posL = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\others\WaterFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */