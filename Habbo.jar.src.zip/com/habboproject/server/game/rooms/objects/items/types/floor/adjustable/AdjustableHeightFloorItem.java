/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.adjustable;
/*    */ 
/*    */ import com.habboproject.server.game.items.types.ItemDefinition;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntityStatus;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class AdjustableHeightFloorItem extends RoomItemFloor
/*    */ {
/*    */   public AdjustableHeightFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 15 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 20 */     if (!isWiredTrigger) {
/* 21 */       if (!(entity instanceof PlayerEntity)) {
/* 22 */         return false;
/*    */       }
/*    */       
/* 25 */       PlayerEntity pEntity = (PlayerEntity)entity;
/* 26 */       if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/* 27 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 31 */     for (RoomItemFloor floorItem : getItemsOnStack()) {
/* 32 */       if ((floorItem.getId() != getId()) && (floorItem.getPosition().getZ() >= getPosition().getZ()))
/*    */       {
/*    */ 
/* 35 */         return false;
/*    */       }
/*    */     }
/* 38 */     toggleInteract(true);
/*    */     
/* 40 */     sendUpdate();
/*    */     
/* 42 */     for (RoomEntity entityOnItem : getEntitiesOnItem()) {
/* 43 */       if (entityOnItem.hasStatus(RoomEntityStatus.SIT)) {
/* 44 */         entityOnItem.removeStatus(RoomEntityStatus.SIT);
/*    */       }
/*    */       
/* 47 */       entityOnItem.setPosition(new Position(entityOnItem.getPosition().getX(), entityOnItem.getPosition().getY(), getTotalHeight()));
/*    */       
/* 49 */       getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.AvatarUpdateMessageComposer(entityOnItem));
/*    */     }
/*    */     
/* 52 */     saveData();
/*    */     
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   public double getCurrentHeight() {
/* 58 */     if ((!getExtraData().isEmpty()) && (getExtraData().equals("0"))) {
/* 59 */       return getDefinition().getHeight();
/*    */     }
/*    */     
/* 62 */     if ((getDefinition().getVariableHeights() != null) && (!getExtraData().isEmpty())) {
/* 63 */       if (!org.apache.commons.lang.StringUtils.isNumeric(getExtraData())) {
/* 64 */         return 0.0D;
/*    */       }
/*    */       
/* 67 */       int heightIndex = Integer.parseInt(getExtraData());
/* 68 */       if (heightIndex >= getDefinition().getVariableHeights().length) {
/* 69 */         return 0.0D;
/*    */       }
/*    */       
/* 72 */       return getDefinition().getVariableHeights()[heightIndex].doubleValue();
/*    */     }
/*    */     
/* 75 */     if ((getDefinition().getVariableHeights() != null) && (getDefinition().getVariableHeights().length != 0)) {
/* 76 */       return getDefinition().getVariableHeights()[0].doubleValue();
/*    */     }
/*    */     
/* 79 */     if ((getExtraData().isEmpty()) || (!org.apache.commons.lang.StringUtils.isNumeric(getExtraData()))) {
/* 80 */       return getDefinition().getHeight();
/*    */     }
/*    */     
/* 83 */     return getDefinition().getHeight();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\adjustable\AdjustableHeightFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */