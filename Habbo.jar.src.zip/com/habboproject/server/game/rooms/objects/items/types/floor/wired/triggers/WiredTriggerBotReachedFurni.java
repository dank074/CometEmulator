/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class WiredTriggerBotReachedFurni extends WiredTriggerItem
/*    */ {
/*    */   public WiredTriggerBotReachedFurni(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 13 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 18 */     return false;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 23 */     return 13;
/*    */   }
/*    */   
/*    */   public static boolean executeTriggers(BotEntity botEntity, RoomItemFloor floorItem) {
/* 27 */     boolean wasExecuted = false;
/* 28 */     for (RoomItemFloor wiredItem : botEntity.getRoom().getItems().getByClass(WiredTriggerBotReachedFurni.class)) {
/* 29 */       WiredTriggerBotReachedFurni trigger = (WiredTriggerBotReachedFurni)wiredItem;
/*    */       
/* 31 */       if (!trigger.getWiredData().getText().isEmpty())
/*    */       {
/*    */ 
/* 34 */         String botName = trigger.getWiredData().getText();
/* 35 */         if ((botEntity != null) && (botEntity.getUsername().equals(botName)) && (floorItem != null))
/*    */         {
/*    */ 
/* 38 */           wasExecuted = trigger.evaluate(botEntity, floorItem); }
/*    */       }
/*    */     }
/* 41 */     return wasExecuted;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerBotReachedFurni.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */