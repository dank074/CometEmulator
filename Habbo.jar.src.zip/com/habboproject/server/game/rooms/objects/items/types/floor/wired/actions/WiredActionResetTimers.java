/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerAtGivenTime;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerAtGivenTimeLong;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.List;
/*    */ 
/*    */ public class WiredActionResetTimers
/*    */   extends WiredActionItem
/*    */ {
/*    */   public WiredActionResetTimers(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 16 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 21 */     return false;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 26 */     return 1;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 31 */     List<WiredTriggerAtGivenTime> items = getRoom().getItems().getByClass(WiredTriggerAtGivenTime.class);
/*    */     
/* 33 */     items.addAll(getRoom().getItems().getByClass(WiredTriggerAtGivenTimeLong.class));
/*    */     
/* 35 */     for (WiredTriggerAtGivenTime floorItem : items) {
/* 36 */       floorItem.setNeedsReset(false);
/*    */     }
/*    */     
/* 39 */     getRoom().resetWiredTimer();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionResetTimers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */