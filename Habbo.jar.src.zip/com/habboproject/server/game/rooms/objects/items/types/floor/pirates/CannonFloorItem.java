/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.pirates;
/*    */ 
/*    */ import com.habboproject.server.game.permissions.types.Rank;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.mapping.RoomMapping;
/*    */ import com.habboproject.server.network.sessions.Session;
/*    */ import java.util.List;
/*    */ 
/*    */ public class CannonFloorItem extends RoomItemFloor
/*    */ {
/* 18 */   private List<PlayerEntity> entitiesToKick = com.google.common.collect.Lists.newArrayList();
/*    */   
/*    */   public CannonFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/* 21 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 26 */     if (!isWiredTrigger) {
/* 27 */       double distance = entity.getPosition().distanceTo(getPosition());
/*    */       
/* 29 */       if (distance > 2.0D) {
/* 30 */         entity.moveTo(getPosition().squareInFront(getRotation()));
/* 31 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 35 */     Position kickTile = null;
/* 36 */     int rotationToFindTile = 6;
/*    */     
/* 38 */     switch (this.rotation) {
/*    */     case 2: 
/* 40 */       rotationToFindTile = 0;
/* 41 */       break;
/*    */     
/*    */ 
/*    */     case 4: 
/* 45 */       rotationToFindTile = 2;
/* 46 */       kickTile = getPosition().squareInFront(rotationToFindTile).squareInFront(rotationToFindTile);
/* 47 */       break;
/*    */     
/*    */ 
/*    */     case 6: 
/* 51 */       rotationToFindTile = 4;
/* 52 */       kickTile = getPosition().squareInFront(rotationToFindTile).squareInFront(rotationToFindTile);
/*    */     }
/*    */     
/*    */     
/*    */ 
/*    */ 
/* 58 */     if (kickTile == null) {
/* 59 */       kickTile = getPosition().squareInFront(rotationToFindTile);
/*    */     }
/*    */     
/* 62 */     for (RoomEntity kickableEntity : getRoom().getMapping().getTile(kickTile).getEntities()) {
/* 63 */       if ((kickableEntity instanceof PlayerEntity)) {
/* 64 */         if ((((PlayerEntity)kickableEntity).getPlayerId() != getRoom().getData().getOwnerId()) && (((PlayerEntity)kickableEntity).getPlayer().getPermissions().getRank().roomKickable())) {
/* 65 */           ((PlayerEntity)kickableEntity).getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer("Alert", com.habboproject.server.config.Locale.getOrDefault("game.kicked", "You've been kicked!"), "room_kick_cannonball"));
/* 66 */           this.entitiesToKick.add((PlayerEntity)kickableEntity);
/*    */         }
/*    */         
/* 69 */         kickableEntity.applyEffect(new PlayerEffect(4, 5));
/*    */       }
/*    */     }
/*    */     
/* 73 */     setExtraData("1");
/* 74 */     sendUpdate();
/*    */     
/* 76 */     setTicks(RoomItemFactory.getProcessTime(1.5D));
/* 77 */     return true;
/*    */   }
/*    */   
/*    */   public void onTickComplete()
/*    */   {
/* 82 */     for (PlayerEntity entity : this.entitiesToKick) {
/* 83 */       entity.kick();
/*    */     }
/*    */     
/* 86 */     this.entitiesToKick.clear();
/*    */     
/* 88 */     setExtraData("0");
/* 89 */     sendUpdate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\pirates\CannonFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */