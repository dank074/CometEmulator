/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.scoreboard;
/*    */ 
/*    */ import com.habboproject.server.utilities.JsonData;
/*    */ 
/*    */ public class ResetItemData
/*    */   implements JsonData
/*    */ {
/*    */   private int lastDay;
/*    */   private int lastDayOfYear;
/*    */   private int lastMonth;
/*    */   private int lastDayOfWeek;
/*    */   private int lastWeekOfWeekyear;
/*    */   
/*    */   public ResetItemData(int lastDay, int lastDayOfYear, int lastMonth, int lastDayOfWeek, int lastWeekOfWeekyear)
/*    */   {
/* 16 */     this.lastDay = lastDay;
/* 17 */     this.lastDayOfYear = lastDayOfYear;
/* 18 */     this.lastMonth = lastMonth;
/* 19 */     this.lastDayOfWeek = lastDayOfWeek;
/* 20 */     this.lastWeekOfWeekyear = lastWeekOfWeekyear;
/*    */   }
/*    */   
/*    */   public int getLastDay() {
/* 24 */     return this.lastDay;
/*    */   }
/*    */   
/*    */   public void setLastDay(int lastDay) {
/* 28 */     this.lastDay = lastDay;
/*    */   }
/*    */   
/*    */   public int getLastMonth() {
/* 32 */     return this.lastMonth;
/*    */   }
/*    */   
/*    */   public void setLastMonth(int lastMonth) {
/* 36 */     this.lastMonth = lastMonth;
/*    */   }
/*    */   
/*    */   public int getLastWeekOfWeekyear() {
/* 40 */     return this.lastWeekOfWeekyear;
/*    */   }
/*    */   
/*    */   public void setLastWeekOfWeekyear(int lastWeekOfWeekyear) {
/* 44 */     this.lastWeekOfWeekyear = lastWeekOfWeekyear;
/*    */   }
/*    */   
/*    */   public int getLastDayOfYear() {
/* 48 */     return this.lastDayOfYear;
/*    */   }
/*    */   
/*    */   public void setLastDayOfYear(int lastDayOfYear) {
/* 52 */     this.lastDayOfYear = lastDayOfYear;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\data\scoreboard\ResetItemData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */