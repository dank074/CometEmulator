/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.groups;
/*    */ 
/*    */ import com.habboproject.server.api.networking.messages.IComposer;
/*    */ import com.habboproject.server.game.groups.GroupManager;
/*    */ import com.habboproject.server.game.groups.items.GroupItemManager;
/*    */ import com.habboproject.server.game.groups.types.GroupData;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntityStatus;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class GroupFloorItem extends com.habboproject.server.game.rooms.objects.items.RoomItemFloor
/*    */ {
/*    */   public GroupFloorItem(long id, int itemId, com.habboproject.server.game.rooms.types.Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 15 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public void compose(IComposer msg, boolean isNew)
/*    */   {
/* 20 */     GroupData groupData = GroupManager.getInstance().getData(getGroupId());
/*    */     
/* 22 */     if (groupData == null) {
/* 23 */       msg.writeInt(0);
/* 24 */       msg.writeInt(2);
/* 25 */       msg.writeInt(0);
/*    */     } else {
/* 27 */       msg.writeInt(0);
/* 28 */       msg.writeInt(2);
/* 29 */       msg.writeInt(5);
/*    */       
/* 31 */       msg.writeString(getExtraData());
/* 32 */       msg.writeString(Integer.valueOf(getGroupId()));
/* 33 */       msg.writeString(groupData.getBadge());
/*    */       
/* 35 */       String colourA = GroupManager.getInstance().getGroupItems().getSymbolColours().get(Integer.valueOf(groupData.getColourA())) != null ? ((com.habboproject.server.game.groups.items.types.GroupSymbolColour)GroupManager.getInstance().getGroupItems().getSymbolColours().get(Integer.valueOf(groupData.getColourA()))).getColour() : "ffffff";
/* 36 */       String colourB = GroupManager.getInstance().getGroupItems().getBackgroundColours().get(Integer.valueOf(groupData.getColourB())) != null ? ((com.habboproject.server.game.groups.items.types.GroupBackgroundColour)GroupManager.getInstance().getGroupItems().getBackgroundColours().get(Integer.valueOf(groupData.getColourB()))).getColour() : "ffffff";
/*    */       
/* 38 */       msg.writeString(colourA);
/* 39 */       msg.writeString(colourB);
/*    */     }
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity, boolean instantUpdate) {
/* 44 */     if (!getDefinition().canSit()) {
/* 45 */       return;
/*    */     }
/*    */     
/* 48 */     double height = ((entity instanceof com.habboproject.server.game.rooms.objects.entities.types.PetEntity)) || (entity.hasAttribute("transformation")) ? getSitHeight() / 2.0D : getSitHeight();
/*    */     
/* 50 */     entity.setBodyRotation(getRotation());
/* 51 */     entity.setHeadRotation(getRotation());
/*    */     
/* 53 */     entity.addStatus(RoomEntityStatus.SIT, String.valueOf(height).replace(',', '.'));
/*    */     
/* 55 */     if (instantUpdate) {
/* 56 */       getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.AvatarUpdateMessageComposer(entity));
/*    */     } else {
/* 58 */       entity.markNeedsUpdate();
/*    */     }
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 64 */     onEntityStepOn(entity, false);
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 69 */     if (entity.hasStatus(RoomEntityStatus.SIT)) {
/* 70 */       entity.removeStatus(RoomEntityStatus.SIT);
/*    */     }
/*    */     
/* 73 */     entity.markNeedsUpdate();
/*    */   }
/*    */   
/*    */   public double getSitHeight() {
/* 77 */     return getDefinition().getHeight();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\groups\GroupFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */