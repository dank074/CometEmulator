/*    */ package com.habboproject.server.game.rooms.objects.items.types.wall;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemWall;
/*    */ import com.habboproject.server.game.rooms.objects.items.data.MoodlightData;
/*    */ import com.habboproject.server.game.rooms.objects.items.data.MoodlightPresetData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import java.util.List;
/*    */ 
/*    */ public class MoodlightWallItem extends RoomItemWall
/*    */ {
/* 12 */   private MoodlightData moodlightData = null;
/*    */   
/*    */   public MoodlightWallItem(long id, int itemId, Room room, int owner, String position, String data) {
/* 15 */     super(id, itemId, room, owner, position, data);
/*    */   }
/*    */   
/*    */   public boolean onInteract(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity, int requestData, boolean isWiredTrigger)
/*    */   {
/* 20 */     return true;
/*    */   }
/*    */   
/*    */   public void onLoad()
/*    */   {
/* 25 */     onPlaced();
/*    */   }
/*    */   
/*    */   public void onPlaced()
/*    */   {
/* 30 */     if (getRoom().getItems().setMoodlight(getId())) {
/* 31 */       this.moodlightData = com.habboproject.server.storage.queries.items.MoodlightDao.getMoodlightData(getId());
/*    */     }
/*    */   }
/*    */   
/*    */   public void onUnload()
/*    */   {
/* 37 */     onPickup();
/*    */   }
/*    */   
/*    */   public void onPickup()
/*    */   {
/* 42 */     if (getRoom().getItems().isMoodlightMatches(this)) {
/* 43 */       getRoom().getItems().removeMoodlight();
/*    */     }
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public static boolean isValidColour(String colour)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: dup
/*    */     //   2: astore_1
/*    */     //   3: invokevirtual 81	java/lang/String:hashCode	()I
/*    */     //   6: lookupswitch	default:+152->158, -1877103645:+66->72, -1876951118:+78->84, -1672344610:+90->96, -1645564977:+102->108, -1269268582:+114->120, -1260067553:+126->132, -1244752035:+138->144
/*    */     //   72: aload_1
/*    */     //   73: ldc 87
/*    */     //   75: invokevirtual 89	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   78: ifne +78 -> 156
/*    */     //   81: goto +77 -> 158
/*    */     //   84: aload_1
/*    */     //   85: ldc 93
/*    */     //   87: invokevirtual 89	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   90: ifne +66 -> 156
/*    */     //   93: goto +65 -> 158
/*    */     //   96: aload_1
/*    */     //   97: ldc 95
/*    */     //   99: invokevirtual 89	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   102: ifne +54 -> 156
/*    */     //   105: goto +53 -> 158
/*    */     //   108: aload_1
/*    */     //   109: ldc 97
/*    */     //   111: invokevirtual 89	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   114: ifne +42 -> 156
/*    */     //   117: goto +41 -> 158
/*    */     //   120: aload_1
/*    */     //   121: ldc 99
/*    */     //   123: invokevirtual 89	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   126: ifne +30 -> 156
/*    */     //   129: goto +29 -> 158
/*    */     //   132: aload_1
/*    */     //   133: ldc 101
/*    */     //   135: invokevirtual 89	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   138: ifne +18 -> 156
/*    */     //   141: goto +17 -> 158
/*    */     //   144: aload_1
/*    */     //   145: ldc 103
/*    */     //   147: invokevirtual 89	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   150: ifne +6 -> 156
/*    */     //   153: goto +5 -> 158
/*    */     //   156: iconst_1
/*    */     //   157: ireturn
/*    */     //   158: iconst_0
/*    */     //   159: ireturn
/*    */     // Line number table:
/*    */     //   Java source line #48	-> byte code offset #0
/*    */     //   Java source line #56	-> byte code offset #156
/*    */     //   Java source line #59	-> byte code offset #158
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	160	0	colour	String
/*    */     //   2	143	1	str	String
/*    */   }
/*    */   
/*    */   public String generateExtraData()
/*    */   {
/* 64 */     MoodlightPresetData preset = getMoodlightData().getPresets().size() >= getMoodlightData().getActivePreset() ? 
/* 65 */       (MoodlightPresetData)getMoodlightData().getPresets().get(getMoodlightData().getActivePreset() - 1) : 
/* 66 */       new MoodlightPresetData(true, "#000000", 255);
/*    */     
/* 68 */     StringBuilder sb = new StringBuilder();
/* 69 */     if (getMoodlightData().isEnabled()) {
/* 70 */       sb.append(2);
/*    */     } else {
/* 72 */       sb.append(1);
/*    */     }
/*    */     
/* 75 */     sb.append(",");
/* 76 */     sb.append(getMoodlightData().getActivePreset());
/* 77 */     sb.append(",");
/*    */     
/* 79 */     if (preset.backgroundOnly) {
/* 80 */       sb.append(2);
/*    */     } else {
/* 82 */       sb.append(1);
/*    */     }
/*    */     
/* 85 */     sb.append(",");
/* 86 */     sb.append(preset.colour);
/* 87 */     sb.append(",");
/* 88 */     sb.append(preset.intensity);
/* 89 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public MoodlightData getMoodlightData() {
/* 93 */     return this.moodlightData;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\wall\MoodlightWallItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */