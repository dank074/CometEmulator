/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.totem;
/*     */ 
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.players.types.PlayerStatistics;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import org.joda.time.DateTime;
/*     */ 
/*     */ public abstract class TotemPartFloorItem extends RoomItemFloor
/*     */ {
/*     */   public TotemPartFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*     */   {
/*  15 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     
/*  17 */     if (!org.apache.commons.lang.StringUtils.isNumeric(getExtraData())) {
/*  18 */       setExtraData("0");
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onInteract(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity, int requestData, boolean isWiredTrigger)
/*     */   {
/*  24 */     if ((entity == null) || (!(entity instanceof PlayerEntity)) || (isWiredTrigger)) {
/*  25 */       return false;
/*     */     }
/*     */     
/*  28 */     PlayerEntity pEntity = (PlayerEntity)entity;
/*  29 */     if ((!pEntity.getRoom().getRights().hasRights(pEntity.getPlayerId())) && (!pEntity.getPlayer().getPermissions().getRank().roomFullControl())) {
/*  30 */       return false;
/*     */     }
/*     */     
/*  33 */     toggleInteract(true);
/*  34 */     sendUpdate();
/*  35 */     saveData();
/*     */     
/*  37 */     if (isComplete()) {
/*  38 */       int effectId = 0;
/*     */       
/*  40 */       int planetData = 0;
/*  41 */       int headData = 0;
/*  42 */       int bodyData = 0;
/*     */       
/*  44 */       double atTop = 0.0D;
/*  45 */       double inMiddle = 0.0D;
/*  46 */       double inFloor = 0.0D;
/*     */       
/*  48 */       boolean isHead = this instanceof TotemHeadFloorItem;
/*  49 */       boolean isBody = this instanceof TotemBodyFloorItem;
/*  50 */       boolean isPlanet = this instanceof TotemPlanetFloorItem;
/*     */       
/*  52 */       if (isBody) {
/*  53 */         bodyData = Integer.parseInt(getExtraData());
/*  54 */         inFloor = getPosition().getZ();
/*     */       }
/*     */       
/*  57 */       if (isHead) {
/*  58 */         headData = Integer.parseInt(getExtraData());
/*  59 */         inMiddle = getPosition().getZ();
/*     */       }
/*     */       
/*  62 */       if (isPlanet) {
/*  63 */         planetData = Integer.parseInt(getExtraData());
/*  64 */         atTop = getPosition().getZ();
/*     */       }
/*     */       
/*  67 */       for (RoomItemFloor floorItem : getItemsOnStack()) {
/*  68 */         if (((floorItem instanceof TotemHeadFloorItem)) && (!isHead)) {
/*  69 */           headData = Integer.parseInt(floorItem.getExtraData());
/*  70 */           inMiddle = floorItem.getPosition().getZ();
/*     */         }
/*     */         
/*  73 */         if (((floorItem instanceof TotemBodyFloorItem)) && (!isBody)) {
/*  74 */           bodyData = Integer.parseInt(floorItem.getExtraData());
/*  75 */           inFloor = floorItem.getPosition().getZ();
/*     */         }
/*     */         
/*  78 */         if (((floorItem instanceof TotemPlanetFloorItem)) && (!isPlanet))
/*     */         {
/*     */ 
/*  81 */           planetData = Integer.parseInt(floorItem.getExtraData());
/*  82 */           atTop = floorItem.getPosition().getZ();
/*     */         }
/*     */       }
/*  85 */       if ((atTop > inMiddle) && (inMiddle > inFloor) && ((effectId = getEffect(bodyData, headData, planetData)) != 0)) {
/*  86 */         DateTime date = new DateTime();
/*  87 */         if (!((PlayerEntity)entity).getPlayer().getStats().getLastTotemEffect().isEmpty()) {
/*  88 */           String dateStr = ((PlayerEntity)entity).getPlayer().getStats().getLastTotemEffect();
/*     */           
/*  90 */           int lastDay = Integer.parseInt(dateStr.split("[/]")[0]);
/*  91 */           int lastMonth = Integer.parseInt(dateStr.split("[/]")[1]);
/*  92 */           int lastYear = Integer.parseInt(dateStr.split("[/]")[2]);
/*     */           
/*  94 */           if ((date.getDayOfMonth() == lastDay) && (date.getMonthOfYear() == lastMonth) && (lastYear == date.getYear())) {
/*  95 */             return false;
/*     */           }
/*     */         }
/*     */         
/*  99 */         ((PlayerEntity)entity).applyEffect(new com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect(effectId, 0));
/*     */         
/* 101 */         if (!((PlayerEntity)entity).getPlayer().getEffectComponent().hasEffect(effectId)) {
/* 102 */           ((PlayerEntity)entity).getPlayer().getEffectComponent().addEffect(effectId, 3600, true);
/* 103 */           ((PlayerEntity)entity).getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.user.inventory.EffectsInventoryMessageComposer(((PlayerEntity)entity).getPlayer().getEffectComponent().getEffects().values()));
/*     */         }
/*     */         
/* 106 */         ((PlayerEntity)entity).getPlayer().getStats().setLastTotemEffect(String.valueOf(date.getDayOfMonth()) + "/" + date.getMonthOfYear() + "/" + date.getYear());
/* 107 */         ((PlayerEntity)entity).getPlayer().getStats().save();
/*     */       }
/*     */     }
/*     */     
/* 111 */     return true;
/*     */   }
/*     */   
/*     */   public void onItemAddedToStack(RoomItemFloor floorItem)
/*     */   {
/* 116 */     if (((floorItem instanceof TotemHeadFloorItem)) && ((this instanceof TotemBodyFloorItem))) {
/* 117 */       if (!org.apache.commons.lang.StringUtils.isNumeric(getExtraData())) {
/* 118 */         setExtraData("0");
/*     */       }
/*     */       
/* 121 */       floorItem.setExtraData("0");
/* 122 */       floorItem.sendUpdate();
/* 123 */       floorItem.saveData();
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isComplete() {
/* 128 */     boolean hasHead = this instanceof TotemHeadFloorItem;
/* 129 */     boolean hasBody = this instanceof TotemBodyFloorItem;
/* 130 */     boolean hasPlanet = this instanceof TotemPlanetFloorItem;
/*     */     
/* 132 */     for (RoomItemFloor floorItem : getItemsOnStack()) {
/* 133 */       if ((floorItem instanceof TotemHeadFloorItem)) {
/* 134 */         hasHead = true;
/*     */       }
/* 136 */       if ((floorItem instanceof TotemBodyFloorItem)) {
/* 137 */         hasBody = true;
/*     */       }
/* 139 */       if ((floorItem instanceof TotemPlanetFloorItem)) {
/* 140 */         hasPlanet = true;
/*     */       }
/*     */     }
/* 143 */     if ((hasHead) && (hasBody) && (hasPlanet)) {
/* 144 */       return true;
/*     */     }
/*     */     
/* 147 */     return false;
/*     */   }
/*     */   
/*     */   public void onPositionChanged(Position newPosition)
/*     */   {
/* 152 */     setExtraData("0");
/* 153 */     sendUpdate();
/* 154 */     saveData();
/*     */   }
/*     */   
/*     */   public int getEffect(int bodyPart, int headPart, int planetHead) {
/* 158 */     if ((bodyPart == 2) && (headPart == 5) && (planetHead == 2)) {
/* 159 */       return 23;
/*     */     }
/*     */     
/* 162 */     if ((bodyPart == 7) && (headPart == 10) && (planetHead == 0)) {
/* 163 */       return 24;
/*     */     }
/*     */     
/* 166 */     if ((bodyPart == 9) && (headPart == 12) && (planetHead == 1)) {
/* 167 */       return 25;
/*     */     }
/*     */     
/* 170 */     if ((bodyPart == 10) && (headPart == 9) && (planetHead == 2)) {
/* 171 */       return 26;
/*     */     }
/*     */     
/* 174 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\totem\TotemPartFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */