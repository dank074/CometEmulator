/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredItemSnapshot;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WiredActionItemData extends WiredItemData
/*    */ {
/*    */   private int delay;
/*    */   
/*    */   public WiredActionItemData(int selectionType, List<Long> selectedIds, String text, Map<Integer, Integer> params, Map<Long, WiredItemSnapshot> snapshots, int delay)
/*    */   {
/* 14 */     super(selectionType, selectedIds, text, params, snapshots);
/* 15 */     this.delay = delay;
/*    */   }
/*    */   
/*    */   public WiredActionItemData(int delay) {
/* 19 */     this.delay = delay;
/*    */   }
/*    */   
/*    */   public WiredActionItemData()
/*    */   {
/* 24 */     this.delay = 0;
/*    */   }
/*    */   
/*    */   public int getDelay() {
/* 28 */     return this.delay;
/*    */   }
/*    */   
/*    */   public void setDelay(int delay) {
/* 32 */     this.delay = delay;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\data\actions\WiredActionItemData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */