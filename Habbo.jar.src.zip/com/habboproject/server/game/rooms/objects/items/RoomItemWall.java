/*     */ package com.habboproject.server.game.rooms.objects.items;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.items.ItemManager;
/*     */ import com.habboproject.server.game.items.types.ItemDefinition;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.RoomData;
/*     */ import com.habboproject.server.storage.queries.rooms.RoomItemDao;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public abstract class RoomItemWall extends RoomItem
/*     */ {
/*     */   private String wallPosition;
/*     */   private String extraData;
/*     */   private ItemDefinition itemDefinition;
/*     */   
/*     */   public RoomItemWall(long id, int itemId, Room room, int owner, String position, String data)
/*     */   {
/*  19 */     super(id, null, room);
/*     */     
/*  21 */     this.itemId = itemId;
/*     */     
/*  23 */     this.ownerId = owner;
/*  24 */     this.wallPosition = position;
/*  25 */     this.extraData = data;
/*     */   }
/*     */   
/*     */   public void serialize(IComposer msg)
/*     */   {
/*  30 */     msg.writeString(Integer.valueOf(getVirtualId()));
/*  31 */     msg.writeInt(getDefinition().getSpriteId());
/*  32 */     msg.writeString(getWallPosition());
/*     */     
/*  34 */     msg.writeString(getExtraData());
/*  35 */     msg.writeInt(!getDefinition().getInteraction().equals("default") ? 1 : 0);
/*  36 */     msg.writeInt(-1);
/*  37 */     msg.writeInt(-1);
/*     */     
/*     */ 
/*  40 */     msg.writeInt(1);
/*     */   }
/*     */   
/*     */   public boolean toggleInteract(boolean state)
/*     */   {
/*  45 */     if (getDefinition().getInteractionCycleCount() > 1) {
/*  46 */       if ((getExtraData().isEmpty()) || (getExtraData().equals(" "))) {
/*  47 */         setExtraData("0");
/*     */       }
/*     */       
/*  50 */       if (!StringUtils.isNumeric(getExtraData())) {
/*  51 */         return false;
/*     */       }
/*     */       
/*  54 */       int i = Integer.parseInt(getExtraData()) + 1;
/*     */       
/*  56 */       if (i > getDefinition().getInteractionCycleCount() - 1) {
/*  57 */         setExtraData("0");
/*     */       } else {
/*  59 */         setExtraData(i);
/*     */       }
/*     */       
/*  62 */       return true;
/*     */     }
/*  64 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void sendUpdate()
/*     */   {
/*  70 */     Room r = getRoom();
/*     */     
/*  72 */     if ((r != null) && (r.getEntities() != null)) {
/*  73 */       r.getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.items.UpdateWallItemMessageComposer(this, this.ownerId, getRoom().getData().getOwner()));
/*     */     }
/*     */   }
/*     */   
/*     */   public void save() {
/*  78 */     saveData();
/*     */   }
/*     */   
/*     */   public void saveData()
/*     */   {
/*  83 */     RoomItemDao.saveData(getId(), this.extraData);
/*     */   }
/*     */   
/*     */   public ItemDefinition getDefinition()
/*     */   {
/*  88 */     if (this.itemDefinition == null) {
/*  89 */       this.itemDefinition = ItemManager.getInstance().getDefinition(getItemId());
/*     */     }
/*     */     
/*  92 */     return this.itemDefinition;
/*     */   }
/*     */   
/*     */   public int getItemId()
/*     */   {
/*  97 */     return this.itemId;
/*     */   }
/*     */   
/*     */   public int getOwner()
/*     */   {
/* 102 */     return this.ownerId;
/*     */   }
/*     */   
/*     */   public void setPosition(String position) {
/* 106 */     this.wallPosition = position;
/*     */   }
/*     */   
/*     */   public String getWallPosition() {
/* 110 */     return this.wallPosition;
/*     */   }
/*     */   
/*     */   public String getExtraData() {
/* 114 */     return this.extraData;
/*     */   }
/*     */   
/*     */   public void setExtraData(String data) {
/* 118 */     this.extraData = data;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\RoomItemWall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */