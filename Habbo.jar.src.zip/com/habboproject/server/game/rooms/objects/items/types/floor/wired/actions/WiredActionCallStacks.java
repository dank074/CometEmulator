/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.threads.ThreadManager;
/*    */ import com.habboproject.server.threads.executors.wired.actions.ActionCallStacksExecuteEvent;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.concurrent.ExecutionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredActionCallStacks
/*    */   extends WiredActionItem
/*    */ {
/*    */   public WiredActionCallStacks(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 18 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 23 */     return false;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 28 */     return 18;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/*    */     try {
/* 34 */       ThreadManager.getInstance().execute(new ActionCallStacksExecuteEvent(this, getWiredData().getSelectedIds(), 
/* 35 */         event.entity, event.data));
/*    */     } catch (ExecutionException e) {
/* 37 */       e.printStackTrace();
/*    */     } catch (InterruptedException e) {
/* 39 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionCallStacks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */