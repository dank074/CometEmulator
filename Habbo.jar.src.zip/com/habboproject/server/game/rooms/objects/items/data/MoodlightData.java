/*    */ package com.habboproject.server.game.rooms.objects.items.data;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class MoodlightData
/*    */ {
/*    */   private boolean enabled;
/*    */   private int activePreset;
/*    */   private List<MoodlightPresetData> presets;
/*    */   
/*    */   public MoodlightData(boolean enabled, int activePreset, List<MoodlightPresetData> presets) {
/* 12 */     this.enabled = enabled;
/* 13 */     this.activePreset = activePreset;
/* 14 */     this.presets = presets;
/*    */   }
/*    */   
/*    */   public void updatePreset(int presetIndex, boolean bgOnly, String color, int intensity) {
/* 18 */     if (this.presets.get(presetIndex) == null) {
/* 19 */       return;
/*    */     }
/* 21 */     MoodlightPresetData data = (MoodlightPresetData)this.presets.get(presetIndex);
/*    */     
/* 23 */     data.backgroundOnly = bgOnly;
/* 24 */     data.colour = color;
/* 25 */     data.intensity = intensity;
/*    */   }
/*    */   
/*    */   public List<MoodlightPresetData> getPresets() {
/* 29 */     return this.presets;
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 33 */     return this.enabled;
/*    */   }
/*    */   
/*    */   public int getActivePreset() {
/* 37 */     return this.activePreset;
/*    */   }
/*    */   
/*    */   public void setEnabled(boolean enabled) {
/* 41 */     this.enabled = enabled;
/*    */   }
/*    */   
/*    */   public void setActivePreset(int activePreset) {
/* 45 */     this.activePreset = activePreset;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\data\MoodlightData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */