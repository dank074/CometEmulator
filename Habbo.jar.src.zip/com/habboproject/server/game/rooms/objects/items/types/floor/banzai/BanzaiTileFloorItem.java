/*     */ package com.habboproject.server.game.rooms.objects.items.types.floor.banzai;
/*     */ 
/*     */ import com.habboproject.server.game.achievements.types.AchievementType;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFactory;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.GameComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*     */ import com.habboproject.server.game.rooms.types.components.games.banzai.BanzaiGame;
/*     */ import java.util.List;
/*     */ 
/*     */ public class BanzaiTileFloorItem extends RoomItemFloor
/*     */ {
/*  16 */   private GameTeam gameTeam = GameTeam.NONE;
/*  17 */   private int points = 0;
/*     */   
/*     */   public BanzaiTileFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) {
/*  20 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*     */     
/*  22 */     setExtraData("0");
/*     */   }
/*     */   
/*     */   public void onPickup()
/*     */   {
/*  27 */     if (!(getRoom().getGame().getInstance() instanceof BanzaiGame)) {
/*  28 */       return;
/*     */     }
/*     */     
/*  31 */     ((BanzaiGame)getRoom().getGame().getInstance()).removeTile();
/*     */   }
/*     */   
/*     */   public void onPlaced()
/*     */   {
/*  36 */     if (!(getRoom().getGame().getInstance() instanceof BanzaiGame)) {
/*  37 */       return;
/*     */     }
/*     */     
/*  40 */     ((BanzaiGame)getRoom().getGame().getInstance()).addTile();
/*     */   }
/*     */   
/*     */   public void onEntityPostStepOn(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity)
/*     */   {
/*  45 */     if ((!(entity instanceof PlayerEntity)) || (((PlayerEntity)entity).getGameTeam() == GameTeam.NONE) || (!(getRoom().getGame().getInstance() instanceof BanzaiGame))) {
/*  46 */       return;
/*     */     }
/*     */     
/*  49 */     if (this.points == 3)
/*     */     {
/*  51 */       return;
/*     */     }
/*     */     
/*  54 */     if (((PlayerEntity)entity).getGameTeam() == this.gameTeam) {
/*  55 */       this.points += 1;
/*     */     } else {
/*  57 */       this.gameTeam = ((PlayerEntity)entity).getGameTeam();
/*  58 */       this.points = 1;
/*     */     }
/*     */     
/*  61 */     if (this.points == 3) {
/*  62 */       ((PlayerEntity)entity).getPlayer().getAchievements().progressAchievement(AchievementType.BB_TILES_LOCKED, 1);
/*  63 */       ((BanzaiGame)getRoom().getGame().getInstance()).increaseScoreByPlayer(this.gameTeam, (PlayerEntity)entity, 1);
/*  64 */       ((BanzaiGame)getRoom().getGame().getInstance()).decreaseTileCount();
/*     */       
/*  66 */       List<BanzaiTileFloorItem> rectangle = buildBanzaiRectangle(this, getPosition().getX(), getPosition().getY(), 0, 0, -1, 4, this.gameTeam);
/*     */       
/*  68 */       if (rectangle != null) {
/*  69 */         for (RoomItemFloor floorItem : getRoom().getItems().getByClass(BanzaiTileFloorItem.class)) {
/*  70 */           BanzaiTileFloorItem tileItem = (BanzaiTileFloorItem)floorItem;
/*  71 */           if (tileItem.getPoints() != 3)
/*     */           {
/*  73 */             boolean[] borderCheck = new boolean[4];
/*     */             
/*  75 */             for (BanzaiTileFloorItem rectangleItem : rectangle) {
/*  76 */               if (rectangleItem.getPosition().getY() == floorItem.getPosition().getY()) {
/*  77 */                 if (rectangleItem.getPosition().getX() > floorItem.getPosition().getX()) {
/*  78 */                   borderCheck[0] = true;
/*     */                 } else {
/*  80 */                   borderCheck[1] = true;
/*     */                 }
/*  82 */               } else if (rectangleItem.getPosition().getX() == floorItem.getPosition().getX()) {
/*  83 */                 if (rectangleItem.getPosition().getY() > floorItem.getPosition().getY()) {
/*  84 */                   borderCheck[2] = true;
/*     */                 } else {
/*  86 */                   borderCheck[3] = true;
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*  91 */             if ((borderCheck[0] != 0) && (borderCheck[1] != 0) && (borderCheck[2] != 0) && (borderCheck[3] != 0) && 
/*  92 */               (tileItem.getId() != getId())) {
/*  93 */               tileItem.setPoints(3);
/*  94 */               tileItem.setTeam(this.gameTeam);
/*     */               
/*  96 */               ((PlayerEntity)entity).getPlayer().getAchievements().progressAchievement(AchievementType.BB_TILES_LOCKED, 1);
/*  97 */               ((BanzaiGame)getRoom().getGame().getInstance()).increaseScoreByPlayer(this.gameTeam, (PlayerEntity)entity, 1);
/*  98 */               ((BanzaiGame)getRoom().getGame().getInstance()).decreaseTileCount();
/*  99 */               tileItem.updateTileData();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 106 */     updateTileData();
/*     */   }
/*     */   
/*     */   public void onItemAddedToStack(RoomItemFloor roomItemFloor)
/*     */   {
/* 111 */     if (((roomItemFloor instanceof BanzaiPuckFloorItem)) && 
/* 112 */       (((BanzaiPuckFloorItem)roomItemFloor).getPusher() != null)) {
/* 113 */       onEntityPostStepOn(((BanzaiPuckFloorItem)roomItemFloor).getPusher());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static List<BanzaiTileFloorItem> buildBanzaiRectangle(BanzaiTileFloorItem triggerItem, int x, int y, int goX, int goY, int currentDirection, int turns, GameTeam team)
/*     */   {
/* 120 */     boolean[] directions = new boolean[4];
/*     */     
/* 122 */     if ((goX == -1) || (goX == 0)) {
/* 123 */       directions[0] = true;
/*     */     }
/* 125 */     if ((goX == 1) || (goX == 0)) {
/* 126 */       directions[2] = true;
/*     */     }
/* 128 */     if ((goY == -1) || (goY == 0)) {
/* 129 */       directions[1] = true;
/*     */     }
/* 131 */     if ((goY == 1) || (goY == 0)) {
/* 132 */       directions[3] = true;
/*     */     }
/*     */     
/* 135 */     if (((goX != 0) || (goY != 0)) && (triggerItem.getPosition().getX() == x) && (triggerItem.getPosition().getY() == y)) {
/* 136 */       return new java.util.LinkedList();
/*     */     }
/*     */     
/* 139 */     Room room = triggerItem.getRoom();
/*     */     
/* 141 */     for (int i = 0; i < 4; i++) {
/* 142 */       if (directions[i] != 0)
/*     */       {
/*     */ 
/*     */ 
/* 146 */         int nextXStep = 0;int nextYStep = 0;
/*     */         
/* 148 */         if ((i == 0) || (i == 2)) {
/* 149 */           nextXStep = i == 0 ? 1 : -1;
/* 150 */         } else if ((i == 1) || (i == 3)) {
/* 151 */           nextYStep = i == 1 ? 1 : -1;
/*     */         }
/*     */         
/* 154 */         int nextX = x + nextXStep;
/* 155 */         int nextY = y + nextYStep;
/*     */         
/* 157 */         if (room.getMapping().getTile(nextX, nextY) != null) {
/* 158 */           RoomItemFloor obj = room.getItems().getFloorItem(room.getMapping().getTile(nextX, nextY).getTopItem());
/*     */           
/* 160 */           if ((obj != null) && ((obj instanceof BanzaiTileFloorItem))) {
/* 161 */             BanzaiTileFloorItem item = (BanzaiTileFloorItem)obj;
/*     */             
/* 163 */             if ((item.getTeam() == team) && (item.getPoints() == 3)) {
/* 164 */               List<BanzaiTileFloorItem> foundPatches = null;
/* 165 */               if ((currentDirection != i) && (currentDirection != -1)) {
/* 166 */                 if (turns > 0) {
/* 167 */                   foundPatches = buildBanzaiRectangle(
/* 168 */                     triggerItem, nextX, nextY, 
/* 169 */                     nextXStep == 0 ? goX * -1 : nextXStep * -1, 
/* 170 */                     nextYStep == 0 ? goY * -1 : nextYStep * -1, 
/* 171 */                     i, turns - 1, team);
/*     */                 }
/*     */               }
/*     */               else {
/* 175 */                 foundPatches = buildBanzaiRectangle(
/* 176 */                   triggerItem, nextX, nextY, 
/* 177 */                   nextXStep == 0 ? goX : nextXStep * -1, 
/* 178 */                   nextYStep == 0 ? goY : nextYStep * -1, 
/* 179 */                   i, turns, team);
/*     */               }
/*     */               
/* 182 */               if (foundPatches != null) {
/* 183 */                 foundPatches.add(item);
/* 184 */                 return foundPatches;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 191 */     return null;
/*     */   }
/*     */   
/* 194 */   private boolean needsChange = false;
/* 195 */   private int ticker = 0;
/*     */   
/*     */   public void onTick()
/*     */   {
/* 199 */     if ((hasTicks()) && (this.ticker >= RoomItemFactory.getProcessTime(0.5D))) {
/* 200 */       if (this.needsChange) {
/* 201 */         setExtraData("1");
/* 202 */         sendUpdate();
/* 203 */         this.needsChange = false;
/*     */       } else {
/* 205 */         this.needsChange = true;
/* 206 */         updateTileData();
/*     */       }
/*     */       
/* 209 */       this.ticker = 0;
/*     */     }
/*     */     
/* 212 */     this.ticker += 1;
/*     */   }
/*     */   
/*     */   public void onTickComplete()
/*     */   {
/* 217 */     updateTileData();
/*     */   }
/*     */   
/*     */   public void flash() {
/* 221 */     if (this.points == 3) {
/* 222 */       this.needsChange = true;
/* 223 */       setTicks(RoomItemFactory.getProcessTime(3.5D));
/*     */     }
/*     */   }
/*     */   
/*     */   public void onGameStarts() {
/* 228 */     this.gameTeam = GameTeam.NONE;
/* 229 */     this.points = 0;
/* 230 */     updateTileData();
/*     */   }
/*     */   
/*     */   public void onGameEnds() {
/* 234 */     setExtraData("0");
/* 235 */     sendUpdate();
/*     */   }
/*     */   
/*     */   public void updateTileData() {
/* 239 */     if (this.points != 0) {
/* 240 */       setExtraData(this.points + this.gameTeam.getTeamId() * 3 - 1);
/*     */     } else
/* 242 */       setExtraData("1");
/* 243 */     sendUpdate();
/*     */   }
/*     */   
/*     */   public GameTeam getTeam() {
/* 247 */     return this.gameTeam;
/*     */   }
/*     */   
/*     */   public void setTeam(GameTeam gameTeam) {
/* 251 */     this.gameTeam = gameTeam;
/*     */   }
/*     */   
/*     */   public int getPoints() {
/* 255 */     return this.points;
/*     */   }
/*     */   
/*     */   public void setPoints(int points) {
/* 259 */     this.points = points;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\banzai\BanzaiTileFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */