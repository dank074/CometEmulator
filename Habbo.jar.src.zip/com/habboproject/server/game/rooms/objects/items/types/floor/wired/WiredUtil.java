/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.concurrent.ThreadLocalRandom;
/*    */ 
/*    */ public class WiredUtil
/*    */ {
/*    */   public static final int MAX_FURNI_SELECTION = 10;
/*    */   
/*    */   public static <T> T getRandomElement(List<T> elements)
/*    */   {
/* 12 */     int size = elements.size();
/* 13 */     if (size > 0) {
/* 14 */       return (T)elements.get(ThreadLocalRandom.current().nextInt(size));
/*    */     }
/* 16 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\WiredUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */