/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.hollywood;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ 
/*    */ public class HaloTileFloorItem extends RoomItemFloor
/*    */ {
/*    */   public HaloTileFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 11 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/* 12 */     setExtraData("0");
/*    */   }
/*    */   
/*    */   public void onEntityStepOn(RoomEntity entity)
/*    */   {
/* 17 */     setExtraData("1");
/* 18 */     sendUpdate();
/*    */   }
/*    */   
/*    */   public void onEntityStepOff(RoomEntity entity)
/*    */   {
/* 23 */     if (this.ticksTimer < 1) {
/* 24 */       setTicks(com.habboproject.server.game.rooms.objects.items.RoomItemFactory.getProcessTime(0.5D));
/*    */     }
/*    */   }
/*    */   
/*    */   public void onTickComplete()
/*    */   {
/* 30 */     setExtraData("0");
/* 31 */     sendUpdate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\hollywood\HaloTileFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */