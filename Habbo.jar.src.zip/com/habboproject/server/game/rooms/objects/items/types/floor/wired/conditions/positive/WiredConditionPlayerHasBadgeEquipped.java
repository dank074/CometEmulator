/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.conditions.positive;
/*    */ 
/*    */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*    */ import com.habboproject.server.game.players.types.Player;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredConditionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredConditionPlayerHasBadgeEquipped
/*    */   extends WiredConditionItem
/*    */ {
/*    */   public WiredConditionPlayerHasBadgeEquipped(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 26 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 31 */     return 11;
/*    */   }
/*    */   
/*    */   public boolean evaluate(RoomEntity entity, Object data)
/*    */   {
/* 36 */     boolean isEquipped = false;
/* 37 */     if ((entity == null) || (!(entity instanceof PlayerEntity))) { return false;
/*    */     }
/* 39 */     PlayerEntity playerEntity = (PlayerEntity)entity;
/*    */     
/* 41 */     if (playerEntity.getPlayer().getInventory().hasBadge(getWiredData().getText())) {
/* 42 */       int slot = ((Integer)playerEntity.getPlayer().getInventory().getBadges().get(getWiredData().getText())).intValue();
/*    */       
/* 44 */       if (slot != 0) {
/* 45 */         isEquipped = true;
/*    */       }
/*    */     }
/* 48 */     if (isEquipped) {
/* 49 */       if (this.isNegative) {
/* 50 */         return false;
/*    */       }
/*    */     }
/* 53 */     else if (!this.isNegative) {
/* 54 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 58 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\conditions\positive\WiredConditionPlayerHasBadgeEquipped.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */