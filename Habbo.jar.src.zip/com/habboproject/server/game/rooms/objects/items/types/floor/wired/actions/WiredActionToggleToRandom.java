/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.banzai.BanzaiTimerFloorItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.football.FootballTimerFloorItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.freeze.FreezeTimerFloorItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredFloorItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.WiredUtil;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredActionItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.actions.WiredActionItemData;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ import com.habboproject.server.game.rooms.types.mapping.RoomMapping;
/*    */ import com.habboproject.server.threads.executors.wired.events.WiredItemExecuteEvent;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WiredActionToggleToRandom
/*    */   extends WiredActionItem
/*    */ {
/*    */   public WiredActionToggleToRandom(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 26 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean requiresPlayer()
/*    */   {
/* 31 */     return false;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 36 */     return 15;
/*    */   }
/*    */   
/*    */   public void onEventComplete(WiredItemExecuteEvent event)
/*    */   {
/* 41 */     List<Position> tilesToUpdate = Lists.newArrayList();
/*    */     
/* 43 */     long itemId = ((Long)WiredUtil.getRandomElement(getWiredData().getSelectedIds())).longValue();
/*    */     
/* 45 */     RoomItemFloor floorItem = getRoom().getItems().getFloorItem(itemId);
/*    */     
/* 47 */     if ((floorItem == null) || ((floorItem instanceof WiredFloorItem))) {
/* 48 */       return;
/*    */     }
/* 50 */     floorItem.onInteract(null, ((floorItem instanceof BanzaiTimerFloorItem)) || ((floorItem instanceof FootballTimerFloorItem)) || ((floorItem instanceof FreezeTimerFloorItem)) ? -2 : 0, true);
/*    */     
/* 52 */     tilesToUpdate.add(new Position(floorItem.getPosition().getX(), floorItem.getPosition().getY()));
/*    */     
/* 54 */     for (Position tileToUpdate : tilesToUpdate) {
/* 55 */       getRoom().getMapping().updateTile(tileToUpdate.getX(), tileToUpdate.getY());
/*    */     }
/*    */     
/* 58 */     tilesToUpdate.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\actions\WiredActionToggleToRandom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */