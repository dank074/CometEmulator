/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.others;
/*    */ 
/*    */ import com.habboproject.server.api.networking.messages.IComposer;
/*    */ import com.habboproject.server.game.catalog.CatalogManager;
/*    */ import com.habboproject.server.game.catalog.types.gifts.GiftData;
/*    */ import com.habboproject.server.game.players.PlayerManager;
/*    */ import com.habboproject.server.game.players.data.PlayerAvatar;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.utilities.JsonFactory;
/*    */ import java.util.List;
/*    */ 
/*    */ public class GiftFloorItem extends RoomItemFloor
/*    */ {
/*    */   private GiftData giftData;
/* 17 */   private boolean isOpened = false;
/*    */   
/*    */   public GiftFloorItem(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data) throws Exception {
/* 20 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */     
/* 22 */     this.giftData = ((GiftData)JsonFactory.getInstance().fromJson(data.split("GIFT::##")[1], GiftData.class));
/*    */     
/* 24 */     if ((!CatalogManager.getInstance().getGiftBoxesNew().contains(Integer.valueOf(this.giftData.getSpriteId()))) && (!CatalogManager.getInstance().getGiftBoxesOld().contains(Integer.valueOf(this.giftData.getSpriteId())))) {
/* 25 */       throw new Exception("some sad fucker used an exploit, bye bye gift.");
/*    */     }
/*    */   }
/*    */   
/*    */   public void compose(IComposer msg, boolean isNew)
/*    */   {
/* 31 */     GiftData giftData = getGiftData();
/* 32 */     PlayerAvatar purchaser = PlayerManager.getInstance().getAvatarByPlayerId(giftData.getSenderId(), (byte)0);
/*    */     
/* 34 */     msg.writeInt(giftData.getWrappingPaper() * 1000 + giftData.getDecorationType());
/* 35 */     msg.writeInt(1);
/*    */     
/* 37 */     msg.writeInt(6);
/* 38 */     msg.writeString("EXTRA_PARAM");
/* 39 */     msg.writeString("");
/* 40 */     msg.writeString("MESSAGE");
/* 41 */     msg.writeString(giftData.getMessage());
/* 42 */     msg.writeString("PURCHASER_NAME");
/* 43 */     msg.writeString(purchaser.getUsername());
/* 44 */     msg.writeString("PURCHASER_FIGURE");
/* 45 */     msg.writeString(purchaser.getFigure());
/* 46 */     msg.writeString("PRODUCT_CODE");
/* 47 */     msg.writeString("");
/* 48 */     msg.writeString("state");
/* 49 */     msg.writeString(isOpened() ? "1" : "0");
/*    */   }
/*    */   
/*    */   public boolean onInteract(RoomEntity entity, int state, boolean isWiredTrigger)
/*    */   {
/* 54 */     this.isOpened = true;
/*    */     
/* 56 */     sendUpdate();
/* 57 */     getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.items.RemoveFloorItemMessageComposer(getVirtualId(), 1200));
/*    */     
/*    */ 
/* 60 */     this.isOpened = false;
/* 61 */     return true;
/*    */   }
/*    */   
/*    */   public GiftData getGiftData() {
/* 65 */     return this.giftData;
/*    */   }
/*    */   
/*    */   public boolean isOpened() {
/* 69 */     return this.isOpened;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\others\GiftFloorItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */