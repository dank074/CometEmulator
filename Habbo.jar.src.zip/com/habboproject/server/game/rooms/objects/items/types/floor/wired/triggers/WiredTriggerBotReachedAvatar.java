/*    */ package com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.base.WiredTriggerItem;
/*    */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.data.WiredItemData;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*    */ 
/*    */ public class WiredTriggerBotReachedAvatar extends WiredTriggerItem
/*    */ {
/*    */   public WiredTriggerBotReachedAvatar(long id, int itemId, Room room, int owner, int groupId, int x, int y, double z, int rotation, String data)
/*    */   {
/* 14 */     super(id, itemId, room, owner, groupId, x, y, z, rotation, data);
/*    */   }
/*    */   
/*    */   public boolean suppliesPlayer()
/*    */   {
/* 19 */     return true;
/*    */   }
/*    */   
/*    */   public int getInterface()
/*    */   {
/* 24 */     return 14;
/*    */   }
/*    */   
/*    */   public static boolean executeTriggers(BotEntity botEntity, PlayerEntity reachedPlayer) {
/* 28 */     boolean wasExecuted = false;
/* 29 */     for (com.habboproject.server.game.rooms.objects.items.RoomItemFloor floorItem : botEntity.getRoom().getItems().getByClass(WiredTriggerBotReachedAvatar.class)) {
/* 30 */       WiredTriggerBotReachedAvatar trigger = (WiredTriggerBotReachedAvatar)floorItem;
/*    */       
/* 32 */       if (!trigger.getWiredData().getText().isEmpty())
/*    */       {
/*    */ 
/* 35 */         String botName = trigger.getWiredData().getText();
/* 36 */         if ((botEntity != null) && (botEntity.getUsername().equals(botName)) && (reachedPlayer != null))
/*    */         {
/*    */ 
/* 39 */           wasExecuted = trigger.evaluate(reachedPlayer, null); }
/*    */       }
/*    */     }
/* 42 */     return wasExecuted;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\items\types\floor\wired\triggers\WiredTriggerBotReachedAvatar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */