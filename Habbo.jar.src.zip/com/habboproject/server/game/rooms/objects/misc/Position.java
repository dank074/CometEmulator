/*     */ package com.habboproject.server.game.rooms.objects.misc;
/*     */ 
/*     */ import com.habboproject.server.api.game.rooms.util.IPosition;
/*     */ import com.habboproject.server.game.rooms.objects.RoomFloorObject;
/*     */ 
/*     */ public class Position implements IPosition
/*     */ {
/*     */   private int x;
/*     */   private int y;
/*     */   private double z;
/*     */   
/*     */   public Position(int x, int y, double z)
/*     */   {
/*  14 */     this.x = x;
/*  15 */     this.y = y;
/*  16 */     this.z = z;
/*     */   }
/*     */   
/*     */   public Position(Position old) {
/*  20 */     this.x = old.getX();
/*  21 */     this.y = old.getY();
/*  22 */     this.z = old.getZ();
/*     */   }
/*     */   
/*     */   public Position() {
/*  26 */     this.x = 0;
/*  27 */     this.y = 0;
/*  28 */     this.z = 0.0D;
/*     */   }
/*     */   
/*     */   public Position(int x, int y) {
/*  32 */     this.x = x;
/*  33 */     this.y = y;
/*  34 */     this.z = 0.0D;
/*     */   }
/*     */   
/*     */   public Position add(Position other) {
/*  38 */     return new Position(other.getX() + getX(), other.getY() + getY(), other.getZ() + getZ());
/*     */   }
/*     */   
/*     */   public Position subtract(Position other) {
/*  42 */     return new Position(other.getX() - getX(), other.getY() - getY(), other.getZ() - getZ());
/*     */   }
/*     */   
/*     */   public int getDistanceSquared(Position point) {
/*  46 */     int dx = getX() - point.getX();
/*  47 */     int dy = getY() - point.getY();
/*     */     
/*  49 */     return dx * dx + dy * dy;
/*     */   }
/*     */   
/*     */   public static String validateWallPosition(String position) {
/*     */     try {
/*  54 */       String[] data = position.split(" ");
/*  55 */       if ((data[2].equals("l")) || (data[2].equals("r"))) {
/*  56 */         String[] width = data[0].substring(3).split(",");
/*  57 */         int widthX = Integer.parseInt(width[0]);
/*  58 */         int widthY = Integer.parseInt(width[1]);
/*     */         
/*     */ 
/*     */ 
/*  62 */         String[] length = data[1].substring(2).split(",");
/*  63 */         int lengthX = Integer.parseInt(length[0]);
/*  64 */         int lengthY = Integer.parseInt(length[1]);
/*     */         
/*     */ 
/*     */ 
/*  68 */         return ":w=" + widthX + "," + widthY + " " + "l=" + lengthX + "," + lengthY + " " + data[2];
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/*  74 */     return null;
/*     */   }
/*     */   
/*     */   public static double calculateHeight(com.habboproject.server.game.rooms.objects.items.RoomItemFloor item) {
/*  78 */     if (item.getDefinition().getInteraction().equals("gate"))
/*  79 */       return 0.0D;
/*  80 */     if (item.getDefinition().canSit()) {
/*  81 */       return 0.0D;
/*     */     }
/*     */     
/*  84 */     return item.getDefinition().getHeight();
/*     */   }
/*     */   
/*     */   public static int calculateRotation(Position from, Position to) {
/*  88 */     return calculateRotation(from.x, from.y, to.x, to.y, false);
/*     */   }
/*     */   
/*     */   public static int calculateRotation(int x, int y, int newX, int newY, boolean reversed) {
/*  92 */     int rotation = 0;
/*     */     
/*  94 */     if ((x > newX) && (y > newY)) {
/*  95 */       rotation = 7;
/*  96 */     } else if ((x < newX) && (y < newY)) {
/*  97 */       rotation = 3;
/*  98 */     } else if ((x > newX) && (y < newY)) {
/*  99 */       rotation = 5;
/* 100 */     } else if ((x < newX) && (y > newY)) {
/* 101 */       rotation = 1;
/* 102 */     } else if (x > newX) {
/* 103 */       rotation = 6;
/* 104 */     } else if (x < newX) {
/* 105 */       rotation = 2;
/* 106 */     } else if (y < newY) {
/* 107 */       rotation = 4;
/* 108 */     } else if (y > newY) {
/* 109 */       rotation = 0;
/*     */     }
/* 111 */     if (reversed) {
/* 112 */       if (rotation > 3) {
/* 113 */         rotation -= 4;
/*     */       } else {
/* 115 */         rotation += 4;
/*     */       }
/*     */     }
/*     */     
/* 119 */     return rotation;
/*     */   }
/*     */   
/*     */   public Position squareInFront(int angle) {
/* 123 */     return calculatePosition(this.x, this.y, angle, false);
/*     */   }
/*     */   
/*     */   public Position squareBehind(int angle) {
/* 127 */     return calculatePosition(this.x, this.y, angle, true);
/*     */   }
/*     */   
/*     */   public static Position calculatePosition(int x, int y, int angle, boolean isReversed) {
/* 131 */     switch (angle) {
/*     */     case 0: 
/* 133 */       if (!isReversed) {
/* 134 */         y--;
/*     */       } else
/* 136 */         y++;
/* 137 */       break;
/*     */     
/*     */     case 1: 
/* 140 */       if (!isReversed) {
/* 141 */         x++;
/* 142 */         y--;
/*     */       } else {
/* 144 */         x--;
/* 145 */         y++;
/*     */       }
/* 147 */       break;
/*     */     
/*     */     case 2: 
/* 150 */       if (!isReversed) {
/* 151 */         x++;
/*     */       } else
/* 153 */         x--;
/* 154 */       break;
/*     */     
/*     */     case 3: 
/* 157 */       if (!isReversed) {
/* 158 */         x++;
/* 159 */         y++;
/*     */       } else {
/* 161 */         x--;
/* 162 */         y--;
/*     */       }
/* 164 */       break;
/*     */     
/*     */     case 4: 
/* 167 */       if (!isReversed) {
/* 168 */         y++;
/*     */       } else
/* 170 */         y--;
/* 171 */       break;
/*     */     
/*     */     case 5: 
/* 174 */       if (!isReversed) {
/* 175 */         x--;
/* 176 */         y++;
/*     */       } else {
/* 178 */         x++;
/* 179 */         y--;
/*     */       }
/* 181 */       break;
/*     */     
/*     */     case 6: 
/* 184 */       if (!isReversed) {
/* 185 */         x--;
/*     */       } else
/* 187 */         x++;
/* 188 */       break;
/*     */     
/*     */     case 7: 
/* 191 */       if (!isReversed) {
/* 192 */         x--;
/* 193 */         y--;
/*     */       } else {
/* 195 */         x++;
/* 196 */         y++;
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/* 201 */     return new Position(x, y);
/*     */   }
/*     */   
/*     */   public double distanceTo(IPosition pos) {
/* 205 */     return Math.abs(getX() - pos.getX()) + Math.abs(getY() - pos.getY());
/*     */   }
/*     */   
/*     */   public double distanceTo(RoomFloorObject roomFloorObject) {
/* 209 */     return distanceTo(roomFloorObject.getPosition());
/*     */   }
/*     */   
/*     */   public boolean touching(Position pos) {
/* 213 */     if ((Math.abs(getX() - pos.getX()) <= 1) && (Math.abs(getY() - pos.getY()) <= 1)) {
/* 214 */       return true;
/*     */     }
/*     */     
/* 217 */     if ((getX() == pos.getX()) && (getY() == pos.getY())) {
/* 218 */       return true;
/*     */     }
/*     */     
/* 221 */     return false;
/*     */   }
/*     */   
/*     */   public boolean touching(RoomFloorObject roomFloorObject) {
/* 225 */     return touching(roomFloorObject.getPosition());
/*     */   }
/*     */   
/*     */   public Position copy() {
/* 229 */     return new Position(this.x, this.y, this.z);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 234 */     return "(" + getX() + ", " + getY() + ", " + getZ() + ")";
/*     */   }
/*     */   
/*     */   public int getX() {
/* 238 */     return this.x;
/*     */   }
/*     */   
/*     */   public int getY() {
/* 242 */     return this.y;
/*     */   }
/*     */   
/*     */   public double getZ() {
/* 246 */     return this.z;
/*     */   }
/*     */   
/*     */   public void setX(int x) {
/* 250 */     this.x = x;
/*     */   }
/*     */   
/*     */   public void setY(int y) {
/* 254 */     this.y = y;
/*     */   }
/*     */   
/*     */   public void setZ(double z) {
/* 258 */     this.z = z;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 263 */     if ((o instanceof Position)) {
/* 264 */       return (((Position)o).getX() == getX()) && (((Position)o).getY() == getY());
/*     */     }
/*     */     
/* 267 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 272 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\misc\Position.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */