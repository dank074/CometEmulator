/*    */ package com.habboproject.server.game.rooms.objects.entities.effects;
/*    */ 
/*    */ public class PlayerEffect {
/*    */   private int effectId;
/*    */   private int duration;
/*    */   private boolean expires;
/*    */   private boolean isItemEffect;
/*    */   
/*    */   public PlayerEffect(int id, int duration) {
/* 10 */     this.effectId = id;
/* 11 */     this.duration = duration;
/* 12 */     this.expires = (duration != 0);
/* 13 */     this.isItemEffect = false;
/*    */   }
/*    */   
/*    */   public PlayerEffect(int id, boolean isItemEffect) {
/* 17 */     this.effectId = id;
/* 18 */     this.isItemEffect = isItemEffect;
/* 19 */     this.duration = 0;
/* 20 */     this.expires = false;
/*    */   }
/*    */   
/*    */   public int getEffectId() {
/* 24 */     return this.effectId;
/*    */   }
/*    */   
/*    */   public int getDuration() {
/* 28 */     return this.duration;
/*    */   }
/*    */   
/*    */   public void decrementDuration() {
/* 32 */     if (this.duration > 0)
/* 33 */       this.duration -= 1;
/*    */   }
/*    */   
/*    */   public boolean expires() {
/* 37 */     return this.expires;
/*    */   }
/*    */   
/*    */   public boolean isItemEffect() {
/* 41 */     return this.isItemEffect;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\effects\PlayerEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */