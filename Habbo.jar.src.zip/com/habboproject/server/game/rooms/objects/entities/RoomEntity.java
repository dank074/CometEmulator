/*     */ package com.habboproject.server.game.rooms.objects.entities;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.objects.RoomFloorObject;
/*     */ import com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.Square;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.types.EntityPathfinder;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PetEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.ai.BotAI;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomMapping;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomTile;
/*     */ import com.habboproject.server.game.rooms.types.tiles.RoomTileState;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.ApplyEffectMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.AvatarUpdateMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.AvatarsMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.HandItemMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.IdleStatusMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.LeaveRoomMessageComposer;
/*     */ import com.habboproject.server.utilities.collections.ConcurrentHashSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RoomEntity
/*     */   extends RoomFloorObject
/*     */   implements AvatarEntity
/*     */ {
/*     */   private RoomEntityType entityType;
/*     */   private Position walkingGoal;
/*     */   private Position positionToSet;
/*     */   private int bodyRotation;
/*     */   private int headRotation;
/*     */   private List<Square> processingPath;
/*     */   private List<Square> walkingPath;
/*     */   private Square futureSquare;
/*     */   private int stepsToGoal;
/*     */   private int idleTime;
/*     */   private int signTime;
/*     */   private int danceId;
/*     */   private PlayerEffect lastEffect;
/*     */   private PlayerEffect effect;
/*     */   private int handItem;
/*     */   private int handItemTimer;
/*     */   private boolean needsUpdate;
/*     */   private boolean isMoonwalking;
/*     */   private boolean overriden;
/*     */   private boolean isVisible;
/*     */   private boolean cancelNextUpdate;
/*  58 */   public int updatePhase = 0;
/*  59 */   public boolean needsForcedUpdate = false;
/*     */   private boolean doorbellAnswered;
/*  61 */   private boolean walkCancelled = false;
/*  62 */   private boolean canWalk = true;
/*  63 */   private boolean isIdle = false;
/*     */   
/*  65 */   private boolean isRoomMuted = false;
/*     */   
/*     */   private long joinTime;
/*     */   
/*     */   private RoomEntity mountedEntity;
/*  70 */   private Set<RoomEntity> followingEntities = new ConcurrentHashSet();
/*     */   
/*  72 */   private long privateChatItemId = 0L;
/*     */   
/*  74 */   private Map<RoomEntityStatus, String> statuses = new ConcurrentHashMap();
/*     */   
/*  76 */   private boolean fastWalkEnabled = false;
/*     */   
/*     */   public RoomEntity(int identifier, Position startPosition, int startBodyRotation, int startHeadRotation, Room roomInstance) {
/*  79 */     super(identifier, startPosition, roomInstance);
/*     */     
/*  81 */     if ((this instanceof PlayerEntity)) {
/*  82 */       this.entityType = RoomEntityType.PLAYER;
/*  83 */     } else if ((this instanceof BotEntity)) {
/*  84 */       this.entityType = RoomEntityType.BOT;
/*  85 */     } else if ((this instanceof PetEntity)) {
/*  86 */       this.entityType = RoomEntityType.PET;
/*     */     }
/*     */     
/*  89 */     this.bodyRotation = startBodyRotation;
/*  90 */     this.headRotation = startHeadRotation;
/*     */     
/*  92 */     this.idleTime = 0;
/*  93 */     this.signTime = 0;
/*  94 */     this.handItem = 0;
/*  95 */     this.handItemTimer = 0;
/*     */     
/*  97 */     this.danceId = 0;
/*     */     
/*  99 */     this.needsUpdate = false;
/* 100 */     this.isMoonwalking = false;
/* 101 */     this.overriden = false;
/* 102 */     this.isVisible = true;
/* 103 */     this.cancelNextUpdate = false;
/*     */     
/* 105 */     this.doorbellAnswered = false;
/*     */     
/* 107 */     this.stepsToGoal = 0;
/*     */     
/* 109 */     if (getRoom().hasRoomMute()) {
/* 110 */       this.isRoomMuted = true;
/*     */     }
/*     */     
/* 113 */     this.joinTime = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   public RoomEntityType getEntityType() {
/* 117 */     return this.entityType;
/*     */   }
/*     */   
/*     */   public Position getWalkingGoal()
/*     */   {
/* 122 */     if (this.walkingGoal == null) {
/* 123 */       return getPosition();
/*     */     }
/* 125 */     return this.walkingGoal;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setWalkingGoal(int x, int y)
/*     */   {
/* 131 */     this.walkingGoal = new Position(x, y, 0.0D);
/*     */   }
/*     */   
/*     */   public void moveTo(Position position) {
/* 135 */     moveTo(position.getX(), position.getY());
/*     */   }
/*     */   
/*     */   public void moveTo(int x, int y)
/*     */   {
/* 140 */     RoomTile tile = getRoom().getMapping().getTile(x, y);
/*     */     
/* 142 */     if (tile == null) {
/* 143 */       return;
/*     */     }
/* 145 */     if (tile.getState() == RoomTileState.INVALID) {
/* 146 */       return;
/*     */     }
/*     */     
/*     */ 
/* 150 */     if (tile.getRedirect() != null) {
/* 151 */       x = tile.getRedirect().getX();
/* 152 */       y = tile.getRedirect().getY();
/*     */     }
/*     */     
/* 155 */     if (getPositionToSet() != null) {
/* 156 */       RoomTile oldTile = getRoom().getMapping().getTile(getPosition());
/* 157 */       RoomTile newTile = getRoom().getMapping().getTile(getPositionToSet());
/*     */       
/* 159 */       if (oldTile != null) {
/* 160 */         oldTile.getEntities().remove(this);
/*     */       }
/*     */       
/* 163 */       if (newTile != null) {
/* 164 */         newTile.getEntities().add(this);
/*     */       }
/*     */       
/* 167 */       setPosition(getPositionToSet());
/*     */     }
/*     */     
/*     */ 
/* 171 */     setWalkingGoal(x, y);
/*     */     
/*     */ 
/* 174 */     List<Square> path = EntityPathfinder.getInstance().makePath(this, new Position(x, y), (byte)(getRoom().hasAttribute("disableDiagonal") ? 0 : 1), false);
/*     */     
/*     */ 
/* 177 */     if ((path == null) || (path.size() == 0)) {
/* 178 */       path = EntityPathfinder.getInstance().makePath(this, new Position(x, y), (byte)(getRoom().hasAttribute("disableDiagonal") ? 0 : 1), true);
/*     */       
/* 180 */       if ((path == null) || (path.size() == 0))
/*     */       {
/* 182 */         setWalkingGoal(getPosition().getX(), getPosition().getY());
/* 183 */         return;
/*     */       }
/*     */     }
/*     */     
/* 187 */     if (isFastWalkEnabled()) {
/* 188 */       List<Square> newPath = new ArrayList();
/*     */       
/* 190 */       boolean add = false;
/* 191 */       for (Square square : path) {
/* 192 */         if (add) {
/* 193 */           newPath.add(square);
/* 194 */           add = false;
/*     */         } else {
/* 196 */           add = true;
/*     */         }
/*     */       }
/*     */       
/* 200 */       path.clear();
/* 201 */       path = newPath;
/*     */     }
/*     */     
/* 204 */     this.stepsToGoal = path.size();
/*     */     
/*     */ 
/* 207 */     unIdle();
/* 208 */     setWalkingPath(path);
/*     */   }
/*     */   
/*     */   public void lookTo(Position position) {
/* 212 */     lookTo(position.getX(), position.getY(), true);
/*     */   }
/*     */   
/*     */   public void lookTo(int x, int y) {
/* 216 */     lookTo(x, y, true);
/*     */   }
/*     */   
/*     */   public void lookTo(Position position, boolean disableSit) {
/* 220 */     lookTo(position.getX(), position.getY(), disableSit);
/*     */   }
/*     */   
/*     */   public void lookTo(int x, int y, boolean disableSit) {
/* 224 */     if ((x == getPosition().getX()) && (y == getPosition().getY())) {
/* 225 */       return;
/*     */     }
/* 227 */     int rotation = Position.calculateRotation(getPosition().getX(), getPosition().getY(), x, y, false);
/*     */     
/* 229 */     unIdle();
/*     */     
/* 231 */     if ((disableSit) && (!hasStatus(RoomEntityStatus.SIT)) && (!hasStatus(RoomEntityStatus.LAY))) {
/* 232 */       setBodyRotation(rotation);
/* 233 */       setHeadRotation(rotation);
/* 234 */       markNeedsUpdate();
/*     */     }
/*     */   }
/*     */   
/*     */   public Position getPositionToSet()
/*     */   {
/* 240 */     return this.positionToSet;
/*     */   }
/*     */   
/*     */   public void updateAndSetPosition(Position pos)
/*     */   {
/* 245 */     this.positionToSet = pos;
/*     */   }
/*     */   
/*     */   public void markPositionIsSet()
/*     */   {
/* 250 */     this.positionToSet = null;
/*     */   }
/*     */   
/*     */   public boolean hasPositionToSet() {
/* 254 */     return this.positionToSet != null;
/*     */   }
/*     */   
/*     */   public int getBodyRotation()
/*     */   {
/* 259 */     return this.bodyRotation;
/*     */   }
/*     */   
/*     */   public void setBodyRotation(int rotation)
/*     */   {
/* 264 */     this.bodyRotation = rotation;
/*     */   }
/*     */   
/*     */   public int getHeadRotation()
/*     */   {
/* 269 */     return this.headRotation;
/*     */   }
/*     */   
/*     */   public void setHeadRotation(int rotation)
/*     */   {
/* 274 */     this.headRotation = rotation;
/*     */   }
/*     */   
/*     */   public List<Square> getProcessingPath()
/*     */   {
/* 279 */     return this.processingPath;
/*     */   }
/*     */   
/*     */   public void setProcessingPath(List<Square> path)
/*     */   {
/* 284 */     this.processingPath = path;
/*     */   }
/*     */   
/*     */   public List<Square> getWalkingPath()
/*     */   {
/* 289 */     return this.walkingPath;
/*     */   }
/*     */   
/*     */   public void setWalkingPath(List<Square> path)
/*     */   {
/* 294 */     if (this.walkingPath != null) {
/* 295 */       this.walkingPath.clear();
/*     */     }
/*     */     
/* 298 */     this.walkingPath = path;
/*     */   }
/*     */   
/*     */   public boolean isWalking()
/*     */   {
/* 303 */     return (this.processingPath != null) && (this.processingPath.size() > 0);
/*     */   }
/*     */   
/*     */   public Square getFutureSquare()
/*     */   {
/* 308 */     return this.futureSquare;
/*     */   }
/*     */   
/*     */   public void setFutureSquare(Square square)
/*     */   {
/* 313 */     this.futureSquare = square;
/*     */   }
/*     */   
/*     */   public Map<RoomEntityStatus, String> getStatuses()
/*     */   {
/* 318 */     return this.statuses;
/*     */   }
/*     */   
/*     */   public void addStatus(RoomEntityStatus key, String value)
/*     */   {
/* 323 */     if (this.statuses.containsKey(key)) {
/* 324 */       this.statuses.replace(key, value);
/*     */     } else {
/* 326 */       this.statuses.put(key, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeStatus(RoomEntityStatus status)
/*     */   {
/* 332 */     if (!this.statuses.containsKey(status)) {
/* 333 */       return;
/*     */     }
/*     */     
/* 336 */     this.statuses.remove(status);
/*     */   }
/*     */   
/*     */   public boolean hasStatus(RoomEntityStatus key)
/*     */   {
/* 341 */     return this.statuses.containsKey(key);
/*     */   }
/*     */   
/*     */   public void markNeedsUpdate()
/*     */   {
/* 346 */     this.needsUpdate = true;
/*     */   }
/*     */   
/*     */   public void markUpdateComplete() {
/* 350 */     this.needsUpdate = false;
/*     */   }
/*     */   
/*     */   public boolean needsUpdate()
/*     */   {
/* 355 */     return this.needsUpdate;
/*     */   }
/*     */   
/*     */   public boolean isMoonwalking() {
/* 359 */     return this.isMoonwalking;
/*     */   }
/*     */   
/*     */   public void setIsMoonwalking(boolean isMoonwalking) {
/* 363 */     this.isMoonwalking = isMoonwalking;
/*     */   }
/*     */   
/*     */   public int getIdleTime()
/*     */   {
/* 368 */     return this.idleTime;
/*     */   }
/*     */   
/*     */   public boolean isIdle() {
/* 372 */     return this.idleTime >= 600;
/*     */   }
/*     */   
/*     */   public boolean isIdleAndIncrement()
/*     */   {
/* 377 */     this.idleTime += 1;
/*     */     
/* 379 */     if (this.idleTime >= 600) {
/* 380 */       if (!this.isIdle) {
/* 381 */         this.isIdle = true;
/* 382 */         getRoom().getEntities().broadcastMessage(new IdleStatusMessageComposer(getId(), true));
/*     */       }
/* 384 */       return true;
/*     */     }
/*     */     
/* 387 */     return false;
/*     */   }
/*     */   
/*     */   public void resetIdleTime()
/*     */   {
/* 392 */     this.idleTime = 0;
/*     */   }
/*     */   
/*     */   public void setIdle()
/*     */   {
/* 397 */     this.idleTime = 600;
/*     */   }
/*     */   
/*     */   public boolean handItemNeedsRemove() {
/* 401 */     if (this.handItemTimer == 64537) {
/* 402 */       return false;
/*     */     }
/* 404 */     this.handItemTimer -= 1;
/*     */     
/* 406 */     return this.handItemTimer <= 0;
/*     */   }
/*     */   
/*     */   public void unIdle() {
/* 410 */     boolean sendUpdate = this.isIdle;
/* 411 */     this.isIdle = false;
/* 412 */     resetIdleTime();
/*     */     
/* 414 */     if ((this instanceof BotEntity)) {
/* 415 */       return;
/*     */     }
/*     */     
/* 418 */     if (sendUpdate) {
/* 419 */       getRoom().getEntities().broadcastMessage(new IdleStatusMessageComposer(getId(), false));
/*     */     }
/*     */   }
/*     */   
/*     */   public int getSignTime()
/*     */   {
/* 425 */     return this.signTime;
/*     */   }
/*     */   
/*     */   public void markDisplayingSign()
/*     */   {
/* 430 */     this.signTime = 6;
/*     */   }
/*     */   
/*     */   public boolean isDisplayingSign()
/*     */   {
/* 435 */     this.signTime -= 1;
/*     */     
/* 437 */     if (this.signTime <= 0) {
/* 438 */       if (this.signTime < 0) {
/* 439 */         this.signTime = 0;
/*     */       }
/*     */       
/* 442 */       return false;
/*     */     }
/* 444 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getDanceId()
/*     */   {
/* 450 */     return this.danceId;
/*     */   }
/*     */   
/*     */   public void setDanceId(int danceId)
/*     */   {
/* 455 */     this.danceId = danceId;
/*     */   }
/*     */   
/*     */   public PlayerEffect getCurrentEffect()
/*     */   {
/* 460 */     return this.effect;
/*     */   }
/*     */   
/*     */   public void setLastEffect(PlayerEffect lastEffect) {
/* 464 */     this.lastEffect = lastEffect;
/*     */   }
/*     */   
/*     */   public int getHandItem()
/*     */   {
/* 469 */     return this.handItem;
/*     */   }
/*     */   
/*     */   public void carryItem(int id)
/*     */   {
/* 474 */     carryItem(id, 240);
/*     */   }
/*     */   
/*     */   public void carryItem(int id, int timer) {
/* 478 */     this.handItem = id;
/* 479 */     this.handItemTimer = timer;
/*     */     
/* 481 */     getRoom().getEntities().broadcastMessage(new HandItemMessageComposer(getId(), this.handItem));
/*     */   }
/*     */   
/*     */   public void carryItem(int id, boolean timer)
/*     */   {
/* 486 */     if (timer) {
/* 487 */       carryItem(id);
/* 488 */       return;
/*     */     }
/*     */     
/* 491 */     this.handItem = id;
/* 492 */     this.handItemTimer = 64537;
/*     */     
/* 494 */     getRoom().getEntities().broadcastMessage(new HandItemMessageComposer(getId(), this.handItem));
/*     */   }
/*     */   
/*     */   public int getHandItemTimer()
/*     */   {
/* 499 */     return this.handItemTimer;
/*     */   }
/*     */   
/*     */   public void setHandItemTimer(int time)
/*     */   {
/* 504 */     this.handItemTimer = time;
/*     */   }
/*     */   
/*     */   public void applyEffect(PlayerEffect effect)
/*     */   {
/* 509 */     if (effect == null) {
/* 510 */       getRoom().getEntities().broadcastMessage(new ApplyEffectMessageComposer(getId(), 0));
/*     */     } else {
/* 512 */       getRoom().getEntities().broadcastMessage(new ApplyEffectMessageComposer(getId(), effect.getEffectId()));
/*     */     }
/*     */     
/* 515 */     if ((effect != null) && (effect.expires())) {
/* 516 */       this.lastEffect = this.effect;
/*     */     }
/*     */     
/* 519 */     this.effect = effect;
/*     */   }
/*     */   
/*     */   public boolean isOverriden() {
/* 523 */     return this.overriden;
/*     */   }
/*     */   
/*     */   public void setOverriden(boolean overriden) {
/* 527 */     this.overriden = overriden;
/*     */   }
/*     */   
/*     */   public abstract void joinRoom(Room paramRoom, String paramString);
/*     */   
/*     */   protected abstract void finalizeJoinRoom();
/*     */   
/*     */   public abstract void leaveRoom(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*     */   
/*     */   public abstract boolean onChat(String paramString);
/*     */   
/*     */   public abstract boolean onRoomDispose();
/*     */   
/*     */   public boolean isVisible() {
/* 541 */     return this.isVisible;
/*     */   }
/*     */   
/*     */   public void updateVisibility(boolean isVisible) {
/* 545 */     if ((isVisible) && (!this.isVisible)) {
/* 546 */       getRoom().getEntities().broadcastMessage(new AvatarsMessageComposer(this));
/*     */     } else {
/* 548 */       getRoom().getEntities().broadcastMessage(new LeaveRoomMessageComposer(getId()));
/*     */     }
/*     */     
/* 551 */     this.isVisible = isVisible;
/*     */   }
/*     */   
/*     */   public void cancelWalk() {
/* 555 */     setWalkCancelled(true);
/* 556 */     markNeedsUpdate();
/*     */   }
/*     */   
/*     */   public void warp(Position position, boolean cancelNextUpdate) {
/* 560 */     if (cancelNextUpdate) {
/* 561 */       cancelNextUpdate();
/*     */     } else {
/* 563 */       this.updatePhase = 1;
/*     */     }
/*     */     
/* 566 */     this.needsForcedUpdate = true;
/*     */     
/* 568 */     updateAndSetPosition(position);
/* 569 */     markNeedsUpdate();
/*     */     
/* 571 */     RoomTile tile = getRoom().getMapping().getTile(position);
/*     */     
/* 573 */     if (tile != null) {
/* 574 */       tile.getEntities().add(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void warp(Position position)
/*     */   {
/* 580 */     if (this.needsForcedUpdate) { return;
/*     */     }
/* 582 */     warp(position, true);
/*     */   }
/*     */   
/*     */   public void warpImmediately(Position position)
/*     */   {
/* 587 */     setPosition(position);
/* 588 */     getRoom().getEntities().broadcastMessage(new AvatarUpdateMessageComposer(this));
/*     */   }
/*     */   
/*     */   public boolean needsUpdateCancel() {
/* 592 */     if (this.cancelNextUpdate) {
/* 593 */       this.cancelNextUpdate = false;
/* 594 */       return true;
/*     */     }
/* 596 */     return false;
/*     */   }
/*     */   
/*     */   public void cancelNextUpdate()
/*     */   {
/* 601 */     this.cancelNextUpdate = true;
/*     */   }
/*     */   
/*     */   public boolean isDoorbellAnswered() {
/* 605 */     return this.doorbellAnswered;
/*     */   }
/*     */   
/*     */   public void setDoorbellAnswered(boolean b) {
/* 609 */     this.doorbellAnswered = b;
/*     */   }
/*     */   
/*     */   public PlayerEffect getLastEffect() {
/* 613 */     return this.lastEffect;
/*     */   }
/*     */   
/*     */   public boolean isWalkCancelled() {
/* 617 */     return this.walkCancelled;
/*     */   }
/*     */   
/*     */   public void setWalkCancelled(boolean walkCancelled) {
/* 621 */     this.walkCancelled = walkCancelled;
/*     */   }
/*     */   
/*     */   public RoomEntity getMountedEntity() {
/* 625 */     if (this.mountedEntity == null) { return null;
/*     */     }
/* 627 */     if (getRoom().getEntities().getEntity(this.mountedEntity.getId()) == null) {
/* 628 */       return null;
/*     */     }
/*     */     
/* 631 */     return this.mountedEntity;
/*     */   }
/*     */   
/*     */   public void setMountedEntity(RoomEntity mountedEntity) {
/* 635 */     this.mountedEntity = mountedEntity;
/*     */   }
/*     */   
/* 638 */   private boolean hasMount = false;
/*     */   
/*     */   public boolean hasMount() {
/* 641 */     return this.hasMount;
/*     */   }
/*     */   
/*     */   public void setHasMount(boolean hasMount) {
/* 645 */     this.hasMount = hasMount;
/*     */   }
/*     */   
/*     */   public void kick()
/*     */   {
/* 650 */     leaveRoom(false, true, true);
/*     */   }
/*     */   
/*     */   public boolean canWalk() {
/* 654 */     return this.canWalk;
/*     */   }
/*     */   
/*     */   public void setCanWalk(boolean canWalk) {
/* 658 */     this.canWalk = canWalk;
/*     */   }
/*     */   
/*     */   public boolean equals(Object entity)
/*     */   {
/* 663 */     if ((entity instanceof RoomEntity)) {
/* 664 */       return ((RoomEntity)entity).getId() == getId();
/*     */     }
/*     */     
/* 667 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isRoomMuted() {
/* 671 */     return this.isRoomMuted;
/*     */   }
/*     */   
/*     */   public void setRoomMuted(boolean isRoomMuted) {
/* 675 */     this.isRoomMuted = isRoomMuted;
/*     */   }
/*     */   
/*     */   public long getJoinTime()
/*     */   {
/* 680 */     return this.joinTime;
/*     */   }
/*     */   
/*     */   public long getPrivateChatItemId() {
/* 684 */     return this.privateChatItemId;
/*     */   }
/*     */   
/*     */   public void setPrivateChatItemId(long privateChatItemId) {
/* 688 */     this.privateChatItemId = privateChatItemId;
/*     */   }
/*     */   
/*     */   public BotAI getAI() {
/* 692 */     return null;
/*     */   }
/*     */   
/*     */   public Set<RoomEntity> getFollowingEntities() {
/* 696 */     return this.followingEntities;
/*     */   }
/*     */   
/*     */   public void toggleFastWalk() {
/* 700 */     this.fastWalkEnabled = (!this.fastWalkEnabled);
/*     */   }
/*     */   
/*     */   public boolean isFastWalkEnabled() {
/* 704 */     return this.fastWalkEnabled;
/*     */   }
/*     */   
/*     */   public void setFastWalkEnabled(boolean fastWalkEnabled) {
/* 708 */     this.fastWalkEnabled = fastWalkEnabled;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\RoomEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */