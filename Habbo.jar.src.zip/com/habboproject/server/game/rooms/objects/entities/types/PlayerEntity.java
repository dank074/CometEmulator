/*     */ package com.habboproject.server.game.rooms.objects.entities.types;
/*     */ 
/*     */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*     */ import com.habboproject.server.api.game.rooms.settings.RoomAccessType;
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.boot.Comet;
/*     */ import com.habboproject.server.game.commands.CommandManager;
/*     */ import com.habboproject.server.game.commands.notifications.NotificationManager;
/*     */ import com.habboproject.server.game.groups.GroupManager;
/*     */ import com.habboproject.server.game.groups.types.Group;
/*     */ import com.habboproject.server.game.moderation.BanManager;
/*     */ import com.habboproject.server.game.permissions.types.Rank;
/*     */ import com.habboproject.server.game.players.components.MessengerComponent;
/*     */ import com.habboproject.server.game.players.components.PermissionComponent;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.players.types.PlayerFreeze;
/*     */ import com.habboproject.server.game.quests.types.QuestType;
/*     */ import com.habboproject.server.game.rooms.RoomManager;
/*     */ import com.habboproject.server.game.rooms.RoomQueue;
/*     */ import com.habboproject.server.game.rooms.RoomSpectator;
/*     */ import com.habboproject.server.game.rooms.models.RoomModel;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntityStatus;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.ai.BotAI;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.triggers.WiredTriggerPlayerSaysKeyword;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.RoomData;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.ItemsComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.RightsComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.TradeComponent;
/*     */ import com.habboproject.server.game.rooms.types.components.games.GameTeam;
/*     */ import com.habboproject.server.game.rooms.types.components.types.Trade;
/*     */ import com.habboproject.server.logging.LogManager;
/*     */ import com.habboproject.server.logging.LogStore;
/*     */ import com.habboproject.server.logging.containers.RoomVisitContainer;
/*     */ import com.habboproject.server.logging.entries.RoomVisitLogEntry;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.messages.incoming.room.engine.InitializeRoomMessageEvent;
/*     */ import com.habboproject.server.network.messages.incoming.room.engine.LoadHeightmapMessageEvent;
/*     */ import com.habboproject.server.network.messages.outgoing.room.access.DoorbellRequestComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.access.RoomReadyMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.alerts.RoomConnectionErrorMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.alerts.RoomErrorMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.LeaveRoomMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.engine.HotelViewMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.engine.RoomForwardMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.engine.RoomPropertyMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.events.RoomPromotionMessageComposer;
/*     */ import com.habboproject.server.network.messages.outgoing.room.permissions.FloodFilterMessageComposer;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.utilities.attributes.Attributable;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class PlayerEntity extends RoomEntity implements com.habboproject.server.game.rooms.objects.entities.PlayerEntityAccess, Attributable, com.habboproject.server.api.game.rooms.entities.PlayerRoomEntity
/*     */ {
/*  62 */   private static final Logger log = Logger.getLogger(PlayerEntity.class.getName());
/*     */   
/*     */   private Player player;
/*     */   
/*     */   private PlayerData playerData;
/*     */   private int playerId;
/*  68 */   private Map<String, Object> attributes = new java.util.HashMap();
/*     */   
/*     */   private RoomVisitLogEntry visitLogEntry;
/*  71 */   private boolean isFinalized = false;
/*  72 */   private boolean isKicked = false;
/*     */   
/*  74 */   private GameTeam gameTeam = GameTeam.NONE;
/*  75 */   private int kickWalkStage = 0;
/*     */   
/*  77 */   private boolean isQueueing = false;
/*     */   
/*  79 */   private int banzaiPlayerAchievement = 0;
/*     */   
/*  81 */   private boolean hasPlacedPet = false;
/*     */   
/*  83 */   private boolean teleporting = false;
/*  84 */   private int lastPhoto = 0;
/*     */   
/*  86 */   private boolean answeredBubble = false;
/*  87 */   private int onBubble = 0;
/*     */   
/*     */   public PlayerEntity(Player player, int identifier, Position startPosition, int startBodyRotation, int startHeadRotation, Room roomInstance) {
/*  90 */     super(identifier, startPosition, startBodyRotation, startHeadRotation, roomInstance);
/*     */     
/*  92 */     this.player = player;
/*     */     
/*     */ 
/*  95 */     this.playerId = player.getId();
/*  96 */     this.playerData = player.getData();
/*     */     
/*  98 */     if (this.player.isInvisible()) {
/*  99 */       updateVisibility(false);
/*     */     }
/*     */     
/* 102 */     if ((getPlayer().isTeleporting()) && (getPlayer().getTeleportRoomId() == roomInstance.getId())) {
/* 103 */       setOverriden(true);
/*     */     }
/* 105 */     if (LogManager.ENABLED) {
/* 106 */       this.visitLogEntry = LogManager.getInstance().getStore().getRoomVisitContainer().put(player.getId(), roomInstance.getId(), Comet.getTime());
/*     */     }
/*     */   }
/*     */   
/*     */   public void joinRoom(Room room, String password) {
/* 111 */     if (isFinalized()) { return;
/*     */     }
/* 113 */     boolean isAuthFailed = false;
/* 114 */     boolean isSpectating = getPlayer().isSpectating(room.getId());
/*     */     
/* 116 */     if (getRoom() == null) {
/* 117 */       getPlayer().getSession().send(new HotelViewMessageComposer());
/* 118 */       isAuthFailed = true;
/*     */     }
/*     */     
/*     */ 
/* 122 */     if ((!isSpectating) && (!getPlayer().hasQueued(room.getId())) && (!isAuthFailed) && (getPlayerId() != getRoom().getData().getOwnerId()) && (getRoom().getEntities().playerCount() >= getRoom().getData().getMaxUsers()) && 
/* 123 */       (!getPlayer().getPermissions().getRank().roomEnterFull()))
/*     */     {
/* 125 */       if (RoomQueue.getInstance().hasQueue(room.getId())) {
/* 126 */         RoomQueue.getInstance().addPlayerToQueue(room.getId(), this.playerId);
/*     */         
/* 128 */         this.isQueueing = true;
/* 129 */         getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.room.queue.RoomQueueStatusMessageComposer(RoomQueue.getInstance().getQueueCount(room.getId(), this.playerId), RoomSpectator.getInstance().getSpectatorsCount(room.getId())));
/* 130 */         return;
/*     */       }
/*     */       
/* 133 */       getPlayer().getSession().send(new RoomConnectionErrorMessageComposer(1, ""));
/* 134 */       getPlayer().getSession().send(new HotelViewMessageComposer());
/* 135 */       isAuthFailed = true;
/*     */     }
/*     */     
/*     */ 
/* 139 */     if ((!isAuthFailed) && (getRoom().getRights().hasBan(getPlayerId())) && (getPlayer().getPermissions().getRank().roomKickable())) {
/* 140 */       getPlayer().getSession().send(new RoomConnectionErrorMessageComposer(4, ""));
/* 141 */       isAuthFailed = true;
/*     */     }
/*     */     
/* 144 */     boolean isOwner = getRoom().getData().getOwnerId() == getPlayerId();
/* 145 */     boolean isTeleporting = (getPlayer().isTeleporting()) && (getPlayer().getTeleportRoomId() == getRoom().getId());
/*     */     
/* 147 */     getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.room.engine.OpenConnectionMessageComposer());
/*     */     
/* 149 */     if ((!isAuthFailed) && (!getPlayer().isBypassingRoomAuth()) && (!isOwner) && (!getPlayer().getPermissions().getRank().roomEnterLocked()) && (!isDoorbellAnswered()) && (!isTeleporting)) {
/* 150 */       if (getRoom().getData().getAccess() == RoomAccessType.PASSWORD) {
/*     */         boolean matched;
/*     */         boolean matched;
/* 153 */         if (com.habboproject.server.config.CometSettings.roomEncryptPasswords) {
/* 154 */           matched = org.mindrot.jbcrypt.BCrypt.checkpw(password, getRoom().getData().getPassword());
/*     */         } else {
/* 156 */           matched = getRoom().getData().getPassword().equals(password);
/*     */         }
/*     */         
/* 159 */         if (!matched) {
/* 160 */           getPlayer().getSession().send(new RoomErrorMessageComposer(-100002));
/* 161 */           getPlayer().getSession().send(new HotelViewMessageComposer());
/* 162 */           isAuthFailed = true;
/*     */         }
/* 164 */       } else if ((getRoom().getData().getAccess() == RoomAccessType.DOORBELL) && 
/* 165 */         (!getRoom().getRights().hasRights(this.playerId))) {
/* 166 */         if (getRoom().getEntities().playerCount() < 1) {
/* 167 */           getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.room.alerts.DoorbellNoAnswerComposer());
/* 168 */           getPlayer().getSession().send(new HotelViewMessageComposer());
/*     */           
/* 170 */           isAuthFailed = true;
/*     */         } else {
/* 172 */           getRoom().getEntities().broadcastMessage(new DoorbellRequestComposer(getUsername()), true);
/* 173 */           getPlayer().getSession().send(new DoorbellRequestComposer(""));
/* 174 */           isAuthFailed = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 180 */     getPlayer().bypassRoomAuth(false);
/* 181 */     getPlayer().setTeleportId(0L);
/* 182 */     getPlayer().setTeleportRoomId(0);
/*     */     
/* 184 */     getPlayer().setRoomQueueId(0);
/*     */     
/* 186 */     if (isAuthFailed) {
/* 187 */       return;
/*     */     }
/*     */     
/* 190 */     getRoom().getEntities().addEntity(this);
/*     */     
/* 192 */     finalizeJoinRoom();
/*     */   }
/*     */   
/*     */   protected void finalizeJoinRoom()
/*     */   {
/* 197 */     Session session = this.player.getSession();
/*     */     
/* 199 */     session.send(new RoomReadyMessageComposer(getRoom().getId(), getRoom().getModel().getId()));
/*     */     
/* 201 */     for (Map.Entry<String, String> decoration : getRoom().getData().getDecorations().entrySet()) {
/* 202 */       if (((!((String)decoration.getKey()).equals("wallpaper")) && (!((String)decoration.getKey()).equals("floor"))) || 
/* 203 */         (!((String)decoration.getValue()).equals("0.0")))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 208 */         session.send(new RoomPropertyMessageComposer((String)decoration.getKey(), (String)decoration.getValue()));
/*     */       }
/*     */     }
/* 211 */     int accessLevel = 0;
/*     */     
/* 213 */     if ((getRoom().getData().getOwnerId() == getPlayerId()) || (getPlayer().getPermissions().getRank().roomFullControl())) {
/* 214 */       addStatus(RoomEntityStatus.CONTROLLER, "useradmin");
/* 215 */       session.send(new com.habboproject.server.network.messages.outgoing.room.permissions.YouAreOwnerMessageComposer());
/* 216 */       accessLevel = 4;
/* 217 */     } else if (getRoom().getRights().hasRights(getPlayerId())) {
/* 218 */       addStatus(RoomEntityStatus.CONTROLLER, "1");
/* 219 */       accessLevel = 1;
/*     */     }
/*     */     
/* 222 */     session.send(new com.habboproject.server.network.messages.outgoing.room.permissions.YouAreControllerMessageComposer(accessLevel));
/*     */     
/* 224 */     boolean isSpectating = getPlayer().isSpectating(getRoom().getId());
/*     */     
/* 226 */     if ((!isSpectating) && 
/* 227 */       (getRoom().getData().getRequiredBadge() != null)) {
/* 228 */       if (!getPlayer().getInventory().hasBadge(getRoom().getData().getRequiredBadge())) {
/* 229 */         isSpectating = true;
/* 230 */       } else if (((Integer)getPlayer().getInventory().getBadges().get(getRoom().getData().getRequiredBadge())).intValue() == 0) {
/* 231 */         isSpectating = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 236 */     if (isSpectating) {
/* 237 */       session.send(new com.habboproject.server.network.messages.outgoing.room.permissions.YouAreSpectatorMessageComposer());
/* 238 */       updateVisibility(false);
/*     */     }
/*     */     
/* 241 */     session.send(new com.habboproject.server.network.messages.outgoing.room.settings.RoomRatingMessageComposer(getRoom().getData().getScore(), canRateRoom()));
/*     */     
/* 243 */     InitializeRoomMessageEvent.heightmapMessageEvent.handle(session, null);
/*     */     
/* 245 */     if (RoomManager.getInstance().hasPromotion(getRoom().getId())) {
/* 246 */       session.send(new RoomPromotionMessageComposer(getRoom().getData(), getRoom().getPromotion()));
/*     */     } else {
/* 248 */       session.send(new RoomPromotionMessageComposer(null, null));
/*     */     }
/*     */     
/* 251 */     if (getPlayer().getEntity().isVisible()) {
/* 252 */       getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.AvatarsMessageComposer(getPlayer().getEntity()));
/*     */     }
/* 254 */     this.isFinalized = true;
/* 255 */     getPlayer().setSpectatorRoomId(0);
/* 256 */     getPlayer().getAchievements().progressAchievement(com.habboproject.server.game.achievements.types.AchievementType.ROOM_ENTRY, 1);
/*     */   }
/*     */   
/*     */   public boolean canRateRoom() {
/* 260 */     return !getRoom().getRatings().contains(Integer.valueOf(getPlayerId()));
/*     */   }
/*     */   
/*     */   public void leaveRoom(boolean isOffline, boolean isKick, boolean toHotelView)
/*     */   {
/* 265 */     if (this.isQueueing) {
/* 266 */       RoomQueue.getInstance().removePlayerFromQueue(getRoom().getId(), Integer.valueOf(this.playerId));
/*     */     }
/*     */     
/* 269 */     RoomSpectator.getInstance().removePlayerFromSpectateMode(getRoom().getId(), Integer.valueOf(getPlayer().getId()));
/*     */     Session nextPlayerSession;
/*     */     try {
/* 272 */       if ((RoomQueue.getInstance().hasQueue(getRoom().getId())) && (!this.isQueueing)) {
/* 273 */         int nextPlayer = RoomQueue.getInstance().getNextPlayer(getRoom().getId());
/*     */         
/* 275 */         RoomQueue.getInstance().removePlayerFromQueue(getRoom().getId(), Integer.valueOf(nextPlayer));
/* 276 */         nextPlayerSession = NetworkManager.getInstance().getSessions().getByPlayerId(nextPlayer);
/*     */         
/* 278 */         if (nextPlayerSession != null) {
/* 279 */           nextPlayerSession.getPlayer().setRoomQueueId(getRoom().getId());
/*     */           
/* 281 */           if ((nextPlayerSession.getPlayer().getEntity() != null) && (nextPlayerSession.getPlayer().getEntity().getRoom().getId() == getRoom().getId())) {
/* 282 */             nextPlayerSession.send(new RoomForwardMessageComposer(getRoom().getId()));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/* 290 */     for (BotEntity entity : getRoom().getEntities().getBotEntities()) {
/* 291 */       if (entity.getAI().onPlayerLeave(this))
/*     */         break;
/*     */     }
/* 294 */     for (Map.Entry<Long, RoomItemFloor> floorItem : getRoom().getItems().getFloorItems().entrySet()) {
/* 295 */       if (floorItem.getValue() != null)
/*     */       {
/* 297 */         ((RoomItemFloor)floorItem.getValue()).onEntityLeaveRoom(this);
/*     */       }
/*     */     }
/*     */     
/* 301 */     Trade trade = getRoom().getTrade().get(this);
/*     */     
/* 303 */     if (trade != null) {
/* 304 */       trade.cancel(getPlayerId());
/*     */     }
/*     */     
/* 307 */     if (getMountedEntity() != null) {
/* 308 */       getMountedEntity().setOverriden(false);
/* 309 */       getMountedEntity().setHasMount(false);
/*     */     }
/*     */     
/*     */ 
/* 313 */     for (RoomItemFloor item : getRoom().getItems().getItemsOnSquare(getPosition().getX(), getPosition().getY())) {
/* 314 */       if (item != null) {
/* 315 */         item.onEntityStepOff(this);
/*     */       }
/*     */     }
/* 318 */     if ((isKick) && (!isOffline) && (getPlayer() != null) && (getPlayer().getSession() != null)) {
/* 319 */       getPlayer().getSession().send(new RoomErrorMessageComposer(4008));
/*     */     }
/*     */     
/*     */ 
/* 323 */     getRoom().getEntities().broadcastMessage(new LeaveRoomMessageComposer(getId()));
/*     */     
/*     */ 
/* 326 */     if ((!isOffline) && (toHotelView) && (getPlayer() != null) && (getPlayer().getSession() != null)) {
/* 327 */       getPlayer().getSession().send(new HotelViewMessageComposer());
/*     */       
/* 329 */       if (getPlayer().getData() != null) {
/* 330 */         getPlayer().getMessenger().sendStatus(true, false);
/*     */       }
/*     */     }
/*     */     
/* 334 */     if ((this.hasPlacedPet) && (getRoom().getData().getOwnerId() != this.playerId)) {
/* 335 */       for (PetEntity petEntity : getRoom().getEntities().getPetEntities()) {
/* 336 */         if (petEntity.getData().getOwnerId() == getPlayerId()) {
/* 337 */           petEntity.kick();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 343 */     getRoom().getEntities().removeEntity(this);
/*     */     
/* 345 */     if (this.player != null) {
/* 346 */       getPlayer().setEntity(null);
/*     */     }
/*     */     
/* 349 */     if (this.visitLogEntry != null) {
/* 350 */       this.visitLogEntry.setExitTime((int)Comet.getTime());
/*     */       
/* 352 */       LogManager.getInstance().getStore().getRoomVisitContainer().updateExit(this.visitLogEntry);
/*     */     }
/*     */     
/* 355 */     getStatuses().clear();
/* 356 */     this.attributes.clear();
/*     */     
/*     */ 
/* 359 */     this.player = null;
/* 360 */     this.playerData = null;
/*     */   }
/*     */   
/*     */   public void kick()
/*     */   {
/* 365 */     this.isKicked = true;
/* 366 */     setCanWalk(false);
/*     */     
/* 368 */     moveTo(getRoom().getModel().getDoorX(), getRoom().getModel().getDoorY());
/*     */   }
/*     */   
/* 371 */   private int lastMessageCounter = 0;
/* 372 */   private String lastMessage = "";
/*     */   
/*     */   public boolean onChat(String message)
/*     */   {
/* 376 */     long time = System.currentTimeMillis();
/*     */     
/* 378 */     if (WiredTriggerPlayerSaysKeyword.executeTriggers(this, message)) {
/* 379 */       return false;
/*     */     }
/*     */     
/* 382 */     if (!getPlayer().getPermissions().getRank().floodBypass()) {
/* 383 */       if (this.lastMessage.equals(message)) {
/* 384 */         this.lastMessageCounter += 1;
/*     */         
/* 386 */         if (this.lastMessageCounter >= 3) {
/* 387 */           getPlayer().setRoomFloodTime(getPlayer().getPermissions().getRank().floodTime());
/*     */         }
/*     */       } else {
/* 390 */         this.lastMessage = message;
/* 391 */         this.lastMessageCounter = 0;
/*     */       }
/*     */       
/* 394 */       if (time - getPlayer().getRoomLastMessageTime() < 750L) {
/* 395 */         getPlayer().setRoomFloodFlag(getPlayer().getRoomFloodFlag() + 1);
/*     */         
/* 397 */         if (getPlayer().getRoomFloodFlag() >= 3) {
/* 398 */           getPlayer().setRoomFloodTime(getPlayer().getPermissions().getRank().floodTime());
/* 399 */           getPlayer().setRoomFloodFlag(0);
/*     */           
/* 401 */           getPlayer().getSession().send(new FloodFilterMessageComposer(this.player.getRoomFloodTime()));
/*     */         }
/*     */       } else {
/* 404 */         getPlayer().setRoomFloodFlag(0);
/*     */       }
/*     */       
/* 407 */       if (getPlayer().getRoomFloodTime() >= 1.0D) {
/* 408 */         return false;
/*     */       }
/*     */       
/* 411 */       this.player.setRoomLastMessageTime(time);
/* 412 */       this.player.setLastMessage(message);
/*     */     }
/*     */     
/* 415 */     if ((message.isEmpty()) || (message.length() > 100)) {
/* 416 */       return false;
/*     */     }
/*     */     try {
/* 419 */       if (CommandManager.getInstance().isCommand(message)) {
/* 420 */         if (CommandManager.getInstance().parse(message, getPlayer().getSession()))
/* 421 */           return false;
/* 422 */       } else if (CommandManager.getInstance().getNotifications().isNotificationExecutor(message, getPlayer().getData().getRank())) {
/* 423 */         CommandManager.getInstance().getNotifications().execute(this.player, message.substring(1));
/*     */       }
/*     */     } catch (Exception e) {
/* 426 */       log.error("Error while executing command", e);
/* 427 */       return false;
/*     */     }
/*     */     
/* 430 */     if ((isRoomMuted()) && (!getPlayer().getPermissions().getRank().roomMuteBypass()) && (getRoom().getData().getOwnerId() != getPlayerId())) {
/* 431 */       return false;
/*     */     }
/*     */     
/* 434 */     if (((getRoom().getRights().hasMute(getPlayerId())) || (BanManager.getInstance().isMuted(getPlayerId()))) && (!getPlayer().getPermissions().getRank().roomMuteBypass())) {
/* 435 */       getPlayer().getSession().send(new com.habboproject.server.network.messages.outgoing.room.avatar.MutedMessageComposer(getRoom().getRights().getMuteTime(getPlayerId())));
/*     */       
/* 437 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 450 */     if (getRoom().getEntities().playerCount() > 1) {
/* 451 */       getPlayer().getQuests().progressQuest(QuestType.SOCIAL_CHAT);
/*     */     }
/*     */     
/* 454 */     unIdle();
/* 455 */     return true;
/*     */   }
/*     */   
/*     */   public void postChat(String message) {
/* 459 */     for (Map.Entry<Integer, RoomEntity> entity : getRoom().getEntities().getAllEntities().entrySet()) {
/* 460 */       if (((RoomEntity)entity.getValue()).getAI() != null) {
/* 461 */         ((RoomEntity)entity.getValue()).getAI().onTalk(this, message);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onRoomDispose()
/*     */   {
/* 468 */     getStatuses().clear();
/*     */     
/*     */ 
/* 471 */     getRoom().getEntities().broadcastMessage(new LeaveRoomMessageComposer(getId()));
/*     */     
/*     */ 
/* 474 */     getPlayer().getSession().send(new HotelViewMessageComposer());
/* 475 */     getPlayer().getSession().getPlayer().getMessenger().sendStatus(true, false);
/*     */     
/*     */ 
/* 478 */     Trade trade = getRoom().getTrade().get(this);
/*     */     
/* 480 */     if (trade != null) {
/* 481 */       trade.cancel(getPlayerId());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 491 */     if (getPlayer() != null)
/*     */     {
/* 493 */       getPlayer().setEntity(null);
/* 494 */       this.player = null;
/*     */     }
/*     */     
/* 497 */     return false;
/*     */   }
/*     */   
/*     */   public void setIdle()
/*     */   {
/* 502 */     super.setIdle();
/*     */     
/* 504 */     getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.IdleStatusMessageComposer(getPlayerId(), true));
/*     */   }
/*     */   
/*     */   public int getPlayerId() {
/* 508 */     return this.playerId;
/*     */   }
/*     */   
/*     */   public String getUsername()
/*     */   {
/* 513 */     return this.playerData == null ? "UnknownPlayer" + this.playerId : this.playerData.getUsername();
/*     */   }
/*     */   
/*     */   public String getMotto()
/*     */   {
/* 518 */     return this.playerData == null ? "" : this.playerData.getMotto();
/*     */   }
/*     */   
/*     */   public String getFigure()
/*     */   {
/* 523 */     return this.playerData == null ? "" : this.playerData.getFigure();
/*     */   }
/*     */   
/*     */   public String getGender()
/*     */   {
/* 528 */     return this.playerData == null ? "M" : this.playerData.getGender();
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg)
/*     */   {
/* 533 */     if (hasAttribute("transformation")) {
/* 534 */       String[] transformationData = ((String)getAttribute("transformation")).split("#");
/*     */       
/* 536 */       com.habboproject.server.game.commands.vip.TransformCommand.composeTransformation(msg, transformationData, this);
/* 537 */       return;
/*     */     }
/*     */     
/* 540 */     msg.writeInt(getPlayerId());
/* 541 */     msg.writeString(getUsername().replace("<", "").replace(">", ""));
/* 542 */     msg.writeString(getMotto());
/* 543 */     msg.writeString(getFigure());
/* 544 */     msg.writeInt(getId());
/*     */     
/* 546 */     msg.writeInt(getPosition().getX());
/* 547 */     msg.writeInt(getPosition().getY());
/* 548 */     msg.writeDouble(getPosition().getZ());
/*     */     
/* 550 */     msg.writeInt(getBodyRotation());
/* 551 */     msg.writeInt(1);
/*     */     
/* 553 */     msg.writeString(getGender().toLowerCase());
/*     */     
/* 555 */     if ((this.playerData == null) || (this.playerData.getFavouriteGroup() == 0)) {
/* 556 */       msg.writeInt(-1);
/* 557 */       msg.writeInt(-1);
/* 558 */       msg.writeInt(0);
/*     */     } else {
/* 560 */       Group group = GroupManager.getInstance().get(this.playerData.getFavouriteGroup());
/*     */       
/* 562 */       if (group == null) {
/* 563 */         msg.writeInt(-1);
/* 564 */         msg.writeInt(-1);
/* 565 */         msg.writeInt(0);
/*     */         
/* 567 */         this.playerData.setFavouriteGroup(0);
/* 568 */         this.playerData.save();
/*     */       } else {
/* 570 */         msg.writeInt(group.getId());
/* 571 */         msg.writeInt(2);
/* 572 */         msg.writeString(group.getData().getTitle());
/* 573 */         msg.writeString("");
/*     */       }
/*     */     }
/*     */     
/* 577 */     msg.writeInt(this.playerData == null ? 0 : this.playerData.getAchievementPoints());
/* 578 */     msg.writeBoolean(Boolean.valueOf(false));
/*     */   }
/*     */   
/*     */   public Player getPlayer()
/*     */   {
/* 583 */     return this.player;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void dispose() {
/* 588 */     leaveRoom(true, false, false);
/* 589 */     this.attributes.clear();
/*     */   }
/*     */   
/*     */   public void setAttribute(String attributeKey, Object attributeValue)
/*     */   {
/* 594 */     if (this.attributes.containsKey(attributeKey)) {
/* 595 */       this.attributes.replace(attributeKey, attributeValue);
/*     */     } else {
/* 597 */       this.attributes.put(attributeKey, attributeValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getAttribute(String attributeKey)
/*     */   {
/* 603 */     return this.attributes.get(attributeKey);
/*     */   }
/*     */   
/*     */   public boolean hasAttribute(String attributeKey)
/*     */   {
/* 608 */     return this.attributes.containsKey(attributeKey);
/*     */   }
/*     */   
/*     */   public void removeAttribute(String attributeKey)
/*     */   {
/* 613 */     this.attributes.remove(attributeKey);
/*     */   }
/*     */   
/*     */   public boolean isWalkCancelled()
/*     */   {
/* 618 */     if (getPlayer().getFreeze().isFreezed()) {
/* 619 */       return true;
/*     */     }
/*     */     
/* 622 */     return super.isWalkCancelled();
/*     */   }
/*     */   
/*     */   public boolean isFinalized() {
/* 626 */     return this.isFinalized;
/*     */   }
/*     */   
/*     */   public GameTeam getGameTeam() {
/* 630 */     return this.gameTeam;
/*     */   }
/*     */   
/*     */   public void setGameTeam(GameTeam gameTeam) {
/* 634 */     this.gameTeam = gameTeam;
/*     */   }
/*     */   
/*     */   public boolean isKicked() {
/* 638 */     return this.isKicked;
/*     */   }
/*     */   
/*     */   public int getKickWalkStage() {
/* 642 */     return this.kickWalkStage;
/*     */   }
/*     */   
/*     */   public void increaseKickWalkStage() {
/* 646 */     this.kickWalkStage += 1;
/*     */   }
/*     */   
/*     */   public void setPlayerId(int playerId) {
/* 650 */     this.playerId = playerId;
/*     */   }
/*     */   
/*     */   public int getBanzaiPlayerAchievement() {
/* 654 */     return this.banzaiPlayerAchievement;
/*     */   }
/*     */   
/*     */   public void setBanzaiPlayerAchievement(int banzaiPlayerAchievement) {
/* 658 */     this.banzaiPlayerAchievement = banzaiPlayerAchievement;
/*     */   }
/*     */   
/*     */   public void incrementBanzaiPlayerAchievement() {
/* 662 */     this.banzaiPlayerAchievement += 1;
/*     */   }
/*     */   
/*     */   public void setPlacedPet(boolean hasPlacedPet) {
/* 666 */     this.hasPlacedPet = hasPlacedPet;
/*     */   }
/*     */   
/*     */   public boolean isTeleporting() {
/* 670 */     return this.teleporting;
/*     */   }
/*     */   
/*     */   public void setTeleporting(boolean teleporting) {
/* 674 */     this.teleporting = teleporting;
/*     */   }
/*     */   
/*     */   public int getLastPhoto() {
/* 678 */     return this.lastPhoto;
/*     */   }
/*     */   
/*     */   public void setLastPhoto(int lastPhoto) {
/* 682 */     this.lastPhoto = lastPhoto;
/*     */   }
/*     */   
/*     */   public boolean isAnsweredBubble() {
/* 686 */     return this.answeredBubble;
/*     */   }
/*     */   
/*     */   public void setAnsweredBubble(boolean answeredBubble) {
/* 690 */     this.answeredBubble = answeredBubble;
/*     */   }
/*     */   
/*     */   public int getOnBubble() {
/* 694 */     return this.onBubble;
/*     */   }
/*     */   
/*     */   public void setOnBubble(int onBubble) {
/* 698 */     this.onBubble = onBubble;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\PlayerEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */