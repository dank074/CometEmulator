/*    */ package com.habboproject.server.game.rooms.objects.entities.types.data;
/*    */ 
/*    */ import com.habboproject.server.game.bots.BotData;
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class PlayerBotData extends BotData
/*    */ {
/*  9 */   private Logger log = Logger.getLogger(PlayerBotData.class.getName());
/*    */   private Position position;
/*    */   
/*    */   public PlayerBotData(int botId, String username, String motto, String figure, String gender, String ownerName, int ownerId, String messages, boolean automaticChat, int chatDelay, String botType, String botMode, String data)
/*    */   {
/* 14 */     super(botId, username, motto, figure, gender, ownerName, ownerId, messages, automaticChat, chatDelay, botType, botMode, data);
/*    */   }
/*    */   
/*    */   public Position getPosition() {
/* 18 */     return this.position;
/*    */   }
/*    */   
/*    */   public void setPosition(Position position) {
/* 22 */     this.position = position;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\data\PlayerBotData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */