package com.habboproject.server.game.rooms.objects.entities.types.ai.pets;

public class MonsterplantAI {}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\ai\pets\MonsterplantAI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */