/*    */ package com.habboproject.server.game.rooms.objects.entities.types.ai.bots;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.rooms.RoomManager;
/*    */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.ai.AbstractBotAI;
/*    */ 
/*    */ public class WaiterAI extends AbstractBotAI
/*    */ {
/* 11 */   private static final Drink[] drinks = {
/* 12 */     new Drink("tea", 1, null), 
/* 13 */     new Drink("juice", 2, null), 
/* 14 */     new Drink("milk", 5, null), 
/* 15 */     new Drink("coffee", 8, null), 
/* 16 */     new Drink("decaff", 9, null), 
/* 17 */     new Drink("espresso", 13, null), 
/* 18 */     new Drink("mocha", 11, null), 
/* 19 */     new Drink("iced_coffee", 15, null), 
/* 20 */     new Drink("cappuccino", 16, null), 
/* 21 */     new Drink("java", 17, null), 
/* 22 */     new Drink("coke", 19, null), 
/* 23 */     new Drink("cola", 19, null), 
/* 24 */     new Drink("bubble", 24, null), 
/* 25 */     new Drink("potion", 25, null), 
/* 26 */     new Drink("pink_champagne", 35, null) };
/*    */   
/*    */   public WaiterAI(RoomEntity entity)
/*    */   {
/* 30 */     super(entity);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean onTalk(PlayerEntity entity, String message)
/*    */   {
/* 36 */     String triggerMessage = message.toLowerCase();
/*    */     Drink[] arrayOfDrink;
/* 38 */     int j = (arrayOfDrink = drinks).length; for (int i = 0; i < j; i++) { Drink drink = arrayOfDrink[i];
/* 39 */       if (triggerMessage.contains(Locale.get("drink." + drink.getTrigger()))) {
/* 40 */         if (entity.getPosition().distanceTo(getEntity()) >= 4.0D) {
/* 41 */           getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer(getEntity().getId(), Locale.get("bots.chat.tooFar").replace("%username%", entity.getUsername()), RoomManager.getInstance().getEmotions().getEmotion(":("), 2));
/* 42 */           return false;
/*    */         }
/*    */         
/* 45 */         entity.carryItem(drink.getHandItemId());
/*    */         
/* 47 */         getEntity().getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer(getEntity().getId(), Locale.get("bots.chat.giveItemMessage").replace("%username%", entity.getUsername()), RoomManager.getInstance().getEmotions().getEmotion(":)"), 2));
/* 48 */         return true;
/*    */       }
/*    */     }
/*    */     
/* 52 */     return false;
/*    */   }
/*    */   
/*    */   private static class Drink {
/*    */     private String trigger;
/*    */     private int handItemId;
/*    */     
/*    */     private Drink(String trigger, int handItemId) {
/* 60 */       this.trigger = trigger;
/* 61 */       this.handItemId = handItemId;
/*    */     }
/*    */     
/*    */     public String getTrigger() {
/* 65 */       return this.trigger;
/*    */     }
/*    */     
/*    */     public int getHandItemId() {
/* 69 */       return this.handItemId;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\ai\bots\WaiterAI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */