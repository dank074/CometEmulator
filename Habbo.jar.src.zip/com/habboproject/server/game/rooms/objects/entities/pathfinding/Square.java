/*   */ package com.habboproject.server.game.rooms.objects.entities.pathfinding;
/*   */ 
/*   */ public class Square {
/*   */   public int x;
/*   */   public int y;
/*   */   
/*   */   public Square(int x, int y) {
/* 8 */     this.x = x;
/* 9 */     this.y = y;
/*   */   }
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\pathfinding\Square.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */