/*     */ package com.habboproject.server.game.rooms.objects.entities.types.ai.bots;
/*     */ 
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.ai.AbstractBotAI;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.ActionMessageComposer;
/*     */ import com.habboproject.server.threads.ThreadManager;
/*     */ import com.habboproject.server.threads.executors.newbie.NewbieFrankSayEvent;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class NewbieAI extends AbstractBotAI
/*     */ {
/*  19 */   private final String[] phrases = {
/*  20 */     "<p style=\"color: #000\">Bem-vindo ao Habbo Hotel,<br/>{0}! - Sou Frank. Clique no <br/>chÃ£o para comeÃ§ar a caminhar. Entre<br/>e fique Ã  vontade.</p>", 
/*  21 */     "<p style=\"color: #000\">Nos prÃ³ximos dias vocÃª<br/>receberÃ¡ um monte de brindes super<br/>bacanas!</p>", 
/*  22 */     "<p style=\"color: #000\">LÃ¡ vai seu primeiro presente:<br/>uma geladeirinha que estÃ¡ sempre<br/>cheia! VocÃª a encontra no seu<br/>inventÃ¡rio.</p>", 
/*  23 */     "<p style=\"color: #000\">Coloque sua geladeira no<br/>chÃ£o e depois dÃª 2 cliques nela para<br/>pegar um refresco.</p>", 
/*  24 */     "<p style=\"color: #000\">AmanhÃ£ vocÃª receberÃ¡ um<br/>mascote sÃ³ seu: um gato, cachorro<br/>ou porquinho!</p>", 
/*  25 */     "<p style=\"color: #000\">AtÃ© amanhÃ£, {0}!</p>" };
/*     */   
/*     */ 
/*  28 */   private int currentStep = 1;
/*  29 */   private int tickToLeave = 0;
/*  30 */   private boolean nextStep = true;
/*  31 */   private PlayerEntity newbieEntity = null;
/*     */   
/*     */   public NewbieAI(RoomEntity entity) {
/*  34 */     super(entity);
/*     */   }
/*     */   
/*     */   public boolean onPlayerEnter(PlayerEntity entity)
/*     */   {
/*  39 */     if (entity.getId() == getNewbieEntity().getId()) {
/*  40 */       getEntity().moveTo(6, 11);
/*     */     }
/*     */     
/*  43 */     return false;
/*     */   }
/*     */   
/*     */   public void onTick()
/*     */   {
/*  48 */     if (getNewbieEntity() != null) {
/*  49 */       if (!getNewbieEntity().isWalking()) {
/*  50 */         int rotation = Position.calculateRotation(getEntity().getPosition(), getNewbieEntity().getPosition());
/*     */         
/*  52 */         if ((getEntity().getHeadRotation() != rotation) && (this.currentStep < 6)) {
/*  53 */           getEntity().lookTo(getNewbieEntity().getPosition());
/*     */         }
/*     */       }
/*     */       
/*  57 */       switch (this.currentStep) {
/*     */       case 1: 
/*  59 */         if ((this.nextStep) && (!getBotEntity().isWalking())) {
/*  60 */           this.nextStep = false;
/*  61 */           getNewbieEntity().getPlayer().getData().setNewbieStep("2");
/*  62 */           ThreadManager.getInstance().executeSchedule(new NewbieFrankSayEvent(this, this.phrases[0].replace("{0}", getNewbieEntity().getUsername())), 3L, TimeUnit.SECONDS);
/*     */         }
/*  64 */         break;
/*     */       case 2: 
/*  66 */         if (this.nextStep) {
/*  67 */           this.nextStep = false;
/*  68 */           getBotEntity().lookTo(getNewbieEntity().getPosition());
/*  69 */           ThreadManager.getInstance().executeSchedule(new NewbieFrankSayEvent(this, this.phrases[1]), 5L, TimeUnit.SECONDS);
/*     */         }
/*  71 */         break;
/*     */       case 3: 
/*  73 */         if (this.nextStep) {
/*  74 */           this.nextStep = false;
/*  75 */           ThreadManager.getInstance().executeSchedule(new NewbieFrankSayEvent(this, this.phrases[2]), 10L, TimeUnit.SECONDS);
/*     */         }
/*  77 */         break;
/*     */       case 4: 
/*  79 */         if (this.nextStep) {
/*  80 */           this.nextStep = false;
/*  81 */           ThreadManager.getInstance().executeSchedule(new NewbieFrankSayEvent(this, this.phrases[3]), 5L, TimeUnit.SECONDS);
/*  82 */           getNewbieEntity().getPlayer().getData().setNewbieStep("3");
/*     */         }
/*  84 */         break;
/*     */       case 5: 
/*  86 */         if (this.nextStep) {
/*  87 */           this.nextStep = false;
/*  88 */           ThreadManager.getInstance().executeSchedule(new com.habboproject.server.threads.executors.newbie.NewbieBubbleEvent(this, getNewbieEntity(), "helpBubble/add/BOTTOM_BAR_INVENTORY/nux.bot.info.inventory.1", 1), 2L, TimeUnit.SECONDS);
/*     */         }
/*  90 */         break;
/*     */       case 6: 
/*  92 */         if ((this.nextStep) && 
/*  93 */           (getNewbieEntity().getOnBubble() == 0) && (getNewbieEntity().getPlayer().getData().getNewbieStep().equals("4"))) {
/*  94 */           this.nextStep = false;
/*  95 */           getBotEntity().moveTo(5, 4);
/*     */         }
/*     */         
/*  98 */         break;
/*     */       case 7: 
/*     */       case 8: 
/*     */       case 9: 
/*     */       case 10: 
/*     */       case 11: 
/* 104 */         if (this.nextStep) {
/* 105 */           increaseStep();
/*     */         }
/* 107 */         break;
/*     */       case 12: 
/* 109 */         if (this.nextStep) {
/* 110 */           this.nextStep = false;
/* 111 */           ThreadManager.getInstance().executeSchedule(new NewbieFrankSayEvent(this, this.phrases[4]), 1L, TimeUnit.SECONDS);
/*     */         }
/* 113 */         break;
/*     */       case 13: 
/* 115 */         if (this.nextStep) {
/* 116 */           this.nextStep = false;
/* 117 */           ThreadManager.getInstance().executeSchedule(new NewbieFrankSayEvent(this, this.phrases[5].replace("{0}", getNewbieEntity().getUsername())), 5L, TimeUnit.SECONDS);
/*     */         }
/* 119 */         break;
/*     */       case 14: 
/* 121 */         if (this.nextStep) {
/* 122 */           this.nextStep = false;
/* 123 */           getEntity().getRoom().getEntities().broadcastMessage(new ActionMessageComposer(getEntity().getId(), 1));
/* 124 */           ThreadManager.getInstance().executeSchedule(new com.habboproject.server.threads.executors.newbie.NewbieFrankLeaveEvent(this, getNewbieEntity()), 2L, TimeUnit.SECONDS);
/*     */         }
/* 126 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/* 131 */       if ((this.currentStep >= 7) && (this.currentStep <= 11)) {
/* 132 */         this.nextStep = true;
/*     */       }
/* 134 */       if ((this.currentStep == 6) && (getNewbieEntity().isWalking())) {
/* 135 */         increaseStep();
/* 136 */       } else if ((this.currentStep == 6) && (!getNewbieEntity().isWalking()) && (getNewbieEntity().getOnBubble() == 0) && 
/* 137 */         (getNewbieEntity().getPlayer().getData().getNewbieStep().equals("4"))) {
/* 138 */         getBotEntity().moveTo(5, 4);
/* 139 */         increaseStep();
/*     */       }
/*     */     }
/*     */     
/* 143 */     if (this.tickToLeave >= 10) {
/* 144 */       getBotEntity().leaveRoom();
/*     */     }
/*     */     
/* 147 */     if ((getNewbieEntity() == null) || (getNewbieEntity().getPlayer() == null) || (getNewbieEntity().getPlayer().getSession() == null) || 
/* 148 */       (getNewbieEntity().getRoom() == null) || (getNewbieEntity().getRoom().getId() != getBotEntity().getRoom().getId())) {
/* 149 */       this.tickToLeave += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public void increaseStep() {
/* 154 */     this.currentStep += 1;
/*     */   }
/*     */   
/*     */   public PlayerEntity getNewbieEntity() {
/* 158 */     return this.newbieEntity;
/*     */   }
/*     */   
/*     */   public void setNewbieEntity(PlayerEntity newbieEntity) {
/* 162 */     this.newbieEntity = newbieEntity;
/*     */   }
/*     */   
/*     */   public void setNextStep(boolean nextStep) {
/* 166 */     this.nextStep = nextStep;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\ai\bots\NewbieAI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */