/*    */ package com.habboproject.server.game.rooms.objects.entities;
/*    */ 
/*    */ public enum RoomEntityStatus {
/*  4 */   SIT("sit"), 
/*  5 */   MOVE("mv"), 
/*  6 */   LAY("lay"), 
/*  7 */   SIGN("sign"), 
/*  8 */   CONTROLLER("flatctrl"), 
/*  9 */   TRADE("trd"), 
/* 10 */   VOTE("vote"), 
/* 11 */   GESTURE("gst"), 
/* 12 */   PLAY("pla"), 
/* 13 */   PLAY_DEAD("ded"), 
/* 14 */   JUMP("jmp");
/*    */   
/*    */   private final String statusCode;
/*    */   
/*    */   private RoomEntityStatus(String statusCode) {
/* 19 */     this.statusCode = statusCode;
/*    */   }
/*    */   
/*    */   public String getStatusCode() {
/* 23 */     return this.statusCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\RoomEntityStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */