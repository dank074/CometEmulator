package com.habboproject.server.game.rooms.objects.entities;

import com.habboproject.server.game.players.types.Player;

public abstract interface PlayerEntityAccess
{
  public abstract Player getPlayer();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\PlayerEntityAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */