package com.habboproject.server.game.rooms.objects.entities;

import com.habboproject.server.api.networking.messages.IComposer;
import com.habboproject.server.game.rooms.objects.entities.effects.PlayerEffect;
import com.habboproject.server.game.rooms.objects.entities.pathfinding.Square;
import com.habboproject.server.game.rooms.objects.misc.Position;
import com.habboproject.server.utilities.attributes.Attributable;
import java.util.List;
import java.util.Map;

public abstract interface AvatarEntity
  extends Attributable
{
  public abstract int getId();
  
  public abstract Position getWalkingGoal();
  
  public abstract void setWalkingGoal(int paramInt1, int paramInt2);
  
  public abstract Position getPositionToSet();
  
  public abstract void updateAndSetPosition(Position paramPosition);
  
  public abstract void markPositionIsSet();
  
  public abstract int getBodyRotation();
  
  public abstract void setBodyRotation(int paramInt);
  
  public abstract int getHeadRotation();
  
  public abstract void setHeadRotation(int paramInt);
  
  public abstract List<Square> getWalkingPath();
  
  public abstract void setWalkingPath(List<Square> paramList);
  
  public abstract List<Square> getProcessingPath();
  
  public abstract void setProcessingPath(List<Square> paramList);
  
  public abstract boolean isWalking();
  
  public abstract Square getFutureSquare();
  
  public abstract void setFutureSquare(Square paramSquare);
  
  public abstract void moveTo(int paramInt1, int paramInt2);
  
  public abstract Map<RoomEntityStatus, String> getStatuses();
  
  public abstract void addStatus(RoomEntityStatus paramRoomEntityStatus, String paramString);
  
  public abstract void removeStatus(RoomEntityStatus paramRoomEntityStatus);
  
  public abstract boolean hasStatus(RoomEntityStatus paramRoomEntityStatus);
  
  public abstract void markNeedsUpdate();
  
  public abstract boolean needsUpdate();
  
  public abstract void setIdle();
  
  public abstract int getIdleTime();
  
  public abstract boolean isIdleAndIncrement();
  
  public abstract void resetIdleTime();
  
  public abstract int getDanceId();
  
  public abstract void setDanceId(int paramInt);
  
  public abstract int getSignTime();
  
  public abstract void markDisplayingSign();
  
  public abstract boolean isDisplayingSign();
  
  public abstract boolean isOverriden();
  
  public abstract void setOverriden(boolean paramBoolean);
  
  public abstract PlayerEffect getCurrentEffect();
  
  public abstract void applyEffect(PlayerEffect paramPlayerEffect);
  
  public abstract void carryItem(int paramInt);
  
  public abstract void carryItem(int paramInt, boolean paramBoolean);
  
  public abstract int getHandItem();
  
  public abstract boolean handItemNeedsRemove();
  
  public abstract int getHandItemTimer();
  
  public abstract void setHandItemTimer(int paramInt);
  
  public abstract String getUsername();
  
  public abstract String getMotto();
  
  public abstract String getFigure();
  
  public abstract String getGender();
  
  public abstract void compose(IComposer paramIComposer);
  
  public abstract void warp(Position paramPosition);
  
  public abstract void warpImmediately(Position paramPosition);
  
  public abstract void kick();
  
  public abstract long getJoinTime();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\AvatarEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */