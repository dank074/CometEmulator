/*    */ package com.habboproject.server.game.rooms.objects.entities.pathfinding.types;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.Pathfinder;
/*    */ 
/*    */ public class EntityPathfinder extends Pathfinder {
/*    */   private static EntityPathfinder pathfinderInstance;
/*    */   
/*    */   public static EntityPathfinder getInstance() {
/*  9 */     if (pathfinderInstance == null) {
/* 10 */       pathfinderInstance = new EntityPathfinder();
/*    */     }
/*    */     
/* 13 */     return pathfinderInstance;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\pathfinding\types\EntityPathfinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */