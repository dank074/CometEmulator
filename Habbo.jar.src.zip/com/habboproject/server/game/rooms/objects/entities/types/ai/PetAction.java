package com.habboproject.server.game.rooms.objects.entities.types.ai;

public enum PetAction
{
  WALK,  TALK,  SIT,  LAY,  PLAY;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\ai\PetAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */