package com.habboproject.server.game.rooms.objects.entities;

public enum RoomEntityType
{
  PLAYER,  BOT,  PET;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\RoomEntityType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */