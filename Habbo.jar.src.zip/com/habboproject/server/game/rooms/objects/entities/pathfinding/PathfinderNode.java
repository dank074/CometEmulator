/*    */ package com.habboproject.server.game.rooms.objects.entities.pathfinding;
/*    */ 
/*    */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*    */ 
/*    */ public class PathfinderNode
/*    */   implements Comparable<PathfinderNode>
/*    */ {
/*    */   private Position position;
/*    */   private PathfinderNode nextNode;
/* 10 */   private Integer cost = Integer.valueOf(Integer.MAX_VALUE);
/* 11 */   private boolean inOpen = false;
/* 12 */   private boolean inClosed = false;
/*    */   
/*    */   public Position getPosition() {
/* 15 */     return this.position;
/*    */   }
/*    */   
/*    */   public void setPosition(Position position) {
/* 19 */     this.position = position;
/*    */   }
/*    */   
/*    */   public PathfinderNode getNextNode() {
/* 23 */     return this.nextNode;
/*    */   }
/*    */   
/*    */   public void setNextNode(PathfinderNode nextNode) {
/* 27 */     this.nextNode = nextNode;
/*    */   }
/*    */   
/*    */   public Integer getCost() {
/* 31 */     return this.cost;
/*    */   }
/*    */   
/*    */   public void setCost(int cost) {
/* 35 */     this.cost = Integer.valueOf(cost);
/*    */   }
/*    */   
/*    */   public boolean isInOpen() {
/* 39 */     return this.inOpen;
/*    */   }
/*    */   
/*    */   public void setInOpen(boolean inOpen) {
/* 43 */     this.inOpen = inOpen;
/*    */   }
/*    */   
/*    */   public boolean isInClosed() {
/* 47 */     return this.inClosed;
/*    */   }
/*    */   
/*    */   public void setInClosed(boolean inClosed) {
/* 51 */     this.inClosed = inClosed;
/*    */   }
/*    */   
/*    */   public PathfinderNode(Position current) {
/* 55 */     this.position = current;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 60 */     return ((obj instanceof PathfinderNode)) && (((PathfinderNode)obj).getPosition().equals(this.position));
/*    */   }
/*    */   
/*    */   public boolean equals(PathfinderNode node) {
/* 64 */     return node.getPosition().equals(this.position);
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 69 */     return this.position.hashCode();
/*    */   }
/*    */   
/*    */   public int compareTo(PathfinderNode o)
/*    */   {
/* 74 */     return getCost().compareTo(o.getCost());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\pathfinding\PathfinderNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */