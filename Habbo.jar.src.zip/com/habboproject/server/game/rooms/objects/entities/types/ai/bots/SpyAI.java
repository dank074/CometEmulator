/*    */ package com.habboproject.server.game.rooms.objects.entities.types.ai.bots;
/*    */ 
/*    */ import com.habboproject.server.config.Locale;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.BotEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
/*    */ import com.habboproject.server.game.rooms.objects.entities.types.data.types.SpyBotData;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SpyAI extends com.habboproject.server.game.rooms.objects.entities.types.ai.AbstractBotAI
/*    */ {
/* 11 */   private boolean hasSaidYes = false;
/*    */   
/*    */   public SpyAI(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity) {
/* 14 */     super(entity);
/*    */   }
/*    */   
/*    */   public boolean onPlayerEnter(PlayerEntity playerEntity)
/*    */   {
/* 19 */     if (playerEntity.getPlayerId() != getBotEntity().getData().getOwnerId()) {
/* 20 */       if (!((SpyBotData)getBotEntity().getDataObject()).getVisitors().contains(playerEntity.getUsername())) {
/* 21 */         ((SpyBotData)getBotEntity().getDataObject()).getVisitors().add(playerEntity.getUsername());
/*    */       }
/*    */     }
/* 24 */     else if (((SpyBotData)getBotEntity().getDataObject()).getVisitors().size() == 0) {
/* 25 */       getBotEntity().say(Locale.getOrDefault("comet.game.bot.spy.noVisitors", "There have been no visitors while you've been away!!!"));
/* 26 */       this.hasSaidYes = true;
/*    */     } else {
/* 28 */       getBotEntity().say(Locale.getOrDefault("comet.game.bot.spy.sayYes", "Nice to see you Sir! Please say yes if you'd like me to tell who have visited room while you've been gone."));
/* 29 */       this.hasSaidYes = false;
/*    */     }
/*    */     
/*    */ 
/* 33 */     return false;
/*    */   }
/*    */   
/*    */   public boolean onTalk(PlayerEntity entity, String message)
/*    */   {
/* 38 */     if (this.hasSaidYes) {
/* 39 */       return false;
/*    */     }
/*    */     
/* 42 */     if ((entity.getPlayerId() == getBotEntity().getData().getOwnerId()) && (
/* 43 */       (message.equals("yes")) || (message.equals("oui")) || (message.equals("sim")) || (message.equals("ya")) || (message.equals(Locale.getOrDefault("comet.game.bot.yes", "yes"))))) {
/* 44 */       String stillIn = "";
/* 45 */       String left = "";
/*    */       
/* 47 */       for (String username : ((SpyBotData)getBotEntity().getDataObject()).getVisitors()) {
/* 48 */         boolean isLast = ((SpyBotData)getBotEntity().getDataObject()).getVisitors().indexOf(username) == ((SpyBotData)getBotEntity().getDataObject()).getVisitors().size() - 1;
/*    */         
/* 50 */         if (getBotEntity().getRoom().getEntities().getEntityByName(username, com.habboproject.server.game.rooms.objects.entities.RoomEntityType.PLAYER) != null) {
/* 51 */           if (isLast) {
/* 52 */             stillIn = stillIn + username + (stillIn.equals("") ? Locale.getOrDefault("comet.game.bot.spy.stillInRoom.single", " is still in the room") : Locale.getOrDefault("comet.game.bot.spy.stillInRoom.multiple", " are still in the room"));
/*    */           } else {
/* 54 */             stillIn = stillIn + username + ", ";
/*    */           }
/*    */         }
/* 57 */         else if (isLast) {
/* 58 */           left = left + username + (left.equals("") ? Locale.getOrDefault("comet.game.bot.spy.leftRoom.single", " has left") : Locale.getOrDefault("comet.game.bot.spy.leftRoom.multiple", " have left"));
/*    */         } else {
/* 60 */           left = left + username + ", ";
/*    */         }
/*    */       }
/*    */       
/*    */ 
/* 65 */       if (!left.equals("")) {
/* 66 */         getBotEntity().say(left);
/*    */       }
/*    */       
/* 69 */       if (!stillIn.equals("")) {
/* 70 */         getBotEntity().say(stillIn);
/*    */       }
/*    */       
/* 73 */       ((SpyBotData)getBotEntity().getDataObject()).getVisitors().clear();
/* 74 */       getBotEntity().saveDataObject();
/* 75 */       this.hasSaidYes = true;
/*    */     }
/*    */     
/* 78 */     return false;
/*    */   }
/*    */   
/*    */   public boolean onPlayerLeave(PlayerEntity entity)
/*    */   {
/* 83 */     if (entity.getPlayerId() == getBotEntity().getData().getOwnerId()) {
/* 84 */       this.hasSaidYes = false;
/*    */     }
/*    */     
/* 87 */     return false;
/*    */   }
/*    */   
/*    */   public boolean onAddedToRoom()
/*    */   {
/* 92 */     getBotEntity().say(Locale.getOrDefault("comet.game.bot.spy.addedToRoom", "Hi! Next time you enter the room, I'll let you know who visited while you were away.."));
/* 93 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\ai\bots\SpyAI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */