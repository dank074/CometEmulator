/*     */ package com.habboproject.server.game.rooms.objects.entities.types;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.bots.BotData;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.ai.BotAI;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.ai.bots.DefaultAI;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.ai.bots.MinionAI;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.data.BotDataObject;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.data.types.SpyBotData;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.RoomData;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.game.rooms.types.misc.ChatEmotion;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.LeaveRoomMessageComposer;
/*     */ import com.habboproject.server.utilities.JsonFactory;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class BotEntity extends RoomEntity
/*     */ {
/*     */   private BotData data;
/*  24 */   private int cycleCount = 0;
/*     */   
/*     */   private BotAI ai;
/*     */   
/*     */   private BotDataObject dataObject;
/*  29 */   private Map<String, Object> attributes = new java.util.concurrent.ConcurrentHashMap();
/*     */   
/*     */   public BotEntity(BotData data, int identifier, Position startPosition, int startBodyRotation, int startHeadRotation, Room roomInstance) {
/*  32 */     super(identifier, startPosition, startBodyRotation, startHeadRotation, roomInstance);
/*     */     
/*  34 */     this.data = data;
/*     */     String str;
/*  36 */     switch ((str = data.getBotType()).hashCode()) {case -1048842402:  if (str.equals("newbie")) break label246; break; case -795274014:  if (str.equals("waiter")) break label148; break; case 114108:  if (str.equals("spy")) break label178; break; case 103899947:  if (str.equals("mimic"))
/*     */         break label163; }
/*  38 */     this.ai = new DefaultAI(this);
/*  39 */     return;
/*     */     
/*     */     label148:
/*  42 */     this.ai = new com.habboproject.server.game.rooms.objects.entities.types.ai.bots.WaiterAI(this);
/*  43 */     return;
/*     */     
/*     */     label163:
/*  46 */     this.ai = new MinionAI(this);
/*  47 */     return;
/*     */     
/*     */     label178:
/*  50 */     this.ai = new com.habboproject.server.game.rooms.objects.entities.types.ai.bots.SpyAI(this);
/*     */     
/*  52 */     if (this.data.getData() == null) {
/*  53 */       this.dataObject = new SpyBotData(new java.util.LinkedList());
/*     */     } else {
/*  55 */       this.dataObject = ((BotDataObject)JsonFactory.getInstance().fromJson(this.data.getData(), SpyBotData.class));
/*     */       
/*     */ 
/*  58 */       return;
/*     */       
/*     */       label246:
/*  61 */       this.ai = new com.habboproject.server.game.rooms.objects.entities.types.ai.bots.NewbieAI(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void say(String message)
/*     */   {
/*  67 */     getRoom().getEntities().broadcastMessage(new com.habboproject.server.network.messages.outgoing.room.avatar.TalkMessageComposer(getId(), message, ChatEmotion.NONE, 2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void joinRoom(Room room, String password) {}
/*     */   
/*     */ 
/*     */ 
/*     */   protected void finalizeJoinRoom() {}
/*     */   
/*     */ 
/*     */   public void leaveRoom()
/*     */   {
/*  81 */     leaveRoom(false, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public void leaveRoom(boolean isOffline, boolean isKick, boolean toHotelView)
/*     */   {
/*  87 */     getRoom().getEntities().broadcastMessage(new LeaveRoomMessageComposer(getId()));
/*     */     
/*     */ 
/*  90 */     getRoom().getEntities().removeEntity(this);
/*  91 */     getRoom().getBots().removeBot(getUsername());
/*     */     
/*  93 */     this.data.dispose();
/*  94 */     this.data = null;
/*     */     
/*  96 */     this.attributes.clear();
/*     */   }
/*     */   
/*     */   public boolean onChat(String message)
/*     */   {
/* 101 */     return false;
/*     */   }
/*     */   
/*     */   public void saveDataObject() {
/* 105 */     if (this.dataObject != null) {
/* 106 */       this.data.setData(JsonFactory.getInstance().toJson(this.dataObject));
/* 107 */       this.data.save();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean onRoomDispose()
/*     */   {
/* 114 */     getRoom().getEntities().broadcastMessage(new LeaveRoomMessageComposer(getId()));
/*     */     
/* 116 */     saveDataObject();
/*     */     
/* 118 */     this.data.dispose();
/* 119 */     this.data = null;
/*     */     
/* 121 */     this.attributes.clear();
/*     */     
/* 123 */     return true;
/*     */   }
/*     */   
/*     */   public String getUsername()
/*     */   {
/* 128 */     return this.data.getUsername();
/*     */   }
/*     */   
/*     */   public String getMotto()
/*     */   {
/* 133 */     return this.data.getMotto();
/*     */   }
/*     */   
/*     */   public String getFigure()
/*     */   {
/* 138 */     return this.data.getFigure();
/*     */   }
/*     */   
/*     */   public String getGender()
/*     */   {
/* 143 */     return this.data.getGender();
/*     */   }
/*     */   
/*     */   public int getBotId() {
/* 147 */     return this.data.getId();
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg)
/*     */   {
/* 152 */     msg.writeInt(getBotId());
/* 153 */     msg.writeString(getUsername());
/* 154 */     msg.writeString(getMotto());
/* 155 */     msg.writeString(getFigure());
/* 156 */     msg.writeInt(getId());
/*     */     
/* 158 */     msg.writeInt(getPosition().getX());
/* 159 */     msg.writeInt(getPosition().getY());
/* 160 */     msg.writeDouble(getPosition().getZ());
/* 161 */     msg.writeInt(0);
/* 162 */     msg.writeInt(4);
/*     */     
/* 164 */     msg.writeString(getGender().toLowerCase());
/* 165 */     msg.writeInt(getRoom().getData().getOwnerId());
/* 166 */     msg.writeString(getRoom().getData().getOwner());
/*     */     
/* 168 */     msg.writeInt(5);
/* 169 */     msg.writeShort(1);
/* 170 */     msg.writeShort(2);
/* 171 */     msg.writeShort(4);
/* 172 */     msg.writeShort(5);
/* 173 */     msg.writeShort(3);
/*     */   }
/*     */   
/*     */   public BotData getData() {
/* 177 */     return this.data;
/*     */   }
/*     */   
/*     */   public int getCycleCount() {
/* 181 */     return this.cycleCount;
/*     */   }
/*     */   
/*     */   public void decrementCycleCount() {
/* 185 */     this.cycleCount -= 1;
/*     */   }
/*     */   
/*     */   public void incrementCycleCount() {
/* 189 */     this.cycleCount += 1;
/*     */   }
/*     */   
/*     */   public void resetCycleCount() {
/* 193 */     this.cycleCount = 0;
/*     */   }
/*     */   
/*     */   public BotAI getAI() {
/* 197 */     return this.ai;
/*     */   }
/*     */   
/*     */   public void setAttribute(String attributeKey, Object attributeValue)
/*     */   {
/* 202 */     if (this.attributes.containsKey(attributeKey)) {
/* 203 */       this.attributes.replace(attributeKey, attributeValue);
/*     */     } else {
/* 205 */       this.attributes.put(attributeKey, attributeValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getAttribute(String attributeKey)
/*     */   {
/* 211 */     return this.attributes.get(attributeKey);
/*     */   }
/*     */   
/*     */   public boolean hasAttribute(String attributeKey)
/*     */   {
/* 216 */     return this.attributes.containsKey(attributeKey);
/*     */   }
/*     */   
/*     */   public void removeAttribute(String attributeKey)
/*     */   {
/* 221 */     this.attributes.remove(attributeKey);
/*     */   }
/*     */   
/*     */   public BotDataObject getDataObject() {
/* 225 */     return this.dataObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\BotEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */