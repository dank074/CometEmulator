/*     */ package com.habboproject.server.game.rooms.objects.entities.pathfinding;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class AffectedTile
/*     */ {
/*     */   public int x;
/*     */   public int y;
/*     */   
/*     */   public AffectedTile(int x, int y)
/*     */   {
/*  15 */     this.x = x;
/*  16 */     this.y = y;
/*     */   }
/*     */   
/*     */   public static List<AffectedTile> getAffectedBothTilesAt(int length, int width, int posX, int posY, int rotation) {
/*  20 */     List<AffectedTile> pointList = new ArrayList();
/*     */     
/*  22 */     pointList.add(new AffectedTile(posX, posY));
/*     */     
/*  24 */     if (length > 1) {
/*  25 */       if ((rotation == 0) || (rotation == 4)) {
/*  26 */         for (int i = 1; i < length; i++) {
/*  27 */           pointList.add(new AffectedTile(posX, posY + i));
/*     */           
/*  29 */           for (int j = 1; j < width; j++) {
/*  30 */             pointList.add(new AffectedTile(posX + j, posY + i));
/*     */           }
/*     */         }
/*  33 */       } else if ((rotation == 2) || (rotation == 6)) {
/*  34 */         for (int i = 1; i < length; i++) {
/*  35 */           pointList.add(new AffectedTile(posX + i, posY));
/*     */           
/*  37 */           for (int j = 1; j < width; j++) {
/*  38 */             pointList.add(new AffectedTile(posX + i, posY + j));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  44 */     if (width > 1) {
/*  45 */       if ((rotation == 0) || (rotation == 4)) {
/*  46 */         for (int i = 1; i < width; i++) {
/*  47 */           pointList.add(new AffectedTile(posX + i, posY));
/*     */           
/*  49 */           for (int j = 1; j < length; j++) {
/*  50 */             pointList.add(new AffectedTile(posX + i, posY + j));
/*     */           }
/*     */         }
/*  53 */       } else if ((rotation == 2) || (rotation == 6)) {
/*  54 */         for (int i = 1; i < width; i++) {
/*  55 */           pointList.add(new AffectedTile(posX, posY + i));
/*     */           
/*  57 */           for (int j = 1; j < length; j++) {
/*  58 */             pointList.add(new AffectedTile(posX + j, posY + i));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  64 */     return pointList;
/*     */   }
/*     */   
/*     */   public static List<AffectedTile> getAffectedTilesAt(int length, int width, int posX, int posY, int rotation) {
/*  68 */     List<AffectedTile> pointList = new ArrayList();
/*     */     
/*  70 */     if (length > 1) {
/*  71 */       if ((rotation == 0) || (rotation == 4)) {
/*  72 */         for (int i = 1; i < length; i++) {
/*  73 */           pointList.add(new AffectedTile(posX, posY + i));
/*     */           
/*  75 */           for (int j = 1; j < width; j++) {
/*  76 */             pointList.add(new AffectedTile(posX + j, posY + i));
/*     */           }
/*     */         }
/*  79 */       } else if ((rotation == 2) || (rotation == 6)) {
/*  80 */         for (int i = 1; i < length; i++) {
/*  81 */           pointList.add(new AffectedTile(posX + i, posY));
/*     */           
/*  83 */           for (int j = 1; j < width; j++) {
/*  84 */             pointList.add(new AffectedTile(posX + i, posY + j));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  90 */     if (width > 1) {
/*  91 */       if ((rotation == 0) || (rotation == 4)) {
/*  92 */         for (int i = 1; i < width; i++) {
/*  93 */           pointList.add(new AffectedTile(posX + i, posY));
/*     */           
/*  95 */           for (int j = 1; j < length; j++) {
/*  96 */             pointList.add(new AffectedTile(posX + i, posY + j));
/*     */           }
/*     */         }
/*  99 */       } else if ((rotation == 2) || (rotation == 6)) {
/* 100 */         for (int i = 1; i < width; i++) {
/* 101 */           pointList.add(new AffectedTile(posX, posY + i));
/*     */           
/* 103 */           for (int j = 1; j < length; j++) {
/* 104 */             pointList.add(new AffectedTile(posX + j, posY + i));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 110 */     return pointList;
/*     */   }
/*     */   
/*     */   public static List<AffectedTile> getAffectedTilesByExplosion(int radius, RoomItemFloor floorItem, boolean isDiagonal) {
/* 114 */     ArrayList<AffectedTile> affectedTiles = com.google.common.collect.Lists.newArrayList();
/*     */     
/* 116 */     affectedTiles.add(new AffectedTile(floorItem.getPosition().getX(), floorItem.getPosition().getY()));
/*     */     
/* 118 */     int i = 0;
/* 119 */     while (i < 4) {
/* 120 */       Position position = floorItem.getPosition().copy();
/*     */       
/* 122 */       int j = 0;
/* 123 */       while (j < radius) {
/* 124 */         int rotation = !isDiagonal ? i * 2 : i * 2 + 1;
/*     */         
/* 126 */         position = position.squareInFront(rotation);
/*     */         
/* 128 */         if (floorItem.getRoom().getMapping().isValidPosition(position)) {
/* 129 */           affectedTiles.add(new AffectedTile(position.getX(), position.getY()));
/*     */         }
/*     */         
/* 132 */         j++;
/*     */       }
/*     */       
/* 135 */       i++;
/*     */     }
/*     */     
/* 138 */     return affectedTiles;
/*     */   }
/*     */   
/*     */   public static boolean tilesAdjecent(Position one, Position two) {
/* 142 */     return tilesAdjecent(one.getX(), one.getY(), two.getX(), two.getY());
/*     */   }
/*     */   
/*     */   public static boolean tilesAdjecent(int x1, int y1, int x2, int y2) {
/* 146 */     if (((Math.abs(x1 - x2) > 1) || (Math.abs(y1 - y2) > 1)) && ((x1 != x2) || (y1 != y2))) {
/* 147 */       return false;
/*     */     }
/*     */     
/* 150 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\pathfinding\AffectedTile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */