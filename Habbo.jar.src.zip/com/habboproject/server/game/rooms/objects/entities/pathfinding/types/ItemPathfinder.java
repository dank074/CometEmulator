/*     */ package com.habboproject.server.game.rooms.objects.entities.pathfinding.types;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.models.RoomModel;
/*     */ import com.habboproject.server.game.rooms.objects.RoomObject;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.pathfinding.Pathfinder;
/*     */ import com.habboproject.server.game.rooms.objects.items.RoomItemFloor;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.groups.GroupGateFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.wired.actions.WiredActionChase;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomEntityMovementNode;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomMapping;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomTile;
/*     */ import com.habboproject.server.game.rooms.types.tiles.RoomTileState;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ItemPathfinder extends Pathfinder
/*     */ {
/*     */   private static ItemPathfinder pathfinderInstance;
/*     */   
/*     */   public static ItemPathfinder getInstance()
/*     */   {
/*  24 */     if (pathfinderInstance == null) {
/*  25 */       pathfinderInstance = new ItemPathfinder();
/*     */     }
/*  27 */     return pathfinderInstance;
/*     */   }
/*     */   
/*     */   public boolean isValidStep(RoomObject roomFloorObject, Position from, Position to, boolean lastStep, boolean isRetry)
/*     */   {
/*  32 */     if ((from.getX() == to.getX()) && (from.getY() == to.getY())) {
/*  33 */       return true;
/*     */     }
/*     */     
/*  36 */     if (to.getX() >= roomFloorObject.getRoom().getModel().getSquareState().length) {
/*  37 */       return false;
/*     */     }
/*     */     
/*  40 */     if ((!roomFloorObject.getRoom().getMapping().isValidPosition(to)) || (roomFloorObject.getRoom().getModel().getSquareState()[to.getX()][to.getY()] == RoomTileState.INVALID)) {
/*  41 */       return false;
/*     */     }
/*     */     
/*  44 */     int rotation = Position.calculateRotation(from, to);
/*     */     
/*  46 */     if ((rotation == 1) || (rotation == 3) || (rotation == 5) || (rotation == 7)) {
/*  47 */       RoomTile left = null;
/*  48 */       RoomTile right = null;
/*     */       
/*  50 */       switch (rotation) {
/*     */       case 1: 
/*  52 */         left = roomFloorObject.getRoom().getMapping().getTile(from.squareInFront(rotation + 1));
/*  53 */         right = roomFloorObject.getRoom().getMapping().getTile(to.squareBehind(rotation + 1));
/*  54 */         break;
/*     */       
/*     */       case 3: 
/*  57 */         left = roomFloorObject.getRoom().getMapping().getTile(to.squareBehind(rotation + 1));
/*  58 */         right = roomFloorObject.getRoom().getMapping().getTile(to.squareBehind(rotation - 1));
/*  59 */         break;
/*     */       
/*     */       case 5: 
/*  62 */         left = roomFloorObject.getRoom().getMapping().getTile(from.squareInFront(rotation - 1));
/*  63 */         right = roomFloorObject.getRoom().getMapping().getTile(to.squareBehind(rotation - 1));
/*  64 */         break;
/*     */       
/*     */       case 7: 
/*  67 */         left = roomFloorObject.getRoom().getMapping().getTile(to.squareBehind(0));
/*  68 */         right = roomFloorObject.getRoom().getMapping().getTile(from.squareInFront(rotation - 1));
/*     */       }
/*     */       
/*     */       
/*  72 */       if ((left != null) && (right != null) && 
/*  73 */         (left.getMovementNode() != RoomEntityMovementNode.OPEN) && (right.getMovementNode() != RoomEntityMovementNode.OPEN)) {
/*  74 */         return false;
/*     */       }
/*     */     }
/*     */     
/*  78 */     RoomTile tile = roomFloorObject.getRoom().getMapping().getTile(to.getX(), to.getY());
/*     */     
/*  80 */     if (tile == null) {
/*  81 */       return false;
/*     */     }
/*     */     
/*  84 */     if ((roomFloorObject instanceof com.habboproject.server.game.rooms.objects.items.types.floor.football.FootballFloorItem)) {
/*  85 */       for (RoomItemFloor floor : tile.getItems()) {
/*  86 */         if ((floor instanceof GroupGateFloorItem)) {
/*  87 */           return false;
/*     */         }
/*     */       }
/*     */       
/*  91 */       if (tile.getItems().size() == 1) {
/*  92 */         return (tile.getStackHeight(null) <= 0.5D) && (tile.canPlaceItemHere());
/*     */       }
/*     */     }
/*     */     
/*  96 */     if ((roomFloorObject instanceof WiredActionChase)) {
/*  97 */       int target = ((WiredActionChase)roomFloorObject).getTargetId();
/*     */       
/*  99 */       if (target != -1) {
/* 100 */         for (RoomEntity entity : tile.getEntities()) {
/* 101 */           if (entity.getId() != target) {
/* 102 */             return false;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 108 */     if (((roomFloorObject instanceof com.habboproject.server.game.rooms.objects.items.types.floor.rollable.RollableFloorItem)) && 
/* 109 */       (tile.getEntities().size() > 0)) { return false;
/*     */     }
/*     */     
/* 112 */     if ((tile.getMovementNode() == RoomEntityMovementNode.CLOSED) || ((tile.getMovementNode() == RoomEntityMovementNode.END_OF_ROUTE) && (!lastStep))) {
/* 113 */       return false;
/*     */     }
/*     */     
/* 116 */     double fromHeight = roomFloorObject.getRoom().getMapping().getStepHeight(from);
/* 117 */     double toHeight = roomFloorObject.getRoom().getMapping().getStepHeight(to);
/*     */     
/* 119 */     if ((fromHeight < toHeight) && (toHeight - fromHeight > 1.0D)) { return false;
/*     */     }
/* 121 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\pathfinding\types\ItemPathfinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */