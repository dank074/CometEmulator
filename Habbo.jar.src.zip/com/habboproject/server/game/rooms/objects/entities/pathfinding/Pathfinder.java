/*     */ package com.habboproject.server.game.rooms.objects.entities.pathfinding;
/*     */ 
/*     */ import com.google.common.collect.MinMaxPriorityQueue;
/*     */ import com.habboproject.server.game.rooms.models.RoomModel;
/*     */ import com.habboproject.server.game.rooms.objects.RoomObject;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.mapping.RoomMapping;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class Pathfinder
/*     */ {
/*     */   public static final byte DISABLE_DIAGONAL = 0;
/*     */   public static final byte ALLOW_DIAGONAL = 1;
/*     */   
/*     */   public List<Square> makePath(RoomObject roomFloorObject, Position end)
/*     */   {
/*  19 */     return makePath(roomFloorObject, end, (byte)1, false);
/*     */   }
/*     */   
/*     */   public List<Square> makePath(RoomObject roomFloorObject, Position end, byte pathfinderMode, boolean isRetry) {
/*  23 */     List<Square> squares = new java.util.concurrent.CopyOnWriteArrayList();
/*     */     
/*  25 */     PathfinderNode nodes = makePathReversed(roomFloorObject, end, pathfinderMode, isRetry);
/*     */     
/*  27 */     if (nodes != null) {
/*  28 */       while (nodes.getNextNode() != null) {
/*  29 */         squares.add(new Square(nodes.getPosition().getX(), nodes.getPosition().getY()));
/*  30 */         nodes = nodes.getNextNode();
/*     */       }
/*     */     }
/*     */     
/*  34 */     return com.google.common.collect.Lists.reverse(squares);
/*     */   }
/*     */   
/*     */   private PathfinderNode makePathReversed(RoomObject roomFloorObject, Position end, byte pathfinderMode, boolean isRetry) {
/*  38 */     MinMaxPriorityQueue<PathfinderNode> openList = MinMaxPriorityQueue.maximumSize(256).create();
/*     */     
/*  40 */     PathfinderNode[][] map = new PathfinderNode[roomFloorObject.getRoom().getMapping().getModel().getSizeX()][roomFloorObject.getRoom().getMapping().getModel().getSizeY()];
/*  41 */     PathfinderNode node = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */     PathfinderNode current = new PathfinderNode(roomFloorObject.getPosition());
/*  48 */     current.setCost(0);
/*     */     
/*  50 */     PathfinderNode finish = new PathfinderNode(end);
/*     */     
/*  52 */     map[current.getPosition().getX()][current.getPosition().getY()] = current;
/*  53 */     openList.add(current);
/*     */     int i;
/*  55 */     for (; openList.size() > 0; 
/*     */         
/*     */ 
/*     */ 
/*  59 */         i < (pathfinderMode == 1 ? this.diagonalMovePoints.length : this.movePoints.length))
/*     */     {
/*  56 */       current = (PathfinderNode)openList.pollFirst();
/*  57 */       current.setInClosed(true);
/*     */       
/*  59 */       i = 0; continue;
/*  60 */       Position tmp = current.getPosition().add(this.movePoints[i]);
/*  61 */       boolean isFinalMove = (tmp.getX() == end.getX()) && (tmp.getY() == end.getY());
/*     */       
/*  63 */       if (isValidStep(roomFloorObject, new Position(current.getPosition().getX(), current.getPosition().getY(), current.getPosition().getZ()), tmp, isFinalMove, isRetry)) {
/*     */         try {
/*  65 */           if (map[tmp.getX()][tmp.getY()] == null) {
/*  66 */             node = new PathfinderNode(tmp);
/*  67 */             map[tmp.getX()][tmp.getY()] = node;
/*     */           } else {
/*  69 */             node = map[tmp.getX()][tmp.getY()];
/*     */           }
/*     */         }
/*     */         catch (ArrayIndexOutOfBoundsException e) {
/*     */           break label481;
/*     */         }
/*  75 */         if (!node.isInClosed()) {
/*  76 */           int diff = 0;
/*     */           
/*  78 */           if (current.getPosition().getX() != node.getPosition().getX()) {
/*  79 */             diff++;
/*     */           }
/*     */           
/*  82 */           if (current.getPosition().getY() != node.getPosition().getY()) {
/*  83 */             diff++;
/*     */           }
/*     */           
/*  86 */           int cost = current.getCost().intValue() + diff + node.getPosition().getDistanceSquared(end);
/*     */           
/*  88 */           if (cost < node.getCost().intValue()) {
/*  89 */             node.setCost(cost);
/*  90 */             node.setNextNode(current);
/*     */           }
/*     */           
/*  93 */           if (!node.isInOpen()) {
/*  94 */             if ((node.getPosition().getX() == finish.getPosition().getX()) && (node.getPosition().getY() == finish.getPosition().getY())) {
/*  95 */               node.setNextNode(current);
/*  96 */               return node;
/*     */             }
/*     */             
/*  99 */             node.setInOpen(true);
/* 100 */             openList.add(node);
/*     */           }
/*     */         }
/*     */       }
/*     */       label481:
/*  59 */       i++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isValidStep(RoomObject roomObject, Position from, Position to, boolean lastStep, boolean isRetry) {
/* 111 */     if ((!roomObject.getRoom().getMapping().isValidStep((roomObject instanceof RoomEntity) ? (RoomEntity)roomObject : null, from, to, lastStep, roomObject instanceof com.habboproject.server.game.rooms.objects.items.RoomItemFloor, isRetry)) && ((!(roomObject instanceof RoomEntity)) || (!((RoomEntity)roomObject).isOverriden()))) {
/* 112 */       return false;
/*     */     }
/*     */     
/* 115 */     return true;
/*     */   }
/*     */   
/* 118 */   private final Position[] diagonalMovePoints = {
/* 119 */     new Position(-1, -1), 
/* 120 */     new Position(0, -1), 
/* 121 */     new Position(1, 1), 
/* 122 */     new Position(0, 1), 
/* 123 */     new Position(1, -1), 
/* 124 */     new Position(1, 0), 
/* 125 */     new Position(-1, 1), 
/* 126 */     new Position(-1, 0) };
/*     */   
/*     */ 
/* 129 */   private final Position[] movePoints = {
/* 130 */     new Position(0, -1), 
/* 131 */     new Position(1, 0), 
/* 132 */     new Position(0, 1), 
/* 133 */     new Position(-1, 0) };
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\pathfinding\Pathfinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */