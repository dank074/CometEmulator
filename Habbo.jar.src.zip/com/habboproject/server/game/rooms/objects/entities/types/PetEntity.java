/*     */ package com.habboproject.server.game.rooms.objects.entities.types;
/*     */ 
/*     */ import com.habboproject.server.api.networking.messages.IComposer;
/*     */ import com.habboproject.server.game.pets.data.PetData;
/*     */ import com.habboproject.server.game.players.PlayerManager;
/*     */ import com.habboproject.server.game.players.data.PlayerAvatar;
/*     */ import com.habboproject.server.game.rooms.objects.entities.RoomEntity;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.ai.BotAI;
/*     */ import com.habboproject.server.game.rooms.objects.entities.types.ai.pets.PetAI;
/*     */ import com.habboproject.server.game.rooms.objects.items.types.floor.pet.PetBreedingBoxFloorItem;
/*     */ import com.habboproject.server.game.rooms.objects.misc.Position;
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import com.habboproject.server.network.messages.outgoing.room.avatar.LeaveRoomMessageComposer;
/*     */ import com.habboproject.server.storage.queries.pets.PetDao;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ public class PetEntity
/*     */   extends RoomEntity
/*     */ {
/*     */   private PetData data;
/*     */   private PetAI ai;
/*     */   private PetBreedingBoxFloorItem breedingBox;
/*  26 */   private int cycleCount = 0;
/*     */   
/*  28 */   private Map<String, Object> attributes = new ConcurrentHashMap();
/*     */   
/*     */   public PetEntity(PetData data, int identifier, Position startPosition, int startBodyRotation, int startHeadRotation, Room roomInstance) {
/*  31 */     super(identifier, startPosition, startBodyRotation, startHeadRotation, roomInstance);
/*     */     
/*  33 */     this.data = data;
/*     */     
/*  35 */     this.ai = new PetAI(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void joinRoom(Room room, String password) {}
/*     */   
/*     */ 
/*     */ 
/*     */   protected void finalizeJoinRoom() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void leaveRoom(boolean isOffline, boolean isKick, boolean toHotelView)
/*     */   {
/*  50 */     leaveRoom(false);
/*     */   }
/*     */   
/*     */   public void leaveRoom(boolean save) {
/*  54 */     if (save) {
/*  55 */       PetDao.savePosition(getPosition().getX(), getPosition().getY(), this.data.getId());
/*     */     }
/*     */     
/*  58 */     getRoom().getEntities().removeEntity(this);
/*  59 */     getRoom().getEntities().broadcastMessage(new LeaveRoomMessageComposer(getId()));
/*  60 */     this.attributes.clear();
/*     */   }
/*     */   
/*     */   public boolean onChat(String message)
/*     */   {
/*  65 */     return false;
/*     */   }
/*     */   
/*     */   public boolean onRoomDispose()
/*     */   {
/*  70 */     if (getData().needsUpdate()) {
/*  71 */       getData().saveStats();
/*     */     }
/*     */     
/*  74 */     PetDao.savePosition(getPosition().getX(), getPosition().getY(), this.data.getId());
/*     */     
/*  76 */     getRoom().getEntities().broadcastMessage(new LeaveRoomMessageComposer(getId()));
/*     */     
/*  78 */     this.attributes.clear();
/*     */     
/*  80 */     return true;
/*     */   }
/*     */   
/*     */   public String getUsername()
/*     */   {
/*  85 */     return null;
/*     */   }
/*     */   
/*     */   public String getMotto()
/*     */   {
/*  90 */     return null;
/*     */   }
/*     */   
/*     */   public String getFigure()
/*     */   {
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   public String getGender()
/*     */   {
/* 100 */     return null;
/*     */   }
/*     */   
/*     */   public void compose(IComposer msg)
/*     */   {
/* 105 */     msg.writeInt(getData().getId());
/* 106 */     msg.writeString(getData().getName());
/* 107 */     msg.writeString("PET_MOTTO");
/*     */     
/* 109 */     String look = getData().getLook();
/*     */     
/* 111 */     switch (getData().getTypeId()) {
/*     */     case 13: case 14: case 24: case 25: default: 
/* 113 */       look = look + " 2 2 -1 0 3 -1 0";
/* 114 */       break;
/*     */     
/*     */     case 12: 
/* 117 */       look = "12 0 ffffff 2 2 -1 0 3 -1 0";
/* 118 */       break;
/*     */     
/*     */     case 15: 
/* 121 */       look = look + new StringBuilder().append(" ").append(getData().isSaddled() ? "3" : "2").append(" 2 ").append(getData().getHair()).append(" ").append(getData().getHairDye()).append(" 3 ").append(getData().getHair()).append(" ").append(getData().getHairDye()).append(getData().isSaddled() ? "0 4 9 0" : "").toString();
/* 122 */       break;
/*     */     
/*     */ 
/*     */     case 16: 
/*     */     case 17: 
/*     */     case 18: 
/*     */     case 19: 
/*     */     case 20: 
/*     */       break;
/*     */     
/*     */ 
/*     */     case 21: 
/*     */     case 22: 
/*     */     case 23: 
/*     */       break;
/*     */     
/*     */ 
/*     */     case 26: 
/*     */     case 27: 
/* 141 */       look = look + new StringBuilder().append(" ").append(getData().getExtraData());
/*     */     }
/*     */     
/*     */     
/* 145 */     msg.writeString(look);
/*     */     
/* 147 */     msg.writeInt(getId());
/* 148 */     msg.writeInt(getPosition().getX());
/* 149 */     msg.writeInt(getPosition().getY());
/* 150 */     msg.writeDouble(getPosition().getZ());
/* 151 */     msg.writeInt(0);
/* 152 */     msg.writeInt(2);
/*     */     
/* 154 */     msg.writeInt(this.data.getRaceId());
/*     */     
/* 156 */     msg.writeInt(this.data.getOwnerId());
/*     */     
/* 158 */     PlayerAvatar petOwner = PlayerManager.getInstance().getAvatarByPlayerId(getData().getOwnerId(), (byte)0);
/*     */     
/* 160 */     msg.writeString(petOwner == null ? "trylix" : petOwner.getUsername());
/*     */     
/* 162 */     msg.writeInt(0);
/* 163 */     msg.writeBoolean(Boolean.valueOf(true));
/* 164 */     msg.writeBoolean(Boolean.valueOf(hasMount()));
/*     */     
/* 166 */     msg.writeInt(0);
/* 167 */     msg.writeInt(0);
/* 168 */     msg.writeString("");
/*     */   }
/*     */   
/*     */   public PetData getData() {
/* 172 */     return this.data;
/*     */   }
/*     */   
/*     */   public int getCycleCount() {
/* 176 */     return this.cycleCount;
/*     */   }
/*     */   
/*     */   public void decrementCycleCount() {
/* 180 */     this.cycleCount -= 1;
/*     */   }
/*     */   
/*     */   public void incrementCycleCount() {
/* 184 */     this.cycleCount += 1;
/*     */   }
/*     */   
/*     */   public void resetCycleCount() {
/* 188 */     this.cycleCount = 0;
/*     */   }
/*     */   
/*     */   public BotAI getAI()
/*     */   {
/* 193 */     return this.ai;
/*     */   }
/*     */   
/*     */   public PetAI getPetAI() {
/* 197 */     return this.ai;
/*     */   }
/*     */   
/*     */   public PetBreedingBoxFloorItem getBreedingBox() {
/* 201 */     return this.breedingBox;
/*     */   }
/*     */   
/*     */   public void setBreedingBox(PetBreedingBoxFloorItem breedingBox) {
/* 205 */     this.breedingBox = breedingBox;
/*     */   }
/*     */   
/*     */   public void setAttribute(String attributeKey, Object attributeValue)
/*     */   {
/* 210 */     if (this.attributes.containsKey(attributeKey)) {
/* 211 */       this.attributes.replace(attributeKey, attributeValue);
/*     */     } else {
/* 213 */       this.attributes.put(attributeKey, attributeValue);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getAttribute(String attributeKey)
/*     */   {
/* 219 */     return this.attributes.get(attributeKey);
/*     */   }
/*     */   
/*     */   public boolean hasAttribute(String attributeKey)
/*     */   {
/* 224 */     return this.attributes.containsKey(attributeKey);
/*     */   }
/*     */   
/*     */   public void removeAttribute(String attributeKey)
/*     */   {
/* 229 */     this.attributes.remove(attributeKey);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\PetEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */