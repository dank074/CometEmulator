package com.habboproject.server.game.rooms.objects.entities.types.data;

public abstract interface BotDataObject {}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\data\BotDataObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */