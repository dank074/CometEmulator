/*    */ package com.habboproject.server.game.rooms.objects.entities.types.data.types;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class SpyBotData implements com.habboproject.server.game.rooms.objects.entities.types.data.BotDataObject
/*    */ {
/*    */   private List<String> visitors;
/*    */   
/*    */   public SpyBotData(List<String> visitors)
/*    */   {
/* 11 */     this.visitors = visitors;
/*    */   }
/*    */   
/*    */   public List<String> getVisitors() {
/* 15 */     return this.visitors;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\data\types\SpyBotData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */