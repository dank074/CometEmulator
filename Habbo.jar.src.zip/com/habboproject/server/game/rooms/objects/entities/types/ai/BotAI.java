package com.habboproject.server.game.rooms.objects.entities.types.ai;

import com.habboproject.server.game.rooms.objects.entities.types.PlayerEntity;
import com.habboproject.server.game.rooms.types.misc.ChatEmotion;

public abstract interface BotAI
{
  public abstract boolean onTalk(PlayerEntity paramPlayerEntity, String paramString);
  
  public abstract boolean onPlayerEnter(PlayerEntity paramPlayerEntity);
  
  public abstract boolean onPlayerLeave(PlayerEntity paramPlayerEntity);
  
  public abstract boolean onAddedToRoom();
  
  public abstract boolean onRemovedFromRoom();
  
  public abstract void onTick();
  
  public abstract void onTickComplete();
  
  public abstract void sit();
  
  public abstract void lay();
  
  public abstract void setTicksUntilCompleteInSeconds(double paramDouble);
  
  public abstract void say(String paramString);
  
  public abstract void say(String paramString, ChatEmotion paramChatEmotion);
  
  public abstract boolean canMove();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\ai\BotAI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */