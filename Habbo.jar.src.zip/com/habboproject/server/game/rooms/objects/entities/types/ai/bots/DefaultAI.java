/*   */ package com.habboproject.server.game.rooms.objects.entities.types.ai.bots;
/*   */ 
/*   */ import com.habboproject.server.game.rooms.objects.entities.types.ai.AbstractBotAI;
/*   */ 
/*   */ public class DefaultAI extends AbstractBotAI
/*   */ {
/*   */   public DefaultAI(com.habboproject.server.game.rooms.objects.entities.RoomEntity entity) {
/* 8 */     super(entity);
/*   */   }
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\game\rooms\objects\entities\types\ai\bots\DefaultAI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */