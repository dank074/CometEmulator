package com.habboproject.server.api.game.rooms;

public abstract interface RoomCategory
{
  public abstract int getId();
  
  public abstract String getCategory();
  
  public abstract String getCategoryId();
  
  public abstract String getPublicName();
  
  public abstract boolean canDoActions();
  
  public abstract int getColour();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\RoomCategory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */