/*    */ package com.habboproject.server.api.game.rooms.settings;
/*    */ 
/*    */ public enum RoomMuteState {
/*  4 */   NONE(0), 
/*  5 */   RIGHTS(1);
/*    */   
/*    */   private int state;
/*    */   
/*    */   private RoomMuteState(int state) {
/* 10 */     this.state = state;
/*    */   }
/*    */   
/*    */   public int getState() {
/* 14 */     return this.state;
/*    */   }
/*    */   
/*    */   public static RoomMuteState valueOf(int state) {
/* 18 */     if (state == 0) return NONE;
/* 19 */     return RIGHTS;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\settings\RoomMuteState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */