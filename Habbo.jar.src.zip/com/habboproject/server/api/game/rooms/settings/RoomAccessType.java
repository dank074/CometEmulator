package com.habboproject.server.api.game.rooms.settings;

public enum RoomAccessType
{
  OPEN,  DOORBELL,  PASSWORD,  INVISIBLE;
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\settings\RoomAccessType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */