/*    */ package com.habboproject.server.api.game.rooms.settings;
/*    */ 
/*    */ public enum RoomKickState {
/*  4 */   EVERYONE(2), 
/*  5 */   RIGHTS(1), 
/*  6 */   NONE(0);
/*    */   
/*    */   private int state;
/*    */   
/*    */   private RoomKickState(int state) {
/* 11 */     this.state = state;
/*    */   }
/*    */   
/*    */   public int getState() {
/* 15 */     return this.state;
/*    */   }
/*    */   
/*    */   public static RoomKickState valueOf(int state) {
/* 19 */     if (state == 0) return NONE;
/* 20 */     if (state == 1) return RIGHTS;
/* 21 */     return EVERYONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\settings\RoomKickState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */