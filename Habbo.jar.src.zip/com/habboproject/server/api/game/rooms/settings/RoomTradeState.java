/*    */ package com.habboproject.server.api.game.rooms.settings;
/*    */ 
/*    */ public enum RoomTradeState {
/*  4 */   DISABLED(0), 
/*  5 */   ENABLED(2), 
/*  6 */   OWNER_ONLY(1);
/*    */   
/*    */   private int state;
/*    */   
/*    */   private RoomTradeState(int state) {
/* 11 */     this.state = state;
/*    */   }
/*    */   
/*    */   public int getState() {
/* 15 */     return this.state;
/*    */   }
/*    */   
/*    */   public static RoomTradeState valueOf(int state) {
/* 19 */     if (state == 0) return DISABLED;
/* 20 */     if (state == 2) return ENABLED;
/* 21 */     return OWNER_ONLY;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\settings\RoomTradeState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */