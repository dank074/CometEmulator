package com.habboproject.server.api.game.rooms.objects;

import com.habboproject.server.api.game.rooms.IRoom;
import com.habboproject.server.api.game.rooms.util.IPosition;

public abstract interface IRoomObject
{
  public abstract IPosition getPosition();
  
  public abstract boolean isAtDoor();
  
  public abstract IRoom getRoom();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\objects\IRoomObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */