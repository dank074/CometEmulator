package com.habboproject.server.api.game.rooms.util;

public abstract interface IPosition
{
  public abstract int getX();
  
  public abstract int getY();
  
  public abstract double getZ();
  
  public abstract void setX(int paramInt);
  
  public abstract void setY(int paramInt);
  
  public abstract void setZ(double paramDouble);
  
  public abstract IPosition squareInFront(int paramInt);
  
  public abstract IPosition squareBehind(int paramInt);
  
  public abstract double distanceTo(IPosition paramIPosition);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\util\IPosition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */