package com.habboproject.server.api.game.rooms;

public abstract interface IRoom
{
  public abstract IRoomData getData();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\IRoom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */