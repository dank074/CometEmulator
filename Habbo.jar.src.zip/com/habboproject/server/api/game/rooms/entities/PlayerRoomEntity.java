package com.habboproject.server.api.game.rooms.entities;

import com.habboproject.server.api.game.players.BasePlayer;

public abstract interface PlayerRoomEntity
{
  public abstract int getId();
  
  public abstract BasePlayer getPlayer();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\entities\PlayerRoomEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */