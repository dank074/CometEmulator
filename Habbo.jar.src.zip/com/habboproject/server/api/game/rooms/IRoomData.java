package com.habboproject.server.api.game.rooms;

import com.habboproject.server.api.game.rooms.settings.RoomAccessType;
import com.habboproject.server.api.game.rooms.settings.RoomBanState;
import com.habboproject.server.api.game.rooms.settings.RoomKickState;
import com.habboproject.server.api.game.rooms.settings.RoomMuteState;
import com.habboproject.server.api.game.rooms.settings.RoomTradeState;
import java.util.List;
import java.util.Map;

public abstract interface IRoomData
{
  public abstract void save();
  
  public abstract int getId();
  
  public abstract String getName();
  
  public abstract String getDescription();
  
  public abstract int getOwnerId();
  
  public abstract String getOwner();
  
  public abstract RoomCategory getCategory();
  
  public abstract int getMaxUsers();
  
  public abstract RoomAccessType getAccess();
  
  public abstract String getPassword();
  
  public abstract int getScore();
  
  public abstract String[] getTags();
  
  public abstract Map<String, String> getDecorations();
  
  public abstract String getModel();
  
  public abstract boolean getHideWalls();
  
  public abstract int getWallThickness();
  
  public abstract int getFloorThickness();
  
  public abstract void setId(int paramInt);
  
  public abstract void setName(String paramString);
  
  public abstract void setDescription(String paramString);
  
  public abstract void setOwnerId(int paramInt);
  
  public abstract void setOwner(String paramString);
  
  public abstract void setCategory(int paramInt);
  
  public abstract void setMaxUsers(int paramInt);
  
  public abstract void setAccess(RoomAccessType paramRoomAccessType);
  
  public abstract void setPassword(String paramString);
  
  public abstract void setScore(int paramInt);
  
  public abstract void setTags(String[] paramArrayOfString);
  
  public abstract void setDecorations(Map<String, String> paramMap);
  
  public abstract void setModel(String paramString);
  
  public abstract void setHideWalls(boolean paramBoolean);
  
  public abstract void setThicknessWall(int paramInt);
  
  public abstract void setThicknessFloor(int paramInt);
  
  public abstract boolean getAllowWalkthrough();
  
  public abstract void setAllowWalkthrough(boolean paramBoolean);
  
  public abstract void setHeightmap(String paramString);
  
  public abstract String getHeightmap();
  
  public abstract boolean isAllowPets();
  
  public abstract void setAllowPets(boolean paramBoolean);
  
  public abstract long getLastReferenced();
  
  public abstract RoomTradeState getTradeState();
  
  public abstract void setTradeState(RoomTradeState paramRoomTradeState);
  
  public abstract int getBubbleMode();
  
  public abstract void setBubbleMode(int paramInt);
  
  public abstract int getBubbleType();
  
  public abstract void setBubbleType(int paramInt);
  
  public abstract int getBubbleScroll();
  
  public abstract void setBubbleScroll(int paramInt);
  
  public abstract int getChatDistance();
  
  public abstract void setChatDistance(int paramInt);
  
  public abstract int getAntiFloodSettings();
  
  public abstract void setAntiFloodSettings(int paramInt);
  
  public abstract RoomMuteState getMuteState();
  
  public abstract void setMuteState(RoomMuteState paramRoomMuteState);
  
  public abstract RoomKickState getKickState();
  
  public abstract void setKickState(RoomKickState paramRoomKickState);
  
  public abstract RoomBanState getBanState();
  
  public abstract void setBanState(RoomBanState paramRoomBanState);
  
  public abstract List<String> getDisabledCommands();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\rooms\IRoomData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */