package com.habboproject.server.api.game.furniture.types;

public abstract interface GiftItemData
{
  public abstract int getPageId();
  
  public abstract int getItemId();
  
  public abstract String getReceiver();
  
  public abstract String getMessage();
  
  public abstract int getSpriteId();
  
  public abstract int getWrappingPaper();
  
  public abstract int getDecorationType();
  
  public abstract boolean isShowUsername();
  
  public abstract int getSenderId();
  
  public abstract String getExtraData();
  
  public abstract void setExtraData(String paramString);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\furniture\types\GiftItemData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */