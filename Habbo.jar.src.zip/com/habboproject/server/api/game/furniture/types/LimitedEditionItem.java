package com.habboproject.server.api.game.furniture.types;

public abstract interface LimitedEditionItem
{
  public abstract long getItemId();
  
  public abstract int getLimitedRare();
  
  public abstract int getLimitedRareTotal();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\furniture\types\LimitedEditionItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */