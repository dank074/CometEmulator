package com.habboproject.server.api.game.furniture.types;

import com.habboproject.server.api.game.players.data.components.inventory.PlayerItemSnapshot;

public abstract interface SongItem
{
  public abstract int getSongId();
  
  public abstract PlayerItemSnapshot getItemSnapshot();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\furniture\types\SongItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */