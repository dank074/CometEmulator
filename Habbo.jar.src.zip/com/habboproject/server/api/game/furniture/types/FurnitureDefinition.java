package com.habboproject.server.api.game.furniture.types;

public abstract interface FurnitureDefinition
{
  public abstract boolean isAdFurni();
  
  public abstract boolean isRoomDecor();
  
  public abstract boolean isTeleporter();
  
  public abstract boolean isSong();
  
  public abstract int getId();
  
  public abstract String getPublicName();
  
  public abstract String getItemName();
  
  public abstract String getType();
  
  public abstract int getWidth();
  
  public abstract double getHeight();
  
  public abstract int getSpriteId();
  
  public abstract int getLength();
  
  public abstract String getInteraction();
  
  public abstract int getInteractionCycleCount();
  
  public abstract int getEffectId();
  
  public abstract String[] getVendingIds();
  
  public abstract int getOfferId();
  
  public abstract boolean canStack();
  
  public abstract boolean canSit();
  
  public abstract boolean canWalk();
  
  public abstract boolean canTrade();
  
  public abstract boolean canRecycle();
  
  public abstract boolean canMarket();
  
  public abstract boolean canGift();
  
  public abstract boolean canInventoryStack();
  
  public abstract Double[] getVariableHeights();
  
  public abstract boolean requiresRights();
  
  public abstract int getSongId();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\furniture\types\FurnitureDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */