package com.habboproject.server.api.game.players.data.components.permissions;

public abstract interface PlayerRank
{
  public abstract int getId();
  
  public abstract String getName();
  
  public abstract boolean floodBypass();
  
  public abstract int floodTime();
  
  public abstract boolean disconnectable();
  
  public abstract boolean bannable();
  
  public abstract boolean modTool();
  
  public abstract boolean roomKickable();
  
  public abstract boolean roomFullControl();
  
  public abstract boolean roomMuteBypass();
  
  public abstract boolean roomFilterBypass();
  
  public abstract boolean roomIgnorable();
  
  public abstract boolean roomEnterFull();
  
  public abstract boolean roomEnterLocked();
  
  public abstract boolean roomStaffPick();
  
  public abstract boolean messengerStaffChat();
  
  public abstract int messengerMaxFriends();
  
  public abstract boolean aboutDetailed();
  
  public abstract boolean aboutStats();
  
  public abstract boolean isAmbassador();
  
  public abstract boolean isHelper();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\components\permissions\PlayerRank.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */