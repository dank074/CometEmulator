package com.habboproject.server.api.game.players.data.components.inventory;

import com.habboproject.server.api.game.furniture.types.FurnitureDefinition;
import com.habboproject.server.api.game.furniture.types.LimitedEditionItem;
import com.habboproject.server.api.networking.messages.IComposer;

public abstract interface PlayerItem
{
  public abstract long getId();
  
  public abstract FurnitureDefinition getDefinition();
  
  public abstract int getBaseId();
  
  public abstract int getGroupId();
  
  public abstract String getExtraData();
  
  public abstract LimitedEditionItem getLimitedEditionItem();
  
  public abstract int getVirtualId();
  
  public abstract void compose(IComposer paramIComposer);
  
  public abstract PlayerItemSnapshot createSnapshot();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\components\inventory\PlayerItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */