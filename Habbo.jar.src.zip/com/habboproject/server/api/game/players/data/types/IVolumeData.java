package com.habboproject.server.api.game.players.data.types;

public abstract interface IVolumeData
{
  public abstract int getSystemVolume();
  
  public abstract void setSystemVolume(int paramInt);
  
  public abstract int getFurniVolume();
  
  public abstract void setFurniVolume(int paramInt);
  
  public abstract int getTraxVolume();
  
  public abstract void setTraxVolume(int paramInt);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\types\IVolumeData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */