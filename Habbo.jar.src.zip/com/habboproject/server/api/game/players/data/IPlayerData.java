package com.habboproject.server.api.game.players.data;

public abstract interface IPlayerData
{
  public abstract void save();
  
  public abstract void decreaseCredits(int paramInt);
  
  public abstract void increaseCredits(int paramInt);
  
  public abstract void decreasePoints(int paramInt);
  
  public abstract void increasePoints(int paramInt);
  
  public abstract void increaseActivityPoints(int paramInt);
  
  public abstract void decreaseActivityPoints(int paramInt);
  
  public abstract void setPoints(int paramInt);
  
  public abstract int getId();
  
  public abstract int getRank();
  
  public abstract String getUsername();
  
  public abstract void setUsername(String paramString);
  
  public abstract int getAchievementPoints();
  
  public abstract String getMotto();
  
  public abstract void setMotto(String paramString);
  
  public abstract String getFigure();
  
  public abstract String getGender();
  
  public abstract int getCredits();
  
  public abstract void setCredits(int paramInt);
  
  public abstract int getVipPoints();
  
  public abstract int getLastVisit();
  
  public abstract String getRegDate();
  
  public abstract boolean isVip();
  
  public abstract void setVip(boolean paramBoolean);
  
  public abstract void setLastVisit(long paramLong);
  
  public abstract void setFigure(String paramString);
  
  public abstract void setGender(String paramString);
  
  public abstract int getRegTimestamp();
  
  public abstract void setRegTimestamp(int paramInt);
  
  public abstract String getEmail();
  
  public abstract void setEmail(String paramString);
  
  public abstract int getFavouriteGroup();
  
  public abstract void setFavouriteGroup(int paramInt);
  
  public abstract String getIpAddress();
  
  public abstract void setIpAddress(String paramString);
  
  public abstract int getActivityPoints();
  
  public abstract void setActivityPoints(int paramInt);
  
  public abstract void setVipPoints(int paramInt);
  
  public abstract void setRank(int paramInt);
  
  public abstract String getTemporaryFigure();
  
  public abstract void setTemporaryFigure(String paramString);
  
  public abstract int getQuestId();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\IPlayerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */