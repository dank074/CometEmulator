package com.habboproject.server.api.game.players.data.components;

import com.habboproject.server.api.game.players.data.PlayerComponent;
import com.habboproject.server.api.game.players.data.components.permissions.PlayerRank;

public abstract interface PlayerPermissions
  extends PlayerComponent
{
  public abstract PlayerRank getRank();
  
  public abstract boolean hasCommand(String paramString);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\components\PlayerPermissions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */