package com.habboproject.server.api.game.players.data;

import com.habboproject.server.api.game.players.data.types.IPlaylistItem;
import com.habboproject.server.api.game.players.data.types.IVolumeData;
import com.habboproject.server.api.game.players.data.types.IWardrobeItem;
import java.util.List;

public abstract interface IPlayerSettings
{
  public abstract IVolumeData getVolumes();
  
  public abstract boolean getHideOnline();
  
  public abstract boolean getHideInRoom();
  
  public abstract boolean getAllowFriendRequests();
  
  public abstract void setAllowFriendRequests(boolean paramBoolean);
  
  public abstract boolean getAllowTrade();
  
  public abstract int getHomeRoom();
  
  public abstract void setHomeRoom(int paramInt);
  
  public abstract List<IWardrobeItem> getWardrobe();
  
  public abstract void setWardrobe(List<IWardrobeItem> paramList);
  
  public abstract List<IPlaylistItem> getPlaylist();
  
  public abstract boolean isUseOldChat();
  
  public abstract void setUseOldChat(boolean paramBoolean);
  
  public abstract boolean isIgnoreInvites();
  
  public abstract boolean enableEventNotif();
  
  public abstract void setIgnoreInvites(boolean paramBoolean);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\IPlayerSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */