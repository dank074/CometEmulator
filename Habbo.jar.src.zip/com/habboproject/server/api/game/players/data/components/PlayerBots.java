package com.habboproject.server.api.game.players.data.components;

import com.habboproject.server.api.game.players.data.components.bots.PlayerBot;
import java.util.Map;

public abstract interface PlayerBots
{
  public abstract void remove(int paramInt);
  
  public abstract boolean isBot(int paramInt);
  
  public abstract Map<Integer, PlayerBot> getBots();
  
  public abstract void clearBots();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\components\PlayerBots.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */