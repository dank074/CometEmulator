package com.habboproject.server.api.game.players.data.types;

public abstract interface IWardrobeItem
{
  public abstract int getSlot();
  
  public abstract void setSlot(int paramInt);
  
  public abstract String getGender();
  
  public abstract void setGender(String paramString);
  
  public abstract String getFigure();
  
  public abstract void setFigure(String paramString);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\types\IWardrobeItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */