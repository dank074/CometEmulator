package com.habboproject.server.api.game.players.data.components;

import com.habboproject.server.api.game.furniture.types.GiftItemData;
import com.habboproject.server.api.game.furniture.types.LimitedEditionItem;
import com.habboproject.server.api.game.furniture.types.SongItem;
import com.habboproject.server.api.game.players.data.PlayerComponent;
import com.habboproject.server.api.game.players.data.components.inventory.PlayerItem;
import java.util.List;
import java.util.Map;

public abstract interface PlayerInventory
  extends PlayerComponent
{
  public abstract void loadItems();
  
  public abstract void loadBadges();
  
  public abstract void addBadge(String paramString, boolean paramBoolean);
  
  public abstract void addBadge(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract boolean hasBadge(String paramString);
  
  public abstract void removeBadge(String paramString, boolean paramBoolean);
  
  public abstract void removebadge(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract void removeBadge(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  public abstract void achievementBadge(String paramString, int paramInt);
  
  public abstract void resetBadgeSlots();
  
  public abstract Map<String, Integer> equippedBadges();
  
  public abstract PlayerItem add(long paramLong, int paramInt1, int paramInt2, String paramString, GiftItemData paramGiftItemData, LimitedEditionItem paramLimitedEditionItem);
  
  public abstract List<SongItem> getSongs();
  
  public abstract void add(long paramLong, int paramInt1, int paramInt2, String paramString, LimitedEditionItem paramLimitedEditionItem);
  
  public abstract void addItem(PlayerItem paramPlayerItem);
  
  public abstract void removeItem(PlayerItem paramPlayerItem);
  
  public abstract void removeFloorItem(long paramLong);
  
  public abstract void removeWallItem(long paramLong);
  
  public abstract boolean hasFloorItem(long paramLong);
  
  public abstract PlayerItem getFloorItem(long paramLong);
  
  public abstract boolean hasWallItem(long paramLong);
  
  @Deprecated
  public abstract PlayerItem getWallItem(int paramInt);
  
  @Deprecated
  public abstract PlayerItem getFloorItem(int paramInt);
  
  public abstract PlayerItem getWallItem(long paramLong);
  
  public abstract PlayerItem getItem(long paramLong);
  
  public abstract int getTotalSize();
  
  public abstract Map<Long, PlayerItem> getWallItems();
  
  public abstract Map<Long, PlayerItem> getFloorItems();
  
  public abstract Map<String, Integer> getBadges();
  
  public abstract boolean itemsLoaded();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\components\PlayerInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */