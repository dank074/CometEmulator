package com.habboproject.server.api.game.players.data.components.inventory;

public abstract interface PlayerItemSnapshot
{
  public abstract long getId();
  
  public abstract int getBaseItemId();
  
  public abstract String getExtraData();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\components\inventory\PlayerItemSnapshot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */