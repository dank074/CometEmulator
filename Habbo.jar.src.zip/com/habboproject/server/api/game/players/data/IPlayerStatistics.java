package com.habboproject.server.api.game.players.data;

public abstract interface IPlayerStatistics
{
  public abstract void save();
  
  public abstract void incrementAchievementPoints(int paramInt);
  
  public abstract void incrementCautions(int paramInt);
  
  public abstract void incrementRespectPoints(int paramInt);
  
  public abstract void decrementDailyRespects(int paramInt);
  
  public abstract void incrementBans(int paramInt);
  
  public abstract void incrementAbusiveHelpTickets(int paramInt);
  
  public abstract int getPlayerId();
  
  public abstract int getDailyRespects();
  
  public abstract int getRespectPoints();
  
  public abstract int getAchievementPoints();
  
  public abstract int getFriendCount();
  
  public abstract int getHelpTickets();
  
  public abstract void setHelpTickets(int paramInt);
  
  public abstract int getAbusiveHelpTickets();
  
  public abstract void setAbusiveHelpTickets(int paramInt);
  
  public abstract int getCautions();
  
  public abstract void setCautions(int paramInt);
  
  public abstract int getBans();
  
  public abstract void setBans(int paramInt);
  
  public abstract void setDailyRespects(int paramInt);
  
  public abstract void setScratches(int paramInt);
  
  public abstract int getScratches();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\IPlayerStatistics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */