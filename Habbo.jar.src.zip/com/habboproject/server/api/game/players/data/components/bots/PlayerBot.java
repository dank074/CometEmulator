package com.habboproject.server.api.game.players.data.components.bots;

public abstract interface PlayerBot
{
  public abstract int getId();
  
  public abstract int getOwnerId();
  
  public abstract String getName();
  
  public abstract String getFigure();
  
  public abstract String getGender();
  
  public abstract String getMotto();
  
  public abstract String getOwnerName();
  
  public abstract String getMode();
  
  public abstract String getType();
  
  public abstract String getData();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\components\bots\PlayerBot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */