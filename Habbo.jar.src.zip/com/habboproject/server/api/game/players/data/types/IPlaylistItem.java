package com.habboproject.server.api.game.players.data.types;

public abstract interface IPlaylistItem
{
  public abstract String getVideoId();
  
  public abstract void setVideoId(String paramString);
  
  public abstract String getTitle();
  
  public abstract void setTitle(String paramString);
  
  public abstract String getDescription();
  
  public abstract void setDescription(String paramString);
  
  public abstract int getDuration();
  
  public abstract void setDuration(int paramInt);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\data\types\IPlaylistItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */