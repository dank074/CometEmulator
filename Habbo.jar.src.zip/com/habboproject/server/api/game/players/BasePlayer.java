package com.habboproject.server.api.game.players;

import com.habboproject.server.api.game.players.data.IPlayerData;
import com.habboproject.server.api.game.players.data.IPlayerSettings;
import com.habboproject.server.api.game.players.data.IPlayerStatistics;
import com.habboproject.server.api.game.players.data.components.PlayerBots;
import com.habboproject.server.api.game.players.data.components.PlayerInventory;
import com.habboproject.server.api.game.players.data.components.PlayerPermissions;
import com.habboproject.server.api.game.rooms.entities.PlayerRoomEntity;
import com.habboproject.server.api.networking.messages.IMessageComposer;
import com.habboproject.server.api.networking.sessions.BaseSession;
import java.util.List;

public abstract interface BasePlayer
{
  public static final int INFINITE_BALANCE = 999999;
  
  public abstract void dispose();
  
  public abstract void sendBalance();
  
  public abstract IMessageComposer composeCreditBalance();
  
  public abstract IMessageComposer composeCurrenciesBalance();
  
  public abstract void loadRoom(int paramInt, String paramString);
  
  public abstract void poof();
  
  public abstract void ignorePlayer(int paramInt);
  
  public abstract void unignorePlayer(int paramInt);
  
  public abstract boolean ignores(int paramInt);
  
  public abstract List<Integer> getRooms();
  
  public abstract void setRooms(List<Integer> paramList);
  
  public abstract void setSession(BaseSession paramBaseSession);
  
  public abstract PlayerRoomEntity getEntity();
  
  public abstract BaseSession getSession();
  
  public abstract IPlayerData getData();
  
  public abstract IPlayerSettings getSettings();
  
  public abstract IPlayerStatistics getStats();
  
  public abstract PlayerPermissions getPermissions();
  
  public abstract PlayerInventory getInventory();
  
  public abstract PlayerBots getBots();
  
  public abstract int getId();
  
  public abstract void sendNotif(String paramString1, String paramString2);
  
  public abstract void sendMotd(String paramString);
  
  public abstract boolean isTeleporting();
  
  public abstract long getTeleportId();
  
  public abstract void setTeleportId(long paramLong);
  
  public abstract long getRoomLastMessageTime();
  
  public abstract void setRoomLastMessageTime(long paramLong);
  
  public abstract double getRoomFloodTime();
  
  public abstract void setRoomFloodTime(double paramDouble);
  
  public abstract int getRoomFloodFlag();
  
  public abstract void setRoomFloodFlag(int paramInt);
  
  public abstract String getLastMessage();
  
  public abstract void setLastMessage(String paramString);
  
  public abstract List<Integer> getGroups();
  
  public abstract int getNotifCooldown();
  
  public abstract void setNotifCooldown(int paramInt);
  
  public abstract int getLastRoomId();
  
  public abstract void setLastRoomId(int paramInt);
  
  public abstract int getLastGift();
  
  public abstract void setLastGift(int paramInt);
  
  public abstract long getMessengerLastMessageTime();
  
  public abstract void setMessengerLastMessageTime(long paramLong);
  
  public abstract double getMessengerFloodTime();
  
  public abstract void setMessengerFloodTime(double paramDouble);
  
  public abstract int getMessengerFloodFlag();
  
  public abstract void setMessengerFloodFlag(int paramInt);
  
  public abstract boolean isDeletingGroup();
  
  public abstract void setDeletingGroup(boolean paramBoolean);
  
  public abstract long getDeletingGroupAttempt();
  
  public abstract void setDeletingGroupAttempt(long paramLong);
  
  public abstract void bypassRoomAuth(boolean paramBoolean);
  
  public abstract boolean isBypassingRoomAuth();
  
  public abstract int getLastFigureUpdate();
  
  public abstract void setLastFigureUpdate(int paramInt);
  
  public abstract long getLastReward();
  
  public abstract void setLastReward(long paramLong);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\game\players\BasePlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */