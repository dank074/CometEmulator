package com.habboproject.server.api.server;

import com.habboproject.server.api.events.EventHandler;
import com.habboproject.server.api.networking.sessions.ISessionManager;

public abstract interface IGameService
{
  public abstract ISessionManager getSessionManager();
  
  public abstract EventHandler getEventHandler();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\server\IGameService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */