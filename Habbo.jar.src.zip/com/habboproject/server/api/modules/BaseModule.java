/*    */ package com.habboproject.server.api.modules;
/*    */ 
/*    */ import com.habboproject.server.api.commands.CommandInfo;
/*    */ import com.habboproject.server.api.config.ModuleConfig;
/*    */ import com.habboproject.server.api.events.Event;
/*    */ import com.habboproject.server.api.events.EventHandler;
/*    */ import com.habboproject.server.api.events.EventListenerContainer;
/*    */ import com.habboproject.server.api.networking.sessions.BaseSession;
/*    */ import com.habboproject.server.api.server.IGameService;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.UUID;
/*    */ import java.util.function.BiConsumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseModule
/*    */   implements EventListenerContainer
/*    */ {
/*    */   private final ModuleConfig config;
/*    */   private final UUID moduleId;
/*    */   private final IGameService gameService;
/*    */   
/*    */   public BaseModule(ModuleConfig config, IGameService gameService)
/*    */   {
/* 34 */     this.moduleId = UUID.randomUUID();
/* 35 */     this.gameService = gameService;
/* 36 */     this.config = config;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void registerEvent(Event event)
/*    */   {
/* 45 */     getGameService().getEventHandler().registerEvent(event);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void registerChatCommand(String commandExecutor, BiConsumer<BaseSession, String[]> consumer)
/*    */   {
/* 54 */     getGameService().getEventHandler().registerChatCommand(commandExecutor, consumer);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void loadModule()
/*    */   {
/* 61 */     for (Map.Entry<String, CommandInfo> commandInfoEntries : getConfig().getCommands().entrySet()) {
/* 62 */       getGameService().getEventHandler().registerCommandInfo((String)commandInfoEntries.getKey(), (CommandInfo)commandInfoEntries.getValue());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void unloadModule() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UUID getModuleId()
/*    */   {
/* 79 */     return this.moduleId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IGameService getGameService()
/*    */   {
/* 88 */     return this.gameService;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ModuleConfig getConfig()
/*    */   {
/* 97 */     return this.config;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\modules\BaseModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */