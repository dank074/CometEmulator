package com.habboproject.server.api.networking.messages;

public class IMessageEvent {}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\networking\messages\IMessageEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */