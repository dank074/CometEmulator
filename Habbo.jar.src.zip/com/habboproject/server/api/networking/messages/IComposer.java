package com.habboproject.server.api.networking.messages;

public abstract interface IComposer
{
  public abstract int getId();
  
  public abstract void clear();
  
  public abstract boolean hasLength();
  
  public abstract void writeString(Object paramObject);
  
  public abstract void writeDouble(double paramDouble);
  
  public abstract void writeInt(int paramInt);
  
  public abstract void writeLong(long paramLong);
  
  public abstract void writeBoolean(Boolean paramBoolean);
  
  public abstract void writeByte(int paramInt);
  
  public abstract void writeShort(int paramInt);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\networking\messages\IComposer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */