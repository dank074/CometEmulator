package com.habboproject.server.api.networking.messages;

import io.netty.buffer.ByteBuf;

public abstract interface IMessageComposer
{
  public abstract IComposer writeMessage(ByteBuf paramByteBuf);
  
  public abstract short getId();
  
  public abstract void compose(IComposer paramIComposer);
  
  public abstract void dispose();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\networking\messages\IMessageComposer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */