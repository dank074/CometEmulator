/*    */ package com.habboproject.server.api.networking.sessions;
/*    */ 
/*    */ public class SessionManagerAccessor
/*    */ {
/*    */   private static SessionManagerAccessor instance;
/*    */   private ISessionManager sessionManager;
/*    */   
/*    */   public ISessionManager getSessionManager() {
/*  9 */     return this.sessionManager;
/*    */   }
/*    */   
/*    */   public void setSessionManager(ISessionManager sessionManager) {
/* 13 */     this.sessionManager = sessionManager;
/*    */   }
/*    */   
/*    */   public static SessionManagerAccessor getInstance() {
/* 17 */     if (instance == null) {
/* 18 */       instance = new SessionManagerAccessor();
/*    */     }
/*    */     
/* 21 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\networking\sessions\SessionManagerAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */