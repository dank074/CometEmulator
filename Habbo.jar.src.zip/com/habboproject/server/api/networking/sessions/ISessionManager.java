package com.habboproject.server.api.networking.sessions;

import com.habboproject.server.api.networking.messages.IMessageComposer;
import java.util.List;
import java.util.Map;

public abstract interface ISessionManager
{
  public abstract boolean disconnectByPlayerId(int paramInt);
  
  public abstract BaseSession getByPlayerId(int paramInt);
  
  public abstract List<BaseSession> getPlayersByRank(int paramInt);
  
  public abstract BaseSession getByPlayerUsername(String paramString);
  
  public abstract int getUsersOnlineCount();
  
  public abstract Map<Integer, BaseSession> getSessions();
  
  public abstract void broadcast(IMessageComposer paramIMessageComposer);
  
  public abstract void broadcastToModerators(IMessageComposer paramIMessageComposer);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\networking\sessions\ISessionManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */