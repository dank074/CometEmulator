package com.habboproject.server.api.networking.sessions;

import com.habboproject.server.api.game.players.BasePlayer;
import com.habboproject.server.api.networking.messages.IMessageComposer;

public abstract interface BaseSession
{
  public abstract BasePlayer getPlayer();
  
  public abstract void disconnect();
  
  public abstract BaseSession send(IMessageComposer paramIMessageComposer);
  
  public abstract BaseSession sendQueue(IMessageComposer paramIMessageComposer);
  
  public abstract String getIpAddress();
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\networking\sessions\BaseSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */