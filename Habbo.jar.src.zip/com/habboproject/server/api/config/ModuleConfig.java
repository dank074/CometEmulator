/*    */ package com.habboproject.server.api.config;
/*    */ 
/*    */ import com.habboproject.server.api.commands.CommandInfo;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ModuleConfig
/*    */ {
/*    */   private final String name;
/*    */   private final String version;
/*    */   private final String entryPoint;
/*    */   private final Map<String, CommandInfo> commands;
/*    */   
/*    */   public ModuleConfig(String name, String version, String entryPoint, Map<String, CommandInfo> commands)
/*    */   {
/* 15 */     this.name = name;
/* 16 */     this.version = version;
/* 17 */     this.entryPoint = entryPoint;
/* 18 */     this.commands = commands;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 22 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getVersion() {
/* 26 */     return this.version;
/*    */   }
/*    */   
/*    */   public String getEntryPoint() {
/* 30 */     return this.entryPoint;
/*    */   }
/*    */   
/*    */   public Map<String, CommandInfo> getCommands() {
/* 34 */     return this.commands;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\config\ModuleConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */