/*     */ package com.habboproject.server.api.rooms;
/*     */ 
/*     */ import com.habboproject.server.game.rooms.types.Room;
/*     */ import com.habboproject.server.game.rooms.types.RoomData;
/*     */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoomStats
/*     */ {
/*     */   private RoomData data;
/*     */   private int players;
/*     */   private int bots;
/*     */   private int pets;
/*     */   private long loadTime;
/*     */   
/*     */   public RoomStats(Room room)
/*     */   {
/*  39 */     this.data = room.getData();
/*  40 */     this.players = room.getEntities().playerCount();
/*  41 */     this.bots = room.getEntities().getBotEntities().size();
/*  42 */     this.pets = room.getEntities().getPetEntities().size();
/*     */     
/*  44 */     this.loadTime = ((Long)room.getAttribute("loadTime")).longValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RoomData getData()
/*     */   {
/*  53 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setData(RoomData data)
/*     */   {
/*  62 */     this.data = data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPlayers()
/*     */   {
/*  71 */     return this.players;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPlayers(int players)
/*     */   {
/*  80 */     this.players = players;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBots()
/*     */   {
/*  89 */     return this.bots;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBots(int bots)
/*     */   {
/*  98 */     this.bots = bots;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPets()
/*     */   {
/* 107 */     return this.pets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPets(int pets)
/*     */   {
/* 116 */     this.pets = pets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getLoadTime()
/*     */   {
/* 125 */     return this.loadTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoadTime(long loadTime)
/*     */   {
/* 134 */     this.loadTime = loadTime;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\rooms\RoomStats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */