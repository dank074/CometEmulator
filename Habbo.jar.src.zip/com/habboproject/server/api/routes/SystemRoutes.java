/*    */ package com.habboproject.server.api.routes;
/*    */ 
/*    */ import com.habboproject.server.api.networking.sessions.BaseSession;
/*    */ import com.habboproject.server.config.CometSettings;
/*    */ import com.habboproject.server.game.catalog.CatalogManager;
/*    */ import com.habboproject.server.game.commands.CommandManager;
/*    */ import com.habboproject.server.game.items.ItemManager;
/*    */ import com.habboproject.server.game.landing.LandingManager;
/*    */ import com.habboproject.server.game.moderation.BanManager;
/*    */ import com.habboproject.server.game.moderation.ModerationManager;
/*    */ import com.habboproject.server.game.navigator.NavigatorManager;
/*    */ import com.habboproject.server.game.permissions.PermissionsManager;
/*    */ import com.habboproject.server.game.rooms.RoomManager;
/*    */ import com.habboproject.server.game.rooms.filter.WordFilter;
/*    */ import com.habboproject.server.network.NetworkManager;
/*    */ import com.habboproject.server.network.messages.outgoing.moderation.ModToolMessageComposer;
/*    */ import com.habboproject.server.network.sessions.SessionManager;
/*    */ import java.util.Map;
/*    */ import spark.Request;
/*    */ import spark.Response;
/*    */ 
/*    */ public class SystemRoutes
/*    */ {
/*    */   public static Object reload(Request req, Response res)
/*    */   {
/* 26 */     Map<String, Object> result = new java.util.HashMap();
/* 27 */     res.type("application/json");
/*    */     
/* 29 */     String type = req.params("type");
/*    */     
/* 31 */     if (type == null) {
/* 32 */       result.put("error", "Invalid type");
/* 33 */       return result;
/*    */     }
/*    */     String str1;
/* 36 */     switch ((str1 = type).hashCode()) {case -1354792126:  if (str1.equals("config")) {} break; case -1274492040:  if (str1.equals("filter")) {} break; case -1097462182:  if (str1.equals("locale")) {} break; case -840020942:  if (str1.equals("modpresets")) {} break; case 3016260:  if (str1.equals("bans")) break; break; case 3377875:  if (str1.equals("news")) {} break; case 100526016:  if (str1.equals("items")) {} break; case 555704345:  if (str1.equals("catalog")) {} break; case 752822871:  if (str1.equals("navigator")) {} break; case 1133704324:  if (!str1.equals("permissions")) {
/*    */         break label449;
/* 38 */         BanManager.getInstance().loadBans();
/*    */         
/*    */         break label449;
/*    */         
/* 42 */         CatalogManager.getInstance().loadItemsAndPages();
/* 43 */         CatalogManager.getInstance().loadGiftBoxes();
/*    */         
/* 45 */         NetworkManager.getInstance().getSessions().broadcast(new com.habboproject.server.network.messages.outgoing.catalog.CatalogPublishMessageComposer(true));
/*    */         
/*    */         break label449;
/*    */         
/* 49 */         NavigatorManager.getInstance().loadPublicRooms();
/*    */       }
/*    */       else
/*    */       {
/* 53 */         PermissionsManager.getInstance().loadRankPermissions();
/* 54 */         PermissionsManager.getInstance().loadPerks();
/* 55 */         PermissionsManager.getInstance().loadCommands();
/*    */         
/*    */         break label449;
/*    */         
/* 59 */         CometSettings.initialize();
/*    */         
/*    */         break label449;
/*    */         
/* 63 */         LandingManager.getInstance().loadArticles();
/*    */         
/*    */         break label449;
/*    */         
/* 67 */         ItemManager.getInstance().loadItemDefinitions();
/*    */         
/*    */         break label449;
/*    */         
/* 71 */         RoomManager.getInstance().getFilter().loadFilter();
/*    */         
/*    */         break label449;
/*    */         
/* 75 */         com.habboproject.server.config.Locale.reload();
/* 76 */         CommandManager.getInstance().reloadAllCommands();
/*    */         
/*    */         break label449;
/*    */         
/* 80 */         ModerationManager.getInstance().loadPresets();
/*    */         
/* 82 */         for (BaseSession session : NetworkManager.getInstance().getSessions().getByPlayerPermission("mod_tool")) {
/* 83 */           session.send(new ModToolMessageComposer());
/*    */         }
/*    */       }
/*    */       break;
/*    */     }
/*    */     label449:
/* 89 */     result.put("success", Boolean.valueOf(true));
/* 90 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\routes\SystemRoutes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */