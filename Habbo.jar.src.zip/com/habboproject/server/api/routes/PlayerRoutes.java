/*     */ package com.habboproject.server.api.routes;
/*     */ 
/*     */ import com.habboproject.server.api.game.players.data.components.PlayerInventory;
/*     */ import com.habboproject.server.game.players.PlayerManager;
/*     */ import com.habboproject.server.game.players.data.PlayerData;
/*     */ import com.habboproject.server.game.players.types.Player;
/*     */ import com.habboproject.server.network.NetworkManager;
/*     */ import com.habboproject.server.network.sessions.Session;
/*     */ import com.habboproject.server.network.sessions.SessionManager;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import spark.Request;
/*     */ import spark.Response;
/*     */ 
/*     */ public class PlayerRoutes
/*     */ {
/*     */   public static Object reloadPlayerData(Request request, Response response)
/*     */   {
/*  20 */     Map<String, Object> result = new HashMap();
/*  21 */     response.type("application/json");
/*     */     
/*  23 */     if (!StringUtils.isNumeric(request.params("id"))) {
/*  24 */       result.put("error", "Invalid ID");
/*  25 */       return result;
/*     */     }
/*     */     
/*  28 */     int playerId = Integer.parseInt(request.params("id"));
/*     */     
/*  30 */     if (!PlayerManager.getInstance().isOnline(playerId)) {
/*  31 */       result.put("error", "Player is not online");
/*  32 */       return result;
/*     */     }
/*     */     
/*  35 */     Session session = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);
/*     */     
/*  37 */     if (session == null) {
/*  38 */       result.put("error", "Unable to find the player's session");
/*  39 */       return result;
/*     */     }
/*     */     
/*  42 */     PlayerData newPlayerData = com.habboproject.server.storage.queries.player.PlayerDao.getDataById(playerId);
/*  43 */     PlayerData currentPlayerData = session.getPlayer().getData();
/*     */     
/*  45 */     if (newPlayerData == null) {
/*  46 */       result.put("error", "Unable to find the player's new data!");
/*  47 */       return result;
/*     */     }
/*     */     
/*  50 */     boolean sendCurrencies = (newPlayerData.getCredits() != currentPlayerData.getCredits()) || 
/*  51 */       (newPlayerData.getActivityPoints() != currentPlayerData.getActivityPoints()) || 
/*  52 */       (newPlayerData.getVipPoints() != currentPlayerData.getVipPoints());
/*     */     
/*  54 */     currentPlayerData.setRank(newPlayerData.getRank());
/*  55 */     currentPlayerData.setMotto(newPlayerData.getMotto());
/*  56 */     currentPlayerData.setFigure(newPlayerData.getFigure());
/*  57 */     currentPlayerData.setGender(newPlayerData.getGender());
/*  58 */     currentPlayerData.setEmail(newPlayerData.getEmail());
/*     */     
/*  60 */     currentPlayerData.setCredits(newPlayerData.getCredits());
/*  61 */     currentPlayerData.setVipPoints(newPlayerData.getVipPoints());
/*  62 */     currentPlayerData.setActivityPoints(newPlayerData.getActivityPoints());
/*     */     
/*  64 */     currentPlayerData.setAchievementPoints(newPlayerData.getAchievementPoints());
/*  65 */     currentPlayerData.setFavouriteGroup(newPlayerData.getFavouriteGroup());
/*  66 */     currentPlayerData.setVip(newPlayerData.isVip());
/*     */     
/*  68 */     if (sendCurrencies) {
/*  69 */       session.getPlayer().sendBalance();
/*     */     }
/*     */     
/*  72 */     session.getPlayer().poof();
/*     */     
/*  74 */     result.put("success", Boolean.valueOf(true));
/*  75 */     return result;
/*     */   }
/*     */   
/*     */   public static Object disconnect(Request req, Response res) {
/*  79 */     Map<String, Object> result = new HashMap();
/*  80 */     res.type("application/json");
/*     */     
/*  82 */     if (!StringUtils.isNumeric(req.params("id"))) {
/*  83 */       result.put("error", "Invalid ID");
/*  84 */       return result;
/*     */     }
/*     */     
/*  87 */     int playerId = Integer.parseInt(req.params("id"));
/*     */     
/*  89 */     if (!PlayerManager.getInstance().isOnline(playerId)) {
/*  90 */       result.put("error", "Player is not online");
/*  91 */       return result;
/*     */     }
/*     */     
/*  94 */     Session session = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);
/*     */     
/*  96 */     if (session == null) {
/*  97 */       result.put("error", "Unable to find the player's session");
/*  98 */       return result;
/*     */     }
/*     */     
/* 101 */     session.disconnect();
/*     */     
/* 103 */     result.put("success", Boolean.valueOf(true));
/* 104 */     return result;
/*     */   }
/*     */   
/*     */   public static Object alert(Request req, Response res) {
/* 108 */     Map<String, Object> result = new HashMap();
/* 109 */     res.type("application/json");
/*     */     
/* 111 */     if (!StringUtils.isNumeric(req.params("id"))) {
/* 112 */       result.put("error", "Invalid ID");
/* 113 */       return result;
/*     */     }
/*     */     
/* 116 */     int playerId = Integer.parseInt(req.params("id"));
/*     */     
/* 118 */     if (!PlayerManager.getInstance().isOnline(playerId)) {
/* 119 */       result.put("error", "Player is not online");
/* 120 */       return result;
/*     */     }
/*     */     
/* 123 */     Session session = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);
/*     */     
/* 125 */     if (session == null) {
/* 126 */       result.put("error", "Unable to find the player's session");
/* 127 */       return result;
/*     */     }
/*     */     
/* 130 */     String title = req.queryParams("title");
/*     */     
/* 132 */     if (title == null) {
/* 133 */       title = "Notification";
/*     */     }
/* 135 */     String alert = req.queryParams("message");
/*     */     
/* 137 */     if (alert != null) {
/* 138 */       session.send(new com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer(title, alert));
/*     */     }
/*     */     
/* 141 */     result.put("success", Boolean.valueOf(true));
/* 142 */     return result;
/*     */   }
/*     */   
/*     */   public static Object giveBadge(Request req, Response res) {
/* 146 */     Map<String, Object> result = new HashMap();
/* 147 */     res.type("application/json");
/*     */     
/* 149 */     if (!StringUtils.isNumeric(req.params("id"))) {
/* 150 */       result.put("error", "Invalid ID");
/* 151 */       return result;
/*     */     }
/*     */     
/* 154 */     int playerId = Integer.parseInt(req.params("id"));
/* 155 */     String badgeId = req.params("badge");
/*     */     
/* 157 */     if (!PlayerManager.getInstance().isOnline(playerId)) {
/* 158 */       if (badgeId != null) {
/* 159 */         com.habboproject.server.storage.queries.player.inventory.InventoryDao.addBadge(badgeId, playerId);
/*     */       }
/*     */     } else {
/* 162 */       Session session = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);
/*     */       
/* 164 */       if ((badgeId != null) && (session != null) && 
/* 165 */         (!session.getPlayer().getInventory().hasBadge(badgeId))) {
/* 166 */         session.getPlayer().getInventory().addBadge(badgeId, true);
/*     */       }
/*     */     }
/*     */     
/* 170 */     result.put("success", Boolean.valueOf(true));
/* 171 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\routes\PlayerRoutes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */