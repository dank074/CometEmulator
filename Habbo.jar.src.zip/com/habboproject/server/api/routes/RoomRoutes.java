/*    */ package com.habboproject.server.api.routes;
/*    */ 
/*    */ import com.habboproject.server.api.rooms.RoomStats;
/*    */ import com.habboproject.server.game.rooms.RoomManager;
/*    */ import com.habboproject.server.game.rooms.types.Room;
/*    */ import com.habboproject.server.game.rooms.types.components.EntityComponent;
/*    */ import com.habboproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import spark.Request;
/*    */ import spark.Response;
/*    */ 
/*    */ public class RoomRoutes
/*    */ {
/*    */   public static Object getAllActiveRooms(Request request, Response response)
/*    */   {
/* 18 */     response.type("application/json");
/* 19 */     Map<String, Object> result = new HashMap();
/*    */     
/* 21 */     List<RoomStats> activeRooms = new java.util.ArrayList();
/*    */     
/* 23 */     for (Room room : RoomManager.getInstance().getRoomInstances().values()) {
/* 24 */       activeRooms.add(new RoomStats(room));
/*    */     }
/*    */     
/* 27 */     result.put("response", activeRooms);
/* 28 */     return result;
/*    */   }
/*    */   
/*    */   public static Object roomAction(Request request, Response response) {
/* 32 */     Map<String, Object> result = new HashMap();
/*    */     
/* 34 */     int roomId = Integer.parseInt(request.params("id"));
/* 35 */     String action = request.params("action");
/*    */     
/* 37 */     if (!RoomManager.getInstance().getRoomInstances().containsKey(Integer.valueOf(roomId))) {
/* 38 */       result.put("active", Boolean.valueOf(false));
/* 39 */       return result;
/*    */     }
/*    */     
/* 42 */     Room room = RoomManager.getInstance().get(roomId);
/*    */     
/* 44 */     result.put("id", Integer.valueOf(roomId));
/*    */     String str1;
/* 46 */     switch ((str1 = action).hashCode()) {case -1335458389:  if (str1.equals("delete")) break label343; break; case 3076010:  if (str1.equals("data")) break label326; break; case 92899676:  if (str1.equals("alert")) break label197; break; case 1671767583:  if (str1.equals("dispose"))
/*    */         break label267; }
/* 48 */     result.put("active", Boolean.valueOf(false));
/* 49 */     return result;
/*    */     
/*    */     label197:
/*    */     
/* 53 */     String message = request.headers("message");
/* 54 */     if ((message == null) || (message.isEmpty())) {
/* 55 */       result.put("success", Boolean.valueOf(false));
/*    */     } else {
/* 57 */       room.getEntities().broadcastMessage(new AdvancedAlertMessageComposer(message));
/* 58 */       result.put("success", Boolean.valueOf(true));
/*    */       
/* 60 */       return result;
/*    */       
/*    */       label267:
/*    */       
/* 64 */       String message = request.headers("message");
/*    */       
/* 66 */       if ((message != null) && (!message.isEmpty())) {
/* 67 */         room.getEntities().broadcastMessage(new AdvancedAlertMessageComposer(message));
/*    */       }
/*    */       
/* 70 */       room.setIdleNow();
/* 71 */       result.put("success", Boolean.valueOf(true));
/* 72 */       return result;
/*    */       
/*    */       label326:
/*    */       
/* 76 */       result.put("data", room.getData());
/* 77 */       return result;
/*    */       
/*    */       label343:
/*    */       
/* 81 */       result.put("message", "Feature not completed");
/*    */     }
/*    */     
/*    */ 
/* 85 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\routes\RoomRoutes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */