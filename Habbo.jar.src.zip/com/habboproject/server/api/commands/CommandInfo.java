/*    */ package com.habboproject.server.api.commands;
/*    */ 
/*    */ public class CommandInfo {
/*    */   private final String description;
/*    */   private final String permission;
/*    */   
/*    */   public CommandInfo(String description, String permission) {
/*  8 */     this.description = description;
/*  9 */     this.permission = permission;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 13 */     return this.description;
/*    */   }
/*    */   
/*    */   public String getPermission() {
/* 17 */     return this.permission;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\commands\CommandInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */