/*    */ package com.habboproject.server.api.commands;
/*    */ 
/*    */ import com.habboproject.server.api.networking.sessions.BaseSession;
/*    */ 
/*    */ public abstract class ModuleChatCommand {
/*    */   public abstract void execute(BaseSession paramBaseSession, String[] paramArrayOfString);
/*    */   
/*    */   public abstract String getDescription();
/*    */   
/*    */   public abstract String getPermission();
/*    */   
/*    */   public boolean isHidden() {
/* 13 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isAsync() {
/* 17 */     return false;
/*    */   }
/*    */   
/*    */   public final String merge(String[] params, int begin) {
/* 21 */     StringBuilder mergedParams = new StringBuilder();
/*    */     
/* 23 */     for (int i = 0; i < params.length; i++) {
/* 24 */       if (i >= begin) {
/* 25 */         mergedParams.append(params[i]).append(" ");
/*    */       }
/*    */     }
/*    */     
/* 29 */     return mergedParams.toString();
/*    */   }
/*    */   
/*    */   public final String merge(String[] params) {
/* 33 */     StringBuilder stringBuilder = new StringBuilder();
/*    */     String[] arrayOfString;
/* 35 */     int j = (arrayOfString = params).length; for (int i = 0; i < j; i++) { String s = arrayOfString[i];
/* 36 */       if (!params[(params.length - 1)].equals(s)) {
/* 37 */         stringBuilder.append(s).append(" ");
/*    */       } else {
/* 39 */         stringBuilder.append(s);
/*    */       }
/*    */     }
/* 42 */     return stringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\commands\ModuleChatCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */