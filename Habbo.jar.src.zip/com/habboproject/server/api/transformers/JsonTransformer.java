/*    */ package com.habboproject.server.api.transformers;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.habboproject.server.utilities.JsonFactory;
/*    */ import spark.ResponseTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonTransformer
/*    */   implements ResponseTransformer
/*    */ {
/*    */   public String render(Object o)
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 18 */       String gsonString = JsonFactory.getInstance().toJson(o);
/*    */       
/* 20 */       if (!gsonString.startsWith("{")) {
/* 21 */         return "{\"response\":" + gsonString + "}";
/*    */       }
/* 23 */       return gsonString;
/*    */     }
/*    */     catch (Exception e) {
/* 26 */       return JsonFactory.getInstance().toJson(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\transformers\JsonTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */