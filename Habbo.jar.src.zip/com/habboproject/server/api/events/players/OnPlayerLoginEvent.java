/*    */ package com.habboproject.server.api.events.players;
/*    */ 
/*    */ import com.habboproject.server.api.events.players.args.OnPlayerLoginEventArgs;
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ public class OnPlayerLoginEvent extends com.habboproject.server.api.events.Event<OnPlayerLoginEventArgs>
/*    */ {
/*    */   public OnPlayerLoginEvent(Consumer<OnPlayerLoginEventArgs> eventConsumer)
/*    */   {
/* 10 */     super(eventConsumer);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\events\players\OnPlayerLoginEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */