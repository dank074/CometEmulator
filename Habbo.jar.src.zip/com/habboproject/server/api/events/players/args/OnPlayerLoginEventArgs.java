/*    */ package com.habboproject.server.api.events.players.args;
/*    */ 
/*    */ import com.habboproject.server.api.game.players.BasePlayer;
/*    */ 
/*    */ public class OnPlayerLoginEventArgs extends com.habboproject.server.api.events.EventArgs
/*    */ {
/*    */   private BasePlayer player;
/*    */   
/*    */   public OnPlayerLoginEventArgs(BasePlayer player) {
/* 10 */     this.player = player;
/*    */   }
/*    */   
/*    */   public BasePlayer getPlayer() {
/* 14 */     return this.player;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\events\players\args\OnPlayerLoginEventArgs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */