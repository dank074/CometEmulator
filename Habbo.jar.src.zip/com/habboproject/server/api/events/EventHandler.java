package com.habboproject.server.api.events;

import com.habboproject.server.api.commands.CommandInfo;
import com.habboproject.server.api.networking.sessions.BaseSession;
import java.util.Map;
import java.util.function.BiConsumer;

public abstract interface EventHandler
{
  public abstract void initialize();
  
  public abstract <T extends EventArgs> boolean handleEvent(Class<? extends Event> paramClass, T paramT);
  
  public abstract void registerEvent(Event paramEvent);
  
  public abstract void registerChatCommand(String paramString, BiConsumer<BaseSession, String[]> paramBiConsumer);
  
  public abstract void registerCommandInfo(String paramString, CommandInfo paramCommandInfo);
  
  public abstract Map<String, CommandInfo> getCommands();
  
  public abstract boolean handleCommand(BaseSession paramBaseSession, String paramString, String[] paramArrayOfString);
}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\events\EventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */