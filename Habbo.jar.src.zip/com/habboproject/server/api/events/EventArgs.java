/*    */ package com.habboproject.server.api.events;
/*    */ 
/*    */ public abstract class EventArgs
/*    */ {
/*  5 */   private boolean cancelled = false;
/*    */   
/*    */   public void setCancelled(boolean cancelled) {
/*  8 */     this.cancelled = cancelled;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 12 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\events\EventArgs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */