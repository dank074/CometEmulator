package com.habboproject.server.api.events;

public abstract interface EventListenerContainer {}


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\events\EventListenerContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */