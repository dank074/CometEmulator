/*    */ package com.habboproject.server.api.events;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ public abstract class Event<T extends EventArgs>
/*    */ {
/*    */   private final Consumer<T> callback;
/*    */   
/*    */   public Event(Consumer<T> callback) {
/* 10 */     this.callback = callback;
/*    */   }
/*    */   
/*    */   public void consume(T args) {
/* 14 */     this.callback.accept(args);
/*    */   }
/*    */   
/*    */   public boolean isAsync() {
/* 18 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Aurora\Habbo.jar!\com\habboproject\server\api\events\Event.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */